/* JARVİS neon ikonlar: kısayol çubuğu + mikrofon. Mevcut mantığa dokunmaz, sadece görünümü değiştirir. */
(function(){
  var st=document.createElement("style");
  st.textContent=
  "#chips{scrollbar-width:none;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 14px,#000 calc(100% - 22px),transparent 100%);mask-image:linear-gradient(90deg,transparent 0,#000 14px,#000 calc(100% - 22px),transparent 100%);padding-left:16px;padding-right:22px}"+
  "#chips::-webkit-scrollbar{display:none}"+
  "#chips button{display:flex;align-items:center;gap:7px;padding:8px 13px 8px 10px;transition:transform .12s,box-shadow .2s,border-color .2s,background .2s;-webkit-tap-highlight-color:transparent}"+
  "#chips button svg{width:16px;height:16px;flex:none;fill:none;stroke:var(--c1);stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 3px var(--c1))}"+
  "#chips button:active{transform:scale(.93);border-color:var(--c1);background:rgba(43,181,255,.18);box-shadow:0 0 14px var(--c1),inset 0 0 8px rgba(43,181,255,.35)}"+
  "#chips button:active svg{stroke:#fff;filter:drop-shadow(0 0 6px var(--c1)) drop-shadow(0 0 2px #fff)}"+
  "#bMic{position:relative;display:flex;align-items:center;justify-content:center;padding:0;overflow:visible;transition:transform .12s}"+
  "#bMic svg{width:24px;height:24px;fill:none;stroke:#bfe9ff;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 4px var(--c1));position:relative;z-index:1}"+
  "#bMic:active{transform:scale(.92)}"+
  "#bMic.on svg{stroke:#ffd9b0;filter:drop-shadow(0 0 5px var(--c2))}"+
  "#bMic::before,#bMic::after{content:'';position:absolute;inset:0;border-radius:50%;border:1.5px solid var(--c2);opacity:0;pointer-events:none}"+
  "#bMic.on::before{animation:jvRing 1.5s ease-out infinite}"+
  "#bMic.on::after{animation:jvRing 1.5s ease-out .75s infinite}"+
  "#bMic.on .jvbars{opacity:1}"+
  ".jvbars{position:absolute;left:0;right:0;bottom:7px;display:flex;justify-content:center;gap:2px;height:6px;opacity:0;transition:opacity .2s;z-index:1}"+
  ".jvbars i{width:2px;background:var(--c2);border-radius:1px;height:3px;animation:jvBar .7s ease-in-out infinite}"+
  ".jvbars i:nth-child(2){animation-delay:.15s}.jvbars i:nth-child(3){animation-delay:.3s}.jvbars i:nth-child(4){animation-delay:.45s}"+
  "@keyframes jvRing{0%{transform:scale(1);opacity:.8}100%{transform:scale(1.7);opacity:0}}"+
  "@keyframes jvBar{0%,100%{height:2px}50%{height:6px}}";
  document.head.appendChild(st);

  var P={
    "HUD":'<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><circle cx="12" cy="12" r="3.2"/>',
    "RADAR":'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12l6-6"/><circle cx="16.5" cy="14.5" r=".6"/>',
    "MEDYA":'<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><circle cx="9" cy="10" r="1.7"/><path d="M4 17l5-4.5 3.5 3L16 12l4 4.5"/>',
    "KASA":'<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle cx="12" cy="15" r="1.2"/>',
    "ÇEVİRİ":'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',
    "DURUM":'<path d="M4 20V10M10 20V4M16 20v-8M21 20H3"/>',
    "ANALİZ":'<rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="M10 9.5v5l4.5-2.5z"/>',
    "YASA":'<path d="M12 4v16M6 20h12M12 7l-6 2 3 6a3 3 0 0 1-6 0l3-6M12 7l6 2-3 6a3 3 0 0 0 6 0"/>',
    "TV":'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M9 21h6M8 3l4 3 4-3"/>',
    "GPS":'<circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="1.5"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
    "HACKER":'<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="M7 10l3 2.5L7 15M12.5 15H17"/>',
    "GÖREV":'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 12.5l3 3 5-6"/>'
  };
  var MIC='<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/></svg><span class="jvbars"><i></i><i></i><i></i><i></i></span>';

  function label(b){ return (b.textContent||"").replace(/[^A-Za-zÇĞİÖŞÜçğıöşü]/g,"").toLocaleUpperCase("tr"); }
  function apply(){
    var c=document.getElementById("chips");
    if(c) Array.prototype.forEach.call(c.querySelectorAll("button"),function(b){
      if(b.getAttribute("data-neon")) return;
      var k=label(b), p=P[k]; if(!p) return;
      var txt=(b.textContent||"").replace(/^[^A-Za-zÇĞİÖŞÜçğıöşü]+/,"").trim();
      b.innerHTML='<svg viewBox="0 0 24 24">'+p+'</svg><span>'+txt+'</span>';
      b.setAttribute("data-neon","1");
    });
    var m=document.getElementById("bMic");
    if(m&&!m.getAttribute("data-neon")){ m.innerHTML=MIC; m.setAttribute("data-neon","1"); m.setAttribute("aria-label","Mikrofon"); }
  }
  apply();
  var c0=document.getElementById("chips");
  if(c0&&window.MutationObserver) new MutationObserver(apply).observe(c0,{childList:true});
})();
