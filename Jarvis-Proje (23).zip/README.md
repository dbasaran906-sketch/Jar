# JARVİS

Kişisel yapay zeka asistanı (Android). Beyin: Claude API.

## Kurulum (3 adım)
1. GitHub'da **herkese açık (public)** yeni bir depo aç.
2. Bu klasörün İÇİNDEKİ her şeyi (`app`, `.github`, `build.gradle.kts` ...) depoya yükle. Web'de "Add file > Upload files" ile sürükle-bırak yeterli. `.github` klasörünün de yüklendiğinden emin ol.
3. Üstteki **Actions** sekmesinde derleme kendiliğinden başlar (5-8 dk). Bitince **Releases** bölümünde `Jarvis.apk` çıkar. Telefona indirip kur.

İlk açılışta ⚙ Ayarlar'dan Claude API anahtarını gir.

## Güncelleme
Yeni sürümde dosyaları depoya yükle, Actions yeni APK'yı Release'e koyar. Uygulamada Ayarlar > Güncelleme > Kontrol et (ya da Jarvis'e "güncelleme var mı" de).

Not: Güncelleme kontrolü için depo herkese açık olmalı.

## v2 (Ağır güncelleme)
Gemini/Claude seçimi, kamera HUD (nesne, mimik/el, çeviri, yüz), radar, medya arama, şifre kasası, canlı çeviri, cihaz durumu, takvim/arama/SMS araçları.

## v3
Gemini model otomatik seçimi ve yeniden deneme, anahtar sihirbazı, video/ses analizi, ESP32 BLE inceleme/yazma, bildirim okuma, alışkanlık analizi.

## v4
Yoğunluk hatasında otomatik yedek model, doğal Gemini sesi, ekran kontrolü (erişilebilirlik), takvim silme/taşıma.

## v5
Bilgi sorularında önce internet araması, HUD'da sesle soru sorma, HUD kota tasarrufu (görüntü değişince analiz), kota dolunca otomatik başka modele geçiş ve anlaşılır Türkçe hata.

v5.1: Gemini araması çalışmazsa Vikipedi yedeği, arama hatası cevabın altında görünür.

## v6
Küçük ses balonu (dışına dokununca kapanır), İzin merkezi, ekrana bak (screen_look), geçmiş sohbet arama ve genişletilmiş hafıza, çevrimdışı komutlar (fener, ses, saat, pil, alarm, sayaç, uygulama aç, ara, müzik).

## v7
- Güncel bilgi: her soruda Google Haberler (RSS) + Vikipedi birlikte, ~2 dk önbellek; sonuç yoksa "yok" demez.
- "WhatsApp'ı aç" gibi eylemlerde araç çağrısı zorunlu; "açtım" deyip açmazsa otomatik yeniden dener.
- Daha akıllı model: analiz/ön görü sorularında daha fazla düşünme.
- GPS radarı (konum, hız, adres, hava, yakındaki eczane/benzin…, navigasyon), Ağ radarı/cihaz tarayıcı/konum terminali (Hacker modu).
- Televizyon (Arçelik Google TV): bul, bir kez eşleştir, aç/kapat, Netflix/YouTube, "ses 28 yap".
- Yasalar: adlandırılmış komut dizileri (saman yasası), Ayarlar'dan yönetilir, "X yasasını aktif et".
- Otonom mod (arka plan nöbeti: pil/ısı/depolama uyarısı), alışkanlık önerileri, ajan modu (sürekli dinleme), görev & tercih hafızası, ön görü aracı, mod açılınca özellik anlatımı.
- Parlaklık ayarı için "sistem ayarlarını değiştir" izni gerekir (İzin merkezinde düğmesi var).

## v7.1
Yasa adımları daha esnek anlaşılır (sıfır, yarım, yüzde, full), anlaşılmayan adım yapay zekaya bırakılır, law_save yanlış parametre adlarını kabul eder, Wi-Fi/Bluetooth/uçak modu erişilebilirlikle hızlı ayarlardan yapılır (izin kapalıysa sorar), ekran kilidi için güvenlik ayarları açılır.

## v7.2
Yasa/komut anlama: sessize al, ekranı kilitle (yan tuş), 'yasayı aç', çoklu görev (tek cümlede 5 komut sırayla), kilit ve Wi-Fi adımları en sona, Wi-Fi durumu doğrulama, araç adı yazı olarak yazılırsa otomatik çalıştırma, dürüst ✅/⚠ rapor.

## v7.3
Genel güncel arama: her bilgi sorusunda (telefon kelimesi geçse bile) önce arama; kısa/yarım takip sorularında sohbet bağlamıyla yapay zeka arama sorgusu planlar, 2-4 kısa anahtar kelime sorgusu, tarih eşleştirme (★), 'kaç' kelimesinin 'aç' sanılması düzeltildi.

## v7.4
TV eşleşme SSL hatası: anahtar yeni adla (jarvis_tv2) RSA-PSS+PKCS1 imzalı üretilir, eski anahtar silinir, TLS 1.2 önce denenir, olmazsa varsayılan.

## v7.5
TV eşleşme: AndroidKeyStore yerine yazılım RSA anahtarı + elle üretilen X.509 sertifika (uygulama klasöründe saklanır; aynı yöntem sunucuda TLS 1.2/1.3 el sıkışmasıyla test edildi). Hata mesajları aşama aşama ve tam yazılır.

## v8 (Otonom mod)
Nöbet servisi artık SESLİ konuşur (Türkçe TTS, ses kısma/duck ile): pil %20/%10, pil doldu, ısınma, depolama, internet koptu/geldi, zamanlı hatırlatmalar. Ayarlar: sesli uyarı aç/kapat, ekran kapalıyken konuş, sessiz saatler, sesli test. Bildirimde 'Evet, uygula' düğmesi. 'saat 18:30 da su iç diye hatırlat' komutu ve reminder_add aracı.
