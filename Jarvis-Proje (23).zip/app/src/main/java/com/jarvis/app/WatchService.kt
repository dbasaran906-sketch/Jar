package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/**
 * Arka plan nöbeti: pil, ısı, depolama, internet, zamanlı hatırlatmalar.
 * Ön plan servisi olarak çalışır; uyarıları hem bildirim hem SESLİ (Türkçe TTS) verir.
 */
class WatchService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastBat = 101
    private var storWarned = false
    private var chargeAnnounced = false
    private var netDown = 0
    private var netAnnounced = false
    private val firedToday = HashSet<String>()
    private var lastDay = -1
    private val lastSaid = HashMap<String, Long>()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingSpeech = ArrayList<String>()
    private var focusReq: AudioFocusRequest? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                check()
            } catch (e: Exception) {
            }
            h.postDelayed(this, 60_000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("jarvis_watch", "Jarvis izleme", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel("jarvis_alert", "Jarvis uyarıları", NotificationManager.IMPORTANCE_HIGH))
        }
        try {
            tts = TextToSpeech(applicationContext) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("tr", "TR"))
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    tts?.setAudioAttributes(attrs())
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) {
                            release()
                        }

                        @Deprecated("eski imza")
                        override fun onError(id: String?) {
                            release()
                        }
                    })
                    if (ttsReady) {
                        val l = ArrayList(pendingSpeech)
                        pendingSpeech.clear()
                        for (t in l) speakNow(t)
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun attrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANT)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private fun release() {
        try {
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focusReq?.let { a.abandonAudioFocusRequest(it) }
        } catch (e: Exception) {
        }
    }

    private fun speakNow(text: String) {
        try {
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val fr = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs()).build()
            focusReq = fr
            a.requestAudioFocus(fr)
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "w" + System.currentTimeMillis())
        } catch (e: Exception) {
        }
    }

    private fun inQuiet(c: JSONObject): Boolean {
        val qs = c.optInt("qs", 23)
        val qe = c.optInt("qe", 7)
        if (qs == qe) return false
        val hh = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (qs > qe) (hh >= qs || hh < qe) else (hh in qs until qe)
    }

    /** Sesli uyarı. force=true: ayarlara bakmadan konuşur (test). */
    private fun say(key: String, text: String, force: Boolean = false) {
        if (!force) {
            val c = cfg()
            if (!c.optBoolean("voice", true)) return
            if (inQuiet(c)) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!c.optBoolean("off", true) && !pm.isInteractive) return
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (a.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            val now = System.currentTimeMillis()
            if (now - (lastSaid[key] ?: 0L) < 10 * 60_000L) return
            lastSaid[key] = now
        }
        if (!ttsReady) {
            if (pendingSpeech.size < 5) pendingSpeech.add(text)
            return
        }
        speakNow(text)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "jarvis_watch") else Notification.Builder(this)
        n.setContentTitle("Jarvis nöbette")
            .setContentText("Pil, sistem ve hatırlatmalar izleniyor")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(7001, n.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else startForeground(7001, n.build())
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        h.removeCallbacks(tick)
        h.post(tick)
        intent?.getStringExtra("speak")?.let { say("test", it, true) }
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        release()
        super.onDestroy()
    }

    private fun cfg(): JSONObject = try {
        JSONObject(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("watch_cfg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun alert(id: Int, title: String, text: String, ask: String? = null, speak: Boolean = true) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (!ask.isNullOrEmpty()) i.putExtra("ask", ask)
        val pi = PendingIntent.getActivity(this, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jarvis_alert") else Notification.Builder(this)
        b.setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pi).setAutoCancel(true)
        if (!ask.isNullOrEmpty()) {
            b.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Evet, uygula", pi
                ).build()
            )
        }
        nm.notify(id, b.build())
        if (speak) say("n$id", text)
    }

    private fun online(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val nc = cm.getNetworkCapabilities(cm.activeNetwork)
            nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    private fun check() {
        val c = cfg()
        val low = c.optInt("low", 20)
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val temp = (st?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (pct in 0..100) {
            if (!charging && pct <= low && lastBat > low) {
                alert(7101, "Pil %$pct", "Efendim pil yüzde $pct. Şarja takmanızı öneririm.", "pil durumunu analiz et ve tasarruf öner")
            }
            if (!charging && pct <= 10 && lastBat > 10) {
                alert(7102, "Pil kritik %$pct", "Efendim pil kritik seviyede, yüzde $pct. Hemen şarj edin.")
            }
            if (temp >= 42.0 && !charging) {
                alert(7103, "Telefon ısındı", "Telefon ısındı efendim, sıcaklık %.0f derece. Ağır uygulamaları kapatmanızı öneririm.".format(temp))
            }
            if (charging && pct >= 100 && !chargeAnnounced) {
                chargeAnnounced = true
                alert(7105, "Pil doldu", "Efendim pil yüzde yüz doldu, şarjı çıkarabilirsiniz.")
            }
            if (!charging) chargeAnnounced = false
            lastBat = pct
        }
        val fs = StatFs(Environment.getDataDirectory().path)
        val freePct = (fs.availableBytes * 100 / fs.totalBytes).toInt()
        if (freePct < 8 && !storWarned) {
            storWarned = true
            alert(7104, "Depolama dolu", "Efendim depolama alanı dolmak üzere, yüzde $freePct boş kaldı.", "depolamayı analiz et")
        }
        if (freePct > 12) storWarned = false

        if (!online()) {
            netDown++
            if (netDown >= 2 && !netAnnounced) {
                netAnnounced = true
                alert(7106, "İnternet yok", "Efendim internet bağlantısı koptu. Çevrimdışı komutlar çalışmaya devam eder.")
            }
        } else {
            if (netAnnounced) say("netback", "İnternet bağlantısı geri geldi efendim.")
            netDown = 0
            netAnnounced = false
        }

        val now = Calendar.getInstance()
        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != lastDay) {
            lastDay = day
            firedToday.clear()
        }
        val today = "%04d-%02d-%02d".format(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val hh = now.get(Calendar.HOUR_OF_DAY)
        val mm = now.get(Calendar.MINUTE)
        val rules: JSONArray = c.optJSONArray("rules") ?: return
        for (i in 0 until rules.length()) {
            val r = rules.optJSONObject(i) ?: continue
            val d = r.optString("date", "")
            if (d.isNotEmpty() && d != today) continue
            val key = r.optString("id") + ":" + day
            val rm = r.optInt("h", -1) * 60 + r.optInt("m", 0)
            val nowM = hh * 60 + mm
            if (r.optInt("h", -1) >= 0 && nowM >= rm && nowM - rm <= 2 && key !in firedToday) {
                firedToday.add(key)
                alert(7200 + (i % 90), "Jarvis", r.optString("text"), r.optString("ask", ""))
            }
        }
    }
}
