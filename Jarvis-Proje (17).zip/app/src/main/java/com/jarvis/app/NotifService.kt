package com.jarvis.app

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gelen bildirimleri (WhatsApp, SMS vb.) cihazda kaydeder. İzin kullanıcı tarafından açılır. */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
            val e = n.extras
            val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return
            NotifStore.add(this, sbn.packageName, title, text, sbn.postTime)
        } catch (e: Exception) {
            // yok say
        }
    }
}

object NotifStore {
    private const val FILE = "notifs.json"

    @Synchronized
    fun add(ctx: Context, pkg: String, title: String, text: String, time: Long) {
        val f = File(ctx.filesDir, FILE)
        val arr = try {
            if (f.exists()) JSONArray(f.readText()) else JSONArray()
        } catch (e: Exception) {
            JSONArray()
        }
        val o = JSONObject()
        o.put("p", pkg)
        o.put("t", title.take(80))
        o.put("x", text.take(300))
        o.put("ts", time)
        arr.put(o)
        val keep = JSONArray()
        val start = maxOf(0, arr.length() - 300)
        for (i in start until arr.length()) keep.put(arr.get(i))
        f.writeText(keep.toString())
    }

    @Synchronized
    fun list(ctx: Context, limit: Int, app: String): JSONArray {
        val f = File(ctx.filesDir, FILE)
        val src = try {
            if (f.exists()) JSONArray(f.readText()) else JSONArray()
        } catch (e: Exception) {
            JSONArray()
        }
        val pm = ctx.packageManager
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))
        val q = app.lowercase(Locale("tr", "TR"))
        val out = JSONArray()
        var i = src.length() - 1
        while (i >= 0 && out.length() < limit) {
            val o = src.getJSONObject(i)
            val pkg = o.getString("p")
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            if (q.isEmpty() || label.lowercase(Locale("tr", "TR")).contains(q) || pkg.lowercase(Locale.ROOT).contains(q)) {
                val r = JSONObject()
                r.put("uygulama", label)
                r.put("baslik", o.getString("t"))
                r.put("metin", o.getString("x"))
                r.put("zaman", fmt.format(Date(o.getLong("ts"))))
                out.put(r)
            }
            i--
        }
        return out
    }
}
