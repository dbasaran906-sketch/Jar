package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import org.json.JSONObject
import java.util.Calendar

/** Arka plan izleme: pil, depolama, zamanlı öneriler (alışkanlık). Ön plan servisi olarak çalışır. */
class WatchService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastBat = 101
    private var storWarned = false
    private var lastMin = -1
    private val firedToday = HashSet<String>()
    private var lastDay = -1

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (e: Exception) {}
            h.postDelayed(this, 60_000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("jarvis_watch", "Jarvis izleme", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel("jarvis_alert", "Jarvis uyarıları", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "jarvis_watch") else Notification.Builder(this)
        n.setContentTitle("Jarvis nöbette")
            .setContentText("Pil, sistem ve hatırlatmalar izleniyor")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(7001, n.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else startForeground(7001, n.build())
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun cfg(): JSONObject = try {
        JSONObject(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("watch_cfg", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }

    private fun alert(id: Int, title: String, text: String, ask: String? = null) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (ask != null) i.putExtra("ask", ask)
        val pi = PendingIntent.getActivity(this, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jarvis_alert") else Notification.Builder(this)
        b.setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pi).setAutoCancel(true)
        nm.notify(id, b.build())
    }

    private fun check() {
        val c = cfg()
        val low = c.optInt("low", 20)
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val temp = (st?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (pct in 0..100) {
            if (!charging && pct <= low && lastBat > low) {
                alert(7101, "Pil %$pct", "Efendim pil %$pct. Şarja takmanızı öneririm; istersen pil tasarrufu için parlaklığı düşüreyim.", "pil durumunu analiz et ve tasarruf öner")
            }
            if (!charging && pct <= 10 && lastBat > 10) {
                alert(7102, "Pil kritik %$pct", "Efendim pil kritik seviyede. Hemen şarj edin.")
            }
            if (temp >= 42.0 && !charging) {
                alert(7103, "Telefon ısındı", "Pil sıcaklığı %.1f°C. Ağır uygulamaları kapatmanızı öneririm.".format(temp))
            }
            lastBat = pct
        }
        val fs = StatFs(Environment.getDataDirectory().path)
        val freePct = (fs.availableBytes * 100 / fs.totalBytes).toInt()
        if (freePct < 8 && !storWarned) {
            storWarned = true
            alert(7104, "Depolama dolu", "Boş alan %$freePct kaldı. Gereksiz dosyaları temizlemenizi öneririm.", "depolamayı analiz et")
        }
        if (freePct > 12) storWarned = false

        val now = Calendar.getInstance()
        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != lastDay) { lastDay = day; firedToday.clear() }
        val hh = now.get(Calendar.HOUR_OF_DAY)
        val mm = now.get(Calendar.MINUTE)
        val rules = c.optJSONArray("rules") ?: return
        for (i in 0 until rules.length()) {
            val r = rules.optJSONObject(i) ?: continue
            val key = r.optString("id") + ":" + day
            if (r.optInt("h", -1) == hh && Math.abs(r.optInt("m", 0) - mm) <= 1 && key !in firedToday) {
                firedToday.add(key)
                alert(7200 + i, "Jarvis", r.optString("text"), r.optString("ask", ""))
            }
        }
    }
}
