package com.jarvis.app

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout

/** Bildirime basınca açılan küçük Siri benzeri ses balonu. Dışına dokununca ya da 5 sn sessizlikte kapanır. */
class VoiceActivity : JarvisActivity() {

    override val voiceMode: Boolean = true

    override fun layoutWeb() {
        val d = resources.displayMetrics
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        val w = (d.widthPixels * 0.9f).toInt()
        val h = (d.density * 250f).toInt()
        window.setLayout(w, h)
        window.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        val lp = window.attributes
        lp.y = (d.density * 56f).toInt()
        lp.dimAmount = 0f
        window.attributes = lp
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        )
        setFinishOnTouchOutside(true)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_OUTSIDE) {
            finish()
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        web.evaluateJavascript("window.beginVoice&&window.beginVoice()", null)
    }
}
