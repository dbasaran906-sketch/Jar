/* JARVİS v7: GPS, TV, Yasalar, Modlar, Ağ radarı, Görevler, Ajan, Alışkanlık, Ön görü */
(function(){
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, P=window.JarvisP||null, N=window.JarvisNative||null;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
function np(fn,a,b){ return JV.natP(fn,a,b); }
function ptool(n,a){ return JV.nat("tool",n,JSON.stringify(a||{})); }
function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
function errT(e){ return String((e&&e.message)||e||"hata"); }
var S=function(d){ return {type:"string",description:d}; };
var I=function(d){ return {type:"integer",description:d}; };
function mkPage(id,html,onClose){
  var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d);
  if(onClose) new MutationObserver(function(){ if(!d.classList.contains("show")) onClose(); }).observe(d,{attributes:true,attributeFilter:["class"]});
  return d;
}
function openPage(id){ $(id).classList.add("show"); }
function closePage(id){ $(id).classList.remove("show"); }

var st=document.createElement("style");
st.textContent=
".term{font-family:monospace;font-size:12px;line-height:1.5;background:#000;color:#39ff7a;border:1px solid rgba(57,255,122,.4);border-radius:10px;padding:10px;min-height:160px;max-height:46vh;overflow:auto;white-space:pre-wrap;word-break:break-all}"+
".pl{padding:9px 0;border-bottom:1px solid rgba(43,181,255,.15);font-size:14px}.pl small{display:block;color:var(--dim);font-size:12px}"+
".pbtn{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.pbtn .btn{flex:1;min-width:30%}"+
"#plc{width:100%;height:220px;display:block;background:#000;border-radius:12px;border:1px solid var(--line)}"+
".inp{width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);background:rgba(0,0,0,.4);color:var(--txt);font-size:14px;outline:none;box-sizing:border-box;margin:4px 0}";
document.head.appendChild(st);

/* ================= Depo ================= */
var laws=lsGet("jv_laws",[]);
if(!laws.length&&P){ try{ var bk=JSON.parse(P.kvGet("laws")||"[]"); if(bk.length){ laws=bk; lsSet("jv_laws",laws); } }catch(e){} }
function saveLaws(){ lsSet("jv_laws",laws); if(P){ try{ P.kvSet("laws",JSON.stringify(laws)); }catch(e){} } }
var tasks=lsGet("jv_tasks",[]); function saveTasks(){ lsSet("jv_tasks",tasks); }
var prefs=lsGet("jv_prefs",{}); function savePrefs(){ lsSet("jv_prefs",prefs); }
var modes=lsGet("jv_modes",{}); function saveModes(){ lsSet("jv_modes",modes); }
var lastLoc=null;

window.EXTRA_SYS=function(){
  var s="";
  var pk=Object.keys(prefs); if(pk.length) s+="Kullanıcı tercihleri: "+pk.map(function(k){ return k+"="+prefs[k]; }).join("; ")+". ";
  var op=tasks.filter(function(t){ return !t.done; }); if(op.length) s+="Açık görevleri: "+op.slice(0,15).map(function(t){ return t.title+(t.when?" ("+t.when+")":""); }).join("; ")+". ";
  if(laws.length) s+="Kayıtlı yasalar: "+laws.map(function(l){ return l.name; }).join(", ")+". ";
  var am=Object.keys(modes).filter(function(k){ return modes[k]; }); if(am.length) s+="Açık modlar: "+am.join(", ")+". ";
  if(lastLoc) s+="Son bilinen konum: "+(lastLoc.addr||(lastLoc.lat.toFixed(4)+","+lastLoc.lon.toFixed(4)))+". ";
  return s;
};

/* ================= Konum / çevre ================= */
async function getLoc(){
  var j=JSON.parse(await np("loc"));
  lastLoc=Object.assign(lastLoc||{},j,{t:Date.now()}); return j;
}
async function httpJ(url){ return JSON.parse(await np("httpGet",url)); }
async function revGeo(lat,lon){
  try{
    var j=await httpJ("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=17&accept-language=tr&lat="+lat+"&lon="+lon);
    return j.display_name||"";
  }catch(e){ return ""; }
}
var WC={0:"açık",1:"çoğunlukla açık",2:"parçalı bulutlu",3:"kapalı",45:"sisli",48:"sisli",51:"çise",53:"çise",55:"çise",61:"hafif yağmurlu",63:"yağmurlu",65:"kuvvetli yağmurlu",71:"karlı",73:"karlı",75:"yoğun karlı",80:"sağanak",81:"sağanak",82:"şiddetli sağanak",95:"gök gürültülü fırtına",96:"dolulu fırtına",99:"dolulu fırtına"};
async function envAt(lat,lon){
  try{
    var j=await httpJ("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&timezone=auto");
    var c=j.current||{};
    return "Hava: "+(WC[c.weather_code]||"?")+", "+c.temperature_2m+"°C (hissedilen "+c.apparent_temperature+"°C), nem %"+c.relative_humidity_2m+", rüzgar "+c.wind_speed_10m+" km/s, yağış "+c.precipitation+" mm";
  }catch(e){ return ""; }
}
function distM(a,b,c,d){ var R=6371000,p=Math.PI/180,x=(c-a)*p,y=(d-b)*p*Math.cos(a*p); return Math.sqrt(x*x+y*y)*R; }
var POI={eczane:'["amenity"="pharmacy"]',nöbetçi:'["amenity"="pharmacy"]',benzin:'["amenity"="fuel"]',akaryakıt:'["amenity"="fuel"]',market:'["shop"="supermarket"]',restoran:'["amenity"="restaurant"]',kafe:'["amenity"="cafe"]',hastane:'["amenity"="hospital"]',atm:'["amenity"="atm"]',banka:'["amenity"="bank"]',otopark:'["amenity"="parking"]',şarj:'["amenity"="charging_station"]',fırın:'["shop"="bakery"]',cami:'["amenity"="place_of_worship"]',okul:'["amenity"="school"]'};
async function poiSearch(kind,lat,lon){
  var k=tl(kind), f=null; Object.keys(POI).forEach(function(n){ if(!f&&k.indexOf(n)>=0) f=POI[n]; });
  if(!f) return {err:"Tanımadığım yer türü. Şunlardan birini dene: "+Object.keys(POI).join(", ")};
  var q='[out:json][timeout:12];(node'+f+'(around:2000,'+lat+','+lon+');way'+f+'(around:2000,'+lat+','+lon+'););out center 25;';
  var j=await httpJ("https://overpass-api.de/api/interpreter?data="+encodeURIComponent(q));
  var arr=(j.elements||[]).map(function(e){ var la=e.lat||(e.center&&e.center.lat), lo=e.lon||(e.center&&e.center.lon); return {name:(e.tags&&(e.tags.name||e.tags.brand))||"(isimsiz)",lat:la,lon:lo,d:Math.round(distM(lat,lon,la,lo))}; }).filter(function(x){ return x.lat; });
  arr.sort(function(a,b){ return a.d-b.d; });
  return {list:arr.slice(0,8)};
}
var EXTRA=[
 {name:"location_info",description:"Kullanıcının canlı konumunu, adresini, hızını, yönünü ve bulunduğu yerin hava/çevre bilgisini verir (GPS).",input_schema:{type:"object",properties:{}}},
 {name:"nearby_places",description:"Yakındaki yerleri bulur: eczane, benzin, market, restoran, kafe, hastane, atm, banka, otopark, şarj, fırın.",input_schema:{type:"object",properties:{kind:S("Yer türü")},required:["kind"]}},
 {name:"tv_control",description:"Kayıtlı Google TV'yi kontrol eder. action: power_on, power_off, volume (value: 0-100), vol_up, vol_down, mute, home, back, netflix, youtube, play, up, down, left, right, ok.",input_schema:{type:"object",properties:{action:S("Eylem"),value:S("İsteğe bağlı değer")},required:["action"]}},
 {name:"set_brightness",description:"Ekran parlaklığını yüzde olarak ayarlar (1-100).",input_schema:{type:"object",properties:{percent:I("Yüzde")},required:["percent"]}},
 {name:"law_save",description:"Kullanıcı için adlandırılmış bir 'yasa' (rutin) kaydeder. steps: adımlar virgülle ayrılmış, her biri kısa komut, örn: 'parlaklık 10, ses 100, whatsapp aç'.",input_schema:{type:"object",properties:{name:S("Yasa adı, örn. saman"),steps:S("Virgülle ayrılmış komutlar")},required:["name","steps"]}},
 {name:"law_run",description:"Kayıtlı bir yasayı çalıştırır (aktif eder).",input_schema:{type:"object",properties:{name:S("Yasa adı")},required:["name"]}},
 {name:"law_list",description:"Kayıtlı yasaları listeler.",input_schema:{type:"object",properties:{}}},
 {name:"predict",description:"Ön görü motoru: bir olayın/kararın ihtimalini ve başarı olasılığını güncel verilerle analiz eder.",input_schema:{type:"object",properties:{question:S("Analiz edilecek soru/durum")},required:["question"]}},
 {name:"network_scan",description:"Kullanıcının kendi Wi-Fi ağındaki cihazları (IP, açık portlar) tarar.",input_schema:{type:"object",properties:{}}},
 {name:"set_mode",description:"Bir modu açar/kapatır: ajan, hacker, otonom, gps, tv, sistem, yasalar.",input_schema:{type:"object",properties:{mode:S("Mod adı"),on:S("true ya da false")},required:["mode"]}},
 {name:"task_add",description:"Görev/yapılacak ekler.",input_schema:{type:"object",properties:{title:S("Görev"),when:S("İsteğe bağlı zaman")},required:["title"]}},
 {name:"task_list",description:"Açık görevleri listeler.",input_schema:{type:"object",properties:{}}},
 {name:"task_done",description:"Bir görevi tamamlandı yapar (başlığına göre).",input_schema:{type:"object",properties:{title:S("Görev başlığı")},required:["title"]}},
 {name:"pref_set",description:"Kullanıcının kalıcı bir tercihini kaydeder (anahtar/değer).",input_schema:{type:"object",properties:{key:S("Tercih adı"),value:S("Değer")},required:["key","value"]}}
];
window.EXTRA_TOOLS=window.EXTRA_TOOLS.concat(EXTRA);
var T=window.JSTOOLS;
T.location_info=async function(){
  var j; try{ j=await getLoc(); }catch(e){ return "Konum alınamadı: "+errT(e); }
  var addr=await revGeo(j.lat,j.lon), env=await envAt(j.lat,j.lon);
  lastLoc.addr=addr;
  return "Konum: "+j.lat.toFixed(5)+", "+j.lon.toFixed(5)+" (doğruluk ±"+Math.round(j.acc)+" m)\nAdres: "+(addr||"bulunamadı")+"\nHız: "+Math.round(j.speed)+" km/s"+(j.bearing>=0?", yön "+Math.round(j.bearing)+"°":"")+", rakım "+Math.round(j.alt)+" m\n"+env+"\nTrafik için navigasyon başlatılırsa Google Haritalar canlı trafiği gösterir.";
};
T.nearby_places=async function(i){
  var j; try{ j=await getLoc(); }catch(e){ return "Konum alınamadı: "+errT(e); }
  try{
    var r=await poiSearch(String(i.kind||""),j.lat,j.lon);
    if(r.err) return r.err;
    if(!r.list.length) return "2 km içinde '"+i.kind+"' bulunamadı (harita verisi eksik olabilir).";
    return "2 km çevrede (OpenStreetMap verisi, çalışma saatleri yok):\n"+r.list.map(function(x){ return "- "+x.name+" — "+x.d+" m"; }).join("\n");
  }catch(e){ return "Yer araması başarısız: "+errT(e); }
};
T.set_brightness=async function(i){ try{ return await np("setBrightness",isNaN(parseInt(i.percent,10))?50:parseInt(i.percent,10)); }catch(e){ return errT(e); } };
var TVAPP={netflix:"https://www.netflix.com/title",youtube:"https://www.youtube.com"};
T.tv_control=async function(i){
  var a=String(i.action||"").toLowerCase(), v=String(i.value||"");
  try{
    if(TVAPP[a]) return await np("tv","launch",TVAPP[a]);
    if(a==="volume") return await np("tv","volume",v||"20");
    return await np("tv",a,v);
  }catch(e){ return errT(e); }
};
T.predict=async function(i){
  var q=String(i.question||""), ctx="";
  try{ ctx=await T.web_search({query:q}); }catch(e){}
  return await JV.aiText("Sen bir ön görü analiz motorusun. Konu: "+q+"\n\nGüncel veriler:\n"+String(ctx).slice(0,4000)+"\n\nŞunları kısa ve net yaz: 1) Mevcut durum, 2) Olumlu/olumsuz etkenler, 3) Tahmini ihtimal yüzdesi (bir aralık ver) ve gerekçesi, 4) Belirsizlikler. Gerçek verilerde olmayan bir şeyi uydurma; bu bir tahmindir, kesinlik değildir.",false);
};
T.network_scan=async function(){
  try{ var j=JSON.parse(await np("lanScan")); return fmtNet(j); }catch(e){ return errT(e); }
};
T.task_add=function(i){ var t=String(i.title||"").trim(); if(!t) return "Boş görev."; tasks.push({title:t,when:String(i.when||""),done:false,ts:Date.now()}); saveTasks(); return "Görev eklendi: "+t; };
T.task_list=function(){ var o=tasks.filter(function(t){ return !t.done; }); return o.length?o.map(function(t,k){ return (k+1)+". "+t.title+(t.when?" ("+t.when+")":""); }).join("\n"):"Açık görev yok."; };
T.task_done=function(i){ var k=tl(i.title||""), f=tasks.filter(function(t){ return !t.done&&tl(t.title).indexOf(k)>=0; })[0]; if(!f) return "Böyle bir açık görev bulamadım."; f.done=true; saveTasks(); return "Tamamlandı: "+f.title; };
T.pref_set=function(i){ prefs[String(i.key||"").slice(0,40)]=String(i.value||"").slice(0,120); savePrefs(); return "Tercih kaydedildi."; };

/* ================= Yasalar ================= */
function lawName(n){ return tl(n).replace(/\s*yasas[ıi]n?[ıi]?$|\s*yasa$/,"").trim(); }
function findLaw(q){ var k=lawName(q); return laws.filter(function(l){ return l.name===k; })[0]||laws.filter(function(l){ return k.indexOf(l.name)>=0||l.name.indexOf(k)>=0; })[0]; }
var deferred=[];
async function runStep(line){
  var r=null;
  try{ r=await window.OFFLINE(line); }catch(e){ return "• "+line+": "+errT(e); }
  if(r===null||r===undefined){ deferred.push(line); return "• "+line+": yapay zekaya bıraktım"; }
  return "• "+line+": "+r;
}
async function runLaw(l){
  var out=[]; deferred=[];
  for(var i=0;i<l.steps.length;i++){ out.push(await runStep(l.steps[i])); await sleep(400); }
  var d=deferred.slice(); deferred=[];
  d.forEach(function(x){ setTimeout(function(){ JV.send(x); },300); });
  return "'"+l.name+"' yasası aktif edildi.\n"+out.join("\n");
}
/* Erişilebilirlik ile hızlı ayar düğmeleri (Wi-Fi, Bluetooth, uçak modu) */
async function accessOn(){ try{ return !!JSON.parse(await JV.natX("permInfo","")).access; }catch(e){ return false; } }
async function qToggle(names,want,label){
  if(!(await accessOn())){
    if(confirm("Erişilebilirlik izni kapalı, "+label+" ayarını ben yapamam. İzin ayarını açayım mı?")){ try{ await JV.natX("openSpecial","access"); }catch(e){} }
    return "Erişilebilirlik izni kapalı. İzin merkezinden açınca "+label+" ayarını yapabilirim.";
  }
  await ptool("screen_action",{action:"quick_settings"}); await sleep(1100);
  var scr=""; try{ scr=String(await ptool("screen_read")); }catch(e){}
  var low=tl(scr), cur=null;
  names.forEach(function(n){ var k=low.indexOf(tl(n)); if(k>=0&&cur===null){ var seg=low.slice(k,k+60); if(/(kapalı|\boff\b)/.test(seg)) cur=false; else if(/(açık|\bon\b)/.test(seg)) cur=true; } });
  if(cur!==null&&cur===want){ await ptool("screen_action",{action:"back"}); return label+" zaten "+(want?"açık":"kapalı")+"."; }
  var done=false;
  for(var i=0;i<names.length&&!done;i++){ var r=String(await ptool("screen_click",{text:names[i]})); if(/^Tıklandı/.test(r)) done=true; }
  await sleep(500); await ptool("screen_action",{action:"back"});
  return done?label+(want?" açıldı":" kapatıldı")+(cur===null?" (önceki durumu okuyamadım, düğmeye dokundum)":"")+".":label+" düğmesini hızlı ayarlarda bulamadım. Ayar ekranını açabilirim.";
}
function normNum(t){
  return String(t).replace(/\bsıfır\b/gi,"0").replace(/\byarım\b/gi,"50").replace(/\by[üu]zde\s*(\d+)/gi,"$1").replace(/\b(parlaklı[ğg][ıi]?|ses[i]?)\s+(full|son|maksimum|max|tam)\b/gi,function(m,a){ return a+" 100"; }).replace(/parlaklı[ğg][ıi]/gi,"parlaklık");
}
function splitSteps(s){ return String(s).split(/[,;\n]|\s+ve\s+|\s+ardından\s+/i).map(function(x){ return x.trim(); }).filter(Boolean); }
T.law_save=function(i){
  var raw=i.steps||i.content||i.commands||i.actions||i.adimlar||"";
  if(Array.isArray(raw)) raw=raw.join(", ");
  var n=lawName(i.name||i.title||i.ad||""), st=splitSteps(String(raw).replace(/[•·]/g,",")); if(!n||!st.length) return "Ad ve adımlar gerekli.";
  var ex=laws.filter(function(l){ return l.name===n; })[0]; if(ex) ex.steps=st; else laws.push({name:n,steps:st});
  saveLaws(); return "'"+n+"' yasası kaydedildi ("+st.length+" adım). Ayarlar > Yasalar'dan görebilirsin.";
};
T.law_run=async function(i){ var l=findLaw(i.name||""); return l?await runLaw(l):"Böyle bir yasa yok. Kayıtlılar: "+laws.map(function(x){ return x.name; }).join(", "); };
T.law_list=function(){ return laws.length?laws.map(function(l){ return "• "+l.name+": "+l.steps.join(", "); }).join("\n"):"Kayıtlı yasa yok."; };

/* ================= Modlar ================= */
var MODEINFO={
 agent:{n:"Ajan modu",say:"Ajan modu açık efendim. Mikrofonu sürekli dinliyorum ve söylediğin her şeyi yerine getiriyorum. Kapatmak için ajan modunu kapat de. Uygulama açık ve ekran açıkken çalışır."},
 hacker:{n:"Hacker modu",say:"Hacker modu açık. Ağ radarı: kendi Wi-Fi ağındaki cihazları listeler. Cihaz tarayıcı: seçtiğin cihazın IP ve açık portlarını gösterir. Konum terminali: canlı konumunu terminalde akıtır. Sadece kendi ağında kullan."},
 auto:{n:"Otonom mod",say:"Otonom mod açık. Arka planda pili, ısıyı ve depolamayı izlerim; pil düşünce ya da sorun çıkınca bildirimle uyarır, çözüm öneririm. Alışkanlıklarına göre de hatırlatırım."},
 gps:{n:"GPS radarı",say:"GPS radarı açık. Canlı konumunu, hızını, adresini, hava durumunu gösterir, yakındaki eczane, benzin gibi yerleri bulur ve navigasyon başlatırım."},
 tv:{n:"TV kontrolü",say:"TV kontrolü hazır. Televizyonu aç kapat, Netflix ya da YouTube aç, sesi yüzde olarak ayarla diyebilirsin. İlk seferde eşleştirme gerekir."},
 system:{n:"Sistem yöneticisi",say:"Sistem yöneticisi açık. Pil, depolama ve sistem durumunu sürekli izler, sorun olursa haber veririm."},
 laws:{n:"Yasalar",say:"Yasalar bölümü açık. Kendi rutinlerini adlandırıp kaydedebilirsin, örneğin saman yasası. Sonra yasanın adını söyleyip aktif et demen yeterli."}
};
function modeKey(s){
  s=tl(s);
  if(/ajan/.test(s)) return "agent"; if(/hacker|haker/.test(s)) return "hacker"; if(/otonom/.test(s)) return "auto";
  if(/gps|radar|konum/.test(s)) return "gps"; if(/\btv\b|televizyon/.test(s)) return "tv"; if(/sistem/.test(s)) return "system"; if(/yasa/.test(s)) return "laws";
  return null;
}
function watchCfg(){
  var rules=(lsGet("jv_rules",[]));
  return JSON.stringify({low:20,rules:rules});
}
function syncWatch(){
  var on=!!(modes.auto||modes.system);
  if(P){ try{ P.watch(on,on?watchCfg():""); }catch(e){} }
}
async function setMode(k,on){
  modes[k]=on; saveModes();
  var info=MODEINFO[k];
  if(k==="agent"){ on?agentStart():agentStop(); }
  if(k==="auto"||k==="system") syncWatch();
  if(on){
    if(k==="hacker") openHack(); if(k==="gps") openGps(); if(k==="tv") openTv(); if(k==="laws") openLaws();
    if(k==="system"){ try{ var s=await ptool("get_device_status"); return info.say+"\nŞu an: "+s; }catch(e){} }
    return info.say;
  }
  return info.n+" kapatıldı.";
}
T.set_mode=async function(i){ var k=modeKey(i.mode||""); if(!k) return "Böyle bir mod yok."; return await setMode(k,String(i.on).toLowerCase()!=="false"); };

/* ----- Ajan modu ----- */
var agent={on:false,timer:0,said:""};
function agentStart(){
  agent.on=true; clearInterval(agent.timer);
  agent.timer=setInterval(function(){
    if(!agent.on) return;
    if(!JV.isBusy()&&!JV.isSpeaking()&&!JV.isListening()) JV.startListen();
  },900);
  setTimeout(function(){ if(agent.on&&!JV.isSpeaking()) JV.startListen(); },300);
}
function agentStop(){ agent.on=false; clearInterval(agent.timer); JV.stopListen(); modes.agent=false; saveModes(); }
var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd;
window.JV_onSpeech=function(t,final){
  if(agent.on){
    if(!final){ $("txt").value=t; return true; }
    $("txt").value="";
    if(/ajan mod(unu|u)?\s*(kapat|bitir|durdur|iptal)/i.test(tl(t))){ agentStop(); JV.say("Ajan modu kapatıldı efendim."); return true; }
    if(String(t).trim().length>=4) JV.send(t);
    return true;
  }
  return prevS?prevS(t,final):false;
};
window.JV_onListenEnd=function(err){
  if(agent.on){
    if(err===9||err===100){ agentStop(); toast("Ajan modu: mikrofon/ses tanıma kullanılamıyor"); }
    return true;
  }
  return prevE?prevE(err):false;
};

/* ================= TV sayfası ================= */
mkPage("pTv",
 '<div class="ph"><button class="ib" data-close>←</button><h2>TELEVİZYON</h2></div>'+
 '<div class="pb"><div id="tvSt" class="sec"></div>'+
 '<div class="sec"><h3>Eşleştirme (bir kez)</h3><div style="font-size:12px;color:var(--dim)">Telefon ve TV aynı Wi-Fi\'da olsun, TV açık olsun.</div>'+
 '<div class="pbtn"><button class="btn" id="tvFind">TV\'Yİ BUL</button></div><div id="tvList"></div>'+
 '<input class="inp" id="tvIp" placeholder="TV IP adresi (örn. 192.168.1.20)"><button class="btn" id="tvPair" style="width:100%">EŞLEŞMEYİ BAŞLAT</button>'+
 '<input class="inp" id="tvCode" placeholder="TV\'de çıkan 6 karakterli kod" maxlength="6"><button class="btn" id="tvOk" style="width:100%">KODU ONAYLA</button></div>'+
 '<div class="sec"><h3>Dene</h3><div class="pbtn"><button class="btn" data-tv="power_on">AÇ</button><button class="btn" data-tv="power_off">KAPAT</button><button class="btn" data-tv="vol_up">SES +</button><button class="btn" data-tv="vol_down">SES −</button><button class="btn" data-tv="mute">SESSİZ</button><button class="btn" data-tv="netflix">NETFLIX</button><button class="btn" data-tv="youtube">YOUTUBE</button><button class="btn" data-tv="home">ANA SAYFA</button></div>'+
 '<button class="btn red" id="tvForget" style="width:100%">EŞLEŞMEYİ UNUT</button></div><div id="tvMsg" style="font-size:13px;color:var(--c2);white-space:pre-wrap"></div></div>');
function tvStatus(){
  var s={}; try{ s=JSON.parse(P.tvStatus()); }catch(e){}
  $("tvSt").innerHTML='<h3>Durum</h3><div class="pl">'+(s.host?("Kayıtlı TV: <b>"+esc(s.host)+"</b>"+(s.paired?" · eşleşmiş ✅":" · eşleşme bekliyor")):"Kayıtlı televizyon yok")+'</div>';
  if(s.host&&!$("tvIp").value) $("tvIp").value=s.host;
}
function tvMsg(t){ $("tvMsg").textContent=t; }
function openTv(){ openPage("pTv"); if(P) tvStatus(); }
$("tvFind").onclick=async function(){
  tvMsg("Ağda aranıyor (10 sn kadar)…");
  try{
    var a=JSON.parse(await np("tvFind"));
    $("tvList").innerHTML=a.length?a.map(function(ip){ return '<div class="pl" data-ip="'+ip+'">📺 '+ip+' <small>dokun: seç</small></div>'; }).join(""):'<div class="pl">Ağda Android/Google TV bulunamadı. TV açık ve aynı Wi-Fi\'da mı?</div>';
    $("tvList").querySelectorAll("[data-ip]").forEach(function(d){ d.onclick=function(){ $("tvIp").value=d.getAttribute("data-ip"); }; });
    tvMsg(a.length?"Bulundu: "+a.join(", "):"Bulunamadı.");
  }catch(e){ tvMsg(errT(e)); }
};
$("tvPair").onclick=async function(){
  var ip=$("tvIp").value.trim(); if(!ip){ tvMsg("Önce IP gir ya da TV'yi bul."); return; }
  tvMsg("Eşleşme başlatılıyor… TV ekranında kod çıkmalı.");
  try{ await np("tvPairStart",ip); tvMsg("TV'de çıkan kodu aşağı yaz ve onayla."); }catch(e){ tvMsg(errT(e)); }
};
$("tvOk").onclick=async function(){
  try{ await np("tvPairFinish",$("tvCode").value); tvMsg("✅ Eşleşti! Artık 'televizyonu aç' diyebilirsin."); tvStatus(); }catch(e){ tvMsg(errT(e)); }
};
$("tvForget").onclick=function(){ try{ P.tvForget(); }catch(e){} tvStatus(); tvMsg("Unutuldu."); };
$("pTv").querySelectorAll("[data-tv]").forEach(function(b){ b.onclick=async function(){ tvMsg("…"); tvMsg(await T.tv_control({action:b.getAttribute("data-tv")})); }; });

/* ================= GPS sayfası ================= */
mkPage("pGps",
 '<div class="ph"><button class="ib" data-close>←</button><h2>GPS RADARI</h2></div>'+
 '<div class="pb"><canvas id="plc" width="600" height="440"></canvas><div class="sec" id="gInfo" style="margin-top:10px">Konum alınıyor…</div>'+
 '<div class="pbtn"><button class="btn" data-poi="eczane">💊 ECZANE</button><button class="btn" data-poi="benzin">⛽ BENZİN</button><button class="btn" data-poi="market">🛒 MARKET</button><button class="btn" data-poi="hastane">🏥 HASTANE</button><button class="btn" data-poi="atm">🏧 ATM</button><button class="btn" data-poi="şarj">🔌 ŞARJ</button></div>'+
 '<div class="sec"><h3>Navigasyon</h3><input class="inp" id="gDest" placeholder="Nereye gidelim?"><button class="btn" id="gNav" style="width:100%">YOL TARİFİ BAŞLAT</button></div><div id="gPoi"></div></div>',
 function(){ gps.on=false; });
var gps={on:false,pts:[],poi:[],last:null,addrAt:0,envAt:0,env:"",sweep:0,raf:0};
function openGps(){ openPage("pGps"); gps.on=true; gpsTick(); gpsDraw(); }
async function gpsTick(){
  if(!gps.on) return;
  try{
    var j=await getLoc(); gps.last=j;
    gps.pts.push([j.lat,j.lon]); if(gps.pts.length>40) gps.pts.shift();
    if(Date.now()-gps.addrAt>40000){ gps.addrAt=Date.now(); revGeo(j.lat,j.lon).then(function(a){ lastLoc.addr=a; gps.addr=a; }); }
    if(Date.now()-gps.envAt>300000){ gps.envAt=Date.now(); envAt(j.lat,j.lon).then(function(e){ gps.env=e; }); }
    $("gInfo").innerHTML='<div class="kv"><span>Koordinat</span><b>'+j.lat.toFixed(5)+', '+j.lon.toFixed(5)+'</b></div><div class="kv"><span>Hız / Yön</span><b>'+Math.round(j.speed)+' km/s'+(j.bearing>=0?' · '+Math.round(j.bearing)+'°':'')+'</b></div><div class="kv"><span>Doğruluk / Rakım</span><b>±'+Math.round(j.acc)+' m · '+Math.round(j.alt)+' m</b></div><div style="font-size:13px;margin-top:8px">'+esc(gps.addr||"Adres aranıyor…")+'</div><div style="font-size:12px;color:var(--dim);margin-top:6px">'+esc(gps.env||"")+'</div>';
  }catch(e){ $("gInfo").textContent=errT(e); }
  if(gps.on) setTimeout(gpsTick,5000);
}
function gpsDraw(){
  if(!gps.on) return;
  var c=$("plc"), g=c.getContext&&c.getContext("2d"); if(!g) return;
  var W=c.width,H=c.height,cx=W/2,cy=H/2,R=Math.min(W,H)/2-14, col=JV.colors()[0];
  g.clearRect(0,0,W,H); g.strokeStyle=col; g.globalAlpha=.35; g.lineWidth=1;
  for(var r=1;r<=3;r++){ g.beginPath(); g.arc(cx,cy,R*r/3,0,7); g.stroke(); }
  g.beginPath(); g.moveTo(cx-R,cy); g.lineTo(cx+R,cy); g.moveTo(cx,cy-R); g.lineTo(cx,cy+R); g.stroke();
  gps.sweep+=0.04; g.globalAlpha=.5; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+Math.cos(gps.sweep)*R,cy+Math.sin(gps.sweep)*R); g.stroke();
  g.globalAlpha=1; g.fillStyle=col; g.font="11px monospace"; g.fillText("500 m",cx+R/3+2,cy-2); g.fillText("1 km",cx+2*R/3+2,cy-2); g.fillText("2 km",cx+R-30,cy-2);
  var L=gps.last;
  if(L){
    g.fillStyle="#fff"; g.beginPath(); g.arc(cx,cy,5,0,7); g.fill();
    if(L.bearing>=0){ var a=(L.bearing-90)*Math.PI/180; g.strokeStyle="#fff"; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+Math.cos(a)*24,cy+Math.sin(a)*24); g.stroke(); }
    gps.poi.forEach(function(p){
      var dy=(p.lat-L.lat)*111320, dx=(p.lon-L.lon)*111320*Math.cos(L.lat*Math.PI/180), sc=R/2000;
      var x=cx+dx*sc, y=cy-dy*sc; g.fillStyle="#ff9b3d"; g.beginPath(); g.arc(x,y,4,0,7); g.fill(); g.fillText(String(p.name).slice(0,14),x+6,y+3);
    });
  }
  gps.raf=requestAnimationFrame(gpsDraw);
}
$("pGps").querySelectorAll("[data-poi]").forEach(function(b){ b.onclick=async function(){
  var box=$("gPoi"); box.innerHTML='<div class="pl">Aranıyor…</div>';
  try{
    var j=gps.last||await getLoc(); var r=await poiSearch(b.getAttribute("data-poi"),j.lat,j.lon);
    if(r.err){ box.innerHTML='<div class="pl">'+esc(r.err)+'</div>'; return; }
    gps.poi=r.list; box.innerHTML=r.list.length?r.list.map(function(x){ return '<div class="pl">'+esc(x.name)+'<small>'+x.d+' m</small></div>'; }).join(""):'<div class="pl">2 km içinde bulunamadı.</div>';
  }catch(e){ box.innerHTML='<div class="pl">'+esc(errT(e))+'</div>'; }
}; });
$("gNav").onclick=async function(){ var d=$("gDest").value.trim(); if(!d) return; toast(await ptool("phone_action",{action:"navigate",value:d})); };

/* ================= Hacker / Ağ sayfası ================= */
mkPage("pHack",
 '<div class="ph"><button class="ib" data-close>←</button><h2>HACKER MODU</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Sadece kendi ağında ve kendi cihazlarında kullan.</div>'+
 '<div class="pbtn"><button class="btn" id="hkNet">📡 AĞ RADARI</button><button class="btn" id="hkDev">🔎 CİHAZ TARA</button><button class="btn" id="hkLoc">🛰 KONUM TERMİNALİ</button></div>'+
 '<input class="inp" id="hkIp" placeholder="Cihaz IP (cihaz taramak için)"><div class="term" id="hkOut">> hazır_</div></div>',
 function(){ hk.loc=false; });
var hk={loc:false,last:null};
function openHack(){ openPage("pHack"); }
function guess(d){
  var p=d.ports||[], has=function(x){ return p.indexOf(x)>=0; };
  if(has(6466)||has(8009)||has(8008)) return "Android/Google TV ya da Chromecast";
  if(has(62078)) return "iPhone/iPad olabilir";
  if(has(5555)) return "Android (ADB açık)";
  if(has(554)) return "IP kamera olabilir";
  if(has(53)&&(has(80)||has(443))) return "Modem/yönlendirici olabilir";
  if(has(445)) return "Bilgisayar/NAS olabilir";
  if(has(22)) return "SSH'li cihaz (Linux/Pi)";
  if(has(1900)) return "UPnP cihazı (TV/yazıcı/router)";
  if(has(80)||has(443)||has(8080)) return "Web arayüzlü cihaz";
  return "Bilinmeyen cihaz";
}
function fmtNet(j){
  var d=j.devices||[]; hk.last=j;
  return "Ağ: "+(j.ssid||"?")+" · benim IP'm "+j.me+" · "+d.length+" cihaz\n"+d.map(function(x){ return "- "+x.ip+(x.name?" ("+x.name+")":"")+" → "+guess(x)+(x.ports.length?" [portlar: "+x.ports.join(",")+"]":""); }).join("\n");
}
function hkOut(t,append){ var o=$("hkOut"); o.textContent=append?o.textContent+t+"\n":t; o.scrollTop=o.scrollHeight; }
$("hkNet").onclick=async function(){
  hk.loc=false; hkOut("> ağ taranıyor… (10-30 sn)");
  try{ hkOut("> tamam\n"+fmtNet(JSON.parse(await np("lanScan")))); }catch(e){ hkOut("> hata: "+errT(e)); }
};
$("hkDev").onclick=async function(){
  hk.loc=false; var ip=$("hkIp").value.trim(); if(!ip){ hkOut("> önce IP gir (ağ radarından)"); return; }
  hkOut("> "+ip+" taranıyor…");
  try{
    var j=JSON.parse(await np("lanScan")), d=(j.devices||[]).filter(function(x){ return x.ip===ip; })[0];
    hkOut(d?("> IP: "+d.ip+"\n> Ad: "+(d.name||"-")+"\n> Açık portlar: "+(d.ports.join(", ")||"yok (cihaz ping'e açık)")+"\n> Tahmin: "+guess(d)):"> cihaz bulunamadı (kapalı ya da farklı ağ).");
  }catch(e){ hkOut("> hata: "+errT(e)); }
};
$("hkLoc").onclick=async function(){
  if(hk.loc){ hk.loc=false; hkOut("> terminal durduruldu",true); return; }
  hk.loc=true; hkOut("> canlı konum akışı başladı (tekrar bas: durdur)");
  while(hk.loc){
    try{ var j=await getLoc(); hkOut("["+new Date().toLocaleTimeString("tr-TR")+"] LAT "+j.lat.toFixed(5)+" LON "+j.lon.toFixed(5)+" ACC "+Math.round(j.acc)+"m SPD "+Math.round(j.speed)+"km/h ALT "+Math.round(j.alt)+"m",true); }catch(e){ hkOut("> "+errT(e),true); }
    await sleep(3000);
  }
};

/* ================= Yasalar + Görevler sayfası ================= */
mkPage("pLaw",
 '<div class="ph"><button class="ib" data-close>←</button><h2>YASALAR</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Bir yasa = adı olan komut dizisi. Örn. ad: saman · adımlar: parlaklık 10, ses 100, whatsapp aç. Sohbette "saman yasasını aktif et" de.</div>'+
 '<div class="sec"><input class="inp" id="lwName" placeholder="Yasa adı (örn. saman)"><textarea class="inp" id="lwSteps" rows="3" placeholder="Adımlar, virgülle ayır: parlaklık 10, ses 100, whatsapp aç"></textarea><button class="btn" id="lwAdd" style="width:100%">KAYDET</button></div><div id="lwList"></div></div>');
function openLaws(){ openPage("pLaw"); lawRender(); }
function lawRender(){
  $("lwList").innerHTML=laws.length?laws.map(function(l,i){ return '<div class="sec"><b>'+esc(l.name)+' yasası</b><div style="font-size:13px;color:var(--dim);margin:6px 0">'+esc(l.steps.join(" → "))+'</div><div class="pbtn"><button class="btn" data-run="'+i+'">AKTİF ET</button><button class="btn" data-edit="'+i+'">DÜZENLE</button><button class="btn red" data-del="'+i+'">SİL</button></div></div>'; }).join(""):'<div class="pl">Henüz yasa yok.</div>';
  $("lwList").querySelectorAll("[data-run]").forEach(function(b){ b.onclick=async function(){ toast("Çalışıyor…"); toast((await runLaw(laws[+b.getAttribute("data-run")])).split("\n")[0]); }; });
  $("lwList").querySelectorAll("[data-edit]").forEach(function(b){ b.onclick=function(){ var l=laws[+b.getAttribute("data-edit")]; $("lwName").value=l.name; $("lwSteps").value=l.steps.join(", "); }; });
  $("lwList").querySelectorAll("[data-del]").forEach(function(b){ b.onclick=function(){ if(confirm("Silinsin mi?")){ laws.splice(+b.getAttribute("data-del"),1); saveLaws(); lawRender(); } }; });
}
$("lwAdd").onclick=function(){ var r=T.law_save({name:$("lwName").value,steps:$("lwSteps").value}); toast(r); $("lwName").value=""; $("lwSteps").value=""; lawRender(); };

mkPage("pTask",
 '<div class="ph"><button class="ib" data-close>←</button><h2>GÖREV & HAFIZA</h2></div>'+
 '<div class="pb"><div class="sec"><h3>Görevler</h3><input class="inp" id="tkNew" placeholder="Yeni görev"><button class="btn" id="tkAdd" style="width:100%">EKLE</button><div id="tkList"></div></div>'+
 '<div class="sec"><h3>Tercihler</h3><div id="prList"></div><div style="font-size:12px;color:var(--dim)">"Tercihim: ..." ya da "şunu hatırla" diyerek de eklenir.</div></div></div>');
function taskRender(){
  $("tkList").innerHTML=tasks.map(function(t,i){ return '<div class="pl" style="display:flex;gap:8px;align-items:center"><div style="flex:1;'+(t.done?'text-decoration:line-through;opacity:.5':'')+'">'+esc(t.title)+(t.when?'<small>'+esc(t.when)+'</small>':'')+'</div><button class="btn" data-tk="'+i+'" style="padding:4px 10px">'+(t.done?'↺':'✓')+'</button><button class="btn red" data-td="'+i+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="pl">Görev yok.</div>';
  $("tkList").querySelectorAll("[data-tk]").forEach(function(b){ b.onclick=function(){ var t=tasks[+b.getAttribute("data-tk")]; t.done=!t.done; saveTasks(); taskRender(); }; });
  $("tkList").querySelectorAll("[data-td]").forEach(function(b){ b.onclick=function(){ tasks.splice(+b.getAttribute("data-td"),1); saveTasks(); taskRender(); }; });
  $("prList").innerHTML=Object.keys(prefs).map(function(k){ return '<div class="pl" style="display:flex"><div style="flex:1">'+esc(k)+': <b>'+esc(prefs[k])+'</b></div><button class="btn red" data-pd="'+esc(k)+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="pl">Tercih yok.</div>';
  $("prList").querySelectorAll("[data-pd]").forEach(function(b){ b.onclick=function(){ delete prefs[b.getAttribute("data-pd")]; savePrefs(); taskRender(); }; });
}
function openTasks(){ openPage("pTask"); taskRender(); }
$("tkAdd").onclick=function(){ var v=$("tkNew").value.trim(); if(v){ T.task_add({title:v}); $("tkNew").value=""; taskRender(); } };

/* ================= Çevrimdışı komut genişletmesi ================= */
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text0){
  var text=normNum(text0);
  var t=tl(text).replace(/[.!?,]+$/g,"").replace(/^(hey |hay |merhaba |lütfen )*(jarvis[, ]*)?/,"").trim(), m;
  habitLog(t);
  try{
    // yasa kaydet
    if((m=t.match(/^(.+?)\s+yasas[ıi]?\s*(?:n[ıi]\s*)?(?:kaydet|oluştur|ekle|tanımla)\s*[:\-]?\s*(.+)$/)))
      return T.law_save({name:m[1],steps:m[2]});
    // yasa aktif et
    if(/yasa/.test(t)&&/(aktif|çalıştır|başlat|uygula|devreye|etkinleştir)/.test(t)){
      var l=laws.filter(function(x){ return t.indexOf(x.name)>=0; })[0];
      if(l) return await runLaw(l);
      if(/yasa/.test(t)&&laws.length&&t.split(/\s+/).length<7) return "Böyle bir yasa bulamadım. Kayıtlılar: "+laws.map(function(x){ return x.name; }).join(", ");
    }
    if(/^yasalar(ı)?( listele| neler| göster)?$/.test(t)) return T.law_list();
    // modlar
    if((m=t.match(/^(.+?)\s*mod(?:unu|u|a)?\s*(aç|kapat|başlat|devreye al|bitir|durdur)$/))){
      var k=modeKey(m[1]); if(k) return await setMode(k,!/(kapat|bitir|durdur)/.test(m[2]));
    }
    if((m=t.match(/^(ajan|hacker|haker|otonom|sistem yöneticisi)\s*(aç|kapat|başlat)$/))){ var k2=modeKey(m[1]); if(k2) return await setMode(k2,m[2]!=="kapat"); }
    // hızlı ayarlar: wifi / bluetooth / uçak modu / ekran kilidi
    if(/(wifi|wi-fi|wlan|kablosuz)/.test(t)&&/(aç|kapat|söndür)/.test(t)&&!/ayar/.test(t)) return await qToggle(["Wi-Fi","WLAN","WiFi"],!/(kapat|söndür)/.test(t),"Wi-Fi");
    if(/bluetooth/.test(t)&&/(aç|kapat)/.test(t)&&!/ayar/.test(t)) return await qToggle(["Bluetooth"],!/kapat/.test(t),"Bluetooth");
    if(/uçak/.test(t)&&/(aç|kapat|ayarlardan)/.test(t)){
      var want=!/kapat/.test(t); var rr=await qToggle(["Uçak modu","Uçak","Airplane"],want,"Uçak modu");
      if(/bulamadım|izni kapalı/.test(rr)) await ptool("phone_action",{action:"open_settings",value:"airplane"});
      return rr;
    }
    if(/(tuş kilidi|ekran kilidi|kilit ekranı)/.test(t)&&/(kapat|kaldır|aç|ayar)/.test(t)){
      await ptool("phone_action",{action:"open_settings",value:"security"});
      return "Güvenlik ayarlarını açtım. Ekran kilidini kapatmak için PIN/parolayı senin girmen gerekiyor, bunu Android uygulamalara bırakmıyor.";
    }
    // parlaklık
    if(/parlakl/.test(t)&&(m=t.match(/(\d{1,3})/))) return await T.set_brightness({percent:m[1]});
    if(/parlakl/.test(t)&&/(kıs|düşür|azalt)/.test(t)) return await T.set_brightness({percent:20});
    if(/parlakl/.test(t)&&/(artır|yükselt|aç|full|son)/.test(t)) return await T.set_brightness({percent:100});
    // telefon sesi full
    if(/^(ses|sesi)\s*(full|son|max|tam|sonuna kadar)(\s*(yap|aç))?$/.test(t)) return await ptool("phone_action",{action:"volume_set",value:"100"});
    // TV
    if(/(televizyon|\btv\b)/.test(t)){
      if(/netflix/.test(t)) return await T.tv_control({action:"netflix"});
      if(/youtube|yutup/.test(t)) return await T.tv_control({action:"youtube"});
      if((m=t.match(/(\d{1,3})/))&&/ses/.test(t)) return await T.tv_control({action:"volume",value:m[1]});
      if(/ses/.test(t)&&/(kıs|azalt|düşür)/.test(t)) return await T.tv_control({action:"vol_down",value:"5"});
      if(/ses/.test(t)&&/(aç|artır|yükselt)/.test(t)) return await T.tv_control({action:"vol_up",value:"5"});
      if(/(sessiz|sustur)/.test(t)) return await T.tv_control({action:"mute"});
      if(/(kapat|söndür)/.test(t)) return await T.tv_control({action:"power_off"});
      if(/(aç|çalıştır|yak)/.test(t)) return await T.tv_control({action:"power_on"});
    }
    if(/^(netflix|youtube)\s*(aç)?\s*(televizyonda|tvde|tv'de|tv'de)$/.test(t)) return await T.tv_control({action:/netflix/.test(t)?"netflix":"youtube"});
    // görev
    if((m=t.match(/^(?:görev|yapılacak)\s*(?:ekle\s*)?[:\-]\s*(.+)$/)||t.match(/^(?:görev|yapılacak) ekle\s+(.+)$/))) return T.task_add({title:m[1]});
    if(/^(görevlerim|görevleri (listele|göster)|yapılacaklar)$/.test(t)) return T.task_list();
    if((m=t.match(/^(.+?)\s+görevini\s+(?:tamamla|bitir|yaptım)$/))) return T.task_done({title:m[1]});
    // konum / çevre (ağ gerektirmeyen kısa yollar)
    if(/^(neredeyim|konumum( ne| neresi)?|şu an neredeyim)$/.test(t)) return await T.location_info();
    if((m=t.match(/^(?:en yakın|yakındaki|yakın)\s+(eczane|benzin( istasyonu)?|market|hastane|atm|kafe|restoran|banka|otopark|fırın)/))) return await T.nearby_places({kind:m[1]});
    if(/^(gps|radar|ağ radarı)\s*(aç)?$/.test(t)){ openGps(); return "GPS radarı açıldı."; }
    if(/^(ağı tara|ağdaki cihazlar|ağ radarı)$/.test(t)) return await T.network_scan();
  }catch(e){ return "Hata: "+errT(e); }
  return prevOff?prevOff(text):null;
};

/* ================= Alışkanlık motoru ================= */
var HCAT=[["göz koruma",/göz koruma|göz konfor|okuma modu/],["fener",/fener|flaş/],["alarm",/alarm/],["müzik",/müzik|şarkı/],["parlaklık",/parlakl/],["televizyon",/televizyon|\btv\b/],["navigasyon",/yol tarifi|navigasyon|git\b/],["sessiz",/sessiz|ses[iı]? kıs/]];
function habitLog(t){
  for(var i=0;i<HCAT.length;i++) if(HCAT[i][1].test(t)){
    var a=lsGet("jv_hab",[]); var d=new Date(); a.push({c:HCAT[i][0],h:d.getHours(),m:d.getMinutes(),d:d.toDateString()}); if(a.length>400) a=a.slice(-400); lsSet("jv_hab",a); return;
  }
}
var ASK={"göz koruma":"göz korumasını açalım mı","fener":"feneri açalım mı","alarm":"alarm kuralım mı","müzik":"müzik açalım mı","parlaklık":"parlaklığı ayarlayalım mı","televizyon":"televizyonu açalım mı","navigasyon":"yol tarifi başlatalım mı","sessiz":"sesi kısalım mı"};
function habitScan(){
  var a=lsGet("jv_hab",[]), sug=lsGet("jv_sug",{}), found=null;
  var by={}; a.forEach(function(x){ var k=x.c+"@"+x.h; (by[k]=by[k]||{c:x.c,h:x.h,days:{},mins:[]}); by[k].days[x.d]=1; by[k].mins.push(x.m); });
  Object.keys(by).forEach(function(k){ var b=by[k]; if(Object.keys(b.days).length>=3&&!sug[k]&&!found) found=[k,b]; });
  if(!found) return;
  var b=found[1], mm=Math.round(b.mins.reduce(function(s,v){ return s+v; },0)/b.mins.length);
  sug[found[0]]=1; lsSet("jv_sug",sug);
  var txt="Efendim, son günlerde saat "+b.h+":"+(mm<10?"0":"")+mm+" civarı sık sık '"+b.c+"' yapıyorsunuz. Her gün bu saatte hatırlatayım mı?";
  JV.say(txt);
  setTimeout(function(){
    if(confirm(txt)){
      var rules=lsGet("jv_rules",[]); rules.push({id:found[0],h:b.h,m:mm,text:"Efendim, "+ASK[b.c]+"?",ask:ASK[b.c]});
      lsSet("jv_rules",rules); modes.auto=true; saveModes(); syncWatch(); toast("Hatırlatma eklendi, Otonom mod açıldı");
    }
  },400);
}

/* ================= Ayarlar bölümü, chips, izin ekleri ================= */
function buildPlusSettings(){
  var pb=document.querySelector("#pSet .pb"); if(!pb) return;
  var old=$("plusSet"); if(old) old.remove();
  var w=document.createElement("div"); w.id="plusSet";
  var rows=[["pYas","📜 YASALAR ("+laws.length+")"],["pTv","📺 TELEVİZYON"],["pGps","🛰 GPS RADARI"],["pHk","🕶 HACKER MODU"],["pTk","✅ GÖREV & HAFIZA"]];
  w.innerHTML='<div class="sec"><h3>Jarvis v7</h3>'+rows.map(function(r){ return '<button class="btn" data-go="'+r[0]+'" style="width:100%;margin-bottom:8px">'+r[1]+'</button>'; }).join("")+
   '<div class="row" style="display:block">Otonom mod (arka plan nöbeti)<select id="pAuto" style="margin-top:6px"><option value="0">Kapalı</option><option value="1">Açık: pil, depolama ve alışkanlık uyarıları</option></select></div></div>';
  var anchor=null; pb.querySelectorAll(".sec").forEach(function(s){ var h=s.querySelector("h3"); if(h&&h.textContent.toLowerCase().indexOf("güncelleme")>=0) anchor=s; });
  if(anchor) pb.insertBefore(w,anchor); else pb.appendChild(w);
  var go={pYas:openLaws,pTv:openTv,pGps:openGps,pHk:openHack,pTk:openTasks};
  w.querySelectorAll("[data-go]").forEach(function(b){ b.onclick=function(){ closePage("pSet"); go[b.getAttribute("data-go")](); }; });
  $("pAuto").value=modes.auto?"1":"0";
  $("pAuto").onchange=async function(){ var on=this.value==="1"; var r=await setMode("auto",on); toast(on?"Otonom mod açıldı":"Kapatıldı"); if(on) JV.say(r); };
}
if($("bSet")) $("bSet").addEventListener("click",function(){ setTimeout(buildPlusSettings,30); });
var chips=$("chips");
if(chips&&chips.appendChild){
  [["📜 YASA",openLaws],["📺 TV",openTv],["🛰 GPS",openGps],["🕶 HACKER",openHack],["✅ GÖREV",openTasks]].forEach(function(c){
    var b=document.createElement("button"); b.textContent=c[0]; b.onclick=c[1]; chips.appendChild(b);
  });
}
// vivo ek izin adımları
var pp=$("pPerm");
if(pp){
  var host=pp.querySelector(".pb"), app=$("pgApp");
  if(host){
    var sec=document.createElement("div"); sec.className="sec";
    sec.innerHTML='<h3>vivo / Android ek adımlar</h3><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Nöbet, ajan modu ve yasaların sorunsuz çalışması için:</div>'+
     '<button class="btn" id="pxWrite" style="width:100%;margin-bottom:8px">☀ Parlaklık izni (sistem ayarlarını değiştir)</button>'+
     '<button class="btn" id="pxBg" style="width:100%">🔋 Arka plan / otomatik başlatma (vivo)</button>'+
     '<div id="pxMsg" style="font-size:12px;color:var(--dim);margin-top:8px;white-space:pre-wrap"></div>';
    if(app) host.insertBefore(sec,app); else host.appendChild(sec);
    $("pxWrite").onclick=function(){ try{ P.openWriteSettings(); }catch(e){} };
    $("pxBg").onclick=function(){
      $("pxMsg").textContent="Açılan uygulama bilgisinde: Pil > Arka plan güç tüketimi > 'Yüksek arka plan güç tüketimine izin ver' aç.\nAyrıca vivo'da: Ayarlar > Uygulamalar > Otomatik başlatma > Jarvis açık olsun. Son uygulamalar ekranında Jarvis'i kilitle (kartı aşağı çekip kilit simgesi).";
      JV.natX("openSpecial","app").catch(function(){});
    };
  }
}

/* ================= Başlangıç ================= */
function pickPending(){
  if(!P) return;
  try{ var q=P.pendingTake(); if(q&&!JV.voice) setTimeout(function(){ JV.send(q); },1800); }catch(e){}
}
pickPending();
if(modes.auto||modes.system) setTimeout(syncWatch,3000);
modes.agent=false; saveModes();
if(!JV.voice){ setTimeout(habitScan,20000); setInterval(habitScan,30*60*1000); }
window.JV_plus={setMode:setMode,laws:laws,tasks:tasks,prefs:prefs,habitScan:habitScan};
})();
