/* JARVİS Hologram Atölyesi: heykel, insan atlası, tarihî yapı, canlı anatomisi, oda yerleşimi, rap yazarı */
(function(){
"use strict";
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, $=function(id){ return document.getElementById(id); }, esc=JV.esc;
var BUSY=/yoğun|high demand|UNAVAILABLE|overload|503|429|limit/i;
var TABS=[["heykel","🗿 HEYKEL"],["atlas","🫀 ATLAS"],["tarih","🏛 TARİHÎ"],["canli","🐾 CANLI"],["oda","🛋 ODA"],["rap","🎤 RAP"]];
var tab="heykel", busy=false;

var st=document.createElement("style");
st.textContent=
"#atT{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;padding:2px 0 12px}"+
"#atT button{flex:none;padding:9px 13px;border-radius:18px;border:1px solid var(--line);background:var(--panel);font-size:12px;letter-spacing:1.5px;color:var(--dim)}"+
"#atT button.on{color:var(--c1);border-color:var(--c1);box-shadow:0 0 10px color-mix(in srgb,var(--c1) 40%,transparent)}"+
"#atB .lb{font-size:12px;letter-spacing:1.5px;color:var(--dim);margin:12px 0 6px}"+
"#atB input,#atB textarea,#atB select{width:100%;box-sizing:border-box;border-radius:12px;border:1px solid var(--line);background:#010912;color:var(--txt);padding:0 12px;height:44px;font:inherit;font-size:15px;outline:none}"+
"#atB textarea{height:96px;padding:10px 12px;resize:vertical}"+
"#atB .go{display:block;width:100%;height:48px;margin-top:14px}"+
"#atB .q{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}#atB .q button{padding:7px 11px;border-radius:14px;border:1px solid var(--line);background:var(--panel);font-size:12px;color:var(--txt)}"+
"#atB .g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px}"+
"#atS{margin-top:12px;font-size:13px;color:var(--c1);line-height:1.45;min-height:18px}"+
"#atR{margin-top:12px;white-space:pre-wrap;line-height:1.6;font-size:15px;padding:12px;border-radius:14px;border:1px solid var(--line);background:rgba(0,0,0,.35);display:none}"+
"#pAt{background:#020810!important}";
document.head.appendChild(st);

var pg=document.createElement("div"); pg.className="page"; pg.id="pAt";
pg.innerHTML='<div class="ph"><button class="ib" data-close>←</button><h2>HOLOGRAM ATÖLYESİ</h2></div><div class="pb"><div id="atT"></div><div id="atB"></div><div id="atS"></div><div id="atR"></div></div>';
document.body.appendChild(pg);

function status(t){ status.last=t||""; $("atS").textContent=t||""; }
function tabs(){ $("atT").innerHTML=TABS.map(function(t){ return '<button data-t="'+t[0]+'" class="'+(t[0]===tab?"on":"")+'">'+t[1]+'</button>'; }).join(""); }
function quick(list,id){ return '<div class="q" id="'+id+'">'+list.map(function(x){ return '<button>'+x+'</button>'; }).join("")+'</div>'; }

var ATLAS=["İskelet","Kaslar","Dolaşım sistemi","Sinir sistemi","İç organlar","Kafatası ve beyin","El ve ayak kemikleri","Solunum sistemi"];
var TARIH=["Ayasofya","Kolezyum","Giza Piramitleri","Eyfel Kulesi","Galata Kulesi","Taj Mahal","Stonehenge","Çin Seddi","Selimiye Camii","Pisa Kulesi"];
var ODA_DEF="2x1.6x0.5 m yatak\n1.2x0.6x0.75 m çalışma masası\n0.9x0.5x1.8 m dolap\n0.8x0.8x0.9 m koltuk";

function draw(){
  tabs(); status(""); $("atR").style.display="none"; var rb0=$("atRb"); if(rb0) rb0.remove(); var b=$("atB");
  if(tab==="heykel") b.innerHTML='<div class="lb">NE ÇİZELİM?</div><input id="atI" placeholder="ejderha, kartal, robot şövalye…"><button class="btn go" id="atGo">HOLOGRAM HEYKELİ ÇİZ</button>';
  else if(tab==="atlas") b.innerHTML='<div class="lb">İNSAN VÜCUDU ATLASI · SİSTEM SEÇ</div>'+quick(ATLAS,"atQ")+'<div class="lb" style="margin-top:14px">Eğitim amaçlı yaklaşık modeldir; tıbbi kesinlik yoktur.</div>';
  else if(tab==="tarih") b.innerHTML='<div class="lb">TARİHÎ YAPI</div><input id="atI" placeholder="yapı adı"><div class="lb">HAZIR SEÇİMLER</div>'+quick(TARIH,"atQ")+'<button class="btn go" id="atGo">KATMAN KATMAN ÇİZ</button>';
  else if(tab==="canli") b.innerHTML='<div class="lb">HAYVAN YA DA BİTKİ ADI</div><input id="atI" placeholder="kedi, kartal, gül, meşe…"><button class="btn go" id="atGo">İSKELET / İÇ YAPISINI ÇİZ</button><button class="btn go" id="atPh" style="margin-top:10px">📷 FOTOĞRAFTAN TANI VE ÇİZ</button><div class="lb" style="margin-top:14px">Fotoğraf: Jarvis hayvanı ya da bitkiyi tanır, fotoğraftaki renkleriyle anatomisini çizer. Kamera HUD\'daki X-RAY modu da aynısını yapar.</div>';
  else if(tab==="oda") b.innerHTML='<div class="lb">ODA ÖLÇÜSÜ (metre): UZUNLUK · GENİŞLİK · YÜKSEKLİK</div><div class="g3"><input id="atL" type="number" step="0.1" value="4"><input id="atW" type="number" step="0.1" value="3.5"><input id="atH" type="number" step="0.1" value="2.6"></div><div class="lb">EŞYALAR (boyutlarıyla, satır satır)</div><textarea id="atE">'+ODA_DEF+'</textarea><button class="btn go" id="atGo">ODAYI KUR VE YERLEŞTİR</button><button class="btn go" id="atPh" style="margin-top:10px">📷 FOTOĞRAFTAN TAHMİN ET (1-3 foto)</button><div class="lb" style="margin-top:14px">Fotoğraftan ölçüler TAHMİNİ çıkar (kapı yüksekliği gibi referanslarla, yaklaşık ±%20). Kesin ölçü için metreyle ölçüp yukarıya yaz.</div>';
  else if(tab==="rap") b.innerHTML='<div class="lb">KONU</div><input id="atI" placeholder="sabah erken kalkmak, İstanbul trafiği…"><div class="lb">TARZ</div><select id="atSt"><option>Old school</option><option>Trap</option><option>Duygusal</option><option>Komik</option><option>Motivasyon</option><option>Savaş (rakibe)</option></select><div class="lb">UZUNLUK</div><select id="atLn"><option value="8">Kısa (8 satır)</option><option value="16" selected>Orta (16 satır)</option><option value="24">Uzun (24 satır)</option></select><button class="btn go" id="atGo">RAP YAZ</button>';
}
$("atT").addEventListener("click",function(e){ var b=e.target.closest("button"); if(!b||busy) return; tab=b.getAttribute("data-t"); draw(); });
$("atB").addEventListener("click",function(e){
  var q=e.target.closest(".q button"); if(q&&!busy){ if(tab==="atlas") go(q.textContent); else { var i=$("atI"); if(i) i.value=q.textContent; } return; }
  if(e.target.closest("#atGo")&&!busy) go(($("atI")||{}).value);
  if(e.target.closest("#atPh")&&!busy) photoGo();
});

function readImgs(files,max){
  var arr=Array.prototype.slice.call(files||[],0,max||1);
  return Promise.all(arr.map(function(f){ return new Promise(function(res,rej){
    var r=new FileReader(); r.onerror=function(){ rej(new Error("dosya okunamadı")); };
    r.onload=function(){ var im=new Image(); im.onerror=function(){ rej(new Error("resim açılamadı")); };
      im.onload=function(){ var k=Math.min(1,1024/Math.max(im.width,im.height)), c=document.createElement("canvas"); c.width=Math.round(im.width*k); c.height=Math.round(im.height*k); c.getContext("2d").drawImage(im,0,0,c.width,c.height); res(c.toDataURL("image/jpeg",0.8).split(",")[1]); };
      im.src=r.result; };
    r.readAsDataURL(f); }); }));
}
function pick(multi,cb){
  var fi=$("atF"); if(fi) fi.remove();
  fi=document.createElement("input"); fi.type="file"; fi.accept="image/*"; fi.id="atF"; fi.style.display="none"; if(multi) fi.multiple=true;
  fi.onchange=function(){ var fl=fi.files; if(fl&&fl.length) cb(fl); };
  document.body.appendChild(fi); fi.click();
}
async function aiRetry(prompt){
  var last="";
  for(var a=0;a<3;a++){
    if(a>0&&BUSY.test(last)){ status("Gemini yoğun, tekrar deniyorum ("+(a+1)+"/3)…"); await new Promise(function(r){ setTimeout(r,a*4000); }); }
    try{ return await JV.withTimeout(JV.aiText(prompt,true),55000,"zaman aşımı"); }catch(e){ last=JV.errMsg(e); if(!BUSY.test(last)&&a>0) break; }
  }
  throw new Error(last||"cevap alınamadı");
}
async function genModel(name,prompt){
  status("Hologram çiziliyor… (20-40 sn sürebilir)");
  var raw=await aiRetry(prompt), arr=window.JV_xrayH3.salvage(raw);
  if(arr.length<4){ raw=await aiRetry(prompt+" ÖNEMLİ: önceki cevap eksikti; en az 8 parça ver."); arr=window.JV_xrayH3.salvage(raw); }
  if(arr.length<3) throw new Error("model çıkmadı, tekrar dene");
  if(!window.JV_xrayH3.show(arr,name)) throw new Error("model açılamadı");
  status("Hazır. AYIR kaydırıcısı, parçaya dokunma, 💾 kaydetme hologramda.");
}
var SPEC=function(g){ return window.JV_xrayH3.spec.replace('"G"','"'+g+'"'); };

async function go(v){
  v=String(v||"").trim(); busy=true; var btn=$("atGo"); if(btn) btn.disabled=true;
  try{
    if(tab==="heykel"){
      if(!v) throw new Error("ne çizeyim?");
      await genModel(v,'"'+v+'" konulu bir 3 boyutlu HEYKEL/figür tasarla: sanatsal, akıcı formlu; dönel yüzey (donel), kıvrımlı boru (egri), küre ve koniyi bol kullan; kasları, kanatları, yüz hatlarını ve süslemeleri ayrı parçalar yap; en çok 26 parça; hepsi grup="ic"; her parçaya uygun "mat" ver. '+SPEC("ic"));
    } else if(tab==="atlas"){
      await genModel("İnsan: "+v,'İnsan vücudu atlası: ayakta duran yetişkin insanın "'+v+'" bölümünü 3 boyutlu anatomik model olarak çiz. Boy: ayak y=-1, baş y=+1; yüze bakan yön +x. Her parça doğru Türkçe anatomi adıyla ve doğru konumda olsun (iki taraflı parçalarda sağ ve sol); "bilgi" alanına kısa görev açıklaması yaz. Önemli parçalar grup="ic". Ayrıca vücut siluetini 5-6 parçayla (kure ve silindir) grup="dis" olarak ekle, renk ten rengi. En çok 30 parça. Eğitim amaçlı yaklaşık model. '+SPEC("ic"));
    } else if(tab==="tarih"){
      if(!v) throw new Error("yapı adını yaz");
      await genModel(v,'Tarihî yapı: "'+v+'" 3 boyutlu, gerçek orantılarla ve katman katman çiz (temel, ana gövde, sütun/kemer/duvar, kubbe/kule/çatı, ayrıntılar); taş, mermer, tuğla renklerini ve "mat" değerini kullan. Dış kabuk (duvar, kubbe, çatı) grup="dis"; sütunlar, kemerler, iç mekân ve temel grup="ic". "bilgi" alanına yapım dönemi ya da işlev yaz. En çok 28 parça. '+SPEC("ic"));
    } else if(tab==="canli"){
      if(!v) throw new Error("hayvan ya da bitki adını yaz");
      await genModel(v,'"'+v+'" için 3 boyutlu anatomi modeli: önce dış gövde siluetini 8-10 parçayla grup="dis" (gerçek renkleriyle), sonra '+(/gül|çiçek|ağaç|meşe|bitki|yaprak|ot|kaktüs|meyve|sebze|lale|papatya/i.test(v)?'iç yapısını (kök, gövde damarları, yaprak damarları, çiçek/meyve iç yapısı)':'iskeletini ve başlıca organlarını (kafatası, omurga, kaburga, uzuv kemikleri, kalp, akciğer, beyin, mide gibi)')+' en çok 18 parçayla grup="ic" olarak doğru Türkçe adlarla çiz. "bilgi" alanına kısa açıklama yaz. '+SPEC("ic"));
    } else if(tab==="oda"){
      await oda();
    } else if(tab==="rap"){
      await rap(v);
    }
  }catch(e){ status("Hata: "+JV.errMsg(e)); }
  busy=false; btn=$("atGo"); if(btn) btn.disabled=false;
}

/* ---- Oda yerleşimi ---- */
async function oda(){
  var L=+$("atL").value, W=+$("atW").value, H=+$("atH").value, txt=$("atE").value.trim();
  if(!(L>0.5&&W>0.5&&H>1)) throw new Error("oda ölçüsü geçersiz");
  if(!txt) throw new Error("eşya listesi boş");
  status("Eşyalar yerleştiriliyor…");
  var raw=await aiRetry('Oda: uzunluk x='+L+' m, genişlik z='+W+' m, yükseklik '+H+' m (köşe başlangıç 0,0). Eşya listesi (boyutlar uzunluk x genişlik x yükseklik metre, sadece söylenen boyutları kullan, uydurma):\n'+txt+'\nHer eşyayı odaya mantıklı yerleştir: üst üste binmesin, duvarlara yakın ve geçiş yolu en az 0.6 m olsun, bir kısa duvarın ortasında 0.9 m kapı boşluğu bırak. Sadece JSON: {"esyalar":[{"ad":"kısa ad","l":uzunluk,"w":genişlik,"h":yükseklik,"x":merkez x metre,"z":merkez z metre,"renk":"#rrggbb"}]}. Boyutu okunamayan eşyayı listeye alma.');
  var d=JV.parseJSON(raw);
  showRoom(L,W,H,(d&&Array.isArray(d.esyalar))?d.esyalar:[]);
}
function showRoom(L,W,H,items){
  items=items.filter(function(i){ return i&&isFinite(+i.l)&&isFinite(+i.w)&&isFinite(+i.h)&&isFinite(+i.x)&&isFinite(+i.z)&&+i.l>0&&+i.w>0&&+i.h>0; });
  if(!items.length) throw new Error("eşya yerleştirilemedi, listeyi boyutlarıyla yaz");
  /* yerel doğrulama: odadan taşma ve çakışma */
  var bad={}, notes=[];
  items.forEach(function(a,i){
    var l=+a.l, w=+a.w, x=+a.x, z=+a.z;
    if(x-l/2<-0.02||x+l/2>L+0.02||z-w/2<-0.02||z+w/2>W+0.02||+a.h>H+0.02){ bad[i]=1; notes.push(a.ad+" odaya sığmıyor"); }
    for(var j=i+1;j<items.length;j++){ var b=items[j]; if(Math.abs(x-b.x)<(l+ +b.l)/2-0.02&&Math.abs(z-b.z)<(w+ +b.w)/2-0.02){ bad[i]=1; bad[j]=1; notes.push(a.ad+" ile "+b.ad+" çakışıyor"); } }
  });
  var s=2/Math.max(L,W,H), th=0.03, spec=[];
  function bx(ad,m,b,col,grp,info,mat){ spec.push({ad:ad,tur:"kutu",grup:grp,m:m,b:b,renk:col,bilgi:info||"",mat:mat}); }
  var cx=L/2, cz=W/2, cyy=H/2;
  bx("Zemin",[0,(-cyy)*s,0],[L*s,th,W*s],"#8a7b6a","dis","","ahsap");
  bx("Duvar arka",[0,0,(-cz)*s],[L*s,H*s,th],"#aebccb","dis","","boya"); bx("Duvar ön",[0,0,cz*s],[L*s,H*s,th],"#aebccb","dis","","boya");
  bx("Duvar sol",[(-cx)*s,0,0],[th,H*s,W*s],"#aebccb","dis","","boya"); bx("Duvar sağ",[cx*s,0,0],[th,H*s,W*s],"#aebccb","dis","","boya");
  items.slice(0,24).forEach(function(a,i){
    var col=bad[i]?"#ff4d4d":(/^#[0-9a-f]{6}$/i.test(a.renk||"")?a.renk:"#c9a36b");
    bx(String(a.ad||"Eşya"),[(+a.x-cx)*s,(+a.h/2-cyy)*s,(+a.z-cz)*s],[+a.l*s,+a.h*s,+a.w*s],col,"ic",Math.round(+a.l*100)+"×"+Math.round(+a.w*100)+"×"+Math.round(+a.h*100)+" cm"+(bad[i]?" ⚠":""),"ahsap");
  });
  if(!window.JV_xrayH3.show(spec,"Oda "+L+"×"+W)) throw new Error("oda açılamadı");
  status(notes.length?("⚠ "+notes.slice(0,4).join(" · ")+" (kırmızı gösterildi)"):"Her şey sığdı, çakışma yok.");
}

async function photoGo(){
  var multi=(tab==="oda");
  pick(multi,async function(fl){
    busy=true; var b=$("atPh"); if(b) b.disabled=true;
    try{
      status("Fotoğraf okunuyor…"); var imgs=await readImgs(fl,multi?3:1);
      if(tab==="canli"){
        status("Tanınıyor ve çiziliyor… (30-60 sn)");
        await window.JV_xrayReal(imgs[0]);
        status("Hazır. Parçaya dokun, AYIR kaydırıcısını dene.");
      } else if(tab==="oda"){
        status("Oda fotoğraflardan ölçülüyor…");
        var raw=await JV.withTimeout(JV.visionAI('Bu fotoğraflar AYNI odayı gösteriyor. Referans olarak kapı yüksekliğini (~2.0 m), priz/anahtar yüksekliğini (~1.1 m) ve standart eşya boyutlarını kullanarak odanın ölçülerini ve görünen eşyaları TAHMİN et (metre). Koordinat: köşe başlangıç 0,0; x uzunluk, z genişlik; x,z eşyanın MERKEZİDİR. Sadece JSON: {"uzunluk":sayı,"genislik":sayı,"yukseklik":sayı,"esyalar":[{"ad":"kısa ad","l":uzunluk,"w":genişlik,"h":yükseklik,"x":sayı,"z":sayı,"renk":"#rrggbb"}]}. En çok 12 eşya, belirsizse eşyayı alma.',imgs.map(function(x){ return {data:x}; }),true),60000,"zaman aşımı");
        var d=JV.parseJSON(raw); if(!d||!(+d.uzunluk>0)||!(+d.genislik>0)) throw new Error("oda ölçüsü çıkarılamadı, başka açıdan çek");
        var L=Math.min(15,+d.uzunluk), W=Math.min(15,+d.genislik), H=Math.min(5,Math.max(2,+d.yukseklik||2.6));
        $("atL").value=L.toFixed(1); $("atW").value=W.toFixed(1); $("atH").value=H.toFixed(1);
        $("atE").value=(Array.isArray(d.esyalar)?d.esyalar:[]).map(function(i){ return (+i.l).toFixed(2)+"x"+(+i.w).toFixed(2)+"x"+(+i.h).toFixed(2)+" m "+i.ad; }).join("\n");
        showRoom(L,W,H,Array.isArray(d.esyalar)?d.esyalar:[]);
        status("Tahmini oda ("+L.toFixed(1)+"×"+W.toFixed(1)+"×"+H.toFixed(1)+" m) kuruldu; değerleri forma yazdım, düzeltip tekrar kurabilirsin. "+status.last);
      }
    }catch(e){ status("Hata: "+JV.errMsg(e)); }
    busy=false; b=$("atPh"); if(b) b.disabled=false;
  });
}

/* ---- Rap yazarı ---- */
async function rap(v){
  if(!v) throw new Error("konuyu yaz");
  var stl=$("atSt").value, n=$("atLn").value; status("Sözler yazılıyor…");
  var t=await JV.withTimeout(JV.aiText('Türkçe, tamamen ÖZGÜN bir rap sözü yaz (var olan şarkıdan söz, dize ya da nakarat alma). Konu: "'+v+'". Tarz: '+stl+'. Uzunluk: '+n+' satır, kafiyeli ve ritmik; 2-3 kıssa nakarat satırı ekle ve "[Nakarat]" ile işaretle. Küfür ve hakaret yok. Başlık ver. Sadece söz metni.'),60000,"zaman aşımı");
  t=String(t).replace(/[*#]/g,"").trim(); var r=$("atR"); r.style.display="block"; r.textContent=t;
  var bar=$("atRb"); if(!bar){ bar=document.createElement("div"); bar.id="atRb"; bar.style.cssText="display:flex;gap:8px;margin-top:10px"; bar.innerHTML='<button class="btn" id="atSay" style="flex:1;height:44px">🔊 SESLİ OKU</button><button class="btn" id="atCp" style="flex:1;height:44px">KOPYALA</button>'; r.parentNode.insertBefore(bar,r.nextSibling);
    $("atSay").onclick=function(){ try{ JV.say($("atR").textContent.replace(/\[[^\]]*\]/g,"")); }catch(e){} };
    $("atCp").onclick=function(){ var tx=$("atR").textContent; if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(tx).then(function(){ JV.toast("Kopyalandı"); },function(){ JV.toast("Kopyalanamadı"); }); else JV.toast("Kopyalanamadı"); }; }
  status("Hazır.");
}

function open(){ draw(); pg.classList.add("show"); }
window.JV_topics={open:open};
var chips=$("chips");
if(chips){ var b=document.createElement("button"); b.id="cAt"; b.textContent="🏛 ATÖLYE"; b.onclick=open; chips.appendChild(b); }
})();
