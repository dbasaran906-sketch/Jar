/* JARVİS v7: GPS, TV, Yasalar, Modlar, Ağ radarı, Görevler, Ajan, Alışkanlık, Ön görü */
(function(){
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, P=window.JarvisP||null, N=window.JarvisNative||null;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
function np(fn,a,b){ return JV.natP(fn,a,b); }
function ptool(n,a){ return JV.nat("tool",n,JSON.stringify(a||{})); }
function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
function errT(e){ return String((e&&e.message)||e||"hata"); }
var S=function(d){ return {type:"string",description:d}; };
var I=function(d){ return {type:"integer",description:d}; };
function mkPage(id,html,onClose){
  var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d);
  if(onClose) new MutationObserver(function(){ if(!d.classList.contains("show")) onClose(); }).observe(d,{attributes:true,attributeFilter:["class"]});
  return d;
}
function openPage(id){ $(id).classList.add("show"); }
function closePage(id){ $(id).classList.remove("show"); }

var st=document.createElement("style");
st.textContent=
".term{font-family:monospace;font-size:12px;line-height:1.5;background:#000;color:#39ff7a;border:1px solid rgba(57,255,122,.4);border-radius:10px;padding:10px;min-height:160px;max-height:46vh;overflow:auto;white-space:pre-wrap;word-break:break-all}"+
".pl{padding:9px 0;border-bottom:1px solid rgba(43,181,255,.15);font-size:14px}.pl small{display:block;color:var(--dim);font-size:12px}"+
".pbtn{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.pbtn .btn{flex:1;min-width:30%}"+
"#plc{width:100%;height:220px;display:block;background:#000;border-radius:12px;border:1px solid var(--line)}"+
".inp{width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);background:rgba(0,0,0,.4);color:var(--txt);font-size:14px;outline:none;box-sizing:border-box;margin:4px 0}";
document.head.appendChild(st);

/* ================= Depo ================= */
var places=lsGet("jv_places",{});
function savePlaces(){ lsSet("jv_places",places); if(P){ try{ P.kvSet("places",JSON.stringify(places)); }catch(e){} } }
if(P){ try{ P.kvSet("places",JSON.stringify(places)); }catch(e){} }
var laws=lsGet("jv_laws",[]);
if(!laws.length&&P){ try{ var bk=JSON.parse(P.kvGet("laws")||"[]"); if(bk.length){ laws=bk; lsSet("jv_laws",laws); } }catch(e){} }
function saveLaws(){ lsSet("jv_laws",laws); if(P){ try{ P.kvSet("laws",JSON.stringify(laws)); }catch(e){} } try{ if(typeof syncWatch==="function"&&laws.some(function(l){ return l.trigger; })) syncWatch(); }catch(e){} }
var tasks=lsGet("jv_tasks",[]); function saveTasks(){ lsSet("jv_tasks",tasks); }
var prefs=lsGet("jv_prefs",{}); function savePrefs(){ lsSet("jv_prefs",prefs); }
var modes=lsGet("jv_modes",{}); function saveModes(){ lsSet("jv_modes",modes); }
var lastLoc=null;

window.EXTRA_SYS=function(){
  var s="";
  var pk=Object.keys(prefs); if(pk.length) s+="Kullanıcı tercihleri: "+pk.map(function(k){ return k+"="+prefs[k]; }).join("; ")+". ";
  var op=tasks.filter(function(t){ return !t.done; }); if(op.length) s+="Açık görevleri: "+op.slice(0,15).map(function(t){ return t.title+(t.when?" ("+t.when+")":""); }).join("; ")+". ";
  if(laws.length) s+="Kayıtlı yasalar: "+laws.map(function(l){ return l.name; }).join(", ")+". ";
  var am=Object.keys(modes).filter(function(k){ return modes[k]; }); if(am.length) s+="Açık modlar: "+am.join(", ")+". ";
  if(lastLoc) s+="Son bilinen konum: "+(lastLoc.addr||(lastLoc.lat.toFixed(4)+","+lastLoc.lon.toFixed(4)))+". ";
  return s;
};

/* ================= Konum / çevre ================= */
function ageText(sec){ sec=Math.round(sec||0); if(sec<90) return sec+" sn"; if(sec<5400) return Math.round(sec/60)+" dk"; if(sec<172800) return Math.round(sec/3600)+" saat"; return Math.round(sec/86400)+" gün"; }
/* strict=true: eski (2 dk+) konumu kabul etme */
async function getLoc(strict){
  var j=JSON.parse(await np("loc"));
  j.stale=(j.age||0)>120;
  if(strict&&j.stale) throw new Error("Taze konum alınamadı (telefonun son bildiği konum "+ageText(j.age)+" önceki). Konum/GPS açık olsun, açık bir yere çıkıp tekrar dene.");
  if(!j.stale) lastLoc=Object.assign(lastLoc||{},j,{t:Date.now()});
  return j;
}
async function httpJ(url){ return JSON.parse(await np("httpGet",url)); }
async function revGeo(lat,lon){
  try{
    var j=await httpJ("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=17&accept-language=tr&lat="+lat+"&lon="+lon);
    return j.display_name||"";
  }catch(e){ return ""; }
}
var WC={0:"açık",1:"çoğunlukla açık",2:"parçalı bulutlu",3:"kapalı",45:"sisli",48:"sisli",51:"çise",53:"çise",55:"çise",61:"hafif yağmurlu",63:"yağmurlu",65:"kuvvetli yağmurlu",71:"karlı",73:"karlı",75:"yoğun karlı",80:"sağanak",81:"sağanak",82:"şiddetli sağanak",95:"gök gürültülü fırtına",96:"dolulu fırtına",99:"dolulu fırtına"};
async function envAt(lat,lon){
  try{
    var j=await httpJ("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&timezone=auto");
    var c=j.current||{};
    return "Hava: "+(WC[c.weather_code]||"?")+", "+c.temperature_2m+"°C (hissedilen "+c.apparent_temperature+"°C), nem %"+c.relative_humidity_2m+", rüzgar "+c.wind_speed_10m+" km/s, yağış "+c.precipitation+" mm";
  }catch(e){ return ""; }
}
function distM(a,b,c,d){ var R=6371000,p=Math.PI/180,x=(c-a)*p,y=(d-b)*p*Math.cos(a*p); return Math.sqrt(x*x+y*y)*R; }
var POI={eczane:'["amenity"="pharmacy"]',nöbetçi:'["amenity"="pharmacy"]',benzin:'["amenity"="fuel"]',akaryakıt:'["amenity"="fuel"]',market:'["shop"="supermarket"]',restoran:'["amenity"="restaurant"]',kafe:'["amenity"="cafe"]',hastane:'["amenity"="hospital"]',atm:'["amenity"="atm"]',banka:'["amenity"="bank"]',otopark:'["amenity"="parking"]',şarj:'["amenity"="charging_station"]',fırın:'["shop"="bakery"]',cami:'["amenity"="place_of_worship"]',okul:'["amenity"="school"]'};
async function poiSearch(kind,lat,lon){
  var k=tl(kind), f=null; Object.keys(POI).forEach(function(n){ if(!f&&k.indexOf(n)>=0) f=POI[n]; });
  if(!f) return {err:"Tanımadığım yer türü. Şunlardan birini dene: "+Object.keys(POI).join(", ")};
  var q='[out:json][timeout:12];(node'+f+'(around:2000,'+lat+','+lon+');way'+f+'(around:2000,'+lat+','+lon+'););out center 25;';
  var j=null, urls=["https://overpass-api.de/api/interpreter?data=","https://overpass.kumi.systems/api/interpreter?data=","https://overpass.private.coffee/api/interpreter?data="], lastE="";
  for(var u=0;u<urls.length&&!j;u++){
    try{ j=await Promise.race([httpJ(urls[u]+encodeURIComponent(q)),new Promise(function(_,rj){ setTimeout(function(){ rj(new Error("zaman aşımı")); },8000); })]); }catch(e){ lastE=errT(e); j=null; }
  }
  if(!j) return {fail:lastE||"sunucu yanıt vermedi"};
  var arr=(j.elements||[]).map(function(e){ var la=e.lat||(e.center&&e.center.lat), lo=e.lon||(e.center&&e.center.lon); return {name:(e.tags&&(e.tags.name||e.tags.brand))||"(isimsiz)",lat:la,lon:lo,d:Math.round(distM(lat,lon,la,lo))}; }).filter(function(x){ return x.lat; });
  arr.sort(function(a,b){ return a.d-b.d; });
  return {list:arr.slice(0,8)};
}
var EXTRA=[
 {name:"location_info",description:"Kullanıcının canlı konumunu, adresini, hızını, yönünü ve bulunduğu yerin hava/çevre bilgisini verir (GPS).",input_schema:{type:"object",properties:{}}},
 {name:"nearby_places",description:"Yakındaki yerleri bulur: eczane, benzin, market, restoran, kafe, hastane, atm, banka, otopark, şarj, fırın.",input_schema:{type:"object",properties:{kind:S("Yer türü")},required:["kind"]}},
 {name:"tv_control",description:"Kayıtlı Google TV'yi kontrol eder. action: power_on, power_off, volume (value: 0-100), vol_up, vol_down, mute, home, back, netflix, youtube, play, up, down, left, right, ok.",input_schema:{type:"object",properties:{action:S("Eylem"),value:S("İsteğe bağlı değer")},required:["action"]}},
 {name:"set_brightness",description:"Ekran parlaklığını yüzde olarak ayarlar (1-100).",input_schema:{type:"object",properties:{percent:I("Yüzde")},required:["percent"]}},
 {name:"place_delete",description:"Kayıtlı bir yeri (ev, iş...) siler.",input_schema:{type:"object",properties:{name:S("Silinecek yer adı")},required:["name"]}},
 {name:"place_list",description:"Kayıtlı yerleri listeler.",input_schema:{type:"object",properties:{}}},
 {name:"place_save",description:"Kullanıcının şu anki konumunu adlandırılmış yer olarak kaydeder (ev, iş, okul). Konum tetikleyicili yasalar için gerekir.",input_schema:{type:"object",properties:{name:S("Yer adı, örn. ev")},required:["name"]}},
 {name:"law_save",description:"Kullanıcı için adlandırılmış bir 'yasa' (rutin) kaydeder. steps: adımlar virgülle ayrılmış, her biri kısa komut, örn: 'parlaklık 10, ses 100, whatsapp aç'.",input_schema:{type:"object",properties:{name:S("Yasa adı, örn. saman"),steps:S("Virgülle ayrılmış komutlar"),trigger:S("İsteğe bağlı otomatik tetikleyici, Türkçe: 'her gün 23:00', 'hafta içi 08:30', 'şarja takınca', 'şarjdan çekince', 'wifi Ev bağlanınca', 'pil %15 altına inince'")},required:["name","steps"]}},
 {name:"law_run",description:"Kayıtlı bir yasayı çalıştırır (aktif eder).",input_schema:{type:"object",properties:{name:S("Yasa adı")},required:["name"]}},
 {name:"law_list",description:"Kayıtlı yasaları listeler.",input_schema:{type:"object",properties:{}}},
 {name:"predict",description:"Ön görü motoru: bir olayın/kararın ihtimalini ve başarı olasılığını güncel verilerle analiz eder.",input_schema:{type:"object",properties:{question:S("Analiz edilecek soru/durum")},required:["question"]}},
 {name:"network_scan",description:"Kullanıcının kendi Wi-Fi ağındaki cihazları (IP, açık portlar) tarar.",input_schema:{type:"object",properties:{}}},
 {name:"set_mode",description:"Bir modu açar/kapatır: ajan, hacker, otonom, gps, tv, sistem, yasalar.",input_schema:{type:"object",properties:{mode:S("Mod adı"),on:S("true ya da false")},required:["mode"]}},
 {name:"task_add",description:"Görev/yapılacak ekler.",input_schema:{type:"object",properties:{title:S("Görev"),when:S("İsteğe bağlı zaman")},required:["title"]}},
 {name:"task_list",description:"Açık görevleri listeler.",input_schema:{type:"object",properties:{}}},
 {name:"task_done",description:"Bir görevi tamamlandı yapar (başlığına göre).",input_schema:{type:"object",properties:{title:S("Görev başlığı")},required:["title"]}},
 {name:"reminder_add",description:"Belirli bir saatte SESLİ hatırlatma kurar (uygulama kapalıyken de konuşur). time: 'SS:DD' (24 saat), day: 'bugün' ya da 'yarın' (varsayılan: bugün, saat geçtiyse yarın).",input_schema:{type:"object",properties:{text:S("Hatırlatılacak şey"),time:S("SS:DD"),day:S("bugün/yarın")},required:["text","time"]}},
 {name:"pref_set",description:"Kullanıcının kalıcı bir tercihini kaydeder (anahtar/değer).",input_schema:{type:"object",properties:{key:S("Tercih adı"),value:S("Değer")},required:["key","value"]}}
];
window.EXTRA_TOOLS=window.EXTRA_TOOLS.concat(EXTRA);
var T=window.JSTOOLS;
T.location_info=async function(){
  var j; try{ j=await getLoc(); }catch(e){ return "Konum alınamadı: "+errT(e); }
  var addr=await revGeo(j.lat,j.lon), env=await envAt(j.lat,j.lon);
  if(j.stale) return "⚠ GÜNCEL KONUM ALINAMADI. Telefon yeni konum veremedi; elimdeki son bilinen konum "+ageText(j.age)+" önceki: "+j.lat.toFixed(5)+", "+j.lon.toFixed(5)+" (adres: "+(addr||"bulunamadı")+"). BUNU 'şu an buradasın' diye söyleme. Kullanıcıya güncel konumu alamadığını, bunun eski bir konum olduğunu açıkça söyle ve konum/GPS'i açıp açık alanda tekrar denemesini öner.";
  lastLoc.addr=addr;
  return "Konum: "+j.lat.toFixed(5)+", "+j.lon.toFixed(5)+" (doğruluk ±"+Math.round(j.acc)+" m)\nAdres: "+(addr||"bulunamadı")+"\nHız: "+Math.round(j.speed)+" km/s"+(j.bearing>=0?", yön "+Math.round(j.bearing)+"°":"")+", rakım "+Math.round(j.alt)+" m\n"+env+"\nTrafik için navigasyon başlatılırsa Google Haritalar canlı trafiği gösterir.";
};
T.nearby_places=async function(i){
  var j; try{ j=await getLoc(true); }catch(e){ return "Konum alınamadı: "+errT(e); }
  try{
    var r=await poiSearch(String(i.kind||""),j.lat,j.lon);
    if(r.err) return r.err;
    if(r.fail){
      try{ await JV.nat("tool","phone_action",JSON.stringify({action:"navigate",value:String(i.kind||"market")})); }catch(e2){}
      return "Harita verisi sunucusuna ulaşamadım ("+r.fail+"), listeyi çıkaramadım. Bunun yerine Google Haritalar'da '"+i.kind+"' aramasını açtım; yakındakileri orada görebilirsin. Bunu kullanıcıya açıkça söyle, bahane uydurma.";
    }
    if(!r.list.length) return "2 km içinde '"+i.kind+"' bulunamadı (harita verisi eksik olabilir).";
    return "2 km çevrede (OpenStreetMap verisi, çalışma saatleri yok):\n"+r.list.map(function(x){ return "- "+x.name+" — "+x.d+" m"; }).join("\n");
  }catch(e){ return "Yer araması başarısız: "+errT(e); }
};
T.set_brightness=async function(i){ try{ return await np("setBrightness",isNaN(parseInt(i.percent,10))?50:parseInt(i.percent,10)); }catch(e){ return errT(e); } };
var TVAPP={netflix:"https://www.netflix.com/title",youtube:"https://www.youtube.com"};
T.tv_control=async function(i){
  var a=String(i.action||"").toLowerCase(), v=String(i.value||"");
  try{
    if(TVAPP[a]) return await np("tv","launch",TVAPP[a]);
    if(a==="volume") return await np("tv","volume",v||"20");
    return await np("tv",a,v);
  }catch(e){ return errT(e); }
};
T.predict=async function(i){
  var q=String(i.question||""), ctx="";
  try{ ctx=await T.web_search({query:q}); }catch(e){}
  return await JV.aiText("Sen bir ön görü analiz motorusun. Konu: "+q+"\n\nGüncel veriler:\n"+String(ctx).slice(0,4000)+"\n\nŞunları kısa ve net yaz: 1) Mevcut durum, 2) Olumlu/olumsuz etkenler, 3) Tahmini ihtimal yüzdesi (bir aralık ver) ve gerekçesi, 4) Belirsizlikler. Gerçek verilerde olmayan bir şeyi uydurma; bu bir tahmindir, kesinlik değildir.",false);
};
T.network_scan=async function(){
  try{ var j=JSON.parse(await np("lanScan")); return fmtNet(j); }catch(e){ return errT(e); }
};
T.task_add=function(i){ var t=String(i.title||"").trim(); if(!t) return "Boş görev."; tasks.push({title:t,when:String(i.when||""),done:false,ts:Date.now()}); saveTasks(); return "Görev eklendi: "+t; };
T.task_list=function(){ var o=tasks.filter(function(t){ return !t.done; }); return o.length?o.map(function(t,k){ return (k+1)+". "+t.title+(t.when?" ("+t.when+")":""); }).join("\n"):"Açık görev yok."; };
T.task_done=function(i){ var k=tl(i.title||""), f=tasks.filter(function(t){ return !t.done&&tl(t.title).indexOf(k)>=0; })[0]; if(!f) return "Böyle bir açık görev bulamadım."; f.done=true; saveTasks(); return "Tamamlandı: "+f.title; };
T.reminder_add=function(i){
  var m=String(i.time||"").match(/(\d{1,2})[:.](\d{2})/); if(!m) return "Saati anlayamadım, 'SS:DD' şeklinde söyle.";
  var h=+m[1], mi=+m[2]; if(h>23||mi>59) return "Geçersiz saat.";
  var d=new Date(), now=d.getHours()*60+d.getMinutes();
  if(/yarın/i.test(String(i.day||""))||(now>h*60+mi&&!/bugün/i.test(String(i.day||"")))) d.setDate(d.getDate()+1);
  var ds=d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2);
  addReminder(String(i.text||"").slice(0,120),h,mi,ds);
  return "Hatırlatma kuruldu: "+ds+" saat "+hhmm(h,mi)+" - "+i.text+". Uygulama kapalı olsa da sesli söylerim (Otonom mod açıldı).";
};
T.pref_set=function(i){ prefs[String(i.key||"").slice(0,40)]=String(i.value||"").slice(0,120); savePrefs(); return "Tercih kaydedildi."; };

/* ================= Yasalar ================= */
function lawName(n){ return tl(n).replace(/\s*yasas[ıi]n?[ıi]?$|\s*yasa$/,"").trim(); }
function findLaw(q){ var k=lawName(q); return laws.filter(function(l){ return l.name===k; })[0]||laws.filter(function(l){ return k.indexOf(l.name)>=0||l.name.indexOf(k)>=0; })[0]; }
var deferred=[];
async function runStep(line){
  var r=null;
  try{ r=await window.OFFLINE(line); }catch(e){ return "• "+line+": "+errT(e); }
  if(r===null||r===undefined){ deferred.push(line); return "• "+line+": yapay zekaya bıraktım"; }
  return "• "+mark(r)+line+": "+r;
}
function prio(x){ x=tl(x); if(/(kilitle|tuş kilid|ekranı kapat|telefonu kapat)/.test(x)) return 3; if(/(wifi|wi-fi|wlan|bluetooth|uçak)/.test(x)) return 2; return 0; }
function sortSteps(a){ return a.map(function(x,i){ return [x,i]; }).sort(function(p,q){ return prio(p[0])-prio(q[0])||p[1]-q[1]; }).map(function(p){ return p[0]; }); }
function mark(r){ return /^(Hata|.*(bulunamadı|bulamadım|izni kapalı|anlaşılamadı|yapamam|ulaşamadım|alınamadı))/i.test(String(r))?"⚠ ":"✅ "; }
async function runLaw(l){
  var out=[]; deferred=[];
  var steps=sortSteps(l.steps);
  for(var i=0;i<steps.length;i++){ out.push(await runStep(steps[i])); await sleep(400); }
  var d=deferred.slice(); deferred=[];
  d.forEach(function(x){ setTimeout(function(){ JV.send("Telefonda şunu araçla yap: "+x); },300); });
  return "'"+l.name+"' yasası çalıştırıldı ("+steps.length+" adım).\n"+out.join("\n");
}
/* Erişilebilirlik ile hızlı ayar düğmeleri (Wi-Fi, Bluetooth, uçak modu) */
async function accessOn(){ try{ return !!JSON.parse(await JV.natX("permInfo","")).access; }catch(e){ return false; } }
async function qToggle(names,want,label){
  if(!(await accessOn())){
    if(confirm("Erişilebilirlik izni kapalı, "+label+" ayarını ben yapamam. İzin ayarını açayım mı?")){ try{ await JV.natX("openSpecial","access"); }catch(e){} }
    return "Erişilebilirlik izni kapalı. İzin merkezinden açınca "+label+" ayarını yapabilirim.";
  }
  await ptool("screen_action",{action:"quick_settings"}); await sleep(1100);
  var scr=""; try{ scr=String(await ptool("screen_read")); }catch(e){}
  var low=tl(scr), cur=null;
  names.forEach(function(n){ var k=low.indexOf(tl(n)); if(k>=0&&cur===null){ var seg=low.slice(k,k+60); if(/(kapalı|\boff\b)/.test(seg)) cur=false; else if(/(açık|\bon\b)/.test(seg)) cur=true; } });
  if(cur!==null&&cur===want){ await ptool("screen_action",{action:"back"}); return label+" zaten "+(want?"açık":"kapalı")+"."; }
  async function readState(){
    var sc=""; try{ sc=tl(String(await ptool("screen_read"))); }catch(e){}
    var c=null; names.forEach(function(n){ var k=sc.indexOf(tl(n)); if(k>=0&&c===null){ var sg=sc.slice(k,k+60); if(/(kapalı|\boff\b)/.test(sg)) c=false; else if(/(açık|\bon\b)/.test(sg)) c=true; } });
    return c;
  }
  var done=false;
  for(var i=0;i<names.length&&!done;i++){ var r=String(await ptool("screen_click",{text:names[i]})); if(/^Tıklandı/.test(r)) done=true; }
  if(!done){ await ptool("screen_action",{action:"back"}); return label+" düğmesini hızlı ayarlarda bulamadım."; }
  await sleep(700);
  var after=await readState();
  if(after!==null&&after!==want){ await ptool("screen_click",{text:names[0]}); await sleep(600); after=await readState(); }
  await ptool("screen_action",{action:"back"});
  if(after===want) return label+(want?" açıldı":" kapatıldı")+" (doğrulandı).";
  if(after===null) return label+" düğmesine dokundum ama son durumunu ekrandan doğrulayamadım.";
  return label+" istediğin duruma gelmedi, kontrol et.";
}
function normNum(t){
  return String(t).replace(/\bsıfır\b/gi,"0").replace(/\byarım\b/gi,"50").replace(/\by[üu]zde\s*(\d+)/gi,"$1").replace(/\b(parlaklı[ğg][ıi]?|ses[i]?)\s+(full|son|maksimum|max|tam)\b/gi,function(m,a){ return a+" 100"; }).replace(/parlaklı[ğg][ıi]/gi,"parlaklık");
}
function splitSteps(s){ return String(s).split(/[,;\n]|\s+ve\s+|\s+ardından\s+/i).map(function(x){ return x.trim(); }).filter(Boolean); }
T.law_save=function(i){
  var raw=i.steps||i.content||i.commands||i.actions||i.adimlar||"";
  if(Array.isArray(raw)) raw=raw.join(", ");
  var n=lawName(i.name||i.title||i.ad||""), st=splitSteps(String(raw).replace(/[•·]/g,",")); if(!n||!st.length) return "Ad ve adımlar gerekli.";
  var ex=laws.filter(function(l){ return l.name===n; })[0]; if(ex) ex.steps=st; else{ ex={name:n,steps:st}; laws.push(ex); }
  var tr=i.trigger&&typeof i.trigger==="object"?i.trigger:parseTrig(i.trigger||i.when||i.tetikleyici||""), tm="";
  if(tr){ ex.trigger=tr; tm=" Tetikleyici: "+trigText(tr)+"."+trigNote(tr); }
  saveLaws(); return "'"+n+"' yasası kaydedildi ("+st.length+" adım)."+tm+" Ayarlar > Yasalar'dan görebilirsin.";
};
/* ---- tetikleyiciler: saat / şarj / wifi / pil ---- */
var DAYS=["pazar","pazartesi","salı","çarşamba","perşembe","cuma","cumartesi"];
function parseTrig(x){
  var t=tl(normNum(String(x||""))).replace(/[.!?]+$/g,""), m;
  if(!t) return null;
  if(/şarj/.test(t)&&/(çek|ayır|sök|kop|bitince|çıkar)/.test(t)) return {type:"charge",on:false};
  if(/şarj/.test(t)&&/(tak|bağla|başla|konunca|koyunca|bağlan)/.test(t)) return {type:"charge",on:true};
  if((m=t.match(/pil[^0-9]{0,20}(?:%\s*)?(\d{1,2})/))||(m=t.match(/(?:%\s*)?(\d{1,2})[^0-9]{0,12}(?:altına|altında|düşünce|inince)/))) return {type:"battery",below:Math.min(99,Math.max(1,+m[1]))};
  if(/wi-?fi|kablosuz|ağ[ıa]/.test(t)){
    var on=!/(ayrılın|kopun|çıkın|bağlantı kesil|kesilin|ayrıl)/.test(t);
    var ss=t.replace(/wi-?fi|kablosuz/g," ").replace(/\b(ağına|ağından|ağı|ağ|bağlanınca|bağlandığında|bağlanırsa|ayrılınca|ayrılırsa|kopunca|kesilince|çıkınca|çıkınca|bağlantısı|bağlantı|olunca|olursa|yasasını|çalıştır|ayrılınca)\b/g," ").replace(/\s+/g," ").trim();
    var orig=String(x).replace(/wi-?fi|kablosuz/ig," ").replace(/(bağlantı[a-zıüöşçğ]*|bağlan[a-zıüöşçğ]*|ayrıl[a-zıüöşçğ]*|kesil[a-zıüöşçğ]*|kop[a-zıüöşçğ]*|çık[a-zıüöşçğ]*|ağ[a-zıüöşçğ]*|ol(unca|ursa)|çalıştır[a-zıüöşçğ]*|aktif[a-zıüöşçğ]*|uygula[a-zıüöşçğ]*|başlat[a-zıüöşçğ]*|tetikle[a-zıüöşçğ]*|yasa[a-zıüöşçğ]*|olsun|yap)/ig," ").replace(/\s+/g," ").trim();
    return {type:"wifi",on:on,ssid:orig||ss||""};
  }
  if(/(varınca|gelince|girince|ulaşınca|çıkınca|ayrılınca|uzaklaşınca|vardığımda|çıktığımda|ayrıldığımda|geldiğimde)/.test(t)&&!/(saat|\d\s*[:.]\s*\d)/.test(t)){
    var leave=/(çıkınca|ayrılınca|uzaklaşınca|çıktığımda|ayrıldığımda)/.test(t), pl="";
    var keys=Object.keys(places).concat(["ev","iş","okul","yurt","spor","işyeri","ofis","market"]);
    t.split(/[\s,]+/).forEach(function(w){ if(pl) return; keys.forEach(function(k){ if(!pl&&k&&w.indexOf(k)===0&&w.length<=k.length+4) pl=k; }); });
    if(!pl){ var w0=(t.split(/[\s,]+/)[0]||"").replace(/(ye|ya|den|dan|ten|tan|e|a)$/,""); pl=w0; }
    if(pl) return {type:"geo",place:pl,on:!leave};
  }
  if((m=t.match(/(?:saat\s*)?(\d{1,2})\s*[:.]\s*(\d{2})/))||(m=t.match(/saat\s*(\d{1,2})\b/))){
    var h=+m[1], mi=m[2]?+m[2]:0; if(h>23||mi>59) return null;
    var days=[];
    if(/hafta\s*içi/.test(t)) days=[1,2,3,4,5]; else if(/hafta\s*sonu/.test(t)) days=[6,0];
    else DAYS.forEach(function(d,k){ if(t.indexOf(d)>=0) days.push(k); });
    return {type:"time",h:h,m:mi,days:days};
  }
  return null;
}
function trigText(tr){
  if(!tr) return "";
  if(tr.type==="charge") return tr.on?"şarja takılınca":"şarjdan çekilince";
  if(tr.type==="battery") return "pil %"+tr.below+" altına inince";
  if(tr.type==="wifi") return (tr.ssid?tr.ssid+" ":"")+"Wi-Fi'ye "+(tr.on?"bağlanınca":"bağlantı kesilince");
  if(tr.type==="geo") return tr.place+(tr.on?" konumuna varınca":" konumundan çıkınca");
  if(tr.type==="time"){
    var d=tr.days||[], ds=!d.length?"her gün":(d.join()==="1,2,3,4,5"?"hafta içi":(d.join()==="6,0"?"hafta sonu":d.map(function(k){ return DAYS[k]; }).join(", ")));
    return ds+" "+hhmm(tr.h,tr.m);
  }
  return "";
}
function trigNote(tr){
  var n=" Otonom mod açıldı.";
  if(!modes.auto){ modes.auto=true; saveModes(); }
  if(tr.type==="wifi") n+=" (Wi-Fi adını okumak için konum izni gerekir.)";
  if(tr.type==="geo"){
    n+=" (Arka plan konum izni gerekir: Ayarlar > Uygulamalar > Jarvis > İzinler > Konum > 'Her zaman izin ver'.)";
    if(!places[tr.place]) n+=" '"+tr.place+"' yeri henüz kayıtlı değil: o yerdeyken 'burayı "+tr.place+" olarak kaydet' de.";
  }
  return n;
}
T.law_run=async function(i){ var l=findLaw(i.name||""); return l?await runLaw(l):"Böyle bir yasa yok. Kayıtlılar: "+laws.map(function(x){ return x.name; }).join(", "); };
T.place_save=async function(i){
  var n=tl(String(i.name||"")).replace(/\s+/g," ").trim(); if(!n) return "Yer adı gerekli (örn. ev, iş).";
  var j; try{ j=await getLoc(true); }catch(e){ return "Yeri kaydedemedim: "+errT(e); }
  places[n]={lat:j.lat,lon:j.lon,r:i.radius||200}; savePlaces();
  return "'"+n+"' yeri bu konum olarak kaydedildi ("+j.lat.toFixed(4)+", "+j.lon.toFixed(4)+"), yarıçap "+places[n].r+" m. Artık 'saman yasasını "+n+"e varınca çalıştır' diyebilirsin.";
};
T.law_list=function(){ return laws.length?laws.map(function(l){ return "• "+l.name+": "+l.steps.join(", "); }).join("\n"):"Kayıtlı yasa yok."; };

/* ================= Modlar ================= */
var MODEINFO={
 agent:{n:"Ajan modu",say:"Ajan modu açık efendim. Mikrofonu sürekli dinliyorum ve söylediğin her şeyi yerine getiriyorum. Kapatmak için ajan modunu kapat de. Uygulama açık ve ekran açıkken çalışır."},
 hacker:{n:"Hacker modu",say:"Hacker modu açık. Ağ radarı: kendi Wi-Fi ağındaki cihazları listeler. Cihaz tarayıcı: seçtiğin cihazın IP ve açık portlarını gösterir. Konum terminali: canlı konumunu terminalde akıtır. Sadece kendi ağında kullan."},
 auto:{n:"Otonom mod",say:"Otonom mod açık. Hangi uygulamada olursan ol arka planda pili, ısıyı, depolamayı ve interneti izlerim. Sorun çıkarsa ya da hatırlatma saati gelirse sana sesli söylerim ve bildirim gönderirim. Sessiz saatleri Ayarlar bölümünden değiştirebilirsin."},
 gps:{n:"GPS radarı",say:"GPS radarı açık. Canlı konumunu, hızını, adresini, hava durumunu gösterir, yakındaki eczane, benzin gibi yerleri bulur ve navigasyon başlatırım."},
 tv:{n:"TV kontrolü",say:"TV kontrolü hazır. Televizyonu aç kapat, Netflix ya da YouTube aç, sesi yüzde olarak ayarla diyebilirsin. İlk seferde eşleştirme gerekir."},
 system:{n:"Sistem yöneticisi",say:"Sistem yöneticisi açık. Pil, depolama ve sistem durumunu sürekli izler, sorun olursa haber veririm."},
 laws:{n:"Yasalar",say:"Yasalar bölümü açık. Kendi rutinlerini adlandırıp kaydedebilirsin, örneğin saman yasası. Sonra yasanın adını söyleyip aktif et demen yeterli."}
};
function modeKey(s){
  s=tl(s);
  if(/ajan/.test(s)) return "agent"; if(/hacker|haker/.test(s)) return "hacker"; if(/otonom/.test(s)) return "auto";
  if(/gps|radar|konum/.test(s)) return "gps"; if(/\btv\b|televizyon/.test(s)) return "tv"; if(/sistem/.test(s)) return "system"; if(/yasa/.test(s)) return "laws";
  return null;
}
function wset(){ var w=lsGet("jv_watch",{}); return {voice:w.voice!==false,qs:w.qs==null?23:w.qs,qe:w.qe==null?7:w.qe,off:w.off!==false,low:w.low||20}; }
function watchCfg(){
  var today=new Date(), ds=today.getFullYear()+"-"+("0"+(today.getMonth()+1)).slice(-2)+"-"+("0"+today.getDate()).slice(-2);
  var rules=(lsGet("jv_rules",[])).filter(function(r){ return !r.date||r.date>=ds; });
  lsSet("jv_rules",rules);
  var w=wset();
  return JSON.stringify({low:w.low,voice:w.voice,qs:w.qs,qe:w.qe,off:w.off,rules:rules});
}
function addReminder(text,h,m,date){
  var rules=lsGet("jv_rules",[]); rules.push({id:"r"+Date.now(),h:h,m:m,text:"Hatırlatma: "+text,date:date||""});
  lsSet("jv_rules",rules); if(!modes.auto){ modes.auto=true; saveModes(); } syncWatch();
}
function hhmm(h,m){ return ("0"+h).slice(-2)+":"+("0"+m).slice(-2); }
function syncWatch(){
  var on=!!(modes.auto||modes.system);
  if(P){ try{ P.watch(on,on?watchCfg():""); }catch(e){} }
}
async function setMode(k,on){
  modes[k]=on; saveModes();
  var info=MODEINFO[k];
  if(k==="agent"){ on?agentStart():agentStop(); }
  if(k==="auto"||k==="system") syncWatch();
  if(on){
    if(k==="hacker") openHack(); if(k==="gps") openGps(); if(k==="tv") openTv(); if(k==="laws") openLaws();
    if(k==="system"){ try{ var s=await ptool("get_device_status"); return info.say+"\nŞu an: "+s; }catch(e){} }
    return info.say;
  }
  return info.n+" kapatıldı.";
}
T.set_mode=async function(i){ var k=modeKey(i.mode||""); if(!k) return "Böyle bir mod yok."; return await setMode(k,String(i.on).toLowerCase()!=="false"); };

/* ----- Ajan modu ----- */
var agent={on:false,timer:0,said:""};
function agentStart(){
  agent.on=true; clearInterval(agent.timer);
  try{ if(P&&P.keepAwake) P.keepAwake(true); }catch(e){}
  agent.timer=setInterval(function(){
    if(!agent.on) return;
    if(!JV.isBusy()&&!JV.isSpeaking()&&!JV.isListening()) JV.startListen();
  },500);
  setTimeout(function(){ if(agent.on&&!JV.isSpeaking()) JV.startListen(); },300);
}
function agentStop(){ agent.on=false; clearInterval(agent.timer); try{ if(P&&P.keepAwake) P.keepAwake(false); }catch(e){} JV.stopListen(); modes.agent=false; saveModes(); }
var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd;
window.JV_onSpeech=function(t,final){
  if(agent.on){
    if(!final){ $("txt").value=t; return true; }
    $("txt").value="";
    if(/ajan mod(unu|u)?\s*(kapat|bitir|durdur|iptal)/i.test(tl(t))){ agentStop(); JV.say("Ajan modu kapatıldı efendim."); return true; }
    if(String(t).trim().length>=4) JV.send(t);
    return true;
  }
  return prevS?prevS(t,final):false;
};
window.JV_onListenEnd=function(err){
  if(agent.on){
    if(err===9||err===100){ agentStop(); toast("Ajan modu: mikrofon/ses tanıma kullanılamıyor"); return true; }
    // sessizlik / eşleşme yok / meşgul: mikrofonu hemen yeniden aç, hiç kapalı kalmasın
    setTimeout(function(){ if(agent.on&&!JV.isBusy()&&!JV.isSpeaking()&&!JV.isListening()) JV.startListen(); },err===8?700:120);
    return true;
  }
  return prevE?prevE(err):false;
};

/* ================= TV sayfası ================= */
mkPage("pTv",
 '<div class="ph"><button class="ib" data-close>←</button><h2>TELEVİZYON</h2></div>'+
 '<div class="pb"><div id="tvSt" class="sec"></div>'+
 '<div class="sec"><h3>Eşleştirme (bir kez)</h3><div style="font-size:12px;color:var(--dim)">Telefon ve TV aynı Wi-Fi\'da olsun, TV açık olsun.</div>'+
 '<div class="pbtn"><button class="btn" id="tvFind">TV\'Yİ BUL</button></div><div id="tvList"></div>'+
 '<input class="inp" id="tvIp" placeholder="TV IP adresi (örn. 192.168.1.20)"><button class="btn" id="tvPair" style="width:100%">EŞLEŞMEYİ BAŞLAT</button>'+
 '<input class="inp" id="tvCode" placeholder="TV\'de çıkan 6 karakterli kod" maxlength="6"><button class="btn" id="tvOk" style="width:100%">KODU ONAYLA</button></div>'+
 '<div class="sec"><h3>Dene</h3><div class="pbtn"><button class="btn" data-tv="power_on">AÇ</button><button class="btn" data-tv="power_off">KAPAT</button><button class="btn" data-tv="vol_up">SES +</button><button class="btn" data-tv="vol_down">SES −</button><button class="btn" data-tv="mute">SESSİZ</button><button class="btn" data-tv="netflix">NETFLIX</button><button class="btn" data-tv="youtube">YOUTUBE</button><button class="btn" data-tv="home">ANA SAYFA</button></div>'+
 '<button class="btn red" id="tvForget" style="width:100%">EŞLEŞMEYİ UNUT</button></div><div id="tvMsg" style="font-size:13px;color:var(--c2);white-space:pre-wrap"></div></div>');
function tvStatus(){
  var s={}; try{ s=JSON.parse(P.tvStatus()); }catch(e){}
  $("tvSt").innerHTML='<h3>Durum</h3><div class="pl">'+(s.host?("Kayıtlı TV: <b>"+esc(s.host)+"</b>"+(s.paired?" · eşleşmiş ✅":" · eşleşme bekliyor")):"Kayıtlı televizyon yok")+'</div>';
  if(s.host&&!$("tvIp").value) $("tvIp").value=s.host;
}
function tvMsg(t){ $("tvMsg").textContent=t; }
function openTv(){ openPage("pTv"); if(P) tvStatus(); }
$("tvFind").onclick=async function(){
  tvMsg("Ağda aranıyor (10 sn kadar)…");
  try{
    var a=JSON.parse(await np("tvFind"));
    $("tvList").innerHTML=a.length?a.map(function(ip){ return '<div class="pl" data-ip="'+ip+'">📺 '+ip+' <small>dokun: seç</small></div>'; }).join(""):'<div class="pl">Ağda Android/Google TV bulunamadı. TV açık ve aynı Wi-Fi\'da mı?</div>';
    $("tvList").querySelectorAll("[data-ip]").forEach(function(d){ d.onclick=function(){ $("tvIp").value=d.getAttribute("data-ip"); }; });
    tvMsg(a.length?"Bulundu: "+a.join(", "):"Bulunamadı.");
  }catch(e){ tvMsg(errT(e)); }
};
$("tvPair").onclick=async function(){
  var ip=$("tvIp").value.trim(); if(!ip){ tvMsg("Önce IP gir ya da TV'yi bul."); return; }
  tvMsg("Eşleşme başlatılıyor… TV ekranında kod çıkmalı.");
  try{ await np("tvPairStart",ip); tvMsg("TV'de çıkan kodu aşağı yaz ve onayla."); }catch(e){ tvMsg(errT(e)); }
};
$("tvOk").onclick=async function(){
  try{ await np("tvPairFinish",$("tvCode").value); tvMsg("✅ Eşleşti! Artık 'televizyonu aç' diyebilirsin."); tvStatus(); }catch(e){ tvMsg(errT(e)); }
};
$("tvForget").onclick=function(){ try{ P.tvForget(); }catch(e){} tvStatus(); tvMsg("Unutuldu."); };
$("pTv").querySelectorAll("[data-tv]").forEach(function(b){ b.onclick=async function(){ tvMsg("…"); tvMsg(await T.tv_control({action:b.getAttribute("data-tv")})); }; });

/* ================= GPS sayfası ================= */
mkPage("pGps",
 '<div class="ph"><button class="ib" data-close>←</button><h2>GPS RADARI</h2></div>'+
 '<div class="pb"><canvas id="plc" width="600" height="440"></canvas><div class="sec" id="gInfo" style="margin-top:10px">Konum alınıyor…</div>'+
 '<div class="pbtn"><button class="btn" data-poi="eczane">💊 ECZANE</button><button class="btn" data-poi="benzin">⛽ BENZİN</button><button class="btn" data-poi="market">🛒 MARKET</button><button class="btn" data-poi="hastane">🏥 HASTANE</button><button class="btn" data-poi="atm">🏧 ATM</button><button class="btn" data-poi="şarj">🔌 ŞARJ</button></div>'+
 '<div class="sec"><h3>Navigasyon</h3><input class="inp" id="gDest" placeholder="Nereye gidelim?"><button class="btn" id="gNav" style="width:100%">YOL TARİFİ BAŞLAT</button></div><div id="gPoi"></div></div>',
 function(){ gps.on=false; });
var gps={on:false,pts:[],poi:[],last:null,addrAt:0,envAt:0,env:"",sweep:0,raf:0};
function openGps(){ openPage("pGps"); gps.on=true; gpsTick(); gpsDraw(); }
async function gpsTick(){
  if(!gps.on) return;
  try{
    var j=await getLoc(); gps.last=j;
    gps.pts.push([j.lat,j.lon]); if(gps.pts.length>40) gps.pts.shift();
    if(Date.now()-gps.addrAt>40000){ gps.addrAt=Date.now(); revGeo(j.lat,j.lon).then(function(a){ lastLoc.addr=a; gps.addr=a; }); }
    if(Date.now()-gps.envAt>300000){ gps.envAt=Date.now(); envAt(j.lat,j.lon).then(function(e){ gps.env=e; }); }
    $("gInfo").innerHTML='<div class="kv"><span>Koordinat</span><b>'+j.lat.toFixed(5)+', '+j.lon.toFixed(5)+'</b></div><div class="kv"><span>Hız / Yön</span><b>'+Math.round(j.speed)+' km/s'+(j.bearing>=0?' · '+Math.round(j.bearing)+'°':'')+'</b></div><div class="kv"><span>Doğruluk / Rakım</span><b>±'+Math.round(j.acc)+' m · '+Math.round(j.alt)+' m</b></div><div style="font-size:13px;margin-top:8px">'+esc(gps.addr||"Adres aranıyor…")+'</div><div style="font-size:12px;color:var(--dim);margin-top:6px">'+esc(gps.env||"")+'</div>';
  }catch(e){ $("gInfo").textContent=errT(e); }
  if(gps.on) setTimeout(gpsTick,5000);
}
function gpsDraw(){
  if(!gps.on) return;
  var c=$("plc"), g=c.getContext&&c.getContext("2d"); if(!g) return;
  var W=c.width,H=c.height,cx=W/2,cy=H/2,R=Math.min(W,H)/2-14, col=JV.colors()[0];
  g.clearRect(0,0,W,H); g.strokeStyle=col; g.globalAlpha=.35; g.lineWidth=1;
  for(var r=1;r<=3;r++){ g.beginPath(); g.arc(cx,cy,R*r/3,0,7); g.stroke(); }
  g.beginPath(); g.moveTo(cx-R,cy); g.lineTo(cx+R,cy); g.moveTo(cx,cy-R); g.lineTo(cx,cy+R); g.stroke();
  gps.sweep+=0.04; g.globalAlpha=.5; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+Math.cos(gps.sweep)*R,cy+Math.sin(gps.sweep)*R); g.stroke();
  g.globalAlpha=1; g.fillStyle=col; g.font="11px monospace"; g.fillText("500 m",cx+R/3+2,cy-2); g.fillText("1 km",cx+2*R/3+2,cy-2); g.fillText("2 km",cx+R-30,cy-2);
  var L=gps.last;
  if(L){
    g.fillStyle="#fff"; g.beginPath(); g.arc(cx,cy,5,0,7); g.fill();
    if(L.bearing>=0){ var a=(L.bearing-90)*Math.PI/180; g.strokeStyle="#fff"; g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+Math.cos(a)*24,cy+Math.sin(a)*24); g.stroke(); }
    gps.poi.forEach(function(p){
      var dy=(p.lat-L.lat)*111320, dx=(p.lon-L.lon)*111320*Math.cos(L.lat*Math.PI/180), sc=R/2000;
      var x=cx+dx*sc, y=cy-dy*sc; g.fillStyle="#ff9b3d"; g.beginPath(); g.arc(x,y,4,0,7); g.fill(); g.fillText(String(p.name).slice(0,14),x+6,y+3);
    });
  }
  gps.raf=requestAnimationFrame(gpsDraw);
}
$("pGps").querySelectorAll("[data-poi]").forEach(function(b){ b.onclick=async function(){
  var box=$("gPoi"); box.innerHTML='<div class="pl">Aranıyor…</div>';
  try{
    var j=gps.last||await getLoc(); var r=await poiSearch(b.getAttribute("data-poi"),j.lat,j.lon);
    if(r.err){ box.innerHTML='<div class="pl">'+esc(r.err)+'</div>'; return; }
    gps.poi=r.list; box.innerHTML=r.list.length?r.list.map(function(x){ return '<div class="pl">'+esc(x.name)+'<small>'+x.d+' m</small></div>'; }).join(""):'<div class="pl">2 km içinde bulunamadı.</div>';
  }catch(e){ box.innerHTML='<div class="pl">'+esc(errT(e))+'</div>'; }
}; });
$("gNav").onclick=async function(){ var d=$("gDest").value.trim(); if(!d) return; toast(await ptool("phone_action",{action:"navigate",value:d})); };

/* ================= Hacker / Ağ sayfası ================= */
mkPage("pHack",
 '<div class="ph"><button class="ib" data-close>←</button><h2>HACKER MODU</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Sadece kendi ağında ve kendi cihazlarında kullan.</div>'+
 '<div class="pbtn"><button class="btn" id="hkNet">📡 AĞ RADARI</button><button class="btn" id="hkDev">🔎 CİHAZ TARA</button><button class="btn" id="hkLoc">🛰 KONUM TERMİNALİ</button></div>'+
 '<input class="inp" id="hkIp" placeholder="Cihaz IP (cihaz taramak için)"><div class="term" id="hkOut">> hazır_</div></div>',
 function(){ hk.loc=false; });
var hk={loc:false,last:null};
function openHack(){ openPage("pHack"); }
function guess(d){
  var p=d.ports||[], has=function(x){ return p.indexOf(x)>=0; };
  if(has(6466)||has(8009)||has(8008)) return "Android/Google TV ya da Chromecast";
  if(has(62078)) return "iPhone/iPad olabilir";
  if(has(5555)) return "Android (ADB açık)";
  if(has(554)) return "IP kamera olabilir";
  if(has(53)&&(has(80)||has(443))) return "Modem/yönlendirici olabilir";
  if(has(445)) return "Bilgisayar/NAS olabilir";
  if(has(22)) return "SSH'li cihaz (Linux/Pi)";
  if(has(1900)) return "UPnP cihazı (TV/yazıcı/router)";
  if(has(80)||has(443)||has(8080)) return "Web arayüzlü cihaz";
  return "Bilinmeyen cihaz";
}
function fmtNet(j){
  var d=j.devices||[]; hk.last=j;
  return "Ağ: "+(j.ssid||"?")+" · benim IP'm "+j.me+" · "+d.length+" cihaz\n"+d.map(function(x){ return "- "+x.ip+(x.name?" ("+x.name+")":"")+" → "+guess(x)+(x.ports.length?" [portlar: "+x.ports.join(",")+"]":""); }).join("\n");
}
function hkOut(t,append){ var o=$("hkOut"); o.textContent=append?o.textContent+t+"\n":t; o.scrollTop=o.scrollHeight; }
$("hkNet").onclick=async function(){
  hk.loc=false; hkOut("> ağ taranıyor… (10-30 sn)");
  try{ hkOut("> tamam\n"+fmtNet(JSON.parse(await np("lanScan")))); }catch(e){ hkOut("> hata: "+errT(e)); }
};
$("hkDev").onclick=async function(){
  hk.loc=false; var ip=$("hkIp").value.trim(); if(!ip){ hkOut("> önce IP gir (ağ radarından)"); return; }
  hkOut("> "+ip+" taranıyor…");
  try{
    var j=JSON.parse(await np("lanScan")), d=(j.devices||[]).filter(function(x){ return x.ip===ip; })[0];
    hkOut(d?("> IP: "+d.ip+"\n> Ad: "+(d.name||"-")+"\n> Açık portlar: "+(d.ports.join(", ")||"yok (cihaz ping'e açık)")+"\n> Tahmin: "+guess(d)):"> cihaz bulunamadı (kapalı ya da farklı ağ).");
  }catch(e){ hkOut("> hata: "+errT(e)); }
};
$("hkLoc").onclick=async function(){
  if(hk.loc){ hk.loc=false; hkOut("> terminal durduruldu",true); return; }
  hk.loc=true; hkOut("> canlı konum akışı başladı (tekrar bas: durdur)");
  while(hk.loc){
    try{ var j=await getLoc(); hkOut("["+new Date().toLocaleTimeString("tr-TR")+"] LAT "+j.lat.toFixed(5)+" LON "+j.lon.toFixed(5)+" ACC "+Math.round(j.acc)+"m SPD "+Math.round(j.speed)+"km/h ALT "+Math.round(j.alt)+"m",true); }catch(e){ hkOut("> "+errT(e),true); }
    await sleep(3000);
  }
};

/* ================= Yasalar + Görevler sayfası ================= */
mkPage("pLaw",
 '<div class="ph"><button class="ib" data-close>←</button><h2>YASALAR</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Bir yasa = adı olan komut dizisi. Örn. ad: saman · adımlar: parlaklık 10, ses 100, whatsapp aç. Sohbette "saman yasasını aktif et" de.</div>'+
 '<div class="sec"><input class="inp" id="lwName" placeholder="Yasa adı (örn. saman)"><textarea class="inp" id="lwSteps" rows="3" placeholder="Adımlar, virgülle ayır: parlaklık 10, ses 100, whatsapp aç"></textarea><input class="inp" id="lwTrig" placeholder="Tetikleyici (isteğe bağlı): her gün 23:00 · şarja takınca · wifi Ev bağlanınca · pil %15 altına inince"><button class="btn" id="lwAdd" style="width:100%">KAYDET</button></div><div id="lwList"></div></div>');
function openLaws(){ openPage("pLaw"); lawRender(); }
function lawRender(){
  $("lwList").innerHTML=laws.length?laws.map(function(l,i){ return '<div class="sec"><b>'+esc(l.name)+' yasası</b><div style="font-size:13px;color:var(--dim);margin:6px 0">'+esc(l.steps.join(" → "))+'</div>'+(l.trigger?'<div style="font-size:12px;color:var(--c1,#4fd1ff);margin-bottom:6px">⚡ '+esc(trigText(l.trigger))+' · <a data-tdel="'+i+'" style="text-decoration:underline">kaldır</a></div>':'')+'<div class="pbtn"><button class="btn" data-run="'+i+'">AKTİF ET</button><button class="btn" data-edit="'+i+'">DÜZENLE</button><button class="btn red" data-del="'+i+'">SİL</button></div></div>'; }).join(""):'<div class="pl">Henüz yasa yok.</div>';
  $("lwList").querySelectorAll("[data-run]").forEach(function(b){ b.onclick=async function(){ toast("Çalışıyor…"); toast((await runLaw(laws[+b.getAttribute("data-run")])).split("\n")[0]); }; });
  $("lwList").querySelectorAll("[data-edit]").forEach(function(b){ b.onclick=function(){ var l=laws[+b.getAttribute("data-edit")]; $("lwName").value=l.name; $("lwSteps").value=l.steps.join(", "); $("lwTrig").value=l.trigger?trigText(l.trigger):""; }; });
  $("lwList").querySelectorAll("[data-tdel]").forEach(function(b){ b.onclick=function(){ delete laws[+b.getAttribute("data-tdel")].trigger; saveLaws(); lawRender(); }; });
  $("lwList").querySelectorAll("[data-del]").forEach(function(b){ b.onclick=function(){ if(confirm("Silinsin mi?")){ laws.splice(+b.getAttribute("data-del"),1); saveLaws(); lawRender(); } }; });
}
$("lwAdd").onclick=function(){ var tv=$("lwTrig").value.trim(); if(tv&&!parseTrig(tv)){ toast("Tetikleyiciyi anlayamadım. Örn: her gün 23:00"); return; } var r=T.law_save({name:$("lwName").value,steps:$("lwSteps").value,trigger:tv}); toast(r); $("lwName").value=""; $("lwSteps").value=""; $("lwTrig").value=""; lawRender(); };

mkPage("pTask",
 '<div class="ph"><button class="ib" data-close>←</button><h2>GÖREV & HAFIZA</h2></div>'+
 '<div class="pb"><div class="sec"><h3>Görevler</h3><input class="inp" id="tkNew" placeholder="Yeni görev"><button class="btn" id="tkAdd" style="width:100%">EKLE</button><div id="tkList"></div></div>'+
 '<div class="sec"><h3>Tercihler</h3><div id="prList"></div><div style="font-size:12px;color:var(--dim)">"Tercihim: ..." ya da "şunu hatırla" diyerek de eklenir.</div></div></div>');
function taskRender(){
  $("tkList").innerHTML=tasks.map(function(t,i){ return '<div class="pl" style="display:flex;gap:8px;align-items:center"><div style="flex:1;'+(t.done?'text-decoration:line-through;opacity:.5':'')+'">'+esc(t.title)+(t.when?'<small>'+esc(t.when)+'</small>':'')+'</div><button class="btn" data-tk="'+i+'" style="padding:4px 10px">'+(t.done?'↺':'✓')+'</button><button class="btn red" data-td="'+i+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="pl">Görev yok.</div>';
  $("tkList").querySelectorAll("[data-tk]").forEach(function(b){ b.onclick=function(){ var t=tasks[+b.getAttribute("data-tk")]; t.done=!t.done; saveTasks(); taskRender(); }; });
  $("tkList").querySelectorAll("[data-td]").forEach(function(b){ b.onclick=function(){ tasks.splice(+b.getAttribute("data-td"),1); saveTasks(); taskRender(); }; });
  $("prList").innerHTML=Object.keys(prefs).map(function(k){ return '<div class="pl" style="display:flex"><div style="flex:1">'+esc(k)+': <b>'+esc(prefs[k])+'</b></div><button class="btn red" data-pd="'+esc(k)+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="pl">Tercih yok.</div>';
  $("prList").querySelectorAll("[data-pd]").forEach(function(b){ b.onclick=function(){ delete prefs[b.getAttribute("data-pd")]; savePrefs(); taskRender(); }; });
}
function openTasks(){ openPage("pTask"); taskRender(); }
$("tkAdd").onclick=function(){ var v=$("tkNew").value.trim(); if(v){ T.task_add({title:v}); $("tkNew").value=""; taskRender(); } };

/* ================= Çevrimdışı komut genişletmesi ================= */
var prevOff=window.OFFLINE;
async function coreOff(text0){
  var text=normNum(text0);
  var t=tl(text).replace(/[.!?,]+$/g,"").replace(/^(hey |hay |merhaba |lütfen )*(jarvis[, ]*)?/,"").trim(), m;
  habitLog(t);
  try{
    // yasa kaydet
    if((m=t.match(/^(.+?)\s+yasas[ıi]?\s*(?:n[ıi]\s*)?(?:kaydet|oluştur|ekle|tanımla)\s*[:\-]?\s*(.+)$/)))
      return T.law_save({name:m[1],steps:m[2]});
    // yer kaydet: "burayı ev olarak kaydet", "burası evim"
    if((m=t.match(/^(?:buray[ıi]|şu an(?:ki)? konumu(?:mu)?|konumu(?:mu)?)\s+(.+?)\s+olarak\s+(?:kaydet|işaretle|ekle|belirle)$/))||(m=t.match(/^burası\s+(?:benim\s+)?(ev|iş|okul|yurt|ofis)(?:im|ım|um|üm)?$/))) return await T.place_save({name:m[1]});
    if((m=t.match(/^(.+?)(?:'?[yı]?[ıiuü]?|[ıiuü]m[ıiuü]?|ni|nı)?\s+(?:yerini\s+)?(?:sil|kaldır|unut)$/))&&Object.keys(places).some(function(k){ return t.indexOf(k)===0; })) return T.place_delete({name:m[1]});
    if(/^(kayıtlı )?yerlerim|kayıtlı yerler/.test(t)) return Object.keys(places).length?"Kayıtlı yerler: "+Object.keys(places).join(", "):"Kayıtlı yer yok. 'burayı ev olarak kaydet' de.";
    // yasaya tetikleyici bağla: "saman yasasını her gün 23:00'te çalıştır", "şarja takınca saman yasasını çalıştır"
    if(/yasa/.test(t)&&laws.length&&/(her\s*gün|hafta\s*(içi|sonu)|\d{1,2}\s*[:.]\s*\d{2}|saat\s*\d|şarj|wi-?fi|pil|varınca|gelince|çıkınca|ayrılınca|girince)/.test(t)&&/(çalıştır|aktif|uygula|başlat|olsun|yap|bağla|tetikle)/.test(t)&&!/(tetikleyici[a-zıöüşçğ]*\s*(sil|kaldır|iptal))/.test(t)){
      var lt=laws.filter(function(x){ return t.indexOf(x.name)>=0; })[0];
      if(lt){ var tr0=parseTrig(t.replace(lt.name,"").replace(/yasas[ıi]?n?[ıi]?/g," ")); if(tr0){ lt.trigger=tr0; saveLaws(); return "Tamam. '"+lt.name+"' yasası "+trigText(tr0)+" otomatik çalışacak."+trigNote(tr0)+" Riskli/ekran gerektiren adımlar için bildirimle sorarım."; } }
    }
    if(/tetikleyici/.test(t)&&/(sil|kaldır|iptal)/.test(t)){ var ld=laws.filter(function(x){ return t.indexOf(x.name)>=0&&x.trigger; })[0]; if(ld){ delete ld.trigger; saveLaws(); return "'"+ld.name+"' yasasının tetikleyicisi kaldırıldı."; } }
    // yasa aktif et
    if(/yasa/.test(t)&&/(aktif|çalıştır|başlat|uygula|devreye|etkinleştir|\baç\b|aç$|getir|yap$)/.test(t)){
      var l=laws.filter(function(x){ return t.indexOf(x.name)>=0; })[0];
      if(l) return await runLaw(l);
      if(/yasa/.test(t)&&laws.length&&t.split(/\s+/).length<7) return "Böyle bir yasa bulamadım. Kayıtlılar: "+laws.map(function(x){ return x.name; }).join(", ");
    }
    if(/^yasalar(ı)?( listele| neler| göster)?$/.test(t)) return T.law_list();
    // modlar
    if((m=t.match(/^(.+?)\s*mod(?:unu|u|a)?\s*(aç|kapat|başlat|devreye al|bitir|durdur)$/))){
      var k=modeKey(m[1]); if(k) return await setMode(k,!/(kapat|bitir|durdur)/.test(m[2]));
    }
    if((m=t.match(/^(ajan|hacker|haker|otonom|sistem yöneticisi)\s*(aç|kapat|başlat)$/))){ var k2=modeKey(m[1]); if(k2) return await setMode(k2,m[2]!=="kapat"); }
    // hızlı ayarlar: wifi / bluetooth / uçak modu / ekran kilidi
    if(/(wifi|wi-fi|wlan|kablosuz)/.test(t)&&/(aç|kapat|söndür)/.test(t)&&!/ayar/.test(t)) return await qToggle(["Wi-Fi","WLAN","WiFi"],!/(kapat|söndür)/.test(t),"Wi-Fi");
    if(/bluetooth/.test(t)&&/(aç|kapat)/.test(t)&&!/ayar/.test(t)) return await qToggle(["Bluetooth"],!/kapat/.test(t),"Bluetooth");
    if(/uçak/.test(t)&&/(aç|kapat|ayarlardan)/.test(t)){
      var want=!/kapat/.test(t); var rr=await qToggle(["Uçak modu","Uçak","Airplane"],want,"Uçak modu");
      if(/bulamadım|izni kapalı/.test(rr)) await ptool("phone_action",{action:"open_settings",value:"airplane"});
      return rr;
    }
    // ekranı kilitle (yan tuşa basmış gibi)
    if(/^(ekranı|telefonu|cihazı)?\s*(kilitle|kilitlensin)$|^(tuş kilidi|tuş kilidini)\s*(kapat|aç|bas|devreye al|aktif et)?$|^(ekranı|telefonu)\s*kapat$|^(ekranı|telefonu)\s*uyut$|^kilit tuşuna bas$/.test(t)){
      if(!(await accessOn())){
        if(confirm("Erişilebilirlik izni kapalı, ekranı kilitleyemem. İzin ayarını açayım mı?")){ try{ await JV.natX("openSpecial","access"); }catch(e){} }
        return "Erişilebilirlik izni kapalı, ekranı kilitleyemedim.";
      }
      await ptool("screen_action",{action:"lock"}); return "Ekran kilitlendi.";
    }
    // telefonu sessize al
    if(/(sessize|sessiz mod|sessiz yap|sesi kapat|sesini kapat)/.test(t)&&!/(televizyon|\btv\b)/.test(t)) return await ptool("phone_action",{action:"volume_mute"});
    if(/(tuş kilidi|ekran kilidi|kilit ekranı)/.test(t)&&/(kaldır|devre dışı|şifre|ayar)/.test(t)){
      await ptool("phone_action",{action:"open_settings",value:"security"});
      return "Güvenlik ayarlarını açtım. Ekran kilidini kapatmak için PIN/parolayı senin girmen gerekiyor, bunu Android uygulamalara bırakmıyor.";
    }
    // parlaklık
    if(/parlakl/.test(t)&&(m=t.match(/(\d{1,3})/))) return await T.set_brightness({percent:m[1]});
    if(/parlakl/.test(t)&&/(kıs|düşür|azalt)/.test(t)) return await T.set_brightness({percent:20});
    if(/parlakl/.test(t)&&/(artır|yükselt|aç|full|son)/.test(t)) return await T.set_brightness({percent:100});
    // telefon sesi full
    if(/^(ses|sesi)\s*(full|son|max|tam|sonuna kadar)(\s*(yap|aç))?$/.test(t)) return await ptool("phone_action",{action:"volume_set",value:"100"});
    // TV
    if(/(televizyon|\btv\b)/.test(t)){
      if(/netflix/.test(t)) return await T.tv_control({action:"netflix"});
      if(/youtube|yutup/.test(t)) return await T.tv_control({action:"youtube"});
      if((m=t.match(/(\d{1,3})/))&&/ses/.test(t)) return await T.tv_control({action:"volume",value:m[1]});
      if(/ses/.test(t)&&/(kıs|azalt|düşür)/.test(t)) return await T.tv_control({action:"vol_down",value:"5"});
      if(/ses/.test(t)&&/(aç|artır|yükselt)/.test(t)) return await T.tv_control({action:"vol_up",value:"5"});
      if(/(sessiz|sustur)/.test(t)) return await T.tv_control({action:"mute"});
      if(/(kapat|söndür)/.test(t)) return await T.tv_control({action:"power_off"});
      if(/(aç|çalıştır|yak)/.test(t)) return await T.tv_control({action:"power_on"});
    }
    if(/^(netflix|youtube)\s*(aç)?\s*(televizyonda|tvde|tv'de|tv'de)$/.test(t)) return await T.tv_control({action:/netflix/.test(t)?"netflix":"youtube"});
    // sesli hatırlatma: "saat 18:30'da su iç diye hatırlat"
    if((m=t.match(/(?:saat\s*)?(\d{1,2})[:.](\d{2})(?:\s*['’]?(?:da|de|ta|te))?\s+(.+?)\s*(?:diye\s*)?hatırlat(?:ır mısın|sana)?$/))&&!/yasa/.test(t)) return T.reminder_add({time:m[1]+":"+m[2],text:m[3],day:/yarın/.test(t)?"yarın":""});
    // görev
    if((m=t.match(/^(?:görev|yapılacak)\s*(?:ekle\s*)?[:\-]\s*(.+)$/)||t.match(/^(?:görev|yapılacak) ekle\s+(.+)$/))) return T.task_add({title:m[1]});
    if(/^(görevlerim|görevleri (listele|göster)|yapılacaklar)$/.test(t)) return T.task_list();
    if((m=t.match(/^(.+?)\s+görevini\s+(?:tamamla|bitir|yaptım)$/))) return T.task_done({title:m[1]});
    // konum / çevre (ağ gerektirmeyen kısa yollar)
    if(/^(neredeyim|konumum( ne| neresi)?|şu an neredeyim)$/.test(t)) return await T.location_info();
    if((m=t.match(/^(?:en yakın|yakındaki|yakın)\s+(eczane|benzin( istasyonu)?|market|hastane|atm|kafe|restoran|banka|otopark|fırın)/))) return await T.nearby_places({kind:m[1]});
    if(/^(gps|radar|ağ radarı)\s*(aç)?$/.test(t)){ openGps(); return "GPS radarı açıldı."; }
    if(/^(ağı tara|ağdaki cihazlar|ağ radarı)$/.test(t)) return await T.network_scan();
  }catch(e){ return "Hata: "+errT(e); }
  return prevOff?prevOff(text):null;
}
/* ---- Çoklu görev: tek cümledeki birden fazla komutu parçala ve sırayla yap ---- */
var ACT_PART=/(aç\b|aç$|kapat|kıs\b|kilitle|sessiz|alarm|sayaç|zamanlayıcı|\bara$|yasa|parlakl|\bses|wifi|wi-fi|bluetooth|uçak|fener|televizyon|\btv\b|başlat|oynat|durdur|ayarla|yap$)/;
function splitCmd(text){
  var raw=String(text||"").trim(); if(raw.length>220||/yasas[ıi]?\s*(kaydet|oluştur|ekle)/i.test(raw)) return null;
  var parts=raw.split(/\s*(?:,|;|\bve\b|\bsonra\b|\bardından\b|\bbide\b|\bbir de\b|\bayrıca\b)\s*/i).map(function(x){ return x.trim(); }).filter(function(x){ return x.length>2; });
  return parts.length>=2?parts:null;
}
window.splitCmd=function(t){ var p=splitCmd(t); return p&&p.every(function(x){ return ACT_PART.test(tl(x)); })?p:null; };
window.OFFLINE=async function(text0){
  var parts=splitCmd(text0);
  if(parts&&parts.length<=8&&parts.every(function(p){ return ACT_PART.test(tl(p)); })){
    var ps=sortSteps(parts), out=[], later=[];
    for(var i=0;i<ps.length;i++){
      var r=null; try{ r=await coreOff(ps[i]); }catch(e){ r="Hata: "+errT(e); }
      if(r===null||r===undefined){ later.push(ps[i]); out.push("• "+ps[i]+": yapay zekaya bıraktım"); }
      else out.push("• "+mark(r)+ps[i]+": "+r);
      await sleep(350);
    }
    later.forEach(function(x){ setTimeout(function(){ JV.send("Telefonda şunu araçla yap: "+x); },300); });
    return out.join("\n");
  }
  return coreOff(text0);
};

/* ================= Alışkanlık motoru ================= */
var HCAT=[["göz koruma",/göz koruma|göz konfor|okuma modu/],["fener",/fener|flaş/],["alarm",/alarm/],["müzik",/müzik|şarkı/],["parlaklık",/parlakl/],["televizyon",/televizyon|\btv\b/],["navigasyon",/yol tarifi|navigasyon|git\b/],["sessiz",/sessiz|ses[iı]? kıs/]];
function habitLog(t){
  for(var i=0;i<HCAT.length;i++) if(HCAT[i][1].test(t)){
    var a=lsGet("jv_hab",[]); var d=new Date(); a.push({c:HCAT[i][0],h:d.getHours(),m:d.getMinutes(),d:d.toDateString()}); if(a.length>400) a=a.slice(-400); lsSet("jv_hab",a); return;
  }
}
var ASK={"göz koruma":"göz korumasını açalım mı","fener":"feneri açalım mı","alarm":"alarm kuralım mı","müzik":"müzik açalım mı","parlaklık":"parlaklığı ayarlayalım mı","televizyon":"televizyonu açalım mı","navigasyon":"yol tarifi başlatalım mı","sessiz":"sesi kısalım mı"};
function habitScan(){
  var a=lsGet("jv_hab",[]), sug=lsGet("jv_sug",{}), found=null;
  var by={}; a.forEach(function(x){ var k=x.c+"@"+x.h; (by[k]=by[k]||{c:x.c,h:x.h,days:{},mins:[]}); by[k].days[x.d]=1; by[k].mins.push(x.m); });
  Object.keys(by).forEach(function(k){ var b=by[k]; if(Object.keys(b.days).length>=3&&!sug[k]&&!found) found=[k,b]; });
  if(!found) return;
  var b=found[1], mm=Math.round(b.mins.reduce(function(s,v){ return s+v; },0)/b.mins.length);
  sug[found[0]]=1; lsSet("jv_sug",sug);
  var txt="Efendim, son günlerde saat "+b.h+":"+(mm<10?"0":"")+mm+" civarı sık sık '"+b.c+"' yapıyorsunuz. Her gün bu saatte hatırlatayım mı?";
  JV.say(txt);
  setTimeout(function(){
    if(confirm(txt)){
      var rules=lsGet("jv_rules",[]); rules.push({id:found[0],h:b.h,m:mm,text:"Efendim, "+ASK[b.c]+"?",ask:ASK[b.c]});
      lsSet("jv_rules",rules); modes.auto=true; saveModes(); syncWatch(); toast("Hatırlatma eklendi, Otonom mod açıldı");
    }
  },400);
}

/* ================= Ayarlar bölümü, chips, izin ekleri ================= */
/* ================= Kayıtlı yerlerim ================= */
mkPage("pPlc",
 '<div class="ph"><button class="ib" data-close>←</button><h2>KAYITLI YERLERİM</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Konum tetikleyicili yasalar bu yerleri kullanır. Yerler sadece telefonunda saklanır.</div>'+
 '<div id="plList"></div>'+
 '<div class="sec"><h3>Yeni yer</h3><input class="inp" id="plName" placeholder="Yer adı (ev, iş, okul…)"><button class="btn" id="plAdd" style="width:100%">BURAYI KAYDET (güncel konumla)</button><div id="plMsg" style="font-size:12px;color:var(--dim);margin-top:6px"></div></div></div>');
function placeUse(n){ return laws.filter(function(l){ return l.trigger&&l.trigger.type==="geo"&&l.trigger.place===n; }).map(function(l){ return l.name; }); }
function plRender(){
  var ks=Object.keys(places);
  $("plList").innerHTML=ks.length?ks.map(function(k,i){
    var p=places[k], u=placeUse(k);
    return '<div class="sec"><div style="display:flex;justify-content:space-between"><b>'+esc(k)+'</b><span style="font-size:12px;color:var(--dim)">'+p.lat.toFixed(4)+', '+p.lon.toFixed(4)+' · '+(p.r||200)+' m</span></div>'+
      (u.length?'<div style="font-size:12px;color:var(--c1)">Kullanan yasa: '+esc(u.join(", "))+'</div>':'')+
      '<div class="pbtn"><button class="btn" data-pmove="'+i+'">BURAYA TAŞI</button><button class="btn" data-pren="'+i+'">ADINI DEĞİŞTİR</button><button class="btn red" data-pdel="'+i+'">SİL</button></div></div>';
  }).join(""):'<div class="pl">Kayıtlı yer yok.</div>';
  $("plList").querySelectorAll("[data-pdel]").forEach(function(b){ b.onclick=function(){ var k=ks[+b.getAttribute("data-pdel")]; if(confirm("'"+k+"' yeri silinsin mi?")){ T.place_delete({name:k}); plRender(); } }; });
  $("plList").querySelectorAll("[data-pren]").forEach(function(b){ b.onclick=function(){ var k=ks[+b.getAttribute("data-pren")], n=tl(prompt("Yeni ad:",k)||""); if(!n||n===k) return; places[n]=places[k]; delete places[k]; laws.forEach(function(l){ if(l.trigger&&l.trigger.type==="geo"&&l.trigger.place===k) l.trigger.place=n; }); savePlaces(); saveLaws(); plRender(); }; });
  $("plList").querySelectorAll("[data-pmove]").forEach(function(b){ b.onclick=async function(){ var k=ks[+b.getAttribute("data-pmove")]; $("plMsg").textContent="Konum alınıyor…"; $("plMsg").textContent=await T.place_save({name:k,radius:places[k].r}); plRender(); }; });
}
$("plAdd").onclick=async function(){ var n=tl($("plName").value); if(!n){ $("plMsg").textContent="Önce yer adı yaz."; return; } $("plMsg").textContent="Konum alınıyor…"; $("plMsg").textContent=await T.place_save({name:n}); $("plName").value=""; plRender(); };
function openPlaces(){ plRender(); openPage("pPlc"); }
T.place_delete=function(i){
  var n=tl(String(i.name||"")), k=Object.keys(places).filter(function(x){ return x===n||n.indexOf(x)===0||x.indexOf(n)===0; })[0];
  if(!k) return "'"+n+"' diye kayıtlı yer yok. Kayıtlılar: "+(Object.keys(places).join(", ")||"hiç yok");
  var u=placeUse(k); delete places[k]; savePlaces();
  return "'"+k+"' yeri silindi."+(u.length?" Bu yeri kullanan yasalar ("+u.join(", ")+") artık çalışmaz; tetikleyicilerini kaldırabilir ya da yeni yer kaydedebilirsin.":"");
};
T.place_list=function(){ var ks=Object.keys(places); return ks.length?"Kayıtlı yerler: "+ks.map(function(k){ return k+" ("+places[k].lat.toFixed(4)+", "+places[k].lon.toFixed(4)+")"; }).join("; "):"Kayıtlı yer yok."; };

/* ================= Mesaj okuma (seçili kişilerden gelen mesajı sesli söyle) ================= */
mkPage("pMsg",
 '<div class="ph"><button class="ib" data-close>←</button><h2>MESAJ OKUMA</h2></div>'+
 '<div class="pb"><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Otonom mod açıkken, seçtiğin kişilerden WhatsApp/SMS gelince Jarvis kimden geldiğini ve mesajı sesli söyler. Sessiz saatler ve zil modu ayarlarına uyar.</div>'+
 '<div class="sec"><select id="mgOn" class="inp"><option value="0">Kapalı</option><option value="1">Sadece seçtiğim kişiler</option><option value="2">Tüm kişiler</option></select>'+
 '<div id="mgAcc" style="font-size:13px;margin:8px 0"></div><button class="btn" id="mgAccB" style="width:100%">BİLDİRİM ERİŞİMİNİ AÇ</button></div>'+
 '<div class="sec"><h3>Seçilen kişiler</h3><div id="mgSel"></div><input class="inp" id="mgQ" placeholder="Rehberde ara (ad yaz)"><div id="mgList"></div></div></div>');
var msgCfg=lsGet("jv_msg",{on:false,all:false,names:[]}), msgAll=null;
function msgSave(){
  lsSet("jv_msg",msgCfg);
  if(P){ try{ P.kvSet("msg_cfg",JSON.stringify(msgCfg)); }catch(e){} }
  if(msgCfg.on&&!modes.auto){ modes.auto=true; saveModes(); syncWatch(); }
}
function msgRender(){
  var ok=false; try{ ok=!!(P&&P.notifAccess&&P.notifAccess()); }catch(e){}
  $("mgAcc").innerHTML=ok?'✅ Bildirim erişimi açık':'⚠️ Bildirim erişimi kapalı. Açılan ekranda Jarvis\'i bulup aç.';
  $("mgAccB").style.display=ok?"none":"block";
  $("mgOn").value=!msgCfg.on?"0":(msgCfg.all?"2":"1");
  $("mgSel").innerHTML=msgCfg.names.length?msgCfg.names.map(function(n,i){ return '<span class="chip" data-rm="'+i+'" style="display:inline-block;margin:3px;padding:6px 10px;border:1px solid var(--line);border-radius:14px">'+esc(n)+' ✕</span>'; }).join(""):'<div class="pl">Kimse seçilmedi.</div>';
  $("mgSel").querySelectorAll("[data-rm]").forEach(function(b){ b.onclick=function(){ msgCfg.names.splice(+b.getAttribute("data-rm"),1); msgSave(); msgRender(); }; });
  var q=tl($("mgQ").value||""), out=[];
  if(msgAll===null){ try{ msgAll=JSON.parse((P&&P.contacts&&P.contacts())||"[]"); }catch(e){ msgAll=[]; } }
  if(!msgAll.length){ $("mgList").innerHTML='<div class="pl">Rehber okunamadı. İzin merkezinden Rehber iznini ver.</div>'; return; }
  for(var i=0;i<msgAll.length&&out.length<40;i++){ if(!q||tl(msgAll[i]).indexOf(q)>=0) out.push(msgAll[i]); }
  $("mgList").innerHTML=out.map(function(n,i){ var on=msgCfg.names.indexOf(n)>=0; return '<div class="pl" data-pk="'+i+'" style="display:flex;justify-content:space-between"><span>'+esc(n)+'</span><b>'+(on?'✓':'+')+'</b></div>'; }).join("");
  $("mgList").querySelectorAll("[data-pk]").forEach(function(b){ b.onclick=function(){ var n=out[+b.getAttribute("data-pk")], k=msgCfg.names.indexOf(n); if(k>=0) msgCfg.names.splice(k,1); else msgCfg.names.push(n); msgSave(); msgRender(); }; });
}
function openMsg(){ msgAll=null; openPage("pMsg"); msgRender(); }
$("mgOn").onchange=function(){ var v=this.value; msgCfg.on=v!=="0"; msgCfg.all=v==="2"; msgSave(); toast(msgCfg.on?"Mesaj okuma açık":"Kapalı"); };
$("mgAccB").onclick=function(){ try{ P.openNotifAccess(); }catch(e){} };
$("mgQ").oninput=msgRender;
if(P){ try{ P.kvSet("msg_cfg",JSON.stringify(msgCfg)); }catch(e){} }

function buildPlusSettings(){
  var pb=document.querySelector("#pSet .pb"); if(!pb) return;
  var old=$("plusSet"); if(old) old.remove();
  var w=document.createElement("div"); w.id="plusSet";
  var rows=[["pYas","📜 YASALAR ("+laws.length+")"],["pTv","📺 TELEVİZYON"],["pGps","🛰 GPS RADARI"],["pHk","🕶 HACKER MODU"],["pTk","✅ GÖREV & HAFIZA"],["pMg","💬 MESAJ OKUMA (KİŞİLER)"],["pPl","📍 KAYITLI YERLERİM"],["pVp","🎙 SES KİLİDİ (sadece benim sesim)"]];
  w.innerHTML='<div class="sec"><h3>Jarvis v7</h3>'+rows.map(function(r){ return '<button class="btn" data-go="'+r[0]+'" style="width:100%;margin-bottom:8px">'+r[1]+'</button>'; }).join("")+
   '<div class="row" style="display:block">Otonom mod (arka plan nöbeti)<select id="pAuto" style="margin-top:6px"><option value="0">Kapalı</option><option value="1">Açık: pil, ısı, depolama, internet, hatırlatma</option></select></div>'+
   '<div class="row" style="display:block">Sesli uyarı<select id="pVoice" style="margin-top:6px"><option value="1">Açık: Jarvis arka planda konuşur</option><option value="0">Kapalı: sadece bildirim</option></select></div>'+
   '<div class="row" style="display:block">Ekran kapalıyken de konuş<select id="pOff" style="margin-top:6px"><option value="1">Evet</option><option value="0">Hayır, sadece ekran açıkken</option></select></div>'+
   '<div class="row" style="display:block">Sessiz saatler (bu aralıkta konuşmaz, bildirim yine gelir)<div style="display:flex;gap:8px;margin-top:6px"><input class="inp" id="pQs" type="number" min="0" max="23" style="flex:1"><input class="inp" id="pQe" type="number" min="0" max="23" style="flex:1"></div><div style="font-size:12px;color:var(--dim)">Başlangıç saati — bitiş saati (örn. 23 ve 7)</div></div>'+
   '<button class="btn" id="pVTest" style="width:100%">🔊 SESLİ TEST</button></div>';
  var anchor=null; pb.querySelectorAll(".sec").forEach(function(s){ var h=s.querySelector("h3"); if(h&&h.textContent.toLowerCase().indexOf("güncelleme")>=0) anchor=s; });
  if(anchor) pb.insertBefore(w,anchor); else pb.appendChild(w);
  var go={pYas:openLaws,pTv:openTv,pGps:openGps,pHk:openHack,pTk:openTasks,pMg:openMsg,pPl:openPlaces,pVp:function(){ if(window.JV_voice) window.JV_voice.open(); }};
  w.querySelectorAll("[data-go]").forEach(function(b){ b.onclick=function(){ closePage("pSet"); go[b.getAttribute("data-go")](); }; });
  $("pAuto").value=modes.auto?"1":"0";
  $("pAuto").onchange=async function(){ var on=this.value==="1"; var r=await setMode("auto",on); toast(on?"Otonom mod açıldı":"Kapatıldı"); if(on) JV.say(r); };
  var ws=wset(); $("pVoice").value=ws.voice?"1":"0"; $("pOff").value=ws.off?"1":"0"; $("pQs").value=ws.qs; $("pQe").value=ws.qe;
  function saveW(){ var w={voice:$("pVoice").value==="1",off:$("pOff").value==="1",qs:Math.min(23,Math.max(0,parseInt($("pQs").value,10)||0)),qe:Math.min(23,Math.max(0,parseInt($("pQe").value,10)||0))}; lsSet("jv_watch",w); syncWatch(); toast("Kaydedildi"); }
  ["pVoice","pOff","pQs","pQe"].forEach(function(id){ $(id).onchange=saveW; });
  $("pVTest").onclick=function(){
    if(!modes.auto){ toast("Önce Otonom modu aç"); return; }
    try{ P.watchSpeak("Efendim, ben Jarvis. Arka planda sizi sesli uyarabilirim."); toast("Birkaç saniye içinde konuşmalı"); }catch(e){ toast("Test başarısız"); }
  };
}
if($("bSet")) $("bSet").addEventListener("click",function(){ setTimeout(buildPlusSettings,30); });
var chips=$("chips");
if(chips&&chips.appendChild){
  [["📜 YASA",openLaws],["📺 TV",openTv],["🛰 GPS",openGps],["🕶 HACKER",openHack],["✅ GÖREV",openTasks]].forEach(function(c){
    var b=document.createElement("button"); b.textContent=c[0]; b.onclick=c[1]; chips.appendChild(b);
  });
}
// vivo ek izin adımları
var pp=$("pPerm");
if(pp){
  var host=pp.querySelector(".pb"), app=$("pgApp");
  if(host){
    var sec=document.createElement("div"); sec.className="sec";
    sec.innerHTML='<h3>vivo / Android ek adımlar</h3><div style="font-size:12px;color:var(--dim);margin-bottom:8px">Nöbet, ajan modu ve yasaların sorunsuz çalışması için:</div>'+
     '<button class="btn" id="pxWrite" style="width:100%;margin-bottom:8px">☀ Parlaklık izni (sistem ayarlarını değiştir)</button>'+
     '<button class="btn" id="pxOver" style="width:100%;margin-bottom:8px">🪟 Diğer uygulamaların üzerinde göster (yasalar sormadan çalışsın)</button>'+
     '<button class="btn" id="pxBg" style="width:100%">🔋 Arka plan / otomatik başlatma (vivo)</button>'+
     '<div id="pxMsg" style="font-size:12px;color:var(--dim);margin-top:8px;white-space:pre-wrap"></div>';
    if(app) host.insertBefore(sec,app); else host.appendChild(sec);
    $("pxWrite").onclick=function(){ try{ P.openWriteSettings(); }catch(e){} };
    $("pxOver").onclick=function(){ var ok=false; try{ ok=P.overlayGranted(); }catch(e){} $("pxMsg").textContent=ok?"İzin zaten açık. vivo'da ayrıca Ayarlar > Uygulamalar > Jarvis > İzinler > 'Arka planda açılır pencere' de açık olsun.":"Açılan ekranda Jarvis'i bulup izni aç. vivo'da ayrıca 'Arka planda açılır pencere' iznini de ver."; try{ P.openOverlay(); }catch(e){} };
    $("pxBg").onclick=function(){
      $("pxMsg").textContent="Açılan uygulama bilgisinde: Pil > Arka plan güç tüketimi > 'Yüksek arka plan güç tüketimine izin ver' aç.\nAyrıca vivo'da: Ayarlar > Uygulamalar > Otomatik başlatma > Jarvis açık olsun. Son uygulamalar ekranında Jarvis'i kilitle (kartı aşağı çekip kilit simgesi).";
      JV.natX("openSpecial","app").catch(function(){});
    };
  }
}

/* ================= Başlangıç ================= */
function pickPending(){
  if(!P) return;
  try{ var q=P.pendingTake(); if(q&&!JV.voice) setTimeout(function(){ JV.send(q); },1800); }catch(e){}
}
pickPending();
if(modes.auto||modes.system) setTimeout(syncWatch,3000);
modes.agent=false; saveModes();
if(!JV.voice){ setTimeout(habitScan,20000); setInterval(habitScan,30*60*1000); }
/* Tetikleyiciyle uyandırılınca kalan yasa adımlarını sormadan çalıştır */
var lawRunning=false;
async function runPendingLaw(){
  if(!P||lawRunning) return;
  var raw=""; try{ raw=P.kvGet("pending_law")||""; }catch(e){}
  if(!raw) return;
  var o=null; try{ o=JSON.parse(raw); }catch(e){}
  try{ P.kvSet("pending_law",""); }catch(e){}
  if(!o||!o.steps||!o.steps.length||Date.now()-(o.ts||0)>180000) return;
  lawRunning=true;
  try{
    toast("Yasa uygulanıyor: "+o.name,2500);
    var r=await runLaw({name:o.name,steps:o.steps});
    var bad=/(yapamadım|anlaşılamadı|izni kapalı|başarısız)/i.test(r);
    JV.say(bad?("Efendim, "+o.name+" yasasında bazı adımlar yapılamadı."):("Efendim, "+o.name+" yasası uygulandı."));
  }catch(e){ JV.say("Efendim, "+o.name+" yasası uygulanırken hata oldu."); }
  lawRunning=false;
  try{ P.keepAwake(false); }catch(e){}
}
setTimeout(function(){ if(!JV.voice) runPendingLaw(); },2500);
window.JV_plus={runPendingLaw:runPendingLaw,setMode:setMode,laws:laws,tasks:tasks,prefs:prefs,habitScan:habitScan};
})();
