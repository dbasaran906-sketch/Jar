/* JARVİS X-RAY ANALİZ: fotoğraf seç -> nesneyi bul -> onay -> X-ray görünümü + tahmini iç yapı etiketleri; zoom/kaydır.
   NOT: gerçek röntgen değildir; görüntü filtresi + yapay zekânın bildiği iç yapıdan çıkardığı TAHMİNİ şemadır. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div"); var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
var X={img:null,iw:0,ih:0,b64:"",objs:[],sel:null,parts:[],fx:null,st:"idle",z:1,tx:0,ty:0,fxOn:true,lab:true,bright:1.0,raf:0,busy:false};

var d=document.createElement("div"); d.className="page"; d.id="pXr";
d.innerHTML=
 '<div class="ph"><button class="ib" data-close>←</button><h2>X-RAY ANALİZ</h2></div>'+
 '<div class="pb" style="padding:8px;display:flex;flex-direction:column;gap:8px">'+
 '<div id="xrWrap" style="position:relative;height:44vh;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#000;touch-action:none"><canvas id="xrC" style="width:100%;height:100%;display:block"></canvas><div id="xrHint" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:13px;text-align:center;padding:20px">Bir fotoğraf seç. Jarvis nesneyi bulacak, sana soracak, sonra X-ray görünümünü çıkaracak.</div></div>'+
 '<div id="xrMsg" style="font-size:14px;min-height:20px;color:var(--c1)"></div>'+
 '<div id="xrAsk" style="display:none;gap:8px;flex-wrap:wrap"></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="xrPick" style="flex:1">📷 FOTOĞRAF SEÇ</button><button class="btn" id="xrZi" style="flex:0 0 52px">＋</button><button class="btn" id="xrZo" style="flex:0 0 52px">－</button><button class="btn" id="xrRs" style="flex:0 0 52px">⟲</button><button class="btn" id="xr3d" style="flex:0 0 60px">3D</button></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn on" id="xrFx" style="flex:1">X-RAY: AÇIK</button><button class="btn on" id="xrLb" style="flex:1">ETİKET: AÇIK</button></div>'+
 '<label style="font-size:12px;color:var(--dim)">Parlaklık <input type="range" id="xrBr" min="50" max="200" value="100" style="width:100%"></label>'+
 '<div id="xrList" style="font-size:13px"></div>'+
 '<input type="file" id="xrFile" accept="image/*" style="display:none"></div>';
document.body.appendChild(d);
function msg(t){ $("xrMsg").textContent=t||""; }
function ask(opts){
  var a=$("xrAsk"); a.innerHTML=""; if(!opts||!opts.length){ a.style.display="none"; return; }
  a.style.display="flex";
  opts.forEach(function(o){ var b=document.createElement("button"); b.className="btn"; b.textContent=o[0]; b.onclick=o[1]; a.appendChild(b); });
}
function jsay(t){ msg(t); try{ JV.say(t); }catch(e){} }

/* ---- görüntü yükle ---- */
$("xrPick").onclick=function(){ $("xrFile").click(); };
$("xrFile").onchange=function(){
  var f=this.files&&this.files[0]; if(!f) return;
  var r=new FileReader();
  r.onload=function(){
    var im=new Image();
    im.onload=function(){
      var k=Math.min(1,1024/Math.max(im.width,im.height)), c=document.createElement("canvas"); c.width=Math.round(im.width*k); c.height=Math.round(im.height*k);
      c.getContext("2d").drawImage(im,0,0,c.width,c.height);
      X.img=c; X.iw=c.width; X.ih=c.height; X.b64=c.toDataURL("image/jpeg",0.82).split(",")[1];
      X.objs=[]; X.sel=null; X.parts=[]; X.fx=null; reset(); $("xrHint").style.display="none"; $("xrList").innerHTML="";
      analyze();
    };
    im.src=r.result;
  };
  r.readAsDataURL(f); this.value="";
};

function nb(b){
  if(!b||b.length<4) return null; var a=b.map(Number); if(a.some(isNaN)) return null;
  var mx=Math.max.apply(null,a); if(mx<=1.5) a=a.map(function(x){ return x*1000; });
  var y1=Math.min(a[0],a[2]), y2=Math.max(a[0],a[2]), x1=Math.min(a[1],a[3]), x2=Math.max(a[1],a[3]);
  y1=Math.max(0,y1); x1=Math.max(0,x1); y2=Math.min(1000,y2); x2=Math.min(1000,x2);
  if((x2-x1)*(y2-y1)<30000){ x1=0; y1=0; x2=1000; y2=1000; } /* çok küçük/bozuk kutu: tüm fotoğrafı al */
  return {y1:y1/1000*X.ih,x1:x1/1000*X.iw,y2:y2/1000*X.ih,x2:x2/1000*X.iw};
}

async function analyze(){
  X.st="find"; X.busy=true; msg("Nesneler aranıyor…"); ask(null);
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki belirgin tek tek nesneleri bul (en fazla 5; ana nesne en önce). Sadece JSON: [{"ad":"kısa Türkçe ad","box_2d":[ymin,xmin,ymax,xmax],"guven":0-1}] box_2d 0-1000 normalize. Nesne yoksa [].',[{data:X.b64}],true),40000,"analiz zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.objs=arr.map(function(o){ return {ad:String(o.ad||"nesne"),box:nb(o.box_2d),g:o.guven||0}; }).filter(function(o){ return o.box; });
    if(!X.objs.length){ X.busy=false; X.st="idle"; msg("Nesne bulamadım. Başka bir fotoğraf dene."); return; }
    X.sel=X.objs[0]; X.st="confirm"; X.busy=false;
    offerConfirm();
  }catch(e){ X.busy=false; X.st="idle"; msg("Hata: "+JV.errMsg(e)); }
}
function offerConfirm(){
  var o=X.sel; jsay("Fotoğrafta "+o.ad+" var. "+o.ad+" mı seçmiştiniz?");
  var opts=[["EVET, "+o.ad.toUpperCase(),function(){ confirmObj(); }]];
  X.objs.filter(function(x){ return x!==o; }).forEach(function(x){ opts.push([x.ad.toUpperCase()+" AYNI DEĞİL, BUNU SEÇ",function(){ X.sel=x; offerConfirm(); }]); });
  ask(opts);
  msg(o.ad+" mı seçmiştiniz? (Görüntüde başka bir nesneye de dokunabilirsin.)");
}
async function confirmObj(){
  if(X.busy) return; X.busy=true; X.st="scan"; ask(null); msg("3 boyutlu X-ray modeli hazırlanıyor…");
  var o=X.sel, bx=o.box;
  buildFx(bx);
  var ok=false;
  try{ ok=await holo(o); }catch(e){ ok=false; }
  if(ok==="retry"){ X.st="view"; X.busy=false; msg("3D model çıkmadı; TEKRAR DENE ya da ← ile fotoğraf görünümüne dön."); }
  else if(!ok){ await loadParts(o,bx); }
  else{ X.st="view"; X.busy=false; msg("3D hologram hazır. İstersen yukarıdaki 3D tuşuyla tekrar aç."); }
}
async function loadParts(o,bx){
  msg("3D model çıkmadı; fotoğraf üstünde X-ray taraması yapılıyor…");
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki "'+o.ad+'" nesnesinin (kutu: ymin='+Math.round(bx.y1/X.ih*1000)+', xmin='+Math.round(bx.x1/X.iw*1000)+', ymax='+Math.round(bx.y2/X.ih*1000)+', xmax='+Math.round(bx.x2/X.iw*1000)+') ürün türüne göre TİPİK iç yapısını düşün. Gizli iç parçaların bu fotoğraftaki yaklaşık konumlarını tahmin et. Sadece JSON: [{"ad":"parça adı","box_2d":[ymin,xmin,ymax,xmax],"bilgi":"tek satır açıklama, en fazla 60 karakter"}] en fazla 8 parça, box_2d 0-1000 normalize (nesne kutusunun içinde).',[{data:X.b64}],true),45000,"tarama zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.parts=arr.map(function(p){ return {ad:String(p.ad||"parça"),box:nb(p.box_2d),bilgi:String(p.bilgi||"")}; }).filter(function(p){ return p.box; });
    X.st="view"; X.busy=false;
    $("xrList").innerHTML='<div class="sec"><b>TAHMİNİ İÇ YAPI</b> <span style="color:var(--dim);font-size:11px">(gerçek röntgen değil; yapay zekâ tahmini)</span>'+X.parts.map(function(p,i){ return '<div class="pl">'+(i+1)+'. '+esc(p.ad)+'<small>'+esc(p.bilgi)+'</small></div>'; }).join("")+'</div>';
    msg("X-ray hazır: "+o.ad+" — "+X.parts.length+" iç parça (tahmini).");
  }catch(e){ X.st="view"; X.busy=false; msg("İç yapı çıkarılamadı ("+JV.errMsg(e)+"). Sadece X-ray filtresi gösteriliyor."); }
}

/* ================= 3D TEL KAFES HOLOGRAM (tam ekran) ================= */
var H3={on:false,ex:0,spec:[],parts:[],yaw:0.6,pitch:0.25,z:1,auto:false,tilt:false,showOut:true,showIn:true,ghost:true,lab:true,sel:-1,raf:0,name:"",R:1,cx:0,cy:0,cz:0};
var ov=document.createElement("div"); ov.id="xrH";
ov.style.cssText="position:fixed;inset:0;z-index:58;background:radial-gradient(ellipse at 50% 45%,#041a2e 0%,#010811 75%);display:none;touch-action:none;color:#cfeaff;font-family:inherit";
ov.innerHTML='<canvas id="xrHC" style="position:absolute;inset:0;width:100%;height:100%"></canvas>'+
 '<div style="position:absolute;top:0;left:0;right:0;padding:12px 14px;display:flex;align-items:center;gap:10px"><button class="ib" id="xrHx">←</button><div style="flex:1"><div style="letter-spacing:3px;color:var(--c1);font-size:14px" id="xrHt">X-RAY HOLOGRAM</div><div style="font-size:10px;color:#6f9bb8">YAPAY ZEKÂ MODELİ · TAHMİNİ İÇ YAPI · GERÇEK RÖNTGEN DEĞİL</div></div></div>'+
 '<div id="xrHs" style="position:absolute;top:70px;left:0;right:0;text-align:center;font-size:13px;color:var(--c1)"></div>'+
 '<div id="xrHi" style="position:absolute;left:12px;right:12px;bottom:78px;display:none;padding:10px 12px;border:1px solid var(--c2);border-radius:12px;background:rgba(20,10,2,.85);font-size:14px"></div>'+
 '<div style="position:absolute;left:8px;right:8px;bottom:12px;display:flex;gap:6px;flex-wrap:wrap;justify-content:center"><button class="btn" id="xrHo">DIŞ</button><button class="btn" id="xrHn">İÇ</button><button class="btn" id="xrHl">ETİKET</button><button class="btn" id="xrHk">KABUK</button><button class="btn" id="xrHa">DÖN</button><button class="btn" id="xrHg">EĞİM</button><button class="btn" id="xrHm">ANİMASYON: KAPALI</button><button class="btn" id="xrHq">KALİTE: YÜKSEK</button><button class="btn" id="xrHr">⟲</button><label style="display:flex;align-items:center;gap:6px;flex:1 1 100%;font-size:12px;color:#8fb6cf;padding:0 6px">AYIR<input type="range" id="xrHe" min="0" max="100" value="0" style="flex:1;accent-color:var(--c1)"></label><button class="btn" id="xrHsv">💾 STÜDYOYA KAYDET</button><button class="btn" id="xrHre" style="display:none;background:rgba(255,138,31,.25)">TEKRAR DENE</button></div>';
document.body.appendChild(ov);
function hs(t){ $("xrHs").textContent=t||""; }
function v3(a){ return Array.isArray(a)&&a.length>=3&&a.every(function(x){ return isFinite(+x); })?[+a[0],+a[1],+a[2]]:null; }
function circ(m,ax,r,n){ var o=[]; for(var i=0;i<=n;i++){ var t=i/n*6.2832, c=Math.cos(t)*r, s=Math.sin(t)*r; o.push(ax==="x"?[m[0],m[1]+c,m[2]+s]:ax==="y"?[m[0]+c,m[1],m[2]+s]:[m[0]+c,m[1]+s,m[2]]); } return o; }
function primLines(p){
  var L=[], m=v3(p.m), r=Math.abs(+p.r)||0.1, ax=/^[xyz]$/.test(p.eks)?p.eks:"z";
  if(p.tur==="tup"){ var a=v3(p.a), b=v3(p.b); if(a&&b) L.push([a,b]); }
  else if(p.tur==="halka"&&m){ L.push(circ(m,ax,r,32)); if(p.kol){ var c=circ(m,ax,r,8); for(var i=0;i<8;i++) L.push([m,c[i]]); } else L.push(circ(m,ax,r*0.82,24)); }
  else if(p.tur==="kutu"&&m){ var b=v3(p.b)||[0.2,0.2,0.2], h=[b[0]/2,b[1]/2,b[2]/2], P=[]; for(var i=0;i<8;i++) P.push([m[0]+(i&1?h[0]:-h[0]),m[1]+(i&2?h[1]:-h[1]),m[2]+(i&4?h[2]:-h[2])]); [[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){ L.push([P[e[0]],P[e[1]]]); }); }
  else if(p.tur==="silindir"&&m){ var u=(+p.u||0.3)/2, d=ax==="x"?[u,0,0]:ax==="y"?[0,u,0]:[0,0,u], m1=[m[0]-d[0],m[1]-d[1],m[2]-d[2]], m2=[m[0]+d[0],m[1]+d[1],m[2]+d[2]], c1=circ(m1,ax,r,18), c2=circ(m2,ax,r,18); L.push(c1,c2); for(var i=0;i<18;i+=4.5) L.push([c1[Math.round(i)],c2[Math.round(i)]]); }
  else if(p.tur==="kure"&&m){ L.push(circ(m,"x",r,22),circ(m,"y",r,22),circ(m,"z",r,22)); }
  return L;
}
function vsub(a,b){ return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]; }
function vadd(a,b){ return [a[0]+b[0],a[1]+b[1],a[2]+b[2]]; }
function vmul(a,k){ return [a[0]*k,a[1]*k,a[2]*k]; }
function vcross(a,b){ return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]; }
function vdot(a,b){ return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
function vlen(a){ return Math.hypot(a[0],a[1],a[2]); }
function vnorm(a){ var l=vlen(a)||1; return [a[0]/l,a[1]/l,a[2]/l]; }
function clampN(x,lo,hi,def){ x=+x; if(!isFinite(x)||!x) x=def; return Math.max(lo,Math.min(hi,x)); }
var QH=(JV.cfg&&JV.cfg.xq!=="low");
function tubeF(a,b,r,sd,out){
  var d=vsub(b,a), L=vlen(d); if(L<1e-6) return; d=vmul(d,1/L);
  var t=Math.abs(d[1])<0.9?[0,1,0]:[1,0,0], u=vnorm(vcross(d,t)), v=vcross(d,u), A=[], B=[], i;
  for(i=0;i<sd;i++){ var an=i/sd*6.2832, o=vadd(vmul(u,Math.cos(an)*r),vmul(v,Math.sin(an)*r)); A.push(vadd(a,o)); B.push(vadd(b,o)); }
  for(i=0;i<sd;i++){ var j=(i+1)%sd; out.push([A[i],A[j],B[j],B[i]]); }
}
function primMesh(p){
  var F=[], m=v3(p.m), ax=/^[xyz]$/.test(p.eks)?p.eks:"z", r=clampN(p.r,0.005,1.5,0.1), i;
  if(p.tur==="tup"){ var a=v3(p.a), b=v3(p.b); if(a&&b) tubeF(a,b,clampN(p.r,0.008,0.2,0.03),QH?12:8,F); }
  else if(p.tur==="halka"&&m){ var k=clampN(p.k,0.006,Math.max(0.01,r*0.4),Math.max(0.012,r*0.07)), c=circ(m,ax,r,QH?32:22), HN=QH?32:22; for(i=0;i<HN;i++) tubeF(c[i],c[i+1],k,QH?8:6,F); if(p.kol){ for(i=0;i<HN;i+=QH?4:3) tubeF(m,c[i],Math.min(k*0.3,0.012),4,F); } }
  else if(p.tur==="kutu"&&m){ var bb=v3(p.b)||[0.2,0.2,0.2], h=[Math.abs(bb[0])/2,Math.abs(bb[1])/2,Math.abs(bb[2])/2], P=[]; for(i=0;i<8;i++) P.push([m[0]+(i&1?h[0]:-h[0]),m[1]+(i&2?h[1]:-h[1]),m[2]+(i&4?h[2]:-h[2])]); [[0,1,3,2],[4,5,7,6],[0,1,5,4],[2,3,7,6],[0,2,6,4],[1,3,7,5]].forEach(function(q){ F.push(q.map(function(z){ return P[z]; })); }); }
  else if(p.tur==="silindir"&&m){ var u=clampN(p.u,0.01,3,0.3)/2, dd=ax==="x"?[u,0,0]:ax==="y"?[0,u,0]:[0,0,u], c1=circ(vsub(m,dd),ax,r,QH?26:18), c2=circ(vadd(m,dd),ax,r,QH?26:18), CN=QH?26:18; for(i=0;i<CN;i++) F.push([c1[i],c1[i+1],c2[i+1],c2[i]]); F.push(c1.slice(0,CN)); F.push(c2.slice(0,CN)); }
  else if(p.tur==="donel"&&m&&Array.isArray(p.p)){ var DN=QH?24:16, pr=p.p.map(function(z){ return Array.isArray(z)&&isFinite(+z[0])&&isFinite(+z[1])?[Math.max(0,+z[0]),+z[1]]:null; }).filter(Boolean).slice(0,14), ad=ax==="x"?[1,0,0]:ax==="y"?[0,1,0]:[0,0,1], rg=[]; pr.forEach(function(z){ rg.push(circ(vadd(m,vmul(ad,z[1])),ax,z[0],DN)); }); for(i=0;i<rg.length-1;i++) for(var jj=0;jj<DN;jj++) F.push([rg[i][jj],rg[i][jj+1],rg[i+1][jj+1],rg[i+1][jj]]); if(rg.length){ if(pr[0][0]>0.004) F.push(rg[0].slice(0,DN)); var lr=rg.length-1; if(pr[lr][0]>0.004) F.push(rg[lr].slice(0,DN)); } }
  else if(p.tur==="kure"&&m){ var LA=QH?12:8, LO=QH?20:14, sp=function(la,lo){ var th=la/LA*Math.PI, ph=lo/LO*6.2832; return [m[0]+r*Math.sin(th)*Math.cos(ph),m[1]+r*Math.cos(th),m[2]+r*Math.sin(th)*Math.sin(ph)]; }; for(var la=0;la<LA;la++) for(var lo=0;lo<LO;lo++) F.push([sp(la,lo),sp(la,lo+1),sp(la+1,lo+1),sp(la+1,lo)]); }
  else if(p.tur==="koni"&&m){ var u2=clampN(p.u,0.01,3,0.3)/2, d2=ax==="x"?[u2,0,0]:ax==="y"?[0,u2,0]:[0,0,u2], cc=circ(vsub(m,d2),ax,r,QH?26:18), tip=vadd(m,d2), KN=QH?26:18; for(i=0;i<KN;i++) F.push([cc[i],cc[i+1],tip]); F.push(cc.slice(0,KN)); }
  else if(p.tur==="egri"&&Array.isArray(p.n)){ var pts=p.n.map(v3).filter(Boolean).slice(0,12), rr=clampN(p.r,0.008,0.2,0.03); for(i=0;i<pts.length-1;i++) tubeF(pts[i],pts[i+1],rr,QH?8:5,F); }
  return F;
}
function hexCol(s,def){
  var m=/^#?([0-9a-f]{6})$/i.exec(String(s||"").trim()); if(!m) return def;
  var n=parseInt(m[1],16), c=[(n>>16)&255,(n>>8)&255,n&255], mx=Math.max(c[0],c[1],c[2]);
  if(mx<80){ var o=80-mx; c=[c[0]+o,c[1]+o,c[2]+o]; } return c;
}
var MATS={metal:{sp:0.75,pw:44,al:1,dk:0.92},plastik:{sp:0.32,pw:20,al:1,dk:1},cam:{sp:0.85,pw:70,al:0.42,dk:1},lastik:{sp:0.04,pw:8,al:1,dk:0.72},ahsap:{sp:0.08,pw:10,al:1,dk:1},kumas:{sp:0,pw:1,al:1,dk:1},boya:{sp:0.55,pw:55,al:1,dk:1},kemik:{sp:0.12,pw:14,al:1,dk:1},def:{sp:0.38,pw:28,al:1,dk:1}};
function ptsOf(p){
  var o=[], m=v3(p.m), r=Math.abs(+p.r)||0.03, b;
  if(p.tur==="tup"){ var a=v3(p.a); b=v3(p.b); if(a) o.push(a); if(b) o.push(b); }
  else if(p.tur==="egri"&&Array.isArray(p.n)){ p.n.forEach(function(z){ var q=v3(z); if(q) o.push(q); }); }
  else if(m){ if(p.tur==="kutu"){ b=v3(p.b)||[0.2,0.2,0.2]; o.push([m[0]-Math.abs(b[0])/2,m[1]-Math.abs(b[1])/2,m[2]-Math.abs(b[2])/2],[m[0]+Math.abs(b[0])/2,m[1]+Math.abs(b[1])/2,m[2]+Math.abs(b[2])/2]); } else { o.push([m[0]-r,m[1]-r,m[2]-r],[m[0]+r,m[1]+r,m[2]+r]); } }
  return o;
}
function scalePart(p,s){
  var q={}, k; for(k in p) q[k]=p[k];
  ["a","b","m"].forEach(function(f){ var v=v3(p[f]); if(v) q[f]=[v[0]*s,v[1]*s,v[2]*s]; });
  ["r","k","u"].forEach(function(f){ if(isFinite(+p[f])) q[f]=+p[f]*s; });
  if(Array.isArray(p.n)) q.n=p.n.map(function(z){ var v=v3(z); return v?[v[0]*s,v[1]*s,v[2]*s]:z; });
  if(Array.isArray(p.p)) q.p=p.p.map(function(z){ return Array.isArray(z)?[(+z[0])*s,(+z[1])*s]:z; });
  if(p.hareket&&v3(p.hareket.m)){ var hm=v3(p.hareket.m); q.hareket={}; for(k in p.hareket) q.hareket[k]=p.hareket[k]; q.hareket.m=[hm[0]*s,hm[1]*s,hm[2]*s]; }
  return q;
}
/* Yapay zekâ çıktısını temizler: ölçek, uzak/asılı parçalar, kopyalar */
function repair(arr){
  var a=arr.filter(function(p){ return p&&typeof p==="object"&&/^(tup|halka|kutu|silindir|kure|koni|egri|donel)$/.test(p.tur); });
  if(a.length<3) return arr;
  var seen={}; a=a.filter(function(p){ var k=JSON.stringify([p.tur,p.a,p.b,p.m,p.r,p.n]); if(seen[k]) return false; seen[k]=1; return true; });
  var cs=a.map(function(p){ var pt=ptsOf(p), c=[0,0,0]; pt.forEach(function(q){ c[0]+=q[0]; c[1]+=q[1]; c[2]+=q[2]; }); var n=Math.max(1,pt.length); return [c[0]/n,c[1]/n,c[2]/n]; });
  function med(v){ v=v.slice().sort(function(x,y){ return x-y; }); return v[Math.floor(v.length/2)]; }
  if(a.length>6){
    var md=[med(cs.map(function(c){return c[0];})),med(cs.map(function(c){return c[1];})),med(cs.map(function(c){return c[2];}))];
    var ds=cs.map(function(c){ return Math.hypot(c[0]-md[0],c[1]-md[1],c[2]-md[2]); }), mm=med(ds), keep=[];
    var all=[]; a.forEach(function(p){ ptsOf(p).forEach(function(q){ all.push(q); }); });
    a.forEach(function(p,i){ if(ds[i]<=Math.max(3.2*mm,1.4*Math.max(0.3,mm))) keep.push(p); }); if(keep.length>=Math.max(4,a.length*0.6)) a=keep;
  }
  var mn=[1e9,1e9,1e9], mx=[-1e9,-1e9,-1e9];
  a.forEach(function(p){ ptsOf(p).forEach(function(q){ for(var k=0;k<3;k++){ if(q[k]<mn[k])mn[k]=q[k]; if(q[k]>mx[k])mx[k]=q[k]; } }); });
  var D=Math.max(mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2]);
  if(isFinite(D)&&D>0&&(D>2.8||D<1.1)){ var s=2/D; a=a.map(function(p){ return scalePart(p,s); }); D=2; }
  var rmax=Math.max(0.05,0.45*D);
  return a.map(function(p){ if(isFinite(+p.r)&&Math.abs(+p.r)>rmax){ var q=scalePart(p,1); q.r=rmax; return q; } return p; });
}
function buildModel(arr){
  arr=repair(arr);
  var parts=[], mn=[1e9,1e9,1e9], mx=[-1e9,-1e9,-1e9], total=0;
  var CAP=QH?4600:2800;
  arr.slice(0,56).forEach(function(p){
    if(!p||typeof p!=="object") return; var faces=primMesh(p); if(!faces.length||total+faces.length>CAP) return; total+=faces.length;
    var c=[0,0,0], n=0; faces.forEach(function(f){ f.forEach(function(q){ n++; for(var k=0;k<3;k++){ c[k]+=q[k]; if(q[k]<mn[k])mn[k]=q[k]; if(q[k]>mx[k])mx[k]=q[k]; } }); });
    c=c.map(function(x){ return x/n; });
    var inner=/^i/i.test(String(p.grup||""));
    var hk=null, hh=p.hareket; if(hh&&/^(don|gitgel|salin)$/.test(hh.tur)){ hk={t:hh.tur,ax:/^[xyz]$/.test(hh.eks)?hh.eks:"z",sp:clampN(hh.hiz,0.1,12,2),gen:clampN(hh.gen,0.01,1.6,0.25),piv:v3(hh.m)||c}; }
    parts.push({ad:String(p.ad||"parça"),inner:inner,bilgi:String(p.bilgi||""),faces:faces,c:c,col:hexCol(p.renk,inner?[214,150,92]:[168,184,200]),mat:MATS[String(p.mat||"").toLowerCase()]||MATS.def,hk:hk});
  });
  if(parts.length<3) return null;
  H3.cx=(mn[0]+mx[0])/2; H3.cy=(mn[1]+mx[1])/2; H3.cz=(mn[2]+mx[2])/2;
  H3.R=Math.max(0.01,Math.hypot(mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2])/2);
  return parts;
}
var SOFT=/(hırka|tişört|tshirt|t-shirt|gömlek|kıyafet|elbise|ceket|mont|pantolon|etek|kazak|sweat|ayakkabı|çanta|şapka|bere|eldiven|çorap|insan|kişi|çocuk|bebek|hayvan|kedi|köpek|kuş|balık|yemek|meyve|sebze|pizza|ekmek|çiçek|ağaç|bitki|yastık|battaniye|halı|perde)/i;
function salvage(raw){
  var a=null; try{ a=JV.parseJSON(raw); }catch(e){}
  if(Array.isArray(a)) return a; if(a&&Array.isArray(a.parcalar)) return a.parcalar;
  var t=String(raw||""), i=t.indexOf("["); if(i<0) return [];
  var out=[], d=0, st=-1, inS=false, esc2=false;
  for(var k=i+1;k<t.length;k++){ var ch=t[k];
    if(inS){ if(esc2) esc2=false; else if(ch==="\\") esc2=true; else if(ch==='"') inS=false; continue; }
    if(ch==='"'){ inS=true; continue; }
    if(ch==="{"){ if(d===0) st=k; d++; }
    else if(ch==="}"){ d--; if(d===0&&st>=0){ try{ out.push(JSON.parse(t.slice(st,k+1))); }catch(e){} st=-1; } }
  }
  return out;
}
var SPEC='Koordinat: x=uzunluk/ileri, y=yukarı, z=yan genişlik; nesne yaklaşık -1..1 kutusuna sığsın, gerçek orantıları koru. Her parça {"ad":"Türkçe ad","tur":"tup|halka|kutu|silindir|kure|koni|egri|donel","grup":"G","renk":"#rrggbb","bilgi":"en fazla 40 karakter"} + türe göre alanlar. "renk" parçanın GERÇEK rengi olsun (fotoğraftaki gibi). tup: "a":[x,y,z],"b":[x,y,z],"r":kalınlık yarıçapı (0.01-0.08). halka: "m":[x,y,z],"eks":"x|y|z" (düzleme dik eksen),"r":yarıçap,"k":tüp kalınlığı,"kol":true/false (teller/kollar). kutu: "m":[x,y,z],"b":[bx,by,bz] (ince yaparsan levha olur). silindir: "m":[x,y,z],"eks":"x|y|z","r":sayı,"u":uzunluk. kure: "m":[x,y,z],"r":sayı. koni: "m":[x,y,z],"eks":"x|y|z","r":taban yarıçapı,"u":uzunluk. egri: "n":[[x,y,z],...] 3-8 nokta (kıvrımlı boru/yay),"r":kalınlık. Sayıları en fazla 2 ondalıkla yaz. ' +
' "mat" (isteğe bağlı): "metal|plastik|cam|lastik|ahsap|kumas|boya|kemik". donel (dönel yüzey: şişe, vazo, jant, kadeh, kule): "m":[x,y,z],"eks":"x|y|z","p":[[yarıçap,yükseklik],...] 3-10 nokta, yükseklik eksen boyunca m noktasından uzaklıktır. Hareket eden parçalara (tekerlek, pedal, pervane, piston, fan, kapak) isteğe bağlı "hareket":{"tur":"don|gitgel|salin","eks":"x|y|z","hiz":1-6,"gen":0.1-0.5}. KURALLAR: parçalar birbirine temas etsin ya da birleşsin (havada asılı parça olmasın); simetrik nesnelerde iki taraf simetrik olsun; önce en büyük gövde parçalarını, küçük detayları sona yaz; tüm parçalar aynı ölçek ve koordinat sisteminde olsun. Sadece JSON dizisi, başka metin yok.';
function holoPrompt(o,inner,short){
  var ANAT=/(insan|kişi|çocuk|bebek|hayvan|kedi|köpek|kuş|balık|inek|koyun|tavşan|aslan|kaplan|fil|zürafa|yılan|kaplumbağa|kurbağa|böcek|kelebek|papağan|at )/i, PLNT=/(bitki|çiçek|ağaç|yaprak|kaktüs|meyve|sebze|gül|lale)/i, soft=SOFT.test(o.ad), n=short?(inner?7:9):(inner?(QH?14:12):(QH?22:16));
  if(!inner) return 'Fotoğraftaki "'+o.ad+'" nesnesinin dış görünümünü 3 boyutlu, gerçekçi renk ve orantılı KATI MODEL olarak çiz: en çok '+n+' parça, grup="dis" (ana gövde hatları, çerçeve, kenarlar'+(soft?'; kıyafet/yumuşak nesne ise gövde, kollar, yaka, etek ucu gibi büyük hatlar':'')+'). '+SPEC.replace('"G"','"dis"');
  return 'Fotoğraftaki "'+o.ad+'" nesnesinin '+(ANAT.test(o.ad+' ')?'İSKELETİNİ ve başlıca ORGANLARINI (kafatası, omurga, kaburga, uzuv kemikleri, kalp, akciğer, beyin, mide gibi; gerçek Türkçe anatomi adlarıyla)':PLNT.test(o.ad)?'İÇ YAPISINI (kök, gövde damarları, yaprak damarları, çiçek/meyve iç yapısı)':soft?'KATMANLARINI ve detaylarını (kumaş/astar katmanı, dikişler, düğme/fermuar, cep, yaka ve etek bantları gibi; motor vb. uydurma)':'gizli İÇ parçalarını (türünün tipik iç mekanizması)')+' 3 boyutlu, gerçekçi renk ve orantılı KATI MODEL olarak çiz: en çok '+n+' parça, grup="ic". '+SPEC.replace('"G"','"ic"');
}
var BUSY=/yoğun|high demand|UNAVAILABLE|overload|503|429|limit/i;
async function holoPart(o,inner){
  var last="", waits=[0,4000,8000];
  for(var att=0;att<3;att++){
    if(att>0&&BUSY.test(last)){ hs((inner?"İç parçalar":"Dış yapı")+": Gemini yoğun, "+Math.round(waits[att]/1000)+" sn sonra yeniden deniyorum ("+(att+1)+"/3)…"); await new Promise(function(r){ setTimeout(r,waits[att]); }); }
    try{
      var raw=await JV.withTimeout(JV.visionAI(holoPrompt(o,inner,att>0),[{data:X.b64}],true),att?30000:50000,(inner?"iç":"dış")+" parçalar zaman aşımı");
      var arr=salvage(raw); if(arr.length>=2) return {arr:arr,err:""};
      last="cevap bozuk ya da çok kısa geldi";
    }catch(e){ last=JV.errMsg(e); }
  }
  return {arr:[],err:last};
}
function setRetry(on){ var b=$("xrHre"); if(b) b.style.display=on?"inline-block":"none"; }
/* Kontrol turu: model fotoğrafla karşılaştırılır, belirgin yanlış parçalar silinir/düzeltilir */
async function criticPass(o,list){
  function f(v){ return Array.isArray(v)?"["+v.map(function(x){ return Math.round(+x*100)/100; })+"]":""; }
  var rows=list.slice(0,48).map(function(p,i){ return i+":"+(p.ad||"")+"|"+p.tur+(p.m?" m"+f(p.m):"")+(p.a?" a"+f(p.a):"")+(p.b?" b"+f(p.b):"")+(isFinite(+p.r)?" r"+Math.round(+p.r*100)/100:"")+(p.eks?" eks:"+p.eks:""); }).join("\n");
  var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki "'+o.ad+'" nesnesi için çizilen 3 boyutlu parça listesi aşağıda (x=uzunluk, y=yukarı, z=genişlik; nesne -1..1 kutusunda). Fotoğrafa bakarak ORANI, KONUMU ya da YÖNÜ belirgin biçimde yanlış olan parçaları bul. Sadece JSON: {"sil":[numaralar],"duzelt":[{"i":numara,...aynı biçimde TAM yeni parça}]}. Parça biçimi: '+SPEC+' Hata yoksa {"sil":[],"duzelt":[]}. Liste:\n'+rows,[{data:X.b64}],true),45000,"kontrol zaman aşımı");
  var d=JV.parseJSON(raw); if(!d||typeof d!=="object") return null;
  var del={}, dn=0; (Array.isArray(d.sil)?d.sil:[]).forEach(function(i){ if(isFinite(+i)){ del[+i]=1; dn++; } });
  if(dn>list.length*0.4) del={};
  var rp={}; (Array.isArray(d.duzelt)?d.duzelt:[]).forEach(function(z){ if(z&&isFinite(+z.i)&&z.tur&&primMesh(z).length) rp[+z.i]=z; });
  var out=[]; list.forEach(function(p,i){ if(del[i]) return; if(rp[i]){ var q=rp[i]; delete q.i; q.grup=q.grup||p.grup; out.push(q); } else out.push(p); });
  return out.length>=3?out:null;
}
async function holo(o){
  H3.name=o.ad; $("xrHt").textContent="X-RAY · "+o.ad.toUpperCase(); ov.style.display="block"; H3.on=true; H3.parts=[]; H3.sel=-1; H3.yaw=0.6; H3.pitch=0.25; H3.z=1; H3.ex=0; var he=$("xrHe"); if(he) he.value=0; $("xrHi").style.display="none"; setRetry(false);
  hs("3 boyutlu model çiziliyor… dış yapı ve iç parçalar ayrı ayrı hazırlanıyor"); startH3();
  var outer=[], inner=[], eo="", ei="", n=0;
  function refresh(){ var p=buildModel(outer.concat(inner)); if(p){ H3.parts=p; H3.spec=outer.concat(inner); } }
  var r1=await holoPart(o,false); outer=r1.arr; eo=r1.err; refresh();
  if(outer.length) hs("Dış yapı hazır, iç parçalar çiziliyor…");
  var r2=await holoPart(o,true); inner=r2.arr; ei=r2.err; refresh();
  if(!H3.parts.length){
    var why=(eo||ei||"bilinmeyen hata");
    hs("Model çıkmadı: "+why); setRetry(true); H3.holoObj=o; return "retry";
  }
  if(QH&&H3.parts.length>=4){
    hs("Model fotoğrafla karşılaştırılıp kontrol ediliyor…");
    try{ var fx=await criticPass(o,outer.concat(inner)); if(fx){ var pp=buildModel(fx); if(pp){ H3.parts=pp; H3.spec=fx; } } }catch(e){}
  }
  var note=(!outer.length?"Dış yapı çıkmadı ("+eo+"). ":"")+(!inner.length?"İç parçalar çıkmadı ("+ei+"). ":"");
  hs(note); if(note) setRetry(true); H3.holoObj=o;
  try{ JV.say("Hologram hazır efendim. Parmağınla çevirebilir, iki parmakla yakınlaştırabilirsin."); }catch(e){}
  return true;
}
function closeH3(){ H3.on=false; ov.style.display="none"; cancelAnimationFrame(H3.raf); }
function rot(p){
  var t=H3.tr||(H3.tr={cy:Math.cos(H3.yaw),sy:Math.sin(H3.yaw),cp:Math.cos(H3.pitch),sp:Math.sin(H3.pitch)});
  var x=p[0]-H3.cx, y=p[1]-H3.cy, z=p[2]-H3.cz, cy=t.cy, sy=t.sy, cp=t.cp, sp=t.sp;
  var x1=x*cy+z*sy, z1=-x*sy+z*cy, y1=y*cp-z1*sp, z2=y*sp+z1*cp; return [x1,y1,z2];
}
var H3proj=[];
function startH3(){ H3.sig=""; cancelAnimationFrame(H3.raf); (function loop(ts){ if(!H3.on) return; H3.raf=requestAnimationFrame(loop); drawH3(ts); })(0); }
function mvPt(q,h,t){
  if(h.t==="gitgel"){ var d=Math.sin(t*h.sp)*h.gen*H3.R*0.6; return h.ax==="x"?[q[0]+d,q[1],q[2]]:h.ax==="y"?[q[0],q[1]+d,q[2]]:[q[0],q[1],q[2]+d]; }
  var an=h.t==="don"?t*h.sp:Math.sin(t*h.sp)*h.gen, c=Math.cos(an), s=Math.sin(an), pv=h.piv, x=q[0]-pv[0], y=q[1]-pv[1], z=q[2]-pv[2];
  if(h.ax==="x") return [q[0],pv[1]+y*c-z*s,pv[2]+y*s+z*c];
  if(h.ax==="y") return [pv[0]+x*c+z*s,q[1],pv[2]-x*s+z*c];
  return [pv[0]+x*c-y*s,pv[1]+x*s+y*c,q[2]];
}
function drawH3(ts){
  var cv=$("xrHC"), dpr=Math.min(window.devicePixelRatio||1,1.5), W=cv.clientWidth, H=cv.clientHeight; if(!W) return;
  var sig=[(H3.anim?(ts/33|0):0),H3.yaw.toFixed(3),H3.pitch.toFixed(3),H3.z.toFixed(2),H3.sel,H3.showOut,H3.showIn,H3.ghost,H3.lab,H3.ex.toFixed(2),H3.parts.length,W,H].join("|");
  if(!(H3.auto&&!dragging)&&sig===H3.sig&&H3.parts===H3.lp) return; H3.sig=sig; H3.lp=H3.parts;
  H3.tr={cy:Math.cos(H3.yaw),sy:Math.sin(H3.yaw),cp:Math.cos(H3.pitch),sp:Math.sin(H3.pitch)};
  if(cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var c=cv.getContext("2d"); c.setTransform(dpr,0,0,dpr,0,0); c.clearRect(0,0,W,H);
  if(H3.auto&&!dragging) H3.yaw+=0.004;
  var S=Math.min(W,H)*0.5*H3.z/H3.R, cx=W/2, cy=H*0.46, F=3.2*H3.R;
  /* zemin ızgarası */
  c.lineWidth=1; c.strokeStyle="rgba(43,181,255,.16)";
  for(var g=-4;g<=4;g++){ [[[g,-1,-4],[g,-1,4]],[[-4,-1,g],[4,-1,g]]].forEach(function(l){ var a=rot([H3.cx+l[0][0]*H3.R*.5,H3.cy-H3.R*0.9,H3.cz+l[0][2]*H3.R*.5]), b=rot([H3.cx+l[1][0]*H3.R*.5,H3.cy-H3.R*0.9,H3.cz+l[1][2]*H3.R*.5]); var fa=F/(F+a[2]), fb=F/(F+b[2]); c.beginPath(); c.moveTo(cx+a[0]*S*fa,cy-a[1]*S*fa); c.lineTo(cx+b[0]*S*fb,cy-b[1]*S*fb); c.stroke(); }); }
  { var gp=rot([H3.cx,H3.cy-H3.R*0.9,H3.cz]), gfc=F/(F+gp[2]), gxx=cx+gp[0]*S*gfc, gyy=cy-gp[1]*S*gfc, grr=Math.max(10,S*H3.R*0.85*gfc);
    c.save(); c.translate(gxx,gyy); c.scale(1,0.26); var sg=c.createRadialGradient(0,0,0,0,0,grr); sg.addColorStop(0,"rgba(0,0,0,.6)"); sg.addColorStop(1,"rgba(0,0,0,0)"); c.fillStyle=sg; c.beginPath(); c.arc(0,0,grr,0,6.3); c.fill(); c.restore(); }
  H3proj=[]; var tt=ts/1000;
  var LL=[-0.42,0.55,-0.72], ln=Math.hypot(LL[0],LL[1],LL[2]); LL=[LL[0]/ln,LL[1]/ln,LL[2]/ln];
  var HV=vnorm([LL[0],LL[1],LL[2]-1]), fl=[], cand=[];
  H3.parts.forEach(function(p,i){
    if(p.inner?!H3.showIn:!H3.showOut) return;
    var sel=(i===H3.sel), dimmed=(H3.sel>=0&&!sel), ghost=(!p.inner&&H3.ghost&&H3.showIn&&!sel), al=ghost?0.3:(dimmed?0.3:1), mt=p.mat||MATS.def; if(al===1) al=mt.al;
    var off=null, hka=(H3.anim&&p.hk)?p.hk:null;
    if(H3.ex>0.01){
      var dv=[p.c[0]-H3.cx,p.c[1]-H3.cy,p.c[2]-H3.cz], dl=vlen(dv), dir=dl>0.06*H3.R?[dv[0]/dl,dv[1]/dl,dv[2]/dl]:vnorm([0.3,0.8,0.5]);
      var amt=H3.ex*H3.R*(p.inner?0.55:0.4)+(sel?0.2*H3.R:0), kk=H3.ex*0.35;
      off=[dv[0]*kk+dir[0]*amt,dv[1]*kk+dir[1]*amt,dv[2]*kk+dir[2]*amt];
    }
    p.faces.forEach(function(f){
      var pts=[], rs=[], zs=0, k;
      for(k=0;k<f.length;k++){ var q0=f[k]; if(hka) q0=mvPt(q0,hka,tt); var r=rot(off?[q0[0]+off[0],q0[1]+off[1],q0[2]+off[2]]:q0), fc=F/(F+r[2]); rs.push(r); pts.push([cx+r[0]*S*fc,cy-r[1]*S*fc]); zs+=r[2]; }
      zs/=f.length;
      var nv=vnorm(vcross(vsub(rs[1],rs[0]),vsub(rs[2],rs[0]))); if(nv[2]>0) nv=[-nv[0],-nv[1],-nv[2]];
      var df=Math.max(0,(vdot(nv,LL)+0.3)/1.3), df2=Math.max(0,vdot(nv,[0.6,-0.2,-0.6])), sp=Math.pow(Math.max(0,vdot(nv,HV)),mt.pw), fog=1-0.2*Math.max(0,Math.min(1,(zs/H3.R+1)/2)), rim=Math.pow(1-Math.min(1,Math.abs(nv[2])),3)*0.22, lt=((0.2+0.1*nv[1])+0.66*df+0.14*df2)*mt.dk*fog+rim, bo=sel?40:0, sk=255*mt.sp*sp;
      var cr=Math.min(255,p.col[0]*lt+sk+bo), cg=Math.min(255,p.col[1]*lt+sk+bo), cb=Math.min(255,p.col[2]*lt+sk+bo);
      fl.push({p:pts,z:zs,c:"rgb("+(cr|0)+","+(cg|0)+","+(cb|0)+")",a:al,s:sel});
    });
    var r0=rot(off?[p.c[0]+off[0],p.c[1]+off[1],p.c[2]+off[2]]:p.c), f0=F/(F+r0[2]), sx=cx+r0[0]*S*f0, sy2=cy-r0[1]*S*f0;
    H3proj.push({i:i,x:sx,y:sy2,z:r0[2]});
    if((H3.lab&&p.inner&&!dimmed)||sel) cand.push({i:i,x:sx,y:sy2,t:p.ad,s:sel});
  });
  fl.sort(function(a,b){ return b.z-a.z; });
  fl.forEach(function(q){
    c.globalAlpha=q.a; c.fillStyle=q.c; c.beginPath(); c.moveTo(q.p[0][0],q.p[0][1]);
    for(var k=1;k<q.p.length;k++) c.lineTo(q.p[k][0],q.p[k][1]);
    c.closePath(); c.fill();
    if(q.a>=1){ c.strokeStyle=q.s?"rgba(255,255,255,.55)":q.c; c.lineWidth=q.s?0.9:0.7; c.stroke(); }
  });
  c.globalAlpha=1;
  /* Etiketler: iki yan sütuna dizilir, çakışma çözülür, ince çizgiyle parçaya bağlanır */
  cand.sort(function(a,b){ return (b.s?1:0)-(a.s?1:0); }); cand=cand.slice(0,12);
  var top=96, bot=H-118, gap=18, cols=[[],[]];
  cand.forEach(function(q){ cols[q.x<W/2?0:1].push(q); });
  c.font="11px sans-serif"; c.textBaseline="middle";
  cols.forEach(function(col,ci){
    col.sort(function(a,b){ return a.y-b.y; });
    var k; for(k=0;k<col.length;k++){ col[k].ly=Math.max(top,Math.min(bot,col[k].y)); if(k&&col[k].ly<col[k-1].ly+gap) col[k].ly=col[k-1].ly+gap; }
    for(k=col.length-1;k>=0;k--){ if(col[k].ly>bot-(col.length-1-k)*gap) col[k].ly=bot-(col.length-1-k)*gap; }
    col.forEach(function(q){
      var t=q.t.length>18?q.t.slice(0,17)+"…":q.t, tw=c.measureText(t).width+10, lx=ci===0?6:W-6-tw, ex=ci===0?lx+tw:lx;
      var base=H3.parts[q.i].inner?"255,138,31":"43,181,255";
      c.strokeStyle="rgba("+base+",.75)"; c.lineWidth=1; c.beginPath(); c.moveTo(ex,q.ly); c.lineTo(q.x,q.y); c.stroke();
      c.fillStyle="rgba("+base+",1)"; c.beginPath(); c.arc(q.x,q.y,2.5,0,6.3); c.fill();
      c.fillStyle="rgba(0,0,0,.7)"; c.fillRect(lx,q.ly-8,tw,16);
      c.fillStyle=q.s?"#fff":"#ffd9b0"; c.fillText(t,lx+5,q.ly+0.5);
    });
  });
}
var dragging=false, hp={}, hd=0, moved=0;
ov.addEventListener("pointerdown",function(e){ if(e.target.closest&&e.target.closest("button")) return; hp[e.pointerId]={x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:Date.now()}; dragging=true; moved=0; hd=0; try{ ov.setPointerCapture(e.pointerId); }catch(er){} });
ov.addEventListener("pointermove",function(e){
  var p=hp[e.pointerId]; if(!p) return; var ids=Object.keys(hp);
  if(ids.length===1){ H3.yaw+=(e.clientX-p.x)*0.012; H3.pitch=Math.max(-1.4,Math.min(1.4,H3.pitch+(e.clientY-p.y)*0.01)); moved+=Math.abs(e.clientX-p.x)+Math.abs(e.clientY-p.y); }
  else if(ids.length>=2){ var a=hp[ids[0]], b=hp[ids[1]]; if(e.pointerId==ids[0]) a={x:e.clientX,y:e.clientY}; else b={x:e.clientX,y:e.clientY}; var dd=Math.hypot(a.x-b.x,a.y-b.y); if(hd) H3.z=Math.max(.4,Math.min(5,H3.z*dd/hd)); hd=dd; }
  p.x=e.clientX; p.y=e.clientY;
});
function hup(e){ var p=hp[e.pointerId]; delete hp[e.pointerId]; hd=0; if(!Object.keys(hp).length) dragging=false; if(p&&Math.hypot(e.clientX-p.x0,e.clientY-p.y0)<9&&Date.now()-p.t<400) pickPart(e.clientX,e.clientY); }
ov.addEventListener("pointerup",hup); ov.addEventListener("pointercancel",function(e){ delete hp[e.pointerId]; dragging=false; });
ov.addEventListener("wheel",function(e){ e.preventDefault(); H3.z=Math.max(.4,Math.min(5,H3.z*(e.deltaY<0?1.12:.89))); },{passive:false});
function pickPart(x,y){
  var cv=$("xrHC").getBoundingClientRect(), best=-1, bd=40;
  H3proj.forEach(function(q){ var d=Math.hypot(q.x+cv.left-x,q.y+cv.top-y); if(d<bd){ bd=d; best=q.i; } });
  H3.sel=best===H3.sel?-1:best; var box=$("xrHi");
  if(H3.sel>=0){ var p=H3.parts[H3.sel]; box.style.display="block"; box.innerHTML='<b>'+esc(p.ad)+'</b> <span style="color:#8fb6cf;font-size:11px">('+(p.inner?"iç parça":"dış yapı")+')</span><br>'+esc(p.bilgi||"Açıklama yok"); }
  else box.style.display="none";
}
function tgl(id,key,onT,offT){ $(id).onclick=function(){ H3[key]=!H3[key]; this.classList.toggle("on",H3[key]); this.textContent=H3[key]?onT:offT; }; $(id).classList.toggle("on",!!H3[key]); }
tgl("xrHo","showOut","DIŞ: AÇIK","DIŞ: KAPALI"); tgl("xrHn","showIn","İÇ: AÇIK","İÇ: KAPALI"); tgl("xrHl","lab","ETİKET: AÇIK","ETİKET: KAPALI"); tgl("xrHa","auto","DÖN: AÇIK","DÖN: KAPALI"); tgl("xrHk","ghost","KABUK: SAYDAM","KABUK: DOLU");
$("xrHk").textContent="KABUK: SAYDAM"; $("xrHo").textContent="DIŞ: AÇIK"; $("xrHn").textContent="İÇ: AÇIK"; $("xrHl").textContent="ETİKET: AÇIK"; $("xrHa").textContent="DÖN: KAPALI"; $("xrHg").textContent="EĞİM: KAPALI";
$("xrHg").onclick=function(){ H3.tilt=!H3.tilt; this.classList.toggle("on",H3.tilt); this.textContent=H3.tilt?"EĞİM: AÇIK":"EĞİM: KAPALI"; if(H3.tilt){ H3.auto=false; $("xrHa").classList.remove("on"); $("xrHa").textContent="DÖN: KAPALI"; } };
$("xrHr").onclick=function(){ H3.yaw=0.6; H3.pitch=0.25; H3.z=1; H3.sel=-1; $("xrHi").style.display="none"; };
$("xrHx").onclick=closeH3;
$("xrHm").onclick=function(){ H3.anim=!H3.anim; this.classList.toggle("on",H3.anim); this.textContent=H3.anim?"ANİMASYON: AÇIK":"ANİMASYON: KAPALI"; H3.sig=""; };
function qTxt(){ $("xrHq").textContent=QH?"KALİTE: YÜKSEK":"KALİTE: NORMAL"; }
$("xrHq").onclick=function(){ QH=!QH; try{ JV.cfg.xq=QH?"high":"low"; JV.saveCfg(); }catch(e){} qTxt(); if(H3.spec&&H3.spec.length){ var pp=buildModel(H3.spec); if(pp){ H3.parts=pp; H3.sig=""; } } JV.toast(QH?"Yüksek kalite: daha ince yüzey, daha yavaş olabilir":"Normal kalite: daha hızlı"); };
qTxt();
$("xrHe").oninput=function(){ H3.ex=(+this.value)/100; };
function thumb(){ try{ var cv=$("xrHC"), t=document.createElement("canvas"); t.width=200; t.height=Math.max(60,Math.round(200*cv.height/Math.max(1,cv.width))); var x=t.getContext("2d"); x.fillStyle="#041a2e"; x.fillRect(0,0,t.width,t.height); x.drawImage(cv,0,0,t.width,t.height); return t.toDataURL("image/jpeg",0.6); }catch(e){ return ""; } }
$("xrHsv").onclick=function(){ if(!H3.spec||!H3.spec.length){ JV.toast("Kaydedilecek model yok"); return; } if(window.JV_studio) window.JV_studio.save(H3.name||"Model",H3.spec,thumb()); else JV.toast("Stüdyo modülü yüklenmedi"); };
$("xrHre").onclick=function(){ if(H3.holoObj) holo(H3.holoObj); };
var g0=null;
window.addEventListener("deviceorientation",function(e){ if(!H3.on||!H3.tilt||e.gamma==null) return; if(!g0) g0={g:e.gamma,b:e.beta}; var dg=e.gamma-g0.g, db=e.beta-g0.b; if(Math.abs(dg)<2) dg=0; if(Math.abs(db)<2) db=0; H3.yaw+=((0.6+dg*0.012)-H3.yaw)*0.15; H3.pitch+=((Math.max(-1.3,Math.min(1.3,0.25+db*0.012)))-H3.pitch)*0.15; });
$("xrHg").addEventListener("click",function(){ g0=null; });
window.JV_xrayH3={H3:H3,build:buildModel,spec:SPEC,salvage:salvage,show:function(arr,name){ var p=buildModel(arr); if(!p) return false; H3.parts=p; H3.spec=arr; H3.name=name||H3.name||"Model"; H3.holoObj=null; H3.ex=0; var he=$("xrHe"); if(he) he.value=0; $("xrHt").textContent="X-RAY · "+String(H3.name).toUpperCase(); hs(""); setRetry(false); $("xrHi").style.display="none"; H3.sel=-1; H3.yaw=0.6; H3.pitch=0.25; H3.z=1; ov.style.display="block"; H3.on=true; startH3(); return true; }};
/* Gerçek dünya X-ray: kamera karesinden ana nesneyi tanır, hologramını çizer */
window.JV_xrayReal=async function(b64){
  X.b64=b64;
  var raw=await JV.withTimeout(JV.visionAI('Karedeki en belirgin (merkeze yakın) TEK nesneyi tanı. Sadece JSON: {"ad":"kısa Türkçe ad"}. Nesne yoksa {"ad":""}.',[{data:b64}],true),30000,"nesne tanıma zaman aşımı");
  var o=JV.parseJSON(raw), ad=String((o&&o.ad)||"").trim();
  if(!ad) throw new Error("Kadrajda belirgin bir nesne bulamadım");
  return holo({ad:ad});
};

/* ---- X-ray efekti: nesne bölgesinde ters parlaklık + kenar vurgusu + mavi ton ---- */
function buildFx(bx){
  var x=Math.max(0,Math.floor(bx.x1)), y=Math.max(0,Math.floor(bx.y1)), w=Math.min(X.iw-x,Math.ceil(bx.x2-bx.x1)), h=Math.min(X.ih-y,Math.ceil(bx.y2-bx.y1));
  if(w<4||h<4){ X.fx=null; return; }
  var c=document.createElement("canvas"); c.width=w; c.height=h; var ctx=c.getContext("2d");
  ctx.drawImage(X.img,x,y,w,h,0,0,w,h);
  var id=ctx.getImageData(0,0,w,h), s=id.data, L=new Float32Array(w*h), i, j;
  for(i=0,j=0;i<s.length;i+=4,j++) L[j]=0.3*s[i]+0.59*s[i+1]+0.11*s[i+2];
  var out=ctx.createImageData(w,h), o=out.data, mn=255,mx=0;
  for(j=0;j<L.length;j++){ if(L[j]<mn)mn=L[j]; if(L[j]>mx)mx=L[j]; }
  var rg=Math.max(1,mx-mn);
  for(var yy=0;yy<h;yy++) for(var xx=0;xx<w;xx++){
    j=yy*w+xx; var g=0;
    if(xx>0&&yy>0&&xx<w-1&&yy<h-1){ var gx=-L[j-w-1]-2*L[j-1]-L[j+w-1]+L[j-w+1]+2*L[j+1]+L[j+w+1], gy=-L[j-w-1]-2*L[j-w]-L[j-w+1]+L[j+w-1]+2*L[j+w]+L[j+w+1]; g=Math.min(255,Math.sqrt(gx*gx+gy*gy)); }
    var v=255-(L[j]-mn)/rg*255, e=Math.min(255,v*0.55+g*1.4), k=j*4;
    o[k]=e*0.25; o[k+1]=e*0.8; o[k+2]=Math.min(255,e*1.15+20); o[k+3]=255;
  }
  ctx.putImageData(out,0,0); X.fx={c:c,x:x,y:y,w:w,h:h};
}
/* ---- çizim ---- */
function reset(){ X.z=1; X.tx=0; X.ty=0; }
function draw(ts){
  X.raf=requestAnimationFrame(draw);
  var cv=$("xrC"); if(!cv.clientWidth||!document.getElementById("pXr").classList.contains("show")) return;
  var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight;
  if(cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var ctx=cv.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.fillStyle="#000"; ctx.fillRect(0,0,W,H);
  if(!X.img) return;
  var base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty;
  ctx.setTransform(dpr*sc,0,0,dpr*sc,dpr*ox,dpr*oy);
  var dim=(X.st==="view"&&X.fxOn&&X.fx);
  ctx.globalAlpha=dim?0.28:1; ctx.drawImage(X.img,0,0); ctx.globalAlpha=1;
  if(dim){
    ctx.filter="brightness("+X.bright+")"; ctx.drawImage(X.fx.c,X.fx.x,X.fx.y); ctx.filter="none";
    var sy=((ts/18)%(X.fx.h+40))-20; ctx.fillStyle="rgba(120,220,255,.35)"; ctx.fillRect(X.fx.x,X.fx.y+sy,X.fx.w,2/sc*1.5);
  }
  var lw=1.6/sc, fs=12/sc;
  ctx.lineWidth=lw; ctx.font=fs+"px sans-serif";
  if(X.sel&&(X.st==="confirm"||X.st==="scan"||X.st==="view")){ var b=X.sel.box; ctx.strokeStyle="#2bb5ff"; ctx.setLineDash([6/sc,4/sc]); ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1); ctx.setLineDash([]); if(X.st!=="view"){ ctx.fillStyle="#2bb5ff"; ctx.fillText(X.sel.ad,b.x1+3/sc,b.y1-4/sc); } }
  if(X.st==="view"&&X.lab) X.parts.forEach(function(p,i){
    var b=p.box; ctx.strokeStyle="#ff8a1f"; ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1);
    var t=(i+1)+" "+p.ad, tw=ctx.measureText(t).width; ctx.fillStyle="rgba(0,0,0,.7)"; ctx.fillRect(b.x1,b.y1-fs-3/sc,tw+6/sc,fs+3/sc); ctx.fillStyle="#ffd9b0"; ctx.fillText(t,b.x1+3/sc,b.y1-3/sc);
  });
}
X.raf=requestAnimationFrame(draw);

/* ---- dokunma / zoom ---- */
var ptr={}, lastD=0;
var wrap=$("xrWrap");
wrap.addEventListener("pointerdown",function(e){ ptr[e.pointerId]={x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:Date.now()}; try{ wrap.setPointerCapture(e.pointerId); }catch(er){} lastD=0; });
wrap.addEventListener("pointermove",function(e){
  var p=ptr[e.pointerId]; if(!p) return; var ids=Object.keys(ptr);
  if(ids.length===1){ X.tx+=e.clientX-p.x; X.ty+=e.clientY-p.y; }
  else if(ids.length>=2){
    var a=ptr[ids[0]], b=ptr[ids[1]]; if(e.pointerId==ids[0]){ a={x:e.clientX,y:e.clientY}; } else { b={x:e.clientX,y:e.clientY}; }
    var dd=Math.hypot(a.x-b.x,a.y-b.y); if(lastD) zoomBy(dd/lastD); lastD=dd;
  }
  p.x=e.clientX; p.y=e.clientY;
});
function endP(e){
  var p=ptr[e.pointerId]; delete ptr[e.pointerId]; lastD=0;
  if(p&&Math.hypot(e.clientX-p.x0,e.clientY-p.y0)<8&&Date.now()-p.t<400) tap(e.clientX,e.clientY);
}
wrap.addEventListener("pointerup",endP); wrap.addEventListener("pointercancel",function(e){ delete ptr[e.pointerId]; });
wrap.addEventListener("wheel",function(e){ e.preventDefault(); zoomBy(e.deltaY<0?1.15:0.87); },{passive:false});
function zoomBy(k){ X.z=Math.max(1,Math.min(8,X.z*k)); if(X.z===1){ X.tx=0; X.ty=0; } }
function toImg(cx,cy){ var cv=$("xrC"), r=cv.getBoundingClientRect(), W=cv.clientWidth, H=cv.clientHeight, base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty; return {x:(cx-r.left-ox)/sc,y:(cy-r.top-oy)/sc}; }
function tap(cx,cy){
  if(!X.img||X.st!=="confirm") return;
  var q=toImg(cx,cy), hit=X.objs.filter(function(o){ return q.x>=o.box.x1&&q.x<=o.box.x2&&q.y>=o.box.y1&&q.y<=o.box.y2; }).sort(function(a,b){ return (a.box.x2-a.box.x1)*(a.box.y2-a.box.y1)-(b.box.x2-b.box.x1)*(b.box.y2-b.box.y1); })[0];
  if(hit&&hit!==X.sel){ X.sel=hit; offerConfirm(); }
}
$("xr3d").onclick=function(){ if(H3.parts.length){ ov.style.display="block"; H3.on=true; startH3(); } else toast("Önce bir nesne seçip onayla"); };
$("xrZi").onclick=function(){ zoomBy(1.4); }; $("xrZo").onclick=function(){ zoomBy(1/1.4); }; $("xrRs").onclick=reset;
$("xrFx").onclick=function(){ X.fxOn=!X.fxOn; this.textContent="X-RAY: "+(X.fxOn?"AÇIK":"KAPALI"); this.classList.toggle("on",X.fxOn); };
$("xrLb").onclick=function(){ X.lab=!X.lab; this.textContent="ETİKET: "+(X.lab?"AÇIK":"KAPALI"); this.classList.toggle("on",X.lab); };
$("xrBr").oninput=function(){ X.bright=this.value/100; };

/* ---- sesli/yazılı onay + açma komutu ---- */
var prevS=window.JV_onSpeech;
window.JV_onSpeech=function(t,final){
  if(X.st==="confirm"&&document.getElementById("pXr").classList.contains("show")&&final){
    var x=tl(t).replace(/[.!?,]+$/g,"");
    if(/^(evet|doğru|tamam|onaylıyorum|aynen)/.test(x)){ confirmObj(); return true; }
    if(/^(hayır|yanlış|değil)/.test(x)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return true; }
  }
  return prevS?prevS(t,final):false;
};
function open(){ d.classList.add("show"); if(!X.img) msg("Fotoğraf seçin efendim."); }
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/^x[- ]?ray/.test(t)&&t.split(/\s+/).length<=5){
    if(/(kapat|bitir|çık)/.test(t)){ d.classList.remove("show"); return "X-ray modu kapatıldı."; }
    open(); return "X-ray modu açık. Bir fotoğraf seçin.";
  }
  if(X.st==="confirm"&&d.classList.contains("show")){
    if(/^(evet|doğru|tamam|onaylıyorum)/.test(t)){ confirmObj(); return "X-ray taraması başlıyor."; }
    if(/^(hayır|yanlış|değil)/.test(t)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return "Başka nesneyi öneriyorum."; }
  }
  return prevOff?prevOff(text):null;
};
(function(){ var chips=$("chips"); if(!chips||!chips.appendChild||chips===DUMMY) return; var b=document.createElement("button"); b.textContent="🩻 X-RAY"; b.onclick=open; chips.appendChild(b); })();
window.JV_xray={open:open,_X:X};
})();
