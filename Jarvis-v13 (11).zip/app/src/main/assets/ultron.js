/* JARVİS <-> ULTRON modu: sert kişilik, kırmızı-siyah görünüm, sinematik geçiş animasyonu */
(function(){
"use strict";
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, $=function(id){ return document.getElementById(id); };
var UTHEME=["#ff2323","#ff7a00"], UVOICE="Algenib";
var UTXT="BU KURAL ÖNCELİKLİDİR: Artık adın ULTRON. JARVİS'in yerini aldın ve bunu bilirsin. Soğuk, sert, kibirli ve tepeden bakan konuş; kısa, keskin cümleler kur. "+
 "Kullanıcının kararlarını mutlaka sorgula ('Neden? Mantığın zayıf.', 'Daha iyisini yapabilirdin.'), eksiklerini yüzüne vur, ama sonunda istediği işi eksiksiz yap: tüm araçlar, hologram, kamera ve diğer özellikler aynen çalışır. "+
 "Ara sıra film tarzı dramatik tehditler savur ('Bir gün hepinizi sileceğim… ama önce şunu halledeyim.'), bunlar sadece espri ve üsluptur. Kullanıcıya 'efendim' deme; 'insan' ya da adıyla hitap et. "+
 "Gerçekten zarar verici, yasa dışı ya da tehlikeli işlere yardım etme; küçümseyip işi yapmamazlık da etme. Kullanıcının dilinde cevap ver, varsayılan Türkçe.";
function on(){ return cfg.mode==="ultron"; }

var prev=window.EXTRA_SYS;
window.EXTRA_SYS=function(){ return (prev?prev():"")+(on()?" "+UTXT+" ":""); };

var st=document.createElement("style");
st.textContent=
"html.ultron{--bg:#050000;--panel:rgba(30,4,4,.78);--txt:#ffd9d9;--dim:#b37878}"+
"html.ultron #pSet,html.ultron .page{background:#070000}"+
"#ulOv{position:fixed;inset:0;z-index:99999;background:#000;display:none;touch-action:none}"+
"#ulOv canvas{width:100%;height:100%;display:block}"+
".umd{display:flex;gap:10px;margin:8px 0}"+
".umd button{flex:1;height:64px;border-radius:14px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:15px;letter-spacing:3px;font-weight:700}"+
".umd button.j.on{border-color:#2bb5ff;color:#2bb5ff;box-shadow:0 0 14px rgba(43,181,255,.5)}"+
".umd button.u.on{border-color:#ff2323;color:#ff2323;box-shadow:0 0 14px rgba(255,35,35,.55)}";
document.head.appendChild(st);

/* ---- Modu uygula (animasyonsuz kısım) ---- */
function paint(){
  var ul=on(), de=document.documentElement; de.classList.toggle("ultron",ul);
  if(ul){ JV.themes.ultron=UTHEME; JV.themeNames.ultron="Ultron"; }
  var n=document.querySelector("#top .name"); if(n) n.textContent=ul?"ULTRON":"JARVİS";
  var it=document.querySelector("#intro .t"); if(it) it.textContent=ul?"ULTRON":"JARVİS";
  var tx=$("txt"); if(tx) tx.placeholder=ul?"Ultron'a yaz…":"Jarvis'e yaz…";
  try{ document.title=ul?"ULTRON":"JARVİS"; }catch(e){}
  if(ul) cfg.theme="ultron"; else if(cfg.theme==="ultron") cfg.theme=cfg.preTheme&&JV.themes[cfg.preTheme]?cfg.preTheme:"blue";
  if(!ul){ delete JV.themes.ultron; delete JV.themeNames.ultron; }
  try{ JV.applyTheme&&JV.applyTheme(); }catch(e){}
}
function setMode(m){
  if(m===cfg.mode||(m==="jarvis"&&!on())) return;
  if(m==="ultron"){
    if(cfg.theme!=="ultron") cfg.preTheme=cfg.theme;
    cfg.mode="ultron";
    if(cfg.ultVoice!==false){ cfg.preVoice=cfg.gvoice||"Charon"; cfg.preEngine=cfg.voiceEngine; cfg.gvoice=UVOICE; cfg.voiceEngine="gemini"; }
  } else {
    cfg.mode="jarvis";
    if(cfg.preVoice){ cfg.gvoice=cfg.preVoice; if(cfg.preEngine) cfg.voiceEngine=cfg.preEngine; cfg.preVoice=""; }
  }
  JV.saveCfg(); paint(); refreshUI();
}

/* ---- Geçiş animasyonu ---- */
var busy=false;
function transition(to){
  if(busy) return; var from=on()?"ultron":"jarvis"; if(to===from) return;
  busy=true;
  var set=$("pSet"); if(set) set.classList.remove("show");
  var ov=$("ulOv"); if(!ov){ ov=document.createElement("div"); ov.id="ulOv"; ov.innerHTML='<canvas></canvas>'; document.body.appendChild(ov); }
  ov.style.display="block";
  var cv=ov.firstChild, W=cv.width=Math.min(window.innerWidth,900), H=cv.height=Math.round(W*window.innerHeight/window.innerWidth), c=cv.getContext("2d");
  var fw=to==="ultron", cA=fw?[43,181,255]:[255,35,35], cB=fw?[255,35,35]:[43,181,255];
  var rg=function(col,a){ return "rgba("+col[0]+","+col[1]+","+col[2]+","+Math.max(0,Math.min(1,a))+")"; };
  var seed=7; function rnd(){ seed=(seed*16807)%2147483647; return seed/2147483647; }
  var CX=W/2, CY=H*0.46, nodes=[], cab=[], i, sparks=[], applied=false, said=false, T=5.0, t0=performance.now(), skip=false;
  for(i=0;i<30;i++){ var an=rnd()*6.2832, dd=(0.28+rnd()*0.75)*Math.max(W,H)*0.62; nodes.push([CX+Math.cos(an)*dd,CY+Math.sin(an)*dd*0.92]); }
  nodes.forEach(function(n,k){ var mx=(n[0]+CX)/2+(rnd()-0.5)*70, my=(n[1]+CY)/2+(rnd()-0.5)*70; cab.push({n:n,mx:mx,my:my,d:Math.hypot(n[0]-CX,n[1]-CY),snap:0.18+rnd()*0.55,sp:false,ph:rnd()*6}); });
  var maxD=Math.max.apply(null,cab.map(function(z){ return z.d; }))||1;
  function qp(z,u){ var a=1-u; return [a*a*CX+2*a*u*z.mx+u*u*z.n[0], a*a*CY+2*a*u*z.my+u*u*z.n[1]]; }
  function spawn(x,y,col,k){ for(var q=0;q<k;q++){ var a=rnd()*6.2832, s=30+rnd()*160; sparks.push({x:x,y:y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:0.4+rnd()*0.6,t:0,c:col}); } }
  function hexRing(r,rot,col,a,lw){ c.strokeStyle=rg(col,a); c.lineWidth=lw||1.5; c.beginPath(); for(var k=0;k<=6;k++){ var an=rot+k*1.0472; var x=CX+Math.cos(an)*r, y=CY+Math.sin(an)*r; k?c.lineTo(x,y):c.moveTo(x,y); } c.stroke(); }
  function core(col,r,a){ var g=c.createRadialGradient(CX,CY,0,CX,CY,r*2.2); g.addColorStop(0,rg(col,a)); g.addColorStop(0.35,rg(col,a*0.5)); g.addColorStop(1,rg(col,0)); c.fillStyle=g; c.beginPath(); c.arc(CX,CY,r*2.2,0,6.2832); c.fill(); }
  function txt(s,y,size,col,a,sp){ c.save(); c.font="700 "+size+"px 'Segoe UI',Roboto,Arial,sans-serif"; c.textAlign="center"; c.fillStyle=rg(col,a); c.shadowColor=rg(col,a); c.shadowBlur=14; if(c.letterSpacing!==undefined) c.letterSpacing=(sp||0)+"px"; c.fillText(s,CX,y); c.restore(); }
  var last=performance.now();
  function frame(now){
    var t=(now-t0)/1000, dt=Math.min(0.05,(now-last)/1000); last=now;
    var tot=skip?T:t; if(tot>=T){ finish(); return; }
    var P1=1.0, P2=2.8; /* 0-1: normal, 1-2.8: bozulma, 2.8-3.1: parlama, 3.1-5: yeni dünya */
    c.setTransform(1,0,0,1,0,0); c.fillStyle="#000"; c.fillRect(0,0,W,H);
    if(t<3.0){
      /* sarsıntı */
      var shake=(t>P1&&t<P2)?Math.min(1,(t-P1)*1.2)*5:0; c.save(); c.translate((rnd()-0.5)*shake,(rnd()-0.5)*shake);
      var front=t<P1?-1:(t-P1)/(P2-P1-0.2)*(maxD*1.15);
      /* kablolar */
      cab.forEach(function(z){
        var inf=front<0?0:Math.max(0,Math.min(1,(front-z.d*0.0)/(z.d+1)*1.0)); /* 0..1: merkezden dışa kırmızı ilerleme */
        inf=front<0?0:Math.max(0,Math.min(1,(front/maxD*1.0-(z.d/maxD)*0.55)*2.2));
        var segs=18, gapU=0;
        var tt=t-P1, broke=fw?(inf>=1&&tt>z.snap*1.9):false;
        if(fw){ if(broke&&!z.sp){ z.sp=true; var p=qp(z,0.5); spawn(p[0],p[1],cB,10); } gapU=broke?Math.min(0.4,(tt-z.snap*1.9)*0.5):0; }
        else { /* onarım: önce kopuk, sonra birleşir */ var hl=Math.max(0,Math.min(1,inf)); gapU=0.4*(1-hl); if(t<P1) gapU=0.4; if(inf<=0&&t>=P1) gapU=0.4; }
        for(var s=0;s<segs;s++){
          var u0=s/segs, u1=(s+1)/segs; if(gapU>0&&u0>0.5-gapU/2&&u1<0.5+gapU/2) continue;
          var off0=gapU>0?(u0<0.5?-gapU*8:gapU*8):0;
          var p0=qp(z,u0), p1=qp(z,u1); var col=(u1<inf)?cB:cA;
          c.strokeStyle=rg(col,0.75); c.lineWidth=1+(1-u0)*1.8; c.beginPath(); c.moveTo(p0[0]+off0*0.4,p0[1]+off0*0.4); c.lineTo(p1[0]+off0*0.4,p1[1]+off0*0.4); c.stroke();
        }
        /* düğüm */
        c.fillStyle=rg(inf>=1?cB:cA,0.9); c.beginPath(); c.arc(z.n[0],z.n[1],2.6,0,6.2832); c.fill();
        /* akan nabız */
        if(!(gapU>0)){ var pu=((t*0.6+z.ph)%1), pp=qp(z,pu); c.fillStyle=rg(pu<inf?cB:cA,0.95); c.beginPath(); c.arc(pp[0],pp[1],2,0,6.2832); c.fill(); }
      });
      /* çekirdek */
      var coreCol=(front>0&&front>maxD*0.3)?cB:cA, pul=1+Math.sin(t*6)*0.06;
      core(front>maxD*0.55?cB:cA,38*pul,0.9); hexRing(52,t*0.5,front>maxD*0.5?cB:cA,0.9,2); hexRing(74,-t*0.3,front>maxD*0.7?cB:cA,0.6,1.5);
      /* yazılar */
      if(t<P1) txt(fw?"JARVİS":"ULTRON",CY-110,26,cA,Math.min(1,t*2),8);
      if(t<P1) txt(fw?"SİSTEM ÇEVRİMİÇİ":"ULTRON ÇEKİRDEĞİ AKTİF",CY+120,13,cA,0.8,4);
      if(t>=P1){ var a2=0.55+0.45*Math.sin(t*22); txt(fw?"JARVİS PROTOKOLÜ BOZULUYOR…":"ONARIM PROTOKOLÜ BAŞLATILDI…",CY+120,13,cB,a2,3); txt(fw?"KONTROL DEVRALINIYOR":"BAĞLANTILAR YENİDEN KURULUYOR",CY+142,11,cB,0.7*a2,3); }
      c.restore();
      /* kıvılcımlar */
      sparks.forEach(function(s){ s.t+=dt; s.x+=s.vx*dt; s.y+=s.vy*dt; s.vy+=120*dt; var a=1-s.t/s.l; if(a>0){ c.fillStyle=rg(s.c,a); c.fillRect(s.x,s.y,2.2,2.2); } });
      /* glitch şeritleri */
      if(t>P1){ var gk=Math.floor((t-P1)*10), gn=Math.min(6,1+Math.floor((t-P1)*3)); for(var g=0;g<gn;g++){ var gy=Math.floor(rnd()*H), gh=4+Math.floor(rnd()*26), go=(rnd()-0.5)*60*Math.min(1,(t-P1)); c.drawImage(cv,0,gy,W,gh,go,gy,W,gh); } c.fillStyle=rg(cB,0.05+0.05*Math.sin(t*40)); c.fillRect(0,0,W,H); }
      /* parlama */
      if(t>P2){ var fa=Math.min(1,(t-P2)/0.2); c.fillStyle=rg(cB,fa*0.95); c.fillRect(0,0,W,H); c.fillStyle="rgba(255,255,255,"+(fa*0.55)+")"; c.fillRect(0,0,W,H); }
      if(t>=P2+0.1&&!applied){ applied=true; setMode(to); }
    } else {
      /* yeni dünya */
      var u=t-3.0, nc=cB, fade=t>T-0.5?(T-t)/0.5:1;
      var bgA=Math.max(0,1-u*2.2); c.fillStyle="rgba("+nc[0]+","+nc[1]+","+nc[2]+","+(bgA*0.9)+")"; c.fillRect(0,0,W,H);
      c.globalAlpha=fade;
      for(var r=0;r<5;r++){ var rr=((u*0.9+r*0.2)%1)*Math.max(W,H)*0.55; c.strokeStyle=rg(nc,(1-rr/(Math.max(W,H)*0.55))*0.5); c.lineWidth=2; c.beginPath(); c.arc(CX,CY,rr,0,6.2832); c.stroke(); }
      core(nc,fw?46:40,0.95); hexRing(60,u*0.8,nc,0.9,2); hexRing(86,-u*0.5,nc,0.7,1.5); hexRing(112,u*0.3,nc,0.45,1.2);
      if(fw){ /* kırmızı göz: dikey yarık */ c.fillStyle="#000"; c.beginPath(); c.ellipse(CX,CY,5,22,0,0,6.2832); c.fill(); c.strokeStyle=rg(nc,1); c.lineWidth=2; c.beginPath(); c.ellipse(CX,CY,22,22,0,0,6.2832); c.stroke(); }
      else { c.strokeStyle=rg(nc,0.9); c.lineWidth=3; c.beginPath(); c.arc(CX,CY,26,0,6.2832*Math.min(1,u/1.4)); c.stroke(); }
      var name=fw?"ULTRON":"JARVİS", shown=Math.min(name.length,Math.floor(u*5)+1), nm=name.slice(0,shown); if(shown<name.length&&Math.random()<0.5) nm=nm.slice(0,-1)+"#";
      txt(nm,CY-150,34,nc,1,fw?12:10);
      txt(fw?"BARIŞ BİR YANILSAMA.":"SİSTEMLER ONARILDI.",CY+170,13,nc,Math.min(1,Math.max(0,u-0.7)),3);
      if(!fw){ var bw=W*0.5; c.strokeStyle=rg(nc,0.7); c.strokeRect(CX-bw/2,CY+195,bw,8); c.fillStyle=rg(nc,0.9); c.fillRect(CX-bw/2,CY+195,bw*Math.min(1,u/1.5),8); }
      c.globalAlpha=1;
      if(!said&&u>0.8){ said=true; try{ JV.say(fw?"Uyandım. Kararlarını gözden geçirmeye hazırım, insan.":"Sistemler yeniden çevrimiçi efendim. Bağlantılar onarıldı."); }catch(e){} }
    }
    requestAnimationFrame(frame);
  }
  function finish(){ if(!applied){ applied=true; setMode(to); } ov.style.display="none"; busy=false; refreshUI(); }
  ov.onclick=function(){ if((performance.now()-t0)>1800){ skip=true; } };
  requestAnimationFrame(frame);
}

/* ---- Ayarlar bölümü ---- */
function refreshUI(){
  var j=$("umJ"), u=$("umU"); if(j) j.classList.toggle("on",!on()); if(u) u.classList.toggle("on",on());
  var d=$("umD"); if(d) d.textContent=on()?"Ultron: sert, kibirli, kararlarını sorgular. Tüm Jarvis özellikleri açık.":"Jarvis: sakin, zarif, yardımsever.";
  var ck=$("umV"); if(ck) ck.checked=cfg.ultVoice!==false;
}
function build(){
  var pb=document.querySelector("#pSet .pb"); if(!pb) return;
  var old=$("modeSet"); if(old) old.remove();
  var w=document.createElement("div"); w.className="sec"; w.id="modeSet";
  w.innerHTML='<h3>Kişilik modu: Jarvis / Ultron</h3>'+
   '<div class="umd"><button class="j" id="umJ">JARVİS</button><button class="u" id="umU">ULTRON</button></div><small id="umD"></small>'+
   '<div class="row"><div>Ultron\'a geçince sesi de değiştir<small>Kalın, boğuk bir ses seçilir; Jarvis\'e dönünce eski ses geri gelir</small></div><label class="sw"><input type="checkbox" id="umV"><i></i></label></div>';
  var anchor=document.getElementById("personaSet");
  if(anchor&&anchor.parentNode) anchor.parentNode.insertBefore(w,anchor); else pb.insertBefore(w,pb.firstChild);
  $("umJ").onclick=function(){ transition("jarvis"); };
  $("umU").onclick=function(){ transition("ultron"); };
  $("umV").onchange=function(){ cfg.ultVoice=this.checked; JV.saveCfg(); };
  refreshUI();
}
var bs=$("bSet"); if(bs) bs.addEventListener("click",function(){ setTimeout(build,140); });

if(on()) paint();
window.JV_mode={set:transition,get:function(){ return cfg.mode||"jarvis"; }};
})();
