# JARVİS

Kişisel yapay zeka asistanı (Android). Beyin: Claude API.

## Kurulum (3 adım)
1. GitHub'da **herkese açık (public)** yeni bir depo aç.
2. Bu klasörün İÇİNDEKİ her şeyi (`app`, `.github`, `build.gradle.kts` ...) depoya yükle. Web'de "Add file > Upload files" ile sürükle-bırak yeterli. `.github` klasörünün de yüklendiğinden emin ol.
3. Üstteki **Actions** sekmesinde derleme kendiliğinden başlar (5-8 dk). Bitince **Releases** bölümünde `Jarvis.apk` çıkar. Telefona indirip kur.

İlk açılışta ⚙ Ayarlar'dan Claude API anahtarını gir.

## Güncelleme
Yeni sürümde dosyaları depoya yükle, Actions yeni APK'yı Release'e koyar. Uygulamada Ayarlar > Güncelleme > Kontrol et (ya da Jarvis'e "güncelleme var mı" de).

Not: Güncelleme kontrolü için depo herkese açık olmalı.

## v2 (Ağır güncelleme)
Gemini/Claude seçimi, kamera HUD (nesne, mimik/el, çeviri, yüz), radar, medya arama, şifre kasası, canlı çeviri, cihaz durumu, takvim/arama/SMS araçları.

## v3
Gemini model otomatik seçimi ve yeniden deneme, anahtar sihirbazı, video/ses analizi, ESP32 BLE inceleme/yazma, bildirim okuma, alışkanlık analizi.

## v4
Yoğunluk hatasında otomatik yedek model, doğal Gemini sesi, ekran kontrolü (erişilebilirlik), takvim silme/taşıma.

## v5
Bilgi sorularında önce internet araması, HUD'da sesle soru sorma, HUD kota tasarrufu (görüntü değişince analiz), kota dolunca otomatik başka modele geçiş ve anlaşılır Türkçe hata.

v5.1: Gemini araması çalışmazsa Vikipedi yedeği, arama hatası cevabın altında görünür.

## v6
Küçük ses balonu (dışına dokununca kapanır), İzin merkezi, ekrana bak (screen_look), geçmiş sohbet arama ve genişletilmiş hafıza, çevrimdışı komutlar (fener, ses, saat, pil, alarm, sayaç, uygulama aç, ara, müzik).

## v7
- Güncel bilgi: her soruda Google Haberler (RSS) + Vikipedi birlikte, ~2 dk önbellek; sonuç yoksa "yok" demez.
- "WhatsApp'ı aç" gibi eylemlerde araç çağrısı zorunlu; "açtım" deyip açmazsa otomatik yeniden dener.
- Daha akıllı model: analiz/ön görü sorularında daha fazla düşünme.
- GPS radarı (konum, hız, adres, hava, yakındaki eczane/benzin…, navigasyon), Ağ radarı/cihaz tarayıcı/konum terminali (Hacker modu).
- Televizyon (Arçelik Google TV): bul, bir kez eşleştir, aç/kapat, Netflix/YouTube, "ses 28 yap".
- Yasalar: adlandırılmış komut dizileri (saman yasası), Ayarlar'dan yönetilir, "X yasasını aktif et".
- Otonom mod (arka plan nöbeti: pil/ısı/depolama uyarısı), alışkanlık önerileri, ajan modu (sürekli dinleme), görev & tercih hafızası, ön görü aracı, mod açılınca özellik anlatımı.
- Parlaklık ayarı için "sistem ayarlarını değiştir" izni gerekir (İzin merkezinde düğmesi var).

## v7.1
Yasa adımları daha esnek anlaşılır (sıfır, yarım, yüzde, full), anlaşılmayan adım yapay zekaya bırakılır, law_save yanlış parametre adlarını kabul eder, Wi-Fi/Bluetooth/uçak modu erişilebilirlikle hızlı ayarlardan yapılır (izin kapalıysa sorar), ekran kilidi için güvenlik ayarları açılır.

## v7.2
Yasa/komut anlama: sessize al, ekranı kilitle (yan tuş), 'yasayı aç', çoklu görev (tek cümlede 5 komut sırayla), kilit ve Wi-Fi adımları en sona, Wi-Fi durumu doğrulama, araç adı yazı olarak yazılırsa otomatik çalıştırma, dürüst ✅/⚠ rapor.

## v7.3
Genel güncel arama: her bilgi sorusunda (telefon kelimesi geçse bile) önce arama; kısa/yarım takip sorularında sohbet bağlamıyla yapay zeka arama sorgusu planlar, 2-4 kısa anahtar kelime sorgusu, tarih eşleştirme (★), 'kaç' kelimesinin 'aç' sanılması düzeltildi.

## v7.4
TV eşleşme SSL hatası: anahtar yeni adla (jarvis_tv2) RSA-PSS+PKCS1 imzalı üretilir, eski anahtar silinir, TLS 1.2 önce denenir, olmazsa varsayılan.

## v7.5
TV eşleşme: AndroidKeyStore yerine yazılım RSA anahtarı + elle üretilen X.509 sertifika (uygulama klasöründe saklanır; aynı yöntem sunucuda TLS 1.2/1.3 el sıkışmasıyla test edildi). Hata mesajları aşama aşama ve tam yazılır.

## v8 (Otonom mod)
Nöbet servisi artık SESLİ konuşur (Türkçe TTS, ses kısma/duck ile): pil %20/%10, pil doldu, ısınma, depolama, internet koptu/geldi, zamanlı hatırlatmalar. Ayarlar: sesli uyarı aç/kapat, ekran kapalıyken konuş, sessiz saatler, sesli test. Bildirimde 'Evet, uygula' düğmesi. 'saat 18:30 da su iç diye hatırlat' komutu ve reminder_add aracı.

## v9
- **Yasa tetikleyicileri**: saat (her gün / hafta içi / hafta sonu / gün adı), şarj takıldı/çekildi, Wi‑Fi bağlandı/koptu (SSID), pil eşiği. Ayarlar > Yasalar'dan veya sohbetten ("saman yasasını her gün 23:00'te çalıştır"). Otonom mod gerekir (WatchService). `LawSteps.kt` arka planda güvenli adımları (fener, parlaklık, ses) çalıştırır; geri kalanlar bildirimle sorulur.
- **Ana ekran widget'ı** (`JarvisWidget.kt`): dokununca ses balonu açılıp dinlemeye başlar.
- **Neon ikonlar** (`neon.js`): kısayol çubuğu SVG ikonları + animasyonlu mikrofon.

## v10
- **WhatsApp**: `send_whatsapp` artık mesajı kendisi gönderir (erişilebilirlikle Gönder tuşu). Birden fazla kişi eşleşirse sorar, cevap sonrası aynı mesajı tam adla gönderir. Başarısızsa dürüstçe söyler.
- **Mesaj okuma**: Ayarlar > Mesaj okuma. Seçili kişilerden WhatsApp/SMS gelince Otonom mod sesli okur (Bildirim erişimi gerekir).
- **Konum tetikleyici**: "burayı ev olarak kaydet", "eve varınca / evden çıkınca" (arka plan konum izni gerekir).
- **Yasa çakışması**: yasalar kuyrukta sırayla çalışır, ayrı bildirim ve ses.
- **HUD açılış ekranı**: dev ▶ simgesi kaldırıldı, neon açılış; ataç ikonu neon; yer araması için yedek sunucular + dürüst hata.
- **Ses kilidi** (`voice.js`): sesini kaydet/test et, istersen sadece senin sesine cevap (basit filtre, güvenlik değil).

## v10.1
- **Hologram modu kaldırıldı.**
- **Derin araştırma**: web araması (Bing Haber + DuckDuckGo), sonuç sayfalarının içi okunur, canlı skor listesi (ESPN); httpGet artık herhangi bir genel https sitesini okuyabilir (yerel adresler hariç). "Yok/bilmiyorum" demeden önce sayfa içeriği okunur.
- **Ses kilidi testi**: MODIFY_AUDIO_SETTINGS izni eklendi, gerçek hata mesajı gösterilir.
- **Ajan modu**: mikrofon her bitişte hemen yeniden açılır, ekran açık kalır.

## v11
- **Konum düzeltmesi:** "şu an" konumu 2 dakikadan eskiyse artık "şu an buradasın" denmez; eski konumla yer kaydedilmez.
- **Kayıtlı yerlerim** sayfası (ayarlar): listele, yeniden adlandır, taşı, sil. Sohbetten: "yerlerim", "evimi sil".
- **Yasalar sormadan çalışır:** bildirimle onay istemez; ekranı açar, öne gelir, adımları uygular. Gerekli: "Diğer uygulamaların üzerinde göster" izni (+ vivo'da "Arka planda açılır pencere").
- **Tercüman modu** (🌐 TERCÜMAN çipi / "tercüman modunu aç"): karşıdakini dinler, dili algılar, Türkçesini yazar; Sesli/Sessiz düğmesi; Türkçe yazdığını İngilizce okur.
- **Uygulama ajanı** (`app_agent`): çok adımlı işleri ekranı okuyarak yapar; riskli adımda (ödeme, silme, gönderme) sorar. Erişilebilirlik izni gerekir.

## v12
- **Durdur tuşu:** Jarvis düşünürken/konuşurken küçük turuncu halka belirir; basınca cevabı ve sesi keser.
- **Araştırma:** kaynak listesi ("Kaynaklar:"), ESPN fikstür (sonraki maç) ve puan durumu, internet yok / kaynak yok için açık hata, başarısız aramada yeniden deneme.
- **HUD QR okuyucu:** HUD'da "QR" modu; BarcodeDetector yoksa cihaz üstü ML Kit (build.gradle'a bağımlılık eklendi). Link açma/kopyalama/okuma.
- **Görev komutanı:** "görev komutanı modunu aç" → hedef sorar → planı okur → onay → uygulama ajanı yürütür.
- **Düşünme katmanları:** mantık, yaratıcı, matematik, eleştirel değerlendirme, sonuç doğrulama. Zor sorularda otomatik; "derin düşünme aç/kapat/otomatik".
- **X-ray modu:** fotoğraf → nesne onayı → X-ray filtresi + TAHMİNİ iç yapı etiketleri, zoom/kaydırma. Gerçek röntgen değildir.
- **Dünya takibi + sabah brifingi:** konu listesi, "brifing ver", zamanlı yasa ile her sabah otomatik. **Öngörü** (🔮): saat, pil, takvim, görev, alışkanlık, konum.

## v12.1
- Uygulama ajanı: erişilebilirlik izni kapalıyken takılıp "zaten çalışıyor" demesi düzeltildi; artık sebebi söyler ve izin ekranını açar.
- QR okuyucu ve ML Kit bağımlılığı kaldırıldı (APK küçülür).
- Tercüman: dil algılama bayrakları kaldırıldı (mikrofon "duymuyorum" sorunu için), hata kodu + sebep gösterilir, 1 otomatik yeniden deneme, ses seviyesi çubuğu. Yeni arayüz: sohbet balonları, 27 dil + arama, KARŞIYA GÖSTER (dev yazı), hazır cümleler, kamera çevirisi, hız ayarı, kopyala, geçmiş.
- X-ray: nesne kutusu doğrulaması (bozuk şerit hatası); onaydan sonra TAM EKRAN 3B tel kafes hologram (parmakla çevir, iki parmakla yakınlaştır, iç/dış parça aç-kapat, dokununca parça bilgisi, eğim sensörü). Model yapay zekâ çizimidir, tahminidir.

## v12.2
- Uygulama ajanı arka planda donması düzeltildi: bekleme yerel taraftan yapılır (`Plus.sleep`), çalışırken ön plan servisi + wake lock + WebView zamanlayıcıları canlı tutulur (`Plus.agentKeep`).
- Ajan, Jarvis'in kendi ekranını okuyup "ana ekrana git" demesin diye kurallar eklendi; ekranda yazı alanı yokken yazmaz.

## v12.3
- Uygulama ajanı: yeni `open_url` (arama/YouTube sonuç sayfasını doğrudan açar, arama kutusuna yazmaya uğraşmaz) ve `enter` (klavye Enter/Ara) eylemleri; "bitti" demeden önce ekranla doğrulama; sonuçta yapılan adımların özeti.

## v12.4
- X-ray hologram: istek dış yapı + iç parçalar olarak ikiye bölündü (paralel), yarıda kesilen JSON kurtarılır, bir kez kısa istekle yeniden denenir, hata sebebi ve TEKRAR DENE düğmesi gösterilir, yumuşak nesneler (kıyafet vb.) için katman/dikiş/düğme tarifi.

## v12.5
- Üstteki beyaz boşluk: durum çubuğunu gizleme kaldırıldı (klavye açılınca boşluk bırakıyordu); durum/gezinme çubuğu hep siyah.

## v13
- X-ray hologramı hafifletildi: kendiliğinden dönme kapalı başlar (DÖN düğmesiyle açılır), ekran sadece değişince çizilir, parlama yalnızca seçili parçada, çözünürlük sınırlı, eğim modu daha düşük hassasiyetli ve yumuşatılmış. Parça sayısı artırıldı (dış 18, iç 14).
- X-ray hologram: Gemini yoğunken 3 kez dener (4 ve 8 sn bekleyerek, ekranda "yoğun, yeniden deniyorum" yazar); dış yapı ve iç parçalar art arda istenir, dış yapı gelince hemen gösterilir.

## v13.2
- Jarvis varsayılan dijital asistan olarak seçilebilir: Ses balonu (VoiceActivity) ASSIST, VOICE_COMMAND ve SEARCH_LONG_PRESS niyetlerini alır. Ayarlar > Uygulamalar > Varsayılan uygulamalar > Dijital asistan uygulaması > Jarvis seçilince güç/ana ekran tuşuna uzun basış ve Bluetooth kulaklık tuşu Jarvis'i açıp dinletir. Arka planda dinleme yoktur, pil harcamaz.

## v13.3
- Jarvis "Dijital asistan uygulaması" listesinde görünür: `JarvisVoiceService`, `JarvisSessionService`, `JarvisRecognitionService` (JarvisAssist.kt) + `voice_interaction_service.xml`, `recognition_service.xml`. Güç/ana ekran tuşuna uzun basınca oturum mevcut ses balonunu açar. Arka planda dinleme yok.
- vivo'da güç tuşu: Ayarlar > Kısayollar ve erişilebilirlik > Güç tuşuna basılı tut > asistan.

## v13.4
- Ses modunda "Hey Google" benzeri ekran kenarı ışıması: tam ekran bir pencere yerine sistem katmanı (EdgeGlow.kt, TYPE_APPLICATION_OVERLAY) olarak çizilir; altındaki uygulama değişmez, dokunmayı engellemez. Dinlerken yavaş, düşünürken turuncu, konuşurken hızlı nefes alır (sadece View saydamlığı animasyonu, çok hafif). "Diğer uygulamaların üzerinde göster" izni gerekir; yoksa ses balonunda uyarı yazar.
- Ses penceresi küçük, saydam ve dokunmayı engellemeyen alt yazı penceresi olarak kaldı; 90 sn sonra kendini kapatır, kapanınca ışık da kalkar.
- Küre animasyonu hafifletildi (boşta 100 ms, aktifken 42 ms).

## v13.5
- X-ray hologram artık tel kafes değil KATI MODEL: ışık/gölge ve parlaklıkla boyanmış yüzeyler (ressam sıralaması), derinlik sisi, parça gerçek rengi (yapay zekâ "renk" verir). Yeni parça türleri: koni, egri (kıvrımlı boru); tup/halka için kalınlık (r, k). "KABUK: SAYDAM/DOLU" düğmesi dış kabuğu saydam yapar, iç parçalar görünür.
- Etiketler iki yan sütuna dizilir, çakışma çözülür, ince çizgiyle parçaya bağlanır (en çok 12). Dokunulan parçanın bilgisi ayrı kutuda.
- Çizim hâlâ sadece değişince yapılır; en çok 2800 yüzey.

## v13.6
- Ayarlar baştan düzenlendi: üstte arama, 7 kart (Beyin, Ses ve Kişilik, Görünüm, Bildirim ve Işık, Özellikler, Sistem, Veri). Karta dokununca sadece o grubun ayarları açılır; geri oku önce ana ayar ekranına döner. Hiçbir ayar silinmedi, sadece gruplandı ve hizalandı (yeni dosya: settings.js).
- Tema paketleri: 8 tema (Neon Mavi, Iron Man, Hacker Yeşil, Kırmızı Alarm, Mor Hayalet, Altın Zırh, Buz Mavisi, Matrix), isimli kutularla seçilir.
- Ses kütüphanesi: Ses 1–30 (Gemini'nin 30 hazır sesi). Dinle / Seç. Dinleme internet ve Gemini anahtarı ister. "Ses ve Kişilik > Jarvis sesi" içinden açılır. Eski 9'luk ses listesi bunun yerine geçti.

## v13.7
- X-ray hologramında "AYIR" kaydırıcısı: parçalar birbirinden ayrılır (patlatılmış görünüm); parçaya dokununca ayrıca öne çıkar.
- Hologram Stüdyosu (ana ekranda 🗂 STÜDYO): X-ray hologramındaki "💾 STÜDYOYA KAYDET" ve Holo Sohbet'teki 💾 ile modeller (en çok 30) kaydedilir; AÇ ile tekrar döndürülür, SİL ile silinir.
- Kişilik (Ayarlar > Ses ve Kişilik): Klasik, Ciddi Butler, Alaycı, Sakin, Komutan, Dost, Hacker. Karakterin önerilen sesi tek dokunuşla uygulanır. Sabah brifingi (kapalı gelir): sabah ilk açılışta tarih, hava, takvim özeti.
- Holo Sohbet (🌐 HOLO SOHBET): soruyu cevaplar ve konuyu 3D hologram olarak çizer. Temalar: Hacker (matris yağmuru), Iron, Alarm, Buz.
- Kamera HUD'a iki yeni mod: X-RAY (eşyaya tut, ŞİMDİ BAK: tanır ve 3D hologramını çizer) ve ORTAK GÖZ (🎤 KONUŞ ya da ŞİMDİ BAK: cevaplar ve baktığı şeyi kutuyla işaretler). Sürekli çekmez, sadece dokununca analiz eder.
- Yeni dosyalar: studio.js, persona.js, holochat.js.

## v13.8
- X-ray/hologram gerçekçilik: yumuşak ışık (iki ışık, kenar ışığı, zemin gölgesi), malzeme türleri (metal, plastik, cam, lastik, ahşap, boya, kemik), daha ince yüzey, yeni "donel" şekli (şişe, vazo, kule). "KALİTE: YÜKSEK/NORMAL" düğmesi (yüksek: daha çok yüzey + fotoğrafla kontrol turu).
- Bozuk model onarımı: yanlış ölçek otomatik düzeltilir, uzağa kaçan/kopya parçalar atılır, çok büyük yarıçaplar kırpılır; yüksek kalitede model fotoğrafla karşılaştırılıp yanlış parçalar silinir/düzeltilir. Hayvan/insan için iskelet-organ, bitki için iç yapı istemi.
- "ANİMASYON" düğmesi: Gemini hareket eden parçalara (tekerlek, pedal, piston, fan) dön / git-gel / salın verir; kapalı gelir (pil ve akıcılık için).
- Hologram Atölyesi (🏛 ATÖLYE): Heykel, İnsan vücudu atlası (8 sistem), Tarihî yapı, Canlı anatomisi, Oda (ölçüleri sen verirsin, eşyalar yerleştirilir, sığmayan/çakışan kırmızı), Rap yazarı (özgün söz, sesli oku, kopyala). Hepsi X-ray ekranında açılır: AYIR, etiket, kaydet çalışır.
- Çoklu görev: tek cümledeki birden çok iş sırayla araçlarla yapılır (sistem komutuna eklendi).
- Yeni dosya: topics.js.

## v13.9
- Atölye > CANLI: "📷 FOTOĞRAFTAN TANI VE ÇİZ" (fotoğraf seç, Jarvis hayvan/bitkiyi tanır, fotoğraftaki renkleriyle iskelet-organ ya da iç yapı hologramını çizer). Kamera HUD'daki X-RAY modu da hayvan/bitki/insan türünü ayırt eder.
- Atölye > ODA: "📷 FOTOĞRAFTAN TAHMİN ET" (1-3 foto): oda ölçüsü ve eşyalar tahmini çıkarılır (kapı yüksekliği gibi referanslarla, yaklaşık ±%20), forma yazılır, hologram oda kurulur; taşan/çakışan eşya kırmızı.

## v13.10 — X-ray "birebir" sadakat
- Yeni şekiller: **izgara** (düz/kavisli tel örgü panel: tel sandalye arkalığı, kafes, çit), **levha** (ince eğri yüzey), **yumusak** (yuvarlak köşeli minder/yastık).
- **ayna**: parça simetrik karşı kopyasıyla otomatik eklenir (sol/sağ bacak, tekerlek çifti).
- **Ön analiz**: önce fotoğraftaki nesnenin yapısı kelimelerle çıkarılır, çizim istemine eklenir.
- **Görsel kontrol**: model iki açıdan çizilip orijinal fotoğrafla birlikte Gemini'ye gönderilir; yanlış parçalar silinir/düzeltilir, eksikler eklenir (en çok 2 tur). Başarısızsa eski sayısal kontrole döner.
- Not: sadece sahte (mock) yanıtlarla test edildi; gerçek Gemini çıktısı kalitesi cihazda denenmeli. Düşük kalite modunda ön analiz ve görsel kontrol atlanır.

## v13.11 — Ultron modu
- Ayarlar > Ses ve Kişilik > "Kişilik modu": JARVİS / ULTRON seçimi. Tüm Jarvis özellikleri Ultron'da da açık; değişen: sert/kibirli üslup (kararları sorgular, film tarzı tehditler), kırmızı-siyah tema, "ULTRON" başlığı, isteğe bağlı kalın ses (Algenib; Jarvis'e dönünce eski ses geri gelir).
- Geçiş animasyonu (ultron.js): mavi kablolar kızıla döner, kopar, kıvılcım/glitch, parlama, ULTRON gözü. Ultron'dan dönüşte kablolar onarılır, JARVİS yeniden başlar. Animasyona dokunarak 2 sn sonra atlanabilir.
- Mod kapanıp açılınca korunur (cfg.mode).
