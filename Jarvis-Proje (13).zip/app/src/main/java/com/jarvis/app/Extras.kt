package com.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread
import kotlin.math.max

/** Ek özellikler için köprü (JS tarafında JarvisX). Her çağrı id ile sonuç döndürür. */
class Extras(private val act: JarvisActivity) {

    private val vault = Vault(act)
    private var unlockId: String? = null

    private fun js(code: String) {
        act.runOnUiThread { act.web.evaluateJavascript(code, null) }
    }

    private fun result(id: String, ok: Boolean, data: String) {
        js("window.onNativeResult(${JSONObject.quote(id)}, $ok, ${JSONObject.quote(data)})")
    }

    // ---------- İzinler ----------

    @JavascriptInterface
    fun requestPerms(id: String, csv: String) {
        thread {
            val list = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val ok = act.ensurePerms(list.toTypedArray())
            result(id, ok, if (ok) "ok" else "izin verilmedi")
        }
    }

    // ---------- Radar ve durum ----------

    @JavascriptInterface
    fun radar(id: String) {
        thread {
            try {
                result(id, true, Radar.scan(act).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "Radar hatası")
            }
        }
    }

    @JavascriptInterface
    fun status(id: String) {
        thread {
            try {
                result(id, true, Tools.deviceStatus(act))
            } catch (e: Exception) {
                result(id, false, e.message ?: "Durum okunamadı")
            }
        }
    }

    // ---------- Medya ----------

    private fun mediaPerms(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun thumb(uri: Uri): String? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 700 || o.outHeight / s > 700) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val k = 288f / max(bmp.width, bmp.height)
            val sc = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
            val bos = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 70, bos)
            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    /** args: {"from":saniye,"to":saniye,"offset":n,"limit":n} */
    @JavascriptInterface
    fun photos(id: String, args: String) {
        thread {
            try {
                val a = JSONObject(args)
                if (!act.ensurePerms(mediaPerms())) {
                    result(id, false, "Fotoğraflara erişim izni verilmedi.")
                    return@thread
                }
                val from = a.optLong("from", 0)
                val to = a.optLong("to", System.currentTimeMillis() / 1000)
                val offset = a.optInt("offset", 0)
                val limit = a.optInt("limit", 24)
                val col = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val dateCol = MediaStore.Images.Media.DATE_ADDED
                val c = act.contentResolver.query(
                    col,
                    arrayOf(MediaStore.Images.Media._ID, dateCol),
                    "$dateCol >= ? AND $dateCol <= ?",
                    arrayOf(from.toString(), to.toString()),
                    "$dateCol DESC"
                )
                val items = JSONArray()
                var total = 0
                if (c != null) {
                    c.use {
                        total = it.count
                        if (offset < total && it.moveToPosition(offset)) {
                            do {
                                val pid = it.getLong(0)
                                val uri = ContentUris.withAppendedId(col, pid)
                                val b64 = thumb(uri)
                                if (b64 != null) {
                                    val o = JSONObject()
                                    o.put("uri", uri.toString())
                                    o.put("date", it.getLong(1))
                                    o.put("b64", b64)
                                    items.put(o)
                                }
                            } while (items.length() < limit && it.moveToNext())
                        }
                    }
                }
                val out = JSONObject()
                out.put("total", total)
                out.put("items", items)
                result(id, true, out.toString())
            } catch (e: Exception) {
                result(id, false, "Fotoğraflar okunamadı: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun findFiles(id: String, q: String) {
        thread {
            try {
                if (!act.ensurePerms(mediaPerms())) {
                    result(id, false, "Dosya erişim izni verilmedi.")
                    return@thread
                }
                val col = MediaStore.Files.getContentUri("external")
                val c = act.contentResolver.query(
                    col,
                    arrayOf(
                        MediaStore.Files.FileColumns._ID,
                        MediaStore.Files.FileColumns.DISPLAY_NAME,
                        MediaStore.Files.FileColumns.MIME_TYPE,
                        MediaStore.Files.FileColumns.DATE_ADDED
                    ),
                    MediaStore.Files.FileColumns.DISPLAY_NAME + " LIKE ?",
                    arrayOf("%$q%"),
                    MediaStore.Files.FileColumns.DATE_ADDED + " DESC"
                )
                val arr = JSONArray()
                c?.use {
                    while (it.moveToNext() && arr.length() < 40) {
                        val o = JSONObject()
                        o.put("uri", ContentUris.withAppendedId(col, it.getLong(0)).toString())
                        o.put("ad", it.getString(1) ?: "")
                        o.put("tur", it.getString(2) ?: "")
                        o.put("date", it.getLong(3))
                        arr.put(o)
                    }
                }
                result(id, true, arr.toString())
            } catch (e: Exception) {
                result(id, false, "Arama başarısız: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun openUri(uri: String, mime: String) {
        act.runOnUiThread {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse(uri), if (mime.isEmpty()) "*/*" else mime)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                act.startActivity(i)
            } catch (e: Exception) {
                // açacak uygulama yok
            }
        }
    }

    // ---------- ESP32 / BLE cihaz inceleme ve yazma ----------

    private val stdNames = mapOf(
        "1800" to "Genel Erişim", "1801" to "Genel Öznitelik", "180a" to "Cihaz Bilgisi", "180f" to "Pil",
        "2a00" to "Cihaz adı", "2a19" to "Pil seviyesi", "2a24" to "Model no", "2a25" to "Seri no",
        "2a26" to "Yazılım sürümü", "2a27" to "Donanım sürümü", "2a28" to "Yazılım", "2a29" to "Üretici"
    )

    private fun shortUuid(u: String): String {
        val l = u.lowercase()
        return if (l.endsWith("-0000-1000-8000-00805f9b34fb")) l.substring(4, 8) else l
    }

    private fun fmtValue(b: ByteArray, short: String): String {
        if (short == "2a19" && b.isNotEmpty()) return "%" + (b[0].toInt() and 0xFF)
        val s = String(b, Charsets.UTF_8)
        val printable = b.isNotEmpty() && s.all { it == '\n' || it.code in 32..126 || it.code > 160 }
        return if (printable) s else b.joinToString(" ") { "%02X".format(it) }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun gattSession(addr: String, write: JSONObject?): JSONObject {
        if (Build.VERSION.SDK_INT >= 31) {
            if (!act.ensurePerms(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))) {
                throw RuntimeException("Bluetooth bağlantı izni verilmedi.")
            }
        }
        val bm = act.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = bm.adapter ?: throw RuntimeException("Bluetooth yok veya kapalı.")
        val dev = adapter.getRemoteDevice(addr)
        val connLatch = CountDownLatch(1)
        val discLatch = CountDownLatch(1)
        val op = arrayOfNulls<CountDownLatch>(1)
        val values = ConcurrentHashMap<String, ByteArray>()
        val flags = BooleanArray(2) // 0: bağlandı, 1: yazma başarılı

        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    flags[0] = true
                    connLatch.countDown()
                    g.discoverServices()
                } else {
                    connLatch.countDown()
                    discLatch.countDown()
                    op[0]?.countDown()
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                discLatch.countDown()
            }

            override fun onCharacteristicRead(
                g: BluetoothGatt,
                c: BluetoothGattCharacteristic,
                value: ByteArray,
                status: Int
            ) {
                if (status == BluetoothGatt.GATT_SUCCESS) values[c.service.uuid.toString() + "|" + c.uuid.toString()] = value
                op[0]?.countDown()
            }

            @Deprecated("Deprecated in Java")
            override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                val v = c.value
                if (status == BluetoothGatt.GATT_SUCCESS && v != null) {
                    values[c.service.uuid.toString() + "|" + c.uuid.toString()] = v
                }
                op[0]?.countDown()
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                flags[1] = status == BluetoothGatt.GATT_SUCCESS
                op[0]?.countDown()
            }
        }

        val gatt = dev.connectGatt(act, false, cb, BluetoothDevice.TRANSPORT_LE)
        try {
            connLatch.await(12, TimeUnit.SECONDS)
            if (!flags[0]) throw RuntimeException("Cihaza bağlanılamadı. Cihaz başka biriyle bağlı olabilir veya bağlantıya kapalıdır.")
            discLatch.await(10, TimeUnit.SECONDS)

            val out = JSONObject()
            val svcs = JSONArray()
            var reads = 0
            for (s in gatt.services) {
                val so = JSONObject()
                val su = shortUuid(s.uuid.toString())
                so.put("uuid", s.uuid.toString())
                so.put("ad", stdNames[su] ?: "Özel servis")
                val chars = JSONArray()
                for (c in s.characteristics) {
                    val cu = shortUuid(c.uuid.toString())
                    val p = c.properties
                    val co = JSONObject()
                    co.put("uuid", c.uuid.toString())
                    co.put("ad", stdNames[cu] ?: "Özel özellik")
                    val pr = JSONArray()
                    val canRead = p and BluetoothGattCharacteristic.PROPERTY_READ != 0
                    val canWrite = p and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    if (canRead) pr.put("okuma")
                    if (canWrite) pr.put("yazma")
                    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) pr.put("bildirim")
                    co.put("ozellikler", pr)
                    if (write == null && canRead && reads < 25) {
                        reads++
                        op[0] = CountDownLatch(1)
                        if (gatt.readCharacteristic(c)) op[0]!!.await(2, TimeUnit.SECONDS)
                        val v = values[s.uuid.toString() + "|" + c.uuid.toString()]
                        if (v != null) co.put("deger", fmtValue(v, cu))
                    }
                    chars.put(co)
                }
                so.put("ozellikler", chars)
                svcs.put(so)
            }
            out.put("servisler", svcs)

            if (write != null) {
                val sv = write.optString("svc").lowercase()
                val ch = write.optString("chr").lowercase()
                var target: BluetoothGattCharacteristic? = null
                for (s in gatt.services) {
                    if (s.uuid.toString().lowercase() != sv) continue
                    for (c in s.characteristics) if (c.uuid.toString().lowercase() == ch) target = c
                }
                val t = target ?: throw RuntimeException("Özellik bulunamadı.")
                val hex = write.optString("hex")
                val bytes = if (hex.isNotEmpty()) {
                    hex.replace(" ", "").chunked(2).map { it.toInt(16).toByte() }.toByteArray()
                } else {
                    write.optString("text").toByteArray(Charsets.UTF_8)
                }
                t.writeType = if (t.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) {
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                } else {
                    BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                }
                t.value = bytes
                op[0] = CountDownLatch(1)
                val started = gatt.writeCharacteristic(t)
                if (started) op[0]!!.await(3, TimeUnit.SECONDS)
                out.put("yazildi", started && (flags[1] || t.writeType == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE))
            }
            return out
        } finally {
            try {
                gatt.disconnect()
                gatt.close()
            } catch (e: Exception) {
                // kapatma hatası önemsiz
            }
        }
    }

    @JavascriptInterface
    fun bleInspect(id: String, addr: String) {
        thread {
            try {
                result(id, true, gattSession(addr, null).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "BLE hatası")
            }
        }
    }

    /** args: {"addr","svc","chr","text" veya "hex"} */
    @JavascriptInterface
    fun bleWrite(id: String, args: String) {
        thread {
            try {
                val a = JSONObject(args)
                result(id, true, gattSession(a.getString("addr"), a).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "BLE yazma hatası")
            }
        }
    }

    // ---------- Şifre kasası (cihazda şifreli, yapay zekaya gitmez) ----------

    private fun store(): JSONObject {
        val s = vault.get("pw_store")
        return if (s.isEmpty()) JSONObject() else try {
            JSONObject(s)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    @JavascriptInterface
    fun vaultList(): String {
        val arr = JSONArray()
        val it = store().keys()
        while (it.hasNext()) arr.put(it.next())
        return arr.toString()
    }

    @JavascriptInterface
    fun vaultSet(name: String, value: String) {
        val s = store()
        s.put(name, value)
        vault.put("pw_store", s.toString())
    }

    @JavascriptInterface
    fun vaultGet(name: String): String = store().optString(name, "")

    @JavascriptInterface
    fun vaultDel(name: String) {
        val s = store()
        s.remove(name)
        vault.put("pw_store", s.toString())
    }

    @JavascriptInterface
    fun unlock(id: String) {
        act.runOnUiThread {
            val km = act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                result(id, true, "ok")
                return@runOnUiThread
            }
            @Suppress("DEPRECATION")
            val i = km.createConfirmDeviceCredentialIntent("JARVİS kasası", "Şifrelerini görmek için kimliğini doğrula")
            if (i == null) {
                result(id, true, "ok")
            } else {
                unlockId = id
                act.startActivityForResult(i, 78)
            }
        }
    }

    fun onUnlockResult(ok: Boolean) {
        val id = unlockId ?: return
        unlockId = null
        result(id, ok, if (ok) "ok" else "doğrulanamadı")
    }
}
