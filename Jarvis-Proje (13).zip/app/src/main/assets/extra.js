/* JARVİS ek modüller: kamera HUD, radar, medya arama, kasa, çeviri, durum, hafıza */
(function(){
"use strict";
var JV = window.JV;
if(!JV) return;
var N = window.JarvisNative || null;
var cfg = JV.cfg;
var $ = function(id){ return document.getElementById(id); };
var X = JV.natX;
var esc = JV.esc, toast = JV.toast;

function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function hexA(hex,a){ var h=hex.replace("#",""); return "rgba("+parseInt(h.substr(0,2),16)+","+parseInt(h.substr(2,2),16)+","+parseInt(h.substr(4,2),16)+","+a+")"; }
function speak(t){ if(t) JV.say(t); }

/* ---------- Stil ---------- */
var st=document.createElement("style");
st.textContent=
"#chips{display:flex;gap:8px;overflow-x:auto;padding:4px 12px 2px;position:relative;z-index:3;-webkit-overflow-scrolling:touch}"+
"#chips button{flex:none;padding:8px 12px;border-radius:18px;border:1px solid var(--line);background:var(--panel);color:var(--c1);font-size:12px;letter-spacing:2px}"+
"#pHud{background:#000}"+
"#pHud video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}"+
"#hc{position:absolute;inset:0;width:100%;height:100%;z-index:2}"+
"#hTop{position:absolute;left:0;right:0;top:0;padding:calc(env(safe-area-inset-top) + 10px) 10px 8px;display:flex;gap:6px;align-items:center;z-index:4;background:linear-gradient(rgba(0,0,0,.65),transparent)}"+
".hm{padding:8px 10px;border-radius:14px;border:1px solid var(--line);background:rgba(0,0,0,.5);color:var(--c1);font-size:11px;letter-spacing:1px}"+
".hm.sel{background:var(--c1);color:#000;font-weight:700}"+
"#hAct{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom) + 74px);display:flex;gap:8px;justify-content:center;z-index:5}#hAct .btn{background:rgba(0,0,0,.55)}#hAct .on{background:rgba(255,120,0,.35);border-color:var(--c2);color:#fff}"+
"#hInfo{position:absolute;left:12px;right:12px;bottom:128px;max-height:34vh;overflow:auto;z-index:4;font-size:14px;line-height:1.45;text-shadow:0 0 6px #000}"+
"#hInfo .sub{background:rgba(0,0,0,.6);border-left:3px solid var(--c2);padding:8px 10px;border-radius:8px;margin-top:6px}"+
"#hBot{position:absolute;left:0;right:0;bottom:0;padding:10px 12px calc(env(safe-area-inset-bottom) + 12px);display:flex;gap:8px;align-items:center;z-index:4;background:linear-gradient(transparent,rgba(0,0,0,.7))}"+
"#hName{flex:1;min-width:0;padding:10px;border-radius:10px;border:1px solid var(--line);background:rgba(0,0,0,.6);color:var(--txt);font-size:14px;outline:none}"+
"#rc{width:100%;height:300px;display:block}"+
".big{font-size:22px;line-height:1.35;padding:14px;border:1px solid var(--line);border-radius:14px;background:var(--panel);min-height:90px;margin-bottom:10px}"+
".big small{display:block;color:var(--dim);font-size:13px;margin-bottom:6px}"+
".grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}"+
".grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:10px;border:1px solid var(--line)}"+
".tag{display:inline-block;font-size:10px;letter-spacing:1px;padding:2px 6px;border-radius:6px;border:1px solid var(--c2);color:var(--c2);margin-left:6px}"+
".kv{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(43,181,255,.15);font-size:15px}"+
".kv b{color:var(--c1)}";
document.head.appendChild(st);

function mkPage(id,html,onClose){
  var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d);
  if(onClose){
    new MutationObserver(function(){ if(!d.classList.contains("show")) onClose(); }).observe(d,{attributes:true,attributeFilter:["class"]});
  }
  return d;
}
function openPage(id){ $(id).classList.add("show"); }
function closePage(id){ $(id).classList.remove("show"); }

/* ---------- Araç tanımları (yapay zekaya) ---------- */
var S=function(d){ return {type:"string",description:d}; };
var I=function(d){ return {type:"integer",description:d}; };
window.EXTRA_TOOLS=window.EXTRA_TOOLS.concat([
 {name:"get_device_status",description:"Telefonun pil, sıcaklık, hareket, ortam ışığı ve depolama durumunu okur.",input_schema:{type:"object",properties:{}}},
 {name:"phone_action",description:"Telefonu kontrol eder: fener, ses, medya oynatıcı, ayar ekranları, adres açma, harita, web araması, kamera.",input_schema:{type:"object",properties:{
   action:{type:"string",description:"flashlight_on, flashlight_off, volume_up, volume_down, volume_mute, volume_set, media_play_pause, media_next, media_previous, open_settings, open_url, navigate, web_search, open_camera"},
   value:S("volume_set için yüzde; open_settings için wifi/bluetooth/display/sound/location/airplane/apps/battery/nfc; open_url için adres; navigate için yer; web_search için sorgu")},required:["action"]}},
 {name:"get_calendar",description:"Önümüzdeki günlerdeki takvim etkinliklerini ve randevuları getirir.",input_schema:{type:"object",properties:{days:I("Kaç gün ileriye bakılacak")}}},
 {name:"add_event",description:"Takvime etkinlik ekleme ekranını hazır doldurur, kullanıcı kaydeder.",input_schema:{type:"object",properties:{title:S("Başlık"),start:S("Yerel başlangıç zamanı, biçim: 2026-11-12T15:00"),duration_min:I("Süre, dakika")},required:["title","start"]}},
 {name:"get_call_log",description:"Son aramaları (gelen, giden, cevapsız) listeler.",input_schema:{type:"object",properties:{limit:I("Kaç kayıt")}}},
 {name:"get_sms",description:"Son gelen SMS mesajlarını okur.",input_schema:{type:"object",properties:{limit:I("Kaç mesaj")}}},
 {name:"send_sms",description:"SMS gönderir. Kullanıcıdan onay istenir.",input_schema:{type:"object",properties:{target:S("Kişi adı veya numara"),message:S("Mesaj")},required:["target","message"]}},
 {name:"get_app_usage",description:"Uygulama kullanım sürelerini getirir (alışkanlık analizi için).",input_schema:{type:"object",properties:{days:I("Kaç gün geriye")}}},
 {name:"scan_nearby",description:"Yakındaki Bluetooth LE cihazlarını ve Wi-Fi ağlarını tarar, ESP32/Arduino olasılığını işaretler.",input_schema:{type:"object",properties:{}}},
 {name:"remember",description:"Kullanıcı hakkında kalıcı bir bilgiyi hafızaya kaydeder.",input_schema:{type:"object",properties:{fact:S("Hatırlanacak bilgi")},required:["fact"]}},
 {name:"show_password",description:"Şifre kasasındaki bir kaydı ekranda gösterir (kimlik doğrulamayla). Şifreyi sana göndermez.",input_schema:{type:"object",properties:{name:S("Kayıt adı, örneğin Instagram")},required:["name"]}},
 {name:"get_notifications",description:"Gelen bildirimleri (WhatsApp, SMS, diğer uygulamalar) okur. İzin açıldıktan sonra gelenleri kaydeder.",input_schema:{type:"object",properties:{limit:I("Kaç bildirim"),app:S("İsteğe bağlı uygulama adı filtresi, örn. WhatsApp")}}},
 {name:"screen_read",description:"Telefon ekranındaki yazıları ve düğmeleri okur (erişilebilirlik izni gerekir).",input_schema:{type:"object",properties:{}}},
 {name:"screen_click",description:"Ekranda verilen yazıya sahip düğmeye veya öğeye dokunur.",input_schema:{type:"object",properties:{text:S("Dokunulacak öğenin ekrandaki yazısı")},required:["text"]}},
 {name:"screen_type",description:"Ekrandaki yazı alanına metin yazar. Kullanıcıdan onay istenir.",input_schema:{type:"object",properties:{text:S("Yazılacak metin")},required:["text"]}},
 {name:"screen_action",description:"Sistem eylemi: back, home, recents, notifications, quick_settings, lock, screenshot, scroll_down, scroll_up.",input_schema:{type:"object",properties:{action:S("Eylem adı")},required:["action"]}},
 {name:"delete_event",description:"Takvimden yaklaşan bir etkinliği başlığına göre siler. Onay istenir.",input_schema:{type:"object",properties:{title:S("Etkinlik başlığı")},required:["title"]}},
 {name:"move_event",description:"Takvimdeki yaklaşan bir etkinliği yeni zamana taşır. Onay istenir.",input_schema:{type:"object",properties:{title:S("Etkinlik başlığı"),new_start:S("Yeni başlangıç, biçim 2026-11-12T15:00")},required:["title","new_start"]}},
 {name:"get_my_habits",description:"Kullanıcının Jarvis kullanım alışkanlıklarını (saat, gün, sohbet sayısı) özetler.",input_schema:{type:"object",properties:{}}}
]);
window.CONFIRM_TOOLS.send_sms=function(i){ return "Jarvis şu kişiye SMS göndermek istiyor:\n\n"+(i.target||"?")+"\n\""+(i.message||"")+"\"\n\nGönderilsin mi?"; };
window.CONFIRM_TOOLS.screen_type=function(i){ return "Jarvis ekrana şunu yazmak istiyor:\n\n"+(i.text||"")+"\n\nYazılsın mı?"; };
window.CONFIRM_TOOLS.screen_click=function(i){
  return /öde|gönder|sil|onayla|satın|transfer|havale|kabul|pay|send|delete|buy|confirm|purchase/i.test(i.text||"")?("Jarvis ekranda şuna dokunmak istiyor: \""+i.text+"\"\nBu önemli bir işlem olabilir. Devam edilsin mi?"):null;
};
window.CONFIRM_TOOLS.delete_event=function(i){ return "Takvimden '"+(i.title||"?")+"' etkinliği silinsin mi?"; };
window.CONFIRM_TOOLS.move_event=function(i){ return "'"+(i.title||"?")+"' etkinliği "+(i.new_start||"?")+" zamanına taşınsın mı?"; };
window.JSTOOLS.remember=function(i){
  var f=String(i&&i.fact||"").trim(); if(!f) return "Boş bilgi.";
  cfg.memory=cfg.memory||[]; if(cfg.memory.indexOf(f)<0) cfg.memory.push(f);
  if(cfg.memory.length>40) cfg.memory=cfg.memory.slice(-40);
  JV.saveCfg(); return "Hafızaya kaydedildi.";
};
window.JSTOOLS.get_my_habits=function(){
  var convs=lsGet("convs",[]), hours=new Array(24).fill(0), days=[0,0,0,0,0,0,0], total=0;
  convs.forEach(function(c){ (c.msgs||[]).forEach(function(m){ if(m.role==="user"&&m.ts){ var d=new Date(m.ts); hours[d.getHours()]++; days[d.getDay()]++; total++; } }); });
  var names=["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];
  var top=hours.map(function(v,h){return [h,v];}).sort(function(a,b){return b[1]-a[1];}).slice(0,3).filter(function(x){return x[1]>0;}).map(function(x){return x[0]+":00";});
  var dd=days.map(function(v,i){return {gun:names[i],mesaj:v};});
  return JSON.stringify({sohbet_sayisi:convs.length,olculen_mesaj:total,en_aktif_saatler:top,gunlere_gore:dd,not:"Uygulama kullanım süreleri için get_app_usage aracını da kullanabilirsin."});
};
window.JSTOOLS.show_password=async function(i){
  var list=JSON.parse(window.JarvisX.vaultList()), q=String(i&&i.name||"").toLowerCase();
  var hit=list.filter(function(n){ return n.toLowerCase().indexOf(q)>=0; })[0];
  if(!hit) return "Kasada '"+(i&&i.name)+"' adında kayıt yok. Mevcut kayıt sayısı: "+list.length+".";
  openVault(hit);
  return "Şifre kasası ekranda açıldı. Kullanıcı kimliğini doğrulayınca kaydı görecek. Şifreyi sana göndermiyorum.";
};

/* ---------- Çip çubuğu ---------- */
if(!JV.voice){
  var chips=document.createElement("div"); chips.id="chips";
  chips.innerHTML='<button id="cHud">📷 HUD</button><button id="cRad">📡 RADAR</button><button id="cMed">🖼 MEDYA</button><button id="cVlt">🔐 KASA</button><button id="cTr">🌐 ÇEVİRİ</button><button id="cSt">📊 DURUM</button><button id="cAn">🎞 ANALİZ</button>';
  var bar=$("bar"); bar.parentNode.insertBefore(chips,bar);
}

/* ================= KAMERA HUD ================= */
var hud={mode:"obj",facing:"environment",stream:null,items:[],last:0,busy:false,raf:0,timer:0,stat:"HAZIR",subs:"",t:0,autoOn:true,force:false,talk:false,sig:null};
mkPage("pHud",
 '<video id="hv" autoplay playsinline muted></video><canvas id="hc"></canvas>'+
 '<div id="hTop"><button class="ib" data-close>←</button>'+
 '<button class="hm sel" data-m="obj">NESNE</button><button class="hm" data-m="gest">MİMİK/EL</button><button class="hm" data-m="trans">ÇEVİRİ</button><button class="hm" data-m="face">YÜZ</button>'+
 '<button class="ib" id="hFlip" style="margin-left:auto">⟲</button></div>'+
 '<div id="hInfo"></div>'+
 '<div id="hAct"><button class="btn" id="hTalk">🎤 KONUŞ</button><button class="btn" id="hNow">🔍 ŞİMDİ BAK</button><button class="btn" id="hAuto">OTO: AÇIK</button></div>'+
 '<div id="hBot"><input id="hName" placeholder="Yüz kaydı için isim (sadece kendin)"><button class="btn" id="hSave">KAYDET</button></div>',
 hudStop);

function hudSig(){
  try{ var v=$("hv"), c=hudSig.c||(hudSig.c=document.createElement("canvas")); c.width=16; c.height=12;
    var x=c.getContext("2d"); x.drawImage(v,0,0,16,12); var d=x.getImageData(0,0,16,12).data, o=[];
    for(var i=0;i<d.length;i+=4) o.push((d[i]+d[i+1]+d[i+2])/3); return o; }catch(e){ return null; }
}
function hudDiff(a,b){ if(!a||!b) return 99; var t=0; for(var i=0;i<a.length;i++) t+=Math.abs(a[i]-b[i]); return t/a.length; }
function hudCapture(maxW,q){
  var v=$("hv"), w=v.videoWidth, h=v.videoHeight, k=Math.min(1,maxW/Math.max(w,h));
  var c=document.createElement("canvas"); c.width=Math.round(w*k); c.height=Math.round(h*k);
  c.getContext("2d").drawImage(v,0,0,c.width,c.height);
  return c.toDataURL("image/jpeg",q).split(",")[1];
}
async function hudStart(){
  openPage("pHud");
  $("hInfo").innerHTML='<div class="sub">Kamera açılıyor…</div>';
  try{ await X("requestPerms","android.permission.CAMERA"); }catch(e){ toast("Kamera izni gerekli"); closePage("pHud"); return; }
  try{
    hud.stream=await Promise.race([navigator.mediaDevices.getUserMedia({video:{facingMode:hud.facing,width:{ideal:640},height:{ideal:480}},audio:false}),new Promise(function(_,rej){ setTimeout(function(){ rej(new Error("kamera yanıt vermedi")); },10000); })]);
    var v=$("hv"); v.srcObject=hud.stream; v.play().catch(function(){});
  }catch(e){ toast("Kamera açılamadı: "+e.message,4000); closePage("pHud"); return; }
  hud.items=[]; hud.last=0; hud.busy=false; hud.subs="";
  hudSetMode(hud.mode);
  hud.timer=setInterval(hudTick,700); setTimeout(hudTick,300);
  cancelAnimationFrame(hud.raf); hud.raf=requestAnimationFrame(hudDraw);
}
function hudStop(){
  if(hud.talk){ hud.talk=false; try{ JV.stopListen(); }catch(e){} var tb=$("hTalk"); if(tb){ tb.textContent="🎤 KONUŞ"; tb.classList.remove("on"); } }
  clearInterval(hud.timer); cancelAnimationFrame(hud.raf);
  if(hud.stream){ hud.stream.getTracks().forEach(function(t){ t.stop(); }); hud.stream=null; }
  try{ $("hv").srcObject=null; }catch(e){}
}
function hudSetMode(m){
  hud.mode=m; hud.items=[]; hud.subs=""; hud.last=0;
  document.querySelectorAll("#hTop .hm").forEach(function(b){ b.classList.toggle("sel",b.getAttribute("data-m")===m); });
  $("hBot").style.display=(m==="face")?"flex":"none";
  var h={obj:"Nesneleri, kabloları ve devre kartlarını kameraya tut.",gest:"Yüzünü ve elini kameraya göster.",trans:"Yazıyı kameraya tut, çeviri üstüne yazılır.",face:"Kayıtlı yüzler aranıyor."}[m];
  $("hInfo").innerHTML='<div class="sub">'+esc(h)+'</div>';
}
function normBox(b){
  if(!b||b.length<4) return null;
  var a=b.map(Number); if(a.some(isNaN)) return null;
  var mx=Math.max.apply(null,a); if(mx<=1.5) a=a.map(function(x){ return x*1000; });
  return {y1:a[0],x1:a[1],y2:a[2],x2:a[3]};
}
function faces(){ return lsGet("faces",[]); }
async function hudTick(){
  if(hud.busy||!hud.stream) return;
  var v=$("hv"); if(!v.videoWidth) return;
  var force=hud.force; hud.force=false;
  if(!force){
    if(!hud.autoOn||hud.talk) return;
    if(Date.now()-hud.last<Math.max(cfg.hudMs,5000)) return;
    var sg=hudSig();
    if(hud.sig&&hudDiff(sg,hud.sig)<10&&Date.now()-hud.last<60000) return;
  }
  hud.sig=hudSig();
  hud.busy=true; hud.last=Date.now(); hud.stat="ANALİZ";
  try{
    var frame=hudCapture(512,0.5), prompt, imgs=[{data:frame}], m=hud.mode;
    if(m==="obj"){
      prompt='Görüntüdeki belirgin nesneleri tanı; özellikle elektronik parçalar, kablolar, devre kartları, çipler, sensörler, konnektörler, mikrodenetleyiciler. En fazla 6 nesne. Sadece JSON dizi ver: [{"label":"kısa Türkçe ad","box_2d":[ymin,xmin,ymax,xmax],"info":"tek satır teknik bilgi, en fazla 60 karakter"}]. box_2d değerleri 0-1000 arası normalize. Nesne yoksa [].';
    } else if(m==="gest"){
      prompt='Karedeki kişinin yüz ifadesini, el hareketini ve olası niyetini analiz et. Tahmin olduğunu unutma. Sadece JSON: {"ifade":"...","el":"...","niyet":"...","guven":0-1}. Kişi yoksa alanlara "yok" yaz. Türkçe.';
    } else if(m==="trans"){
      prompt='Görüntüdeki yazıları oku ve '+cfg.transTo+' diline çevir. Sadece JSON dizi: [{"text":"orijinal","translation":"çeviri","box_2d":[ymin,xmin,ymax,xmax]}]. En fazla 6 parça, box_2d 0-1000 normalize. Yazı yoksa [].';
    } else {
      var fs=faces();
      if(!fs.length){ hud.items=[]; hud.subs="Önce yüz kaydet: ismi yaz, yüzünü göster, KAYDET'e bas."; hud.busy=false; hudInfo(); return; }
      fs.slice(0,4).forEach(function(f){ imgs.unshift({label:"Referans kişi: "+f.name,data:f.img}); });
      prompt='İlk görüntüler kayıtlı referans kişilerdir (isimleri başlıkta). Son görüntü analiz edilecek karedir. Karedeki her yüz için referanslardan biriyle eşleşiyor mu karşılaştır. Emin değilsen "bilinmiyor" yaz. Sadece JSON dizi: [{"name":"isim veya bilinmiyor","box_2d":[ymin,xmin,ymax,xmax],"confidence":0-1}]. Yüz yoksa [].';
    }
    var data=JV.parseJSON(await Promise.race([JV.visionAI(prompt,imgs,true),new Promise(function(_,rej){ setTimeout(function(){ rej(new Error("analiz zaman aşımı, tekrar deniyorum")); },40000); })]));
    if(hud.mode!==m) { hud.busy=false; return; }
    hud.t=Date.now();
    if(m==="gest"){
      hud.items=[]; hud.subs='<b>İFADE:</b> '+esc(data.ifade||"-")+'<br><b>EL:</b> '+esc(data.el||"-")+'<br><b>NİYET (tahmin):</b> '+esc(data.niyet||"-");
    } else {
      var arr=Array.isArray(data)?data:[];
      hud.items=arr.map(function(o){
        var b=normBox(o.box_2d);
        return {box:b,label:m==="trans"?(o.translation||""):(m==="face"?(o.name||"bilinmiyor"):(o.label||"?")),
                info:m==="trans"?(o.text||""):(m==="face"?("güven %"+Math.round((o.confidence||0)*100)):(o.info||""))};
      });
      if(m==="trans") hud.subs=arr.map(function(o){ return o.translation; }).filter(Boolean).join(" · ")||"Yazı bulunamadı.";
      else if(m==="face") hud.subs=arr.length?arr.map(function(o){ return o.name; }).join(", "):"Yüz bulunamadı.";
      else hud.subs=arr.length+" nesne algılandı.";
    }
    hudInfo();
  }catch(e){
    var em=JV.errMsg(e); hud.subs="Hata: "+esc(em); hudInfo();
    if(/hakkı doldu/.test(em)&&hud.autoOn){ hud.autoOn=false; $("hAuto").textContent="OTO: KAPALI"; $("hAuto").classList.remove("on"); }
  }
  hud.busy=false; hud.stat="HAZIR";
}
function hudInfo(){ $("hInfo").innerHTML=hud.subs?'<div class="sub">'+(hud.mode==="trans"||hud.mode==="gest"?hud.subs:esc(hud.subs)).replace(/^(Hata:.*)$/,"$1")+'</div>':""; }
function hudDraw(ts){
  var cv=$("hc"), v=$("hv"); if(!cv) return;
  var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight;
  if(W&&cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var ctx=cv.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,W,H);
  var col=JV.colors(), c1=col[0], c2=col[1];
  // çerçeve köşeleri
  ctx.strokeStyle=c1; ctx.lineWidth=2.5; var L=34, M=14, top=96, bot=H-110;
  [[M,top,1,1],[W-M,top,-1,1],[M,bot,1,-1],[W-M,bot,-1,-1]].forEach(function(p){
    ctx.beginPath(); ctx.moveTo(p[0],p[1]+p[3]*L); ctx.lineTo(p[0],p[1]); ctx.lineTo(p[0]+p[2]*L,p[1]); ctx.stroke();
  });
  // tarama çizgisi
  var sy=top+((ts/18)%(bot-top)); var g=ctx.createLinearGradient(0,sy-20,0,sy+2);
  g.addColorStop(0,hexA(c1,0)); g.addColorStop(1,hexA(c1,0.45)); ctx.fillStyle=g; ctx.fillRect(M,sy-20,W-2*M,22);
  // merkez nişan
  var cx=W/2, cy=(top+bot)/2; ctx.strokeStyle=hexA(c1,0.55); ctx.lineWidth=1.5;
  ctx.beginPath(); ctx.arc(cx,cy,26,0,7); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx,cy,42,ts/700,ts/700+Math.PI*1.3); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx-60,cy); ctx.lineTo(cx-30,cy); ctx.moveTo(cx+30,cy); ctx.lineTo(cx+60,cy); ctx.stroke();
  // telemetri
  ctx.fillStyle=c1; ctx.font="11px monospace"; ctx.textAlign="right";
  var d=new Date(), pad=function(n){ return (n<10?"0":"")+n; };
  var lines=["JARVİS // GÖRÜŞ","MOD "+({obj:"NESNE",gest:"MİMİK/EL",trans:"ÇEVİRİ",face:"YÜZ"})[hud.mode],"KAM "+(hud.facing==="user"?"ÖN":"ARKA"),pad(d.getHours())+":"+pad(d.getMinutes())+":"+pad(d.getSeconds()),hud.stat];
  lines.forEach(function(t,i){ ctx.fillText(t,W-M-4,top+16+i*15); });
  // kutular
  var vw=v.videoWidth, vh=v.videoHeight;
  if(vw&&vh&&Date.now()-hud.t<12000){
    var sc=Math.max(W/vw,H/vh), ox=(W-vw*sc)/2, oy=(H-vh*sc)/2;
    hud.items.forEach(function(it){
      if(!it.box) return;
      var x1=it.box.x1/1000*vw*sc+ox, y1=it.box.y1/1000*vh*sc+oy, x2=it.box.x2/1000*vw*sc+ox, y2=it.box.y2/1000*vh*sc+oy;
      var w=x2-x1, h=y2-y1; if(w<4||h<4) return;
      ctx.strokeStyle=c2; ctx.lineWidth=2; ctx.strokeRect(x1,y1,w,h);
      ctx.fillStyle=c2; var k=Math.min(14,w/3,h/3);
      ctx.fillRect(x1-2,y1-2,k,3); ctx.fillRect(x1-2,y1-2,3,k); ctx.fillRect(x2-k+2,y2-1,k,3); ctx.fillRect(x2-1,y2-k+2,3,k);
      ctx.font="bold 13px sans-serif"; ctx.textAlign="left";
      var lab=String(it.label||""), tw=Math.min(ctx.measureText(lab).width+12,W-x1-4);
      ctx.fillStyle=hexA("#000000",0.65); ctx.fillRect(x1,Math.max(top,y1-22),tw,20);
      ctx.fillStyle=c1; ctx.fillText(lab.slice(0,34),x1+6,Math.max(top,y1-22)+14);
      if(it.info&&hud.mode!=="trans"){
        ctx.font="11px sans-serif"; var inf=String(it.info).slice(0,60), iw=Math.min(ctx.measureText(inf).width+12,W-x1-4);
        ctx.fillStyle=hexA("#000000",0.6); ctx.fillRect(x1,y2+2,iw,17); ctx.fillStyle=hexA("#ffffff",0.9); ctx.fillText(inf,x1+6,y2+14);
      }
    });
  }
  hud.raf=requestAnimationFrame(hudDraw);
}
document.addEventListener("click",function(e){
  var t=e.target; if(!t||!t.getAttribute) return;
  var m=t.getAttribute("data-m"); if(m&&t.classList.contains("hm")) hudSetMode(m);
});
$("hFlip").onclick=async function(){
  hud.facing=hud.facing==="user"?"environment":"user"; hudStop(); await hudStart();
};
$("hAuto").onclick=function(){
  hud.autoOn=!hud.autoOn; this.textContent="OTO: "+(hud.autoOn?"AÇIK":"KAPALI"); this.classList.toggle("on",hud.autoOn);
  toast(hud.autoOn?"Görüntü değişince kendiliğinden analiz eder":"Otomatik analiz kapalı: ŞİMDİ BAK'a bas");
};
$("hAuto").classList.add("on");
$("hNow").onclick=function(){ hud.force=true; hud.last=0; hudTick(); };
$("hTalk").onclick=function(){
  if(!hud.stream){ return; }
  if(hud.talk){ hud.talk=false; try{ JV.stopListen(); }catch(e){} this.textContent="🎤 KONUŞ"; this.classList.remove("on"); return; }
  hud.talk=true; this.textContent="🎤 DİNLİYORUM…"; this.classList.add("on");
  $("hInfo").innerHTML='<div class="sub">Konuş, kameradaki şeyi sorabilirsin…</div>';
  try{ JV.say(""); }catch(e){}
  JV.listen();
};
function hudTalkEnd(){ hud.talk=false; var b=$("hTalk"); b.textContent="🎤 KONUŞ"; b.classList.remove("on"); }
async function hudAsk(q){
  hudTalkEnd();
  $("hInfo").innerHTML='<div class="sub"><b>Sen:</b> '+esc(q)+'<br>Bakıyorum…</div>';
  hud.stat="ANALİZ";
  try{
    var frame=hudCapture(768,0.6);
    var ans=await JV.visionAI("Sen JARVİS'sin. Kullanıcı telefon kamerasından bir şey gösteriyor ve soruyor: \""+q+"\". Görüntüye bakarak Türkçe, kısa (en fazla 3 cümle), net ve doğru cevap ver. Emin olmadığını belirt, uydurma.",[{data:frame}],false);
    ans=String(ans||"").trim()||"Görüntüden bir şey anlayamadım efendim.";
    $("hInfo").innerHTML='<div class="sub"><b>Sen:</b> '+esc(q)+'<br><b>JARVİS:</b> '+esc(ans)+'</div>';
    JV.say(ans.replace(/[*_`#]/g,""));
  }catch(e){ $("hInfo").innerHTML='<div class="sub">Hata: '+esc(JV.errMsg(e))+'</div>'; }
  hud.stat="HAZIR";
}
$("hSave").onclick=function(){
  var n=$("hName").value.trim(); if(!n){ toast("Önce bir isim yaz"); return; }
  if(!hud.stream){ return; }
  var fs=faces(); if(fs.length>=8){ toast("En fazla 8 yüz kaydedilir"); return; }
  fs.push({name:n,img:hudCapture(320,0.7)}); lsSet("faces",fs); $("hName").value=""; toast(n+" kaydedildi");
};
$("cHud").onclick=hudStart;

/* ================= RADAR ================= */
var rad={data:null,raf:0,scanning:false,sum:""};
mkPage("pRad",
 '<div class="ph"><button class="ib" data-close>←</button><h2>RADAR</h2><button class="btn" id="rScan">TARA</button></div>'+
 '<div class="pb"><canvas id="rc"></canvas><div id="rMsg" style="text-align:center;color:var(--dim);font-size:12px;letter-spacing:2px;margin:6px 0 10px">Taramak için TARA düğmesine bas</div>'+
 '<button class="btn" id="rAI" style="width:100%;margin-bottom:10px">YAKINDAKİLERİ ANALİZ ET</button><div id="rAn" class="big" style="display:none;font-size:15px"></div><div id="rGatt"></div><div id="rList"></div></div>',
 function(){ cancelAnimationFrame(rad.raf); });
function hash(s){ var h=0; for(var i=0;i<s.length;i++){ h=(h*31+s.charCodeAt(i))|0; } return Math.abs(h); }
function radDraw(ts){
  var cv=$("rc"); if(!cv||!$("pRad").classList.contains("show")) return;
  var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight;
  if(W&&cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var ctx=cv.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,W,H);
  var col=JV.colors(), c1=col[0], c2=col[1], cx=W/2, cy=H/2, R=Math.min(W,H)/2-8;
  ctx.strokeStyle=hexA(c1,0.35); ctx.lineWidth=1;
  for(var i=1;i<=4;i++){ ctx.beginPath(); ctx.arc(cx,cy,R*i/4,0,7); ctx.stroke(); }
  ctx.beginPath(); ctx.moveTo(cx-R,cy); ctx.lineTo(cx+R,cy); ctx.moveTo(cx,cy-R); ctx.lineTo(cx,cy+R); ctx.stroke();
  var ang=(ts/(rad.scanning?700:1800))%(Math.PI*2);
  ctx.beginPath(); ctx.moveTo(cx,cy); ctx.arc(cx,cy,R,ang-0.6,ang); ctx.closePath(); ctx.fillStyle=hexA(c1,0.28); ctx.fill();
  ctx.strokeStyle=c1; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+Math.cos(ang)*R,cy+Math.sin(ang)*R); ctx.stroke();
  if(rad.data){
    var all=(rad.data.ble||[]).concat(rad.data.wifi||[]);
    all.forEach(function(o){
      var a=(hash(o.adres||o.ad)%360)*Math.PI/180, r=Math.max(0.06,Math.min(1,(-o.rssi-35)/60))*R;
      var x=cx+Math.cos(a)*r, y=cy+Math.sin(a)*r, c=o.esp?c2:(o.tur==="WIFI"?"#2dff9a":c1);
      var pulse=o.esp?3+2*Math.sin(ts/220):0;
      ctx.fillStyle=hexA(c,0.9); ctx.beginPath(); ctx.arc(x,y,4+pulse,0,7); ctx.fill();
      ctx.strokeStyle=hexA(c,0.4); ctx.lineWidth=1; ctx.beginPath(); ctx.arc(x,y,9+pulse,0,7); ctx.stroke();
      if(o.esp){ ctx.fillStyle=c2; ctx.font="10px monospace"; ctx.textAlign="left"; ctx.fillText(String(o.ad).slice(0,14),x+10,y+3); }
    });
  }
  ctx.fillStyle=c1; ctx.beginPath(); ctx.arc(cx,cy,5,0,7); ctx.fill();
  rad.raf=requestAnimationFrame(radDraw);
}
function radList(){
  var d=rad.data, box=$("rList"); if(!d){ box.innerHTML=""; return; }
  var all=(d.ble||[]).concat(d.wifi||[]).sort(function(a,b){ return b.rssi-a.rssi; });
  box.innerHTML="";
  if(!all.length){ box.innerHTML='<div class="m s">Cihaz bulunamadı.</div>'; return; }
  all.forEach(function(o){
    var row=document.createElement("div"); row.className="conv";
    row.innerHTML='<div style="flex:1;min-width:0"><div class="t">'+esc(o.ad)+(o.esp?'<span class="tag">ESP32/ARDUINO OLABİLİR</span>':'')+'</div><div class="d">'+o.tur+' · '+o.rssi+' dBm · ~'+o.mesafe_m+' m</div></div>'+(o.tur==="BLE"?'<button class="btn" style="padding:6px 10px">İNCELE</button>':'');
    var btn=row.querySelector("button"); if(btn) btn.onclick=function(){ bleInspect(o.adres,o.ad); };
    box.appendChild(row);
  });
}
async function bleInspect(addr,name){
  var box=$("rGatt"); box.innerHTML='<div class="sec"><h3>'+esc(name)+'</h3><div class="m s">Bağlanılıyor… (10-20 sn sürebilir)</div></div>';
  box.scrollIntoView({behavior:"smooth"});
  try{
    var j=JSON.parse(await X("bleInspect",addr));
    var h='<div class="sec"><h3>'+esc(name)+' · '+esc(addr)+'</h3>';
    if(!j.servisler.length) h+='<div class="m s">Servis bulunamadı.</div>';
    j.servisler.forEach(function(s){
      h+='<div style="margin:10px 0 2px;color:var(--c1);font-size:13px">'+esc(s.ad)+' <span style="color:var(--dim);font-size:10px">'+esc(s.uuid.slice(0,8))+'</span></div>';
      s.ozellikler.forEach(function(c){
        h+='<div class="kv" style="font-size:13px;flex-wrap:wrap"><span>'+esc(c.ad)+' <span style="color:var(--dim);font-size:10px">['+esc(c.ozellikler.join(","))+']</span></span><b>'+esc(c.deger!=null?c.deger:"")+'</b>';
        if(c.ozellikler.indexOf("yazma")>=0) h+='<div style="width:100%;display:flex;gap:6px;margin-top:6px"><input type="text" class="wv" placeholder="Gönderilecek metin" data-s="'+esc(s.uuid)+'" data-c="'+esc(c.uuid)+'"><button class="btn wb" style="padding:6px 10px">GÖNDER</button></div>';
        h+='</div>';
      });
    });
    h+='</div>'; box.innerHTML=h;
    box.querySelectorAll(".wb").forEach(function(bt){ bt.onclick=async function(){
      var inp=bt.parentNode.querySelector(".wv"), txt=inp.value; if(!txt) return;
      if(!confirm(name+" cihazına şunu yaz:\n\n"+txt+"\n\nBu cihazın davranışını etkileyebilir. Gönderilsin mi?")) return;
      try{ var r=JSON.parse(await X("bleWrite",JSON.stringify({addr:addr,svc:inp.getAttribute("data-s"),chr:inp.getAttribute("data-c"),text:txt}))); toast(r.yazildi?"Gönderildi":"Yazma doğrulanamadı",3000); }catch(e){ toast(JV.errMsg(e),4000); }
    }; });
  }catch(e){ box.innerHTML='<div class="sec"><div class="m s">'+esc(JV.errMsg(e))+'</div></div>'; }
}
async function radScan(){
  if(rad.scanning) return;
  rad.scanning=true; $("rMsg").textContent="SİNYAL TARANIYOR…";
  cancelAnimationFrame(rad.raf); rad.raf=requestAnimationFrame(radDraw);
  try{
    rad.data=JSON.parse(await X("radar"));
    var b=(rad.data.ble||[]).length, w=(rad.data.wifi||[]).length;
    var esp=(rad.data.ble||[]).concat(rad.data.wifi||[]).filter(function(o){ return o.esp; }).length;
    $("rMsg").textContent="SİNYAL TESPİT EDİLDİ: "+b+" BLUETOOTH, "+w+" WI-FI"+(esp?", "+esp+" OLASI ESP/ARDUINO":"");
    radList();
  }catch(e){ $("rMsg").textContent=JV.errMsg(e); }
  rad.scanning=false;
}
$("rScan").onclick=radScan;
$("rAI").onclick=async function(){
  if(!rad.data){ toast("Önce tara"); return; }
  var box=$("rAn"); box.style.display="block"; box.textContent="Analiz ediliyor…";
  try{
    var slim=JSON.stringify({ble:(rad.data.ble||[]).slice(0,20).map(function(o){return {ad:o.ad,rssi:o.rssi,esp:o.esp};}),wifi:(rad.data.wifi||[]).slice(0,12).map(function(o){return {ad:o.ad,rssi:o.rssi,esp:o.esp};})});
    var t=await JV.aiText("Telefonun yakın çevre taraması (Bluetooth LE ve Wi-Fi). Kısa Türkçe analiz yap: ne tür cihazlar var, ESP32/Arduino/geliştirme kartı olasılığı olan var mı, dikkat çeken bir şey var mı. Mesafeler RSSI tahminidir. Veri: "+slim);
    box.textContent=t;
  }catch(e){ box.textContent=JV.errMsg(e); }
};
$("cRad").onclick=function(){ openPage("pRad"); cancelAnimationFrame(rad.raf); rad.raf=requestAnimationFrame(radDraw); radList(); };

/* ================= MEDYA ARAMA ================= */
mkPage("pMed",
 '<div class="ph"><button class="ib" data-close>←</button><h2>MEDYA ARA</h2></div>'+
 '<div class="pb"><input type="text" id="mQ" placeholder="Örn: geçen ay çektiğim ay fotoğrafı" style="margin-bottom:8px">'+
 '<div style="display:flex;gap:8px;margin-bottom:10px"><button class="btn" id="mGo" style="flex:1">FOTOĞRAF ARA</button><button class="btn" id="mFile" style="flex:1">DOSYA ADI ARA</button></div>'+
 '<div id="mMsg" style="color:var(--dim);font-size:13px;margin-bottom:10px"></div><div class="grid" id="mGrid"></div><div id="mFiles"></div></div>');
var med={run:0};
async function mediaSearch(q){
  var run=++med.run; $("mGrid").innerHTML=""; $("mFiles").innerHTML="";
  $("mMsg").textContent="İsteğin anlaşılıyor…";
  var today=new Date().toISOString().slice(0,10), r;
  try{
    r=JV.parseJSON(await JV.aiText('Bugün '+today+'. Kullanıcı galerisinde şunu arıyor: "'+q+'". Tarih aralığını ve aranan şeyi çıkar. Sadece JSON: {"from":"YYYY-MM-DD","to":"YYYY-MM-DD","what":"aranan şeyin kısa Türkçe tanımı"}. Tarih belirtilmediyse son 120 günü ver.',true));
  }catch(e){ $("mMsg").textContent=JV.errMsg(e); return; }
  var from=Math.floor(Date.parse(r.from+"T00:00:00")/1000), to=Math.floor(Date.parse(r.to+"T23:59:59")/1000);
  if(isNaN(from)||isNaN(to)){ $("mMsg").textContent="Tarih aralığı anlaşılamadı."; return; }
  var offset=0, found=0, total=1, scanned=0;
  while(offset<total&&offset<120&&found<15&&run===med.run){
    $("mMsg").textContent='"'+r.what+'" aranıyor… '+r.from+" / "+r.to+" ("+scanned+" fotoğraf tarandı)";
    var res;
    try{ res=JSON.parse(await X("photos",JSON.stringify({from:from,to:to,offset:offset,limit:20}))); }catch(e){ $("mMsg").textContent=JV.errMsg(e); return; }
    total=res.total; if(!res.items.length&&offset>=total) break;
    if(res.items.length){
      var imgs=res.items.map(function(it,i){ return {label:"Foto "+i+":",data:it.b64}; });
      try{
        var ans=JV.parseJSON(await JV.visionAI('Aranan: "'+r.what+'". Yukarıdaki numaralı fotoğraflardan hangileri buna uyuyor? Sadece JSON: {"matches":[numaralar]}. Hiçbiri uymuyorsa boş dizi.',imgs,true));
        (ans.matches||[]).forEach(function(i){
          var it=res.items[i]; if(!it) return; found++;
          var im=document.createElement("img"); im.src="data:image/jpeg;base64,"+it.b64;
          im.onclick=function(){ window.JarvisX.openUri(it.uri,"image/*"); };
          $("mGrid").appendChild(im);
        });
      }catch(e){ $("mMsg").textContent=JV.errMsg(e); return; }
    }
    scanned+=res.items.length; offset+=20;
  }
  if(run===med.run) $("mMsg").textContent=found?(found+" fotoğraf bulundu. Açmak için dokun."):"Bu aralıkta eşleşen fotoğraf bulunamadı ("+scanned+" taranan).";
}
$("mGo").onclick=function(){ var q=$("mQ").value.trim(); if(q) mediaSearch(q); };
$("mFile").onclick=async function(){
  var q=$("mQ").value.trim(); if(!q) return; $("mGrid").innerHTML=""; $("mMsg").textContent="Dosyalar aranıyor…";
  try{
    var list=JSON.parse(await X("findFiles",q));
    $("mMsg").textContent=list.length?(list.length+" dosya (Android yalnızca medya dosyalarını listeler)"):"Eşleşen dosya yok.";
    $("mFiles").innerHTML="";
    list.forEach(function(f){
      var d=document.createElement("div"); d.className="conv";
      d.innerHTML='<div style="flex:1;min-width:0"><div class="t">'+esc(f.ad)+'</div><div class="d">'+esc(f.tur)+'</div></div>';
      d.onclick=function(){ window.JarvisX.openUri(f.uri,f.tur||"*/*"); }; $("mFiles").appendChild(d);
    });
  }catch(e){ $("mMsg").textContent=JV.errMsg(e); }
};
$("cMed").onclick=function(){ openPage("pMed"); };

/* ================= ŞİFRE KASASI ================= */
var vlt={unlocked:false,focus:""};
mkPage("pVlt",
 '<div class="ph"><button class="ib" data-close>←</button><h2>KASA</h2></div>'+
 '<div class="pb"><div id="vLock" style="text-align:center;padding:30px 0"><div style="font-size:42px">🔐</div><div style="color:var(--dim);margin:10px 0 16px;font-size:13px">Şifrelerin cihazda şifreli saklanır, yapay zekaya gönderilmez.</div><button class="btn" id="vOpen">KİLİDİ AÇ</button></div>'+
 '<div id="vBody" style="display:none"><div class="sec"><h3>Yeni kayıt</h3><input type="text" id="vN" placeholder="Ad (örn. Instagram)" style="margin-bottom:8px"><input type="password" id="vV" placeholder="Şifre" style="margin-bottom:8px"><button class="btn" id="vAdd">KAYDET</button></div><div id="vList"></div></div></div>',
 function(){ vlt.unlocked=false; vlt.focus=""; $("vBody").style.display="none"; $("vLock").style.display="block"; });
function vRender(){
  var list=JSON.parse(window.JarvisX.vaultList()); var box=$("vList"); box.innerHTML="";
  if(!list.length) box.innerHTML='<div class="m s">Kasa boş.</div>';
  list.forEach(function(n){
    var d=document.createElement("div"); d.className="conv"; d.style.flexWrap="wrap";
    d.innerHTML='<div class="t" style="flex:1">'+esc(n)+'</div><button class="btn" data-a="show">Göster</button><button class="btn" data-a="copy">Kopyala</button><button class="btn red" data-a="del">Sil</button><div class="val" style="width:100%;font-family:monospace;color:var(--c2);word-break:break-all;display:none"></div>';
    var val=d.querySelector(".val");
    d.querySelector('[data-a="show"]').onclick=function(){ val.textContent=window.JarvisX.vaultGet(n); val.style.display=val.style.display==="none"?"block":"none"; };
    d.querySelector('[data-a="copy"]').onclick=function(){ if(N) N.copy(window.JarvisX.vaultGet(n)); toast("Kopyalandı"); };
    d.querySelector('[data-a="del"]').onclick=function(){ if(confirm(n+" silinsin mi?")){ window.JarvisX.vaultDel(n); vRender(); } };
    box.appendChild(d);
    if(vlt.focus&&vlt.focus===n){ val.textContent=window.JarvisX.vaultGet(n); val.style.display="block"; d.style.borderColor="var(--c2)"; }
  });
}
async function vUnlock(){
  try{ await X("unlock"); }catch(e){ toast("Kimlik doğrulanamadı"); return false; }
  vlt.unlocked=true; $("vLock").style.display="none"; $("vBody").style.display="block"; vRender(); return true;
}
function openVault(focus){ vlt.focus=focus||""; openPage("pVlt"); vUnlock(); }
$("vOpen").onclick=function(){ vUnlock(); };
$("vAdd").onclick=function(){
  var n=$("vN").value.trim(), v=$("vV").value; if(!n||!v){ toast("Ad ve şifre gerekli"); return; }
  window.JarvisX.vaultSet(n,v); $("vN").value=""; $("vV").value=""; vRender(); toast("Kaydedildi");
};
$("cVlt").onclick=function(){ openVault(""); };

/* ================= ÇEVİRİ (mikrofon, canlı altyazı) ================= */
var LANGS=[["tr-TR","Türkçe"],["en-US","English"],["de-DE","Deutsch"],["fr-FR","Français"],["es-ES","Español"],["it-IT","Italiano"],["ru-RU","Русский"],["ar-SA","العربية"],["ja-JP","日本語"],["zh-CN","中文"],["ko-KR","한국어"]];
var tr={on:false};
mkPage("pTr",
 '<div class="ph"><button class="ib" data-close>←</button><h2>CANLI ÇEVİRİ</h2></div>'+
 '<div class="pb"><div class="row" style="display:block">Konuşulan dil<select id="tSrc" style="margin-top:6px"></select></div>'+
 '<div class="row" style="display:block">Çevrilecek dil<select id="tDst" style="margin-top:6px"></select></div>'+
 '<button class="btn" id="tGo" style="width:100%;margin:6px 0 14px">BAŞLAT</button>'+
 '<div class="big"><small>DUYULAN</small><span id="tOrig">…</span></div><div class="big" style="border-color:var(--c2)"><small>ÇEVİRİ</small><span id="tOut">…</span></div></div>',
 trStop);
LANGS.forEach(function(l){
  var o=document.createElement("option"); o.value=l[0]; o.textContent=l[1]; $("tSrc").appendChild(o);
  var p=document.createElement("option"); p.value=l[1]; p.textContent=l[1]; $("tDst").appendChild(p);
});
$("tSrc").value="en-US"; $("tDst").value=cfg.transTo||"Türkçe";
function trStop(){ tr.on=false; if(N){ N.setListenLang(""); } JV.stopListen(); var b=$("tGo"); if(b) b.textContent="BAŞLAT"; }
$("tGo").onclick=function(){
  if(tr.on){ trStop(); return; }
  tr.on=true; $("tGo").textContent="DURDUR"; $("tOrig").textContent="Dinleniyor…"; $("tOut").textContent="…";
  if(N) N.setListenLang($("tSrc").value);
  JV.listen();
};
window.JV_onSpeech=function(t,final){
  if(hud.talk){
    if(!final){ $("hInfo").innerHTML='<div class="sub"><b>Sen:</b> '+esc(t)+'…</div>'; return true; }
    hudAsk(t); return true;
  }
  if(!tr.on) return false;
  $("tOrig").textContent=t;
  if(final){
    $("tOut").textContent="…";
    JV.aiText("Şu cümleyi "+$("tDst").value+" diline çevir. Sadece çeviriyi yaz, başka hiçbir şey ekleme: "+t).then(function(x){ $("tOut").textContent=x.trim(); })
      .catch(function(e){ $("tOut").textContent=JV.errMsg(e); })
      .then(function(){ if(tr.on) JV.listen(); });
  }
  return true;
};
window.JV_onListenEnd=function(err){
  if(hud.talk){
    hudTalkEnd();
    if(err===9) toast("Mikrofon izni gerekli");
    else if(err===6||err===7) $("hInfo").innerHTML='<div class="sub">Ses duyamadım, tekrar bas.</div>';
    return true;
  }
  if(!tr.on) return false;
  if(err===9||err===100){ trStop(); toast("Ses tanıma kullanılamıyor"); return true; }
  setTimeout(function(){ if(tr.on) JV.listen(); },500);
  return true;
};
$("cTr").onclick=function(){ openPage("pTr"); };

/* ================= DURUM / SENSÖR ================= */
function statusText(j){
  var p=[];
  if(j.pil_yuzde!=null) p.push("pil yüzde "+j.pil_yuzde+(j.sarj_oluyor?", şarj oluyor":""));
  if(j.pil_sicakligi_c) p.push("pil sıcaklığı "+j.pil_sicakligi_c+" derece");
  if(j.hareket) p.push("cihaz "+j.hareket);
  if(j.isik_lux!=null) p.push("ortam ışığı "+j.isik_lux+" lüks");
  if(j.bos_depolama_gb!=null) p.push("boş depolama "+j.bos_depolama_gb+" gigabayt");
  return "Sistem raporu: "+p.join(", ")+".";
}
mkPage("pSt",
 '<div class="ph"><button class="ib" data-close>←</button><h2>CİHAZ DURUMU</h2><button class="btn" id="sRef">YENİLE</button></div>'+
 '<div class="pb"><div id="sBox"></div><button class="btn" id="sSay" style="width:100%;margin-top:14px">SESLİ RAPOR</button></div>');
var lastStatus=null;
async function stRefresh(){
  $("sBox").innerHTML='<div class="m s">Sensörler okunuyor…</div>';
  try{
    var j=JSON.parse(await X("status")); lastStatus=j;
    var rows=[["Pil",j.pil_yuzde!=null?"%"+j.pil_yuzde+(j.sarj_oluyor?" (şarjda)":""):"-"],["Pil sıcaklığı",j.pil_sicakligi_c!=null?j.pil_sicakligi_c+" °C":"-"],["Hareket",j.hareket||"-"],["Ortam ışığı",j.isik_lux!=null?j.isik_lux+" lüks":"-"],["Dönme hızı (jiroskop)",j.donme_hizi_rad_s!=null?j.donme_hizi_rad_s+" rad/s":"-"],["Boş depolama",j.bos_depolama_gb!=null?j.bos_depolama_gb+" GB":"-"]];
    $("sBox").innerHTML=rows.map(function(r){ return '<div class="kv"><span>'+r[0]+'</span><b>'+esc(String(r[1]))+'</b></div>'; }).join("");
  }catch(e){ $("sBox").innerHTML='<div class="m s">'+esc(JV.errMsg(e))+'</div>'; }
}
$("sRef").onclick=stRefresh;
$("sSay").onclick=function(){ if(lastStatus) speak(statusText(lastStatus)); else toast("Önce yenile"); };
$("cSt").onclick=function(){ openPage("pSt"); stRefresh(); };
$("cAn").onclick=function(){ openPage("pAn"); };

/* Periyodik sesli rapor (uygulama açıkken) */
var lastReport=Date.now();
if(!JV.voice){
  setInterval(async function(){
    if(!cfg.reportMin||Date.now()-lastReport<cfg.reportMin*60000) return;
    lastReport=Date.now();
    try{ var j=JSON.parse(await X("status")); speak(statusText(j)); }catch(e){}
  },60000);
}

/* ================= VİDEO / SES ANALİZİ ================= */
mkPage("pAn",
 '<div class="ph"><button class="ib" data-close>←</button><h2>VİDEO / SES ANALİZİ</h2></div>'+
 '<div class="pb"><input type="file" id="aFile" accept="video/*,audio/*" style="display:none">'+
 '<button class="btn" id="aPick" style="width:100%">📁 VİDEO VEYA SES DOSYASI SEÇ</button>'+
 '<div id="aName" style="color:var(--dim);font-size:13px;margin:8px 0"></div>'+
 '<input type="text" id="aQ" placeholder="İstersen soru yaz (örn. kim ne konuşuyor?)" style="margin-bottom:8px">'+
 '<button class="btn" id="aGo" style="width:100%">ANALİZ ET</button>'+
 '<div id="aMsg" style="color:var(--dim);font-size:13px;margin:10px 0"></div>'+
 '<div id="aOut" class="big" style="display:none;font-size:15px;white-space:pre-wrap"></div>'+
 '<button class="btn" id="aSay" style="width:100%;display:none">SESLİ OKU</button></div>');
var an={file:null};
function fileB64(f){ return new Promise(function(res,rej){ var r=new FileReader(); r.onload=function(){ res(String(r.result).split(",")[1]); }; r.onerror=function(){ rej(new Error("Dosya okunamadı")); }; r.readAsDataURL(f); }); }
async function videoFrames(f,n){
  var url=URL.createObjectURL(f), v=document.createElement("video"); v.muted=true; v.playsInline=true; v.preload="auto"; v.src=url;
  await new Promise(function(res,rej){ v.onloadedmetadata=res; v.onerror=function(){ rej(new Error("Video açılamadı")); }; });
  var dur=v.duration||1, frames=[];
  for(var i=0;i<n;i++){
    v.currentTime=Math.max(0,Math.min(dur-0.05,(i+0.5)*dur/n));
    await new Promise(function(res){ v.onseeked=res; });
    var c=document.createElement("canvas"), k=Math.min(1,640/Math.max(v.videoWidth,v.videoHeight)||1);
    c.width=Math.max(1,Math.round(v.videoWidth*k)); c.height=Math.max(1,Math.round(v.videoHeight*k));
    c.getContext("2d").drawImage(v,0,0,c.width,c.height);
    frames.push({label:"Kare "+(i+1)+" ("+Math.round(v.currentTime)+". sn):",data:c.toDataURL("image/jpeg",0.6).split(",")[1]});
  }
  URL.revokeObjectURL(url); return frames;
}
$("aPick").onclick=function(){ $("aFile").click(); };
$("aFile").onchange=function(){ an.file=this.files&&this.files[0]||null; $("aName").textContent=an.file?(an.file.name+" · "+(an.file.size/1048576).toFixed(1)+" MB"):""; };
$("aGo").onclick=async function(){
  var f=an.file; if(!f){ toast("Önce bir dosya seç"); return; }
  var out=$("aOut"), msg=$("aMsg"); out.style.display="none"; $("aSay").style.display="none";
  var q=$("aQ").value.trim(), isAudio=(f.type||"").indexOf("audio")===0;
  var base="Bu "+(isAudio?"ses kaydını":"videoyu")+" ayrıntılı analiz et: ne oluyor, ne söyleniyor, kimler/neler var, dikkat çeken şeyler neler. Türkçe, düzenli ve kısa yaz."+(q?" Kullanıcının sorusu: "+q:"");
  try{
    var text;
    if(isAudio){
      if(cfg.provider!=="gemini") throw new Error("Ses analizi için Ayarlar'dan Gemini'yi seç.");
      if(f.size>12*1048576) throw new Error("Ses dosyası en fazla 12 MB olabilir.");
      msg.textContent="Ses yükleniyor ve analiz ediliyor…";
      var b64=await fileB64(f);
      var body={contents:[{role:"user",parts:[{text:base},{inlineData:{mimeType:f.type||"audio/mpeg",data:b64}}]}],generationConfig:{temperature:0.4,maxOutputTokens:4096}};
      text=JV.gText(JSON.parse(await JV.gCall(body)));
    } else if(cfg.provider==="gemini"&&f.size<=8*1048576){
      msg.textContent="Video (görüntü + ses) analiz ediliyor…";
      var vb=await fileB64(f);
      var body2={contents:[{role:"user",parts:[{text:base},{inlineData:{mimeType:f.type||"video/mp4",data:vb}}]}],generationConfig:{temperature:0.4,maxOutputTokens:4096}};
      text=JV.gText(JSON.parse(await JV.gCall(body2)));
    } else {
      msg.textContent="Video kareleri çıkarılıyor…";
      var fr=await videoFrames(f,8);
      msg.textContent="Kareler analiz ediliyor… (büyük videolarda yalnızca görüntü, ses analiz edilmez)";
      text=await JV.visionAI(base+" Aşağıdaki kareler videodan eşit aralıklarla alındı.",fr,false);
    }
    msg.textContent=""; out.textContent=text.trim(); out.style.display="block"; $("aSay").style.display="block";
  }catch(e){ msg.textContent="❌ "+JV.errMsg(e); }
};
$("aSay").onclick=function(){ speak($("aOut").textContent.replace(/[*_`#]/g,"").slice(0,1500)); };

/* ================= ANAHTAR SİHİRBAZI ================= */
mkPage("pKey",
 '<div class="ph"><button class="ib" data-close>←</button><h2>ANAHTAR</h2></div>'+
 '<div class="pb"><div style="text-align:center;font-size:40px">🔑</div>'+
 '<div style="text-align:center;color:var(--dim);font-size:13px;margin:6px 0 14px">Jarvis\'in beyni için bir API anahtarı gerekiyor. 3 adımda hallet:</div>'+
 '<div class="sec"><h3>1 · Beyni seç</h3><select id="kProv"><option value="gemini">Gemini (Google), ücretsiz kullanım var</option><option value="claude">Claude (Anthropic)</option></select></div>'+
 '<div class="sec"><h3>2 · Anahtarı al</h3><button class="btn" id="kGet" style="width:100%">ANAHTAR SAYFASINI AÇ</button>'+
 '<div id="kHelp" style="font-size:12px;color:var(--dim);margin-top:8px;line-height:1.5"></div></div>'+
 '<div class="sec"><h3>3 · Yapıştır ve test et</h3><input type="password" id="kKey" placeholder="Anahtarı buraya yapıştır" style="margin-bottom:8px">'+
 '<div style="display:flex;gap:8px"><button class="btn" id="kPaste" style="flex:1">PANODAN YAPIŞTIR</button><button class="btn" id="kGo" style="flex:1">KAYDET VE TEST ET</button></div>'+
 '<div id="kMsg" style="margin-top:12px;font-size:14px;line-height:1.5"></div></div></div>');
var KP={
  gemini:{url:"https://aistudio.google.com/apikey",secret:"gemini_key",help:'Açılan sayfada Google hesabınla gir, <b>Create API key</b> düğmesine bas, çıkan anahtarı <b>kopyala</b> (AIza ile başlar). Sonra Jarvis\'e dön.'},
  claude:{url:"https://console.anthropic.com/settings/keys",secret:"api_key",help:'Açılan sayfada giriş yap, kredi yüklü olmalı, <b>Create Key</b> düğmesine bas ve anahtarı <b>kopyala</b> (sk-ant ile başlar). Sonra Jarvis\'e dön.'}
};
function kRefresh(){ var k=KP[$("kProv").value]; $("kHelp").innerHTML=k.help; }
$("kProv").onchange=kRefresh;
$("kGet").onclick=function(){ JV.nat("tool","phone_action",JSON.stringify({action:"open_url",value:KP[$("kProv").value].url})).catch(function(){}); };
$("kPaste").onclick=function(){
  var t=N?String(N.paste()||"").trim():"";
  if(!t){ $("kMsg").textContent="Panoda anahtar bulunamadı. Önce anahtarı kopyala."; return; }
  $("kKey").value=t; $("kMsg").textContent="Yapıştırıldı. Şimdi KAYDET VE TEST ET'e bas.";
};
$("kGo").onclick=async function(){
  var prov=$("kProv").value, key=JV.cleanKey($("kKey").value), msg=$("kMsg");
  if(!key){ msg.textContent="Önce anahtarı yapıştır."; return; }
  N.setSecret(KP[prov].secret,key); cfg.provider=prov; JV.saveCfg();
  var step="1/3 Anahtar kontrol ediliyor…";
  try{
    if(prov==="gemini"){
      msg.textContent=step;
      var model=await JV.pickModel();
      msg.textContent="2/3 Model bulundu: "+model+". 3/3 Deneniyor…";
    } else { msg.textContent="Deneniyor…"; }
    var t=await JV.aiText("Sadece şu kelimeleri yaz: Hazırım efendim.");
    $("kKey").value=""; msg.innerHTML='✅ <b>Bağlandı.</b>'+(prov==="gemini"?' Model: '+esc(cfg.gmodel)+'.':'')+' Jarvis cevap verdi: '+esc(t.trim().slice(0,60));
    setTimeout(function(){ closePage("pKey"); },1800);
  }catch(e){
    var m=JV.errMsg(e), hint="";
    if(/API key not valid|API_KEY_INVALID|invalid x-api-key|authentication|PERMISSION_DENIED|unregistered/i.test(m)) hint="\n→ Anahtar Google/Anthropic tarafından reddedildi. Anahtarı baştan, boşluksuz kopyalayıp tekrar dene. Gerekirse sayfadan yeni anahtar oluştur.";
    else if(/quota|billing|credit|RESOURCE_EXHAUSTED|429/i.test(m)) hint="\n→ Kullanım limiti dolmuş olabilir. Biraz bekleyip tekrar dene.";
    else if(/location|region|not supported in your/i.test(m)) hint="\n→ Bulunduğun bölgede bu hizmet kapalı olabilir. Claude'u seçip dene.";
    else if(/Bağlantı|network|Unable|timeout|resolve/i.test(m)) hint="\n→ İnternet bağlantını kontrol et.";
    msg.style.whiteSpace="pre-wrap"; msg.textContent="❌ "+m+hint+"\n\n(Bu hata mesajının ekran görüntüsünü bana gönderirsen kesin çözerim.)";
  }
};
function openKeyWizard(){ $("kProv").value=cfg.provider||"gemini"; kRefresh(); $("kMsg").textContent=""; openPage("pKey"); }
if(!JV.voice && N && !N.hasSecret(cfg.provider==="gemini"?"gemini_key":"api_key")){
  setTimeout(openKeyWizard,4600);
}

/* ================= EK AYARLAR ================= */
function buildExtraSettings(){
  var pb=document.querySelector("#pSet .pb"); if(!pb) return;
  var old=$("extraSet"); if(old) old.remove();
  var wrap=document.createElement("div"); wrap.id="extraSet";
  var mem=(cfg.memory||[]).map(function(f,i){ return '<div class="row"><div style="flex:1;font-size:13px">'+esc(f)+'</div><button class="btn red" data-mdel="'+i+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="m s">Hafıza boş. "Şunu hatırla: ..." de.</div>';
  var fs=faces().map(function(f,i){ return '<div class="row"><div style="flex:1;font-size:14px">'+esc(f.name)+'</div><button class="btn red" data-fdel="'+i+'" style="padding:4px 10px">×</button></div>'; }).join("")||'<div class="m s">Kayıtlı yüz yok.</div>';
  wrap.innerHTML=
   '<div class="sec"><h3>API anahtarı</h3><button class="btn" id="xKey" style="width:100%">🔑 ANAHTAR SİHİRBAZINI AÇ</button><button class="btn" id="xFix" style="width:100%;margin-top:8px">🛠 BAĞLANTIYI ONAR (çalışan modeli bul)</button><div id="xFixMsg" style="font-size:12px;color:var(--dim);margin-top:8px;white-space:pre-wrap"></div></div>'+
   '<div class="sec"><h3>Jarvis sesi</h3>'+
   '<div class="row" style="display:block">Ses motoru<select id="xEng" style="margin-top:6px"><option value="gemini">Gemini doğal ses (internet gerekir, daha kaliteli)</option><option value="system">Telefon sesi</option></select></div>'+
   '<div class="row" style="display:block">Gemini ses karakteri<select id="xGV" style="margin-top:6px">'+["Charon","Orus","Fenrir","Algenib","Puck","Zephyr","Kore","Aoede","Leda"].map(function(v){ return '<option>'+v+'</option>'; }).join("")+'</select></div>'+
   '<button class="btn" id="xSay">Sesi dene</button></div>'+
   '<div class="sec"><h3>Hafıza</h3>'+mem+'</div>'+
   '<div class="sec"><h3>Kamera HUD</h3>'+
   '<div class="row" style="display:block">Analiz aralığı<select id="xHud" style="margin-top:6px"><option value="2500">Hızlı (2,5 sn, daha çok kullanım)</option><option value="3500">Dengeli (3,5 sn)</option><option value="6000">Ekonomik (6 sn)</option></select></div>'+
   '<div class="row" style="display:block">Çeviri hedef dili<select id="xTo" style="margin-top:6px">'+LANGS.map(function(l){ return '<option>'+l[1]+'</option>'; }).join("")+'</select></div>'+
   '<h3 style="margin-top:14px">Kayıtlı yüzler</h3>'+fs+'</div>'+
   '<div class="sec"><h3>Sesli sistem raporu</h3><div class="row" style="display:block">Jarvis kaç dakikada bir rapor versin? (uygulama açıkken)<select id="xRep" style="margin-top:6px"><option value="0">Kapalı</option><option value="30">30 dakika</option><option value="60">1 saat</option><option value="120">2 saat</option></select></div></div>';
  var secs=pb.querySelectorAll(".sec"), anchor=null;
  secs.forEach(function(s){ var h=s.querySelector("h3"); if(h&&h.textContent.toLowerCase().indexOf("güncelleme")>=0) anchor=s; });
  if(anchor) pb.insertBefore(wrap,anchor); else pb.appendChild(wrap);
  $("xKey").onclick=function(){ closePage("pSet"); openKeyWizard(); };
  $("xFix").onclick=async function(){
    var m=$("xFixMsg"); m.textContent="Modeller deneniyor… (1 dakika kadar sürebilir)";
    try{ var x=await JV.pickModel(); m.textContent="✅ Çalışan model bulundu ve seçildi: "+x; }catch(e){ m.textContent="❌ "+JV.errMsg(e); }
  };
  $("xEng").value=cfg.voiceEngine||"gemini"; $("xGV").value=cfg.gvoice||"Charon";
  $("xEng").onchange=function(){ cfg.voiceEngine=this.value; JV.saveCfg(); };
  $("xGV").onchange=function(){ cfg.gvoice=this.value; JV.saveCfg(); };
  $("xSay").onclick=function(){ JV.say("Merhaba efendim, ben Jarvis. Sistemler çevrimiçi."); };
  $("xHud").value=String(cfg.hudMs); $("xTo").value=cfg.transTo; $("xRep").value=String(cfg.reportMin||0);
  $("xHud").onchange=function(){ cfg.hudMs=parseInt(this.value,10); JV.saveCfg(); };
  $("xTo").onchange=function(){ cfg.transTo=this.value; JV.saveCfg(); $("tDst").value=cfg.transTo; };
  $("xRep").onchange=function(){ cfg.reportMin=parseInt(this.value,10); lastReport=Date.now(); JV.saveCfg(); };
  wrap.querySelectorAll("[data-mdel]").forEach(function(b){ b.onclick=function(){ cfg.memory.splice(parseInt(b.getAttribute("data-mdel"),10),1); JV.saveCfg(); buildExtraSettings(); }; });
  wrap.querySelectorAll("[data-fdel]").forEach(function(b){ b.onclick=function(){ var a=faces(); a.splice(parseInt(b.getAttribute("data-fdel"),10),1); lsSet("faces",a); buildExtraSettings(); }; });
}
$("bSet").addEventListener("click",function(){ setTimeout(buildExtraSettings,0); });
})();
