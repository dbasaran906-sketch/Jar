package com.jarvis.app

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout

/** Asistan/bildirim/widget ile açılan ses modu: balon yok, ekran kenarında ışıma. 5 sn sessizlikte kapanır. */
class VoiceActivity : JarvisActivity() {

    override val voiceMode: Boolean = true

    // Dokunma engellenmediği için takılı kalırsa 90 sn sonra kendini kapatır
    private val bye = android.os.Handler(android.os.Looper.getMainLooper())
    private val byeRun = Runnable { finish() }
    private fun armBye() { bye.removeCallbacks(byeRun); bye.postDelayed(byeRun, 90000L) }

    override fun onDestroy() {
        bye.removeCallbacks(byeRun)
        super.onDestroy()
    }

    override fun layoutWeb() {
        val d = resources.displayMetrics
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // Tam ekran, saydam, dokunmayı engellemez: sadece kenar ışıması ve küçük yazı görünür
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        val lp = window.attributes
        lp.dimAmount = 0f
        window.attributes = lp
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        armBye()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_OUTSIDE) {
            finish()
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        armBye()
        web.evaluateJavascript("window.beginVoice&&window.beginVoice()", null)
    }
}
