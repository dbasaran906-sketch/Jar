/* JARVİS X-RAY ANALİZ: fotoğraf seç -> nesneyi bul -> onay -> X-ray görünümü + tahmini iç yapı etiketleri; zoom/kaydır.
   NOT: gerçek röntgen değildir; görüntü filtresi + yapay zekânın bildiği iç yapıdan çıkardığı TAHMİNİ şemadır. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div"); var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
var X={img:null,iw:0,ih:0,b64:"",objs:[],sel:null,parts:[],fx:null,st:"idle",z:1,tx:0,ty:0,fxOn:true,lab:true,bright:1.0,raf:0,busy:false};

var d=document.createElement("div"); d.className="page"; d.id="pXr";
d.innerHTML=
 '<div class="ph"><button class="ib" data-close>←</button><h2>X-RAY ANALİZ</h2></div>'+
 '<div class="pb" style="padding:8px;display:flex;flex-direction:column;gap:8px">'+
 '<div id="xrWrap" style="position:relative;height:44vh;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#000;touch-action:none"><canvas id="xrC" style="width:100%;height:100%;display:block"></canvas><div id="xrHint" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:13px;text-align:center;padding:20px">Bir fotoğraf seç. Jarvis nesneyi bulacak, sana soracak, sonra X-ray görünümünü çıkaracak.</div></div>'+
 '<div id="xrMsg" style="font-size:14px;min-height:20px;color:var(--c1)"></div>'+
 '<div id="xrAsk" style="display:none;gap:8px;flex-wrap:wrap"></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="xrPick" style="flex:1">📷 FOTOĞRAF SEÇ</button><button class="btn" id="xrZi" style="flex:0 0 52px">＋</button><button class="btn" id="xrZo" style="flex:0 0 52px">－</button><button class="btn" id="xrRs" style="flex:0 0 52px">⟲</button><button class="btn" id="xr3d" style="flex:0 0 60px">3D</button></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn on" id="xrFx" style="flex:1">X-RAY: AÇIK</button><button class="btn on" id="xrLb" style="flex:1">ETİKET: AÇIK</button></div>'+
 '<label style="font-size:12px;color:var(--dim)">Parlaklık <input type="range" id="xrBr" min="50" max="200" value="100" style="width:100%"></label>'+
 '<div id="xrList" style="font-size:13px"></div>'+
 '<input type="file" id="xrFile" accept="image/*" style="display:none"></div>';
document.body.appendChild(d);
function msg(t){ $("xrMsg").textContent=t||""; }
function ask(opts){
  var a=$("xrAsk"); a.innerHTML=""; if(!opts||!opts.length){ a.style.display="none"; return; }
  a.style.display="flex";
  opts.forEach(function(o){ var b=document.createElement("button"); b.className="btn"; b.textContent=o[0]; b.onclick=o[1]; a.appendChild(b); });
}
function jsay(t){ msg(t); try{ JV.say(t); }catch(e){} }

/* ---- görüntü yükle ---- */
$("xrPick").onclick=function(){ $("xrFile").click(); };
$("xrFile").onchange=function(){
  var f=this.files&&this.files[0]; if(!f) return;
  var r=new FileReader();
  r.onload=function(){
    var im=new Image();
    im.onload=function(){
      var k=Math.min(1,1024/Math.max(im.width,im.height)), c=document.createElement("canvas"); c.width=Math.round(im.width*k); c.height=Math.round(im.height*k);
      c.getContext("2d").drawImage(im,0,0,c.width,c.height);
      X.img=c; X.iw=c.width; X.ih=c.height; X.b64=c.toDataURL("image/jpeg",0.82).split(",")[1];
      X.objs=[]; X.sel=null; X.parts=[]; X.fx=null; reset(); $("xrHint").style.display="none"; $("xrList").innerHTML="";
      analyze();
    };
    im.src=r.result;
  };
  r.readAsDataURL(f); this.value="";
};

function nb(b){
  if(!b||b.length<4) return null; var a=b.map(Number); if(a.some(isNaN)) return null;
  var mx=Math.max.apply(null,a); if(mx<=1.5) a=a.map(function(x){ return x*1000; });
  var y1=Math.min(a[0],a[2]), y2=Math.max(a[0],a[2]), x1=Math.min(a[1],a[3]), x2=Math.max(a[1],a[3]);
  y1=Math.max(0,y1); x1=Math.max(0,x1); y2=Math.min(1000,y2); x2=Math.min(1000,x2);
  if((x2-x1)*(y2-y1)<30000){ x1=0; y1=0; x2=1000; y2=1000; } /* çok küçük/bozuk kutu: tüm fotoğrafı al */
  return {y1:y1/1000*X.ih,x1:x1/1000*X.iw,y2:y2/1000*X.ih,x2:x2/1000*X.iw};
}

async function analyze(){
  X.st="find"; X.busy=true; msg("Nesneler aranıyor…"); ask(null);
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki belirgin tek tek nesneleri bul (en fazla 5; ana nesne en önce). Sadece JSON: [{"ad":"kısa Türkçe ad","box_2d":[ymin,xmin,ymax,xmax],"guven":0-1}] box_2d 0-1000 normalize. Nesne yoksa [].',[{data:X.b64}],true),40000,"analiz zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.objs=arr.map(function(o){ return {ad:String(o.ad||"nesne"),box:nb(o.box_2d),g:o.guven||0}; }).filter(function(o){ return o.box; });
    if(!X.objs.length){ X.busy=false; X.st="idle"; msg("Nesne bulamadım. Başka bir fotoğraf dene."); return; }
    X.sel=X.objs[0]; X.st="confirm"; X.busy=false;
    offerConfirm();
  }catch(e){ X.busy=false; X.st="idle"; msg("Hata: "+JV.errMsg(e)); }
}
function offerConfirm(){
  var o=X.sel; jsay("Fotoğrafta "+o.ad+" var. "+o.ad+" mı seçmiştiniz?");
  var opts=[["EVET, "+o.ad.toUpperCase(),function(){ confirmObj(); }]];
  X.objs.filter(function(x){ return x!==o; }).forEach(function(x){ opts.push([x.ad.toUpperCase()+" AYNI DEĞİL, BUNU SEÇ",function(){ X.sel=x; offerConfirm(); }]); });
  ask(opts);
  msg(o.ad+" mı seçmiştiniz? (Görüntüde başka bir nesneye de dokunabilirsin.)");
}
async function confirmObj(){
  if(X.busy) return; X.busy=true; X.st="scan"; ask(null); msg("3 boyutlu X-ray modeli hazırlanıyor…");
  var o=X.sel, bx=o.box;
  buildFx(bx);
  var ok=false;
  try{ ok=await holo(o); }catch(e){ ok=false; }
  if(!ok){ await loadParts(o,bx); }
  else{ X.st="view"; X.busy=false; msg("3D hologram hazır. İstersen yukarıdaki 3D tuşuyla tekrar aç."); }
}
async function loadParts(o,bx){
  msg("3D model çıkmadı; fotoğraf üstünde X-ray taraması yapılıyor…");
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki "'+o.ad+'" nesnesinin (kutu: ymin='+Math.round(bx.y1/X.ih*1000)+', xmin='+Math.round(bx.x1/X.iw*1000)+', ymax='+Math.round(bx.y2/X.ih*1000)+', xmax='+Math.round(bx.x2/X.iw*1000)+') ürün türüne göre TİPİK iç yapısını düşün. Gizli iç parçaların bu fotoğraftaki yaklaşık konumlarını tahmin et. Sadece JSON: [{"ad":"parça adı","box_2d":[ymin,xmin,ymax,xmax],"bilgi":"tek satır açıklama, en fazla 60 karakter"}] en fazla 8 parça, box_2d 0-1000 normalize (nesne kutusunun içinde).',[{data:X.b64}],true),45000,"tarama zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.parts=arr.map(function(p){ return {ad:String(p.ad||"parça"),box:nb(p.box_2d),bilgi:String(p.bilgi||"")}; }).filter(function(p){ return p.box; });
    X.st="view"; X.busy=false;
    $("xrList").innerHTML='<div class="sec"><b>TAHMİNİ İÇ YAPI</b> <span style="color:var(--dim);font-size:11px">(gerçek röntgen değil; yapay zekâ tahmini)</span>'+X.parts.map(function(p,i){ return '<div class="pl">'+(i+1)+'. '+esc(p.ad)+'<small>'+esc(p.bilgi)+'</small></div>'; }).join("")+'</div>';
    msg("X-ray hazır: "+o.ad+" — "+X.parts.length+" iç parça (tahmini).");
  }catch(e){ X.st="view"; X.busy=false; msg("İç yapı çıkarılamadı ("+JV.errMsg(e)+"). Sadece X-ray filtresi gösteriliyor."); }
}

/* ================= 3D TEL KAFES HOLOGRAM (tam ekran) ================= */
var H3={on:false,parts:[],yaw:0.6,pitch:0.25,z:1,auto:true,tilt:false,showOut:true,showIn:true,lab:true,sel:-1,raf:0,name:"",R:1,cx:0,cy:0,cz:0};
var ov=document.createElement("div"); ov.id="xrH";
ov.style.cssText="position:fixed;inset:0;z-index:58;background:radial-gradient(ellipse at 50% 45%,#041a2e 0%,#010811 75%);display:none;touch-action:none;color:#cfeaff;font-family:inherit";
ov.innerHTML='<canvas id="xrHC" style="position:absolute;inset:0;width:100%;height:100%"></canvas>'+
 '<div style="position:absolute;top:0;left:0;right:0;padding:12px 14px;display:flex;align-items:center;gap:10px"><button class="ib" id="xrHx">←</button><div style="flex:1"><div style="letter-spacing:3px;color:var(--c1);font-size:14px" id="xrHt">X-RAY HOLOGRAM</div><div style="font-size:10px;color:#6f9bb8">YAPAY ZEKÂ MODELİ · TAHMİNİ İÇ YAPI · GERÇEK RÖNTGEN DEĞİL</div></div></div>'+
 '<div id="xrHs" style="position:absolute;top:70px;left:0;right:0;text-align:center;font-size:13px;color:var(--c1)"></div>'+
 '<div id="xrHi" style="position:absolute;left:12px;right:12px;bottom:78px;display:none;padding:10px 12px;border:1px solid var(--c2);border-radius:12px;background:rgba(20,10,2,.85);font-size:14px"></div>'+
 '<div style="position:absolute;left:8px;right:8px;bottom:12px;display:flex;gap:6px;flex-wrap:wrap;justify-content:center"><button class="btn" id="xrHo">DIŞ</button><button class="btn" id="xrHn">İÇ</button><button class="btn" id="xrHl">ETİKET</button><button class="btn" id="xrHa">DÖN</button><button class="btn" id="xrHg">EĞİM</button><button class="btn" id="xrHr">⟲</button></div>';
document.body.appendChild(ov);
function hs(t){ $("xrHs").textContent=t||""; }
function v3(a){ return Array.isArray(a)&&a.length>=3&&a.every(function(x){ return isFinite(+x); })?[+a[0],+a[1],+a[2]]:null; }
function circ(m,ax,r,n){ var o=[]; for(var i=0;i<=n;i++){ var t=i/n*6.2832, c=Math.cos(t)*r, s=Math.sin(t)*r; o.push(ax==="x"?[m[0],m[1]+c,m[2]+s]:ax==="y"?[m[0]+c,m[1],m[2]+s]:[m[0]+c,m[1]+s,m[2]]); } return o; }
function primLines(p){
  var L=[], m=v3(p.m), r=Math.abs(+p.r)||0.1, ax=/^[xyz]$/.test(p.eks)?p.eks:"z";
  if(p.tur==="tup"){ var a=v3(p.a), b=v3(p.b); if(a&&b) L.push([a,b]); }
  else if(p.tur==="halka"&&m){ L.push(circ(m,ax,r,32)); if(p.kol){ var c=circ(m,ax,r,8); for(var i=0;i<8;i++) L.push([m,c[i]]); } else L.push(circ(m,ax,r*0.82,24)); }
  else if(p.tur==="kutu"&&m){ var b=v3(p.b)||[0.2,0.2,0.2], h=[b[0]/2,b[1]/2,b[2]/2], P=[]; for(var i=0;i<8;i++) P.push([m[0]+(i&1?h[0]:-h[0]),m[1]+(i&2?h[1]:-h[1]),m[2]+(i&4?h[2]:-h[2])]); [[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]].forEach(function(e){ L.push([P[e[0]],P[e[1]]]); }); }
  else if(p.tur==="silindir"&&m){ var u=(+p.u||0.3)/2, d=ax==="x"?[u,0,0]:ax==="y"?[0,u,0]:[0,0,u], m1=[m[0]-d[0],m[1]-d[1],m[2]-d[2]], m2=[m[0]+d[0],m[1]+d[1],m[2]+d[2]], c1=circ(m1,ax,r,18), c2=circ(m2,ax,r,18); L.push(c1,c2); for(var i=0;i<18;i+=4.5) L.push([c1[Math.round(i)],c2[Math.round(i)]]); }
  else if(p.tur==="kure"&&m){ L.push(circ(m,"x",r,22),circ(m,"y",r,22),circ(m,"z",r,22)); }
  return L;
}
function buildModel(arr){
  var parts=[], mn=[1e9,1e9,1e9], mx=[-1e9,-1e9,-1e9];
  arr.slice(0,32).forEach(function(p){
    if(!p||typeof p!=="object") return; var lines=primLines(p); if(!lines.length) return;
    var pts=[]; lines.forEach(function(l){ l.forEach(function(q){ pts.push(q); for(var k=0;k<3;k++){ if(q[k]<mn[k])mn[k]=q[k]; if(q[k]>mx[k])mx[k]=q[k]; } }); });
    var c=[0,0,0]; pts.forEach(function(q){ c[0]+=q[0]; c[1]+=q[1]; c[2]+=q[2]; }); c=c.map(function(x){ return x/pts.length; });
    parts.push({ad:String(p.ad||"parça"),inner:/^i/i.test(String(p.grup||"")),bilgi:String(p.bilgi||""),lines:lines,c:c});
  });
  if(parts.length<3) return null;
  H3.cx=(mn[0]+mx[0])/2; H3.cy=(mn[1]+mx[1])/2; H3.cz=(mn[2]+mx[2])/2;
  H3.R=Math.max(0.01,Math.hypot(mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2])/2);
  return parts;
}
async function holo(o){
  H3.name=o.ad; $("xrHt").textContent="X-RAY · "+o.ad.toUpperCase(); ov.style.display="block"; H3.on=true; H3.parts=[]; H3.sel=-1; H3.yaw=0.6; H3.pitch=0.25; H3.z=1; hs("3 boyutlu model çiziliyor… (10-30 sn)"); $("xrHi").style.display="none";
  startH3();
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki "'+o.ad+'" nesnesinin 3 boyutlu TEL KAFES modelini oluştur. Koordinat: x=uzunluk/ileri, y=yukarı, z=yan genişlik; nesne yaklaşık -1..1 kutusuna sığsın, gerçek orantıları koru. Parçalar (en fazla 28), her biri {"ad":"Türkçe ad","tur":"tup|halka|kutu|silindir|kure","grup":"dis|ic","bilgi":"en fazla 60 karakter"} + türe göre alanlar. tup: "a":[x,y,z],"b":[x,y,z]. halka: "m":[x,y,z],"eks":"x|y|z" (halkanın düzlemine dik eksen),"r":sayı,"kol":true/false. kutu: "m":[x,y,z],"b":[genişlikX,yükseklikY,derinlikZ]. silindir: "m":[x,y,z],"eks":"x|y|z","r":sayı,"u":uzunluk. kure: "m":[x,y,z],"r":sayı. grup "dis" = dışarıdan görünen yapı (en az 8 parça), "ic" = gizli iç mekanizma / iç parçalar (nesne türünün tipik iç yapısı, en az 6 parça). Sadece JSON dizisi.',[{data:X.b64}],true),70000,"model zaman aşımı");
    var arr=JV.parseJSON(raw); if(!Array.isArray(arr)) arr=(arr&&arr.parcalar)||[];
    var parts=buildModel(arr);
    if(!parts){ closeH3(); return false; }
    H3.parts=parts; hs(""); try{ JV.say("Hologram hazır efendim. Parmağınla çevirebilir, iki parmakla yakınlaştırabilirsin."); }catch(e){}
    return true;
  }catch(e){ closeH3(); return false; }
}
function closeH3(){ H3.on=false; ov.style.display="none"; cancelAnimationFrame(H3.raf); }
function rot(p){
  var x=p[0]-H3.cx, y=p[1]-H3.cy, z=p[2]-H3.cz, cy=Math.cos(H3.yaw), sy=Math.sin(H3.yaw), cp=Math.cos(H3.pitch), sp=Math.sin(H3.pitch);
  var x1=x*cy+z*sy, z1=-x*sy+z*cy, y1=y*cp-z1*sp, z2=y*sp+z1*cp; return [x1,y1,z2];
}
var H3proj=[];
function startH3(){ cancelAnimationFrame(H3.raf); (function loop(ts){ if(!H3.on) return; H3.raf=requestAnimationFrame(loop); drawH3(ts); })(0); }
function drawH3(ts){
  var cv=$("xrHC"), dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight; if(!W) return;
  if(cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var c=cv.getContext("2d"); c.setTransform(dpr,0,0,dpr,0,0); c.clearRect(0,0,W,H);
  if(H3.auto&&!dragging) H3.yaw+=0.006;
  var S=Math.min(W,H)*0.42*H3.z/H3.R, cx=W/2, cy=H*0.46, F=3.2*H3.R;
  /* zemin ızgarası */
  c.lineWidth=1; c.strokeStyle="rgba(43,181,255,.16)";
  for(var g=-4;g<=4;g++){ [[[g,-1,-4],[g,-1,4]],[[-4,-1,g],[4,-1,g]]].forEach(function(l){ var a=rot([H3.cx+l[0][0]*H3.R*.5,H3.cy-H3.R*0.9,H3.cz+l[0][2]*H3.R*.5]), b=rot([H3.cx+l[1][0]*H3.R*.5,H3.cy-H3.R*0.9,H3.cz+l[1][2]*H3.R*.5]); var fa=F/(F+a[2]), fb=F/(F+b[2]); c.beginPath(); c.moveTo(cx+a[0]*S*fa,cy-a[1]*S*fa); c.lineTo(cx+b[0]*S*fb,cy-b[1]*S*fb); c.stroke(); }); }
  H3proj=[]; var order=H3.parts.map(function(p,i){ return i; });
  order.forEach(function(i){
    var p=H3.parts[i]; if(p.inner?!H3.showIn:!H3.showOut) return;
    var sel=(i===H3.sel), base=p.inner?"255,138,31":"43,181,255", dimmed=(H3.sel>=0&&!sel);
    c.lineWidth=(sel?2.6:1.4); c.shadowBlur=sel?14:7; c.shadowColor="rgba("+(sel?"255,255,255":base)+",.9)";
    var avgz=0, n=0;
    p.lines.forEach(function(l){
      c.beginPath();
      l.forEach(function(q,k){ var r=rot(q), f=F/(F+r[2]); var X2=cx+r[0]*S*f, Y2=cy-r[1]*S*f; avgz+=r[2]; n++; if(k===0) c.moveTo(X2,Y2); else c.lineTo(X2,Y2); });
      var dz=(l.length?avgz/Math.max(1,n):0); var al=Math.max(.25,Math.min(1,.75-dz/(H3.R*2.2)));
      c.strokeStyle="rgba("+(sel?"255,255,255":base)+","+(dimmed?al*.25:al)+")"; c.stroke();
    });
    c.shadowBlur=0;
    var r0=rot(p.c), f0=F/(F+r0[2]); var sx=cx+r0[0]*S*f0, sy2=cy-r0[1]*S*f0; H3proj.push({i:i,x:sx,y:sy2,z:r0[2]});
    if((H3.lab&&p.inner&&!dimmed)||sel){ c.font="11px sans-serif"; var t=p.ad, tw=c.measureText(t).width; c.fillStyle="rgba(0,0,0,.6)"; c.fillRect(sx+8,sy2-16,tw+8,16); c.fillStyle=sel?"#fff":"#ffd9b0"; c.fillText(t,sx+12,sy2-4); c.strokeStyle="rgba("+base+",.7)"; c.lineWidth=1; c.beginPath(); c.moveTo(sx,sy2); c.lineTo(sx+8,sy2-8); c.stroke(); c.fillStyle="rgba("+base+",1)"; c.beginPath(); c.arc(sx,sy2,2.5,0,6.3); c.fill(); }
  });
  /* tarama çizgisi */
  var sy3=(ts/10)%H; c.fillStyle="rgba(120,220,255,.06)"; c.fillRect(0,sy3,W,26);
}
var dragging=false, hp={}, hd=0, moved=0;
ov.addEventListener("pointerdown",function(e){ if(e.target.closest&&e.target.closest("button")) return; hp[e.pointerId]={x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:Date.now()}; dragging=true; moved=0; hd=0; try{ ov.setPointerCapture(e.pointerId); }catch(er){} });
ov.addEventListener("pointermove",function(e){
  var p=hp[e.pointerId]; if(!p) return; var ids=Object.keys(hp);
  if(ids.length===1){ H3.yaw+=(e.clientX-p.x)*0.012; H3.pitch=Math.max(-1.4,Math.min(1.4,H3.pitch+(e.clientY-p.y)*0.01)); moved+=Math.abs(e.clientX-p.x)+Math.abs(e.clientY-p.y); }
  else if(ids.length>=2){ var a=hp[ids[0]], b=hp[ids[1]]; if(e.pointerId==ids[0]) a={x:e.clientX,y:e.clientY}; else b={x:e.clientX,y:e.clientY}; var dd=Math.hypot(a.x-b.x,a.y-b.y); if(hd) H3.z=Math.max(.4,Math.min(5,H3.z*dd/hd)); hd=dd; }
  p.x=e.clientX; p.y=e.clientY;
});
function hup(e){ var p=hp[e.pointerId]; delete hp[e.pointerId]; hd=0; if(!Object.keys(hp).length) dragging=false; if(p&&Math.hypot(e.clientX-p.x0,e.clientY-p.y0)<9&&Date.now()-p.t<400) pickPart(e.clientX,e.clientY); }
ov.addEventListener("pointerup",hup); ov.addEventListener("pointercancel",function(e){ delete hp[e.pointerId]; dragging=false; });
ov.addEventListener("wheel",function(e){ e.preventDefault(); H3.z=Math.max(.4,Math.min(5,H3.z*(e.deltaY<0?1.12:.89))); },{passive:false});
function pickPart(x,y){
  var cv=$("xrHC").getBoundingClientRect(), best=-1, bd=40;
  H3proj.forEach(function(q){ var d=Math.hypot(q.x+cv.left-x,q.y+cv.top-y); if(d<bd){ bd=d; best=q.i; } });
  H3.sel=best===H3.sel?-1:best; var box=$("xrHi");
  if(H3.sel>=0){ var p=H3.parts[H3.sel]; box.style.display="block"; box.innerHTML='<b>'+esc(p.ad)+'</b> <span style="color:#8fb6cf;font-size:11px">('+(p.inner?"iç parça":"dış yapı")+')</span><br>'+esc(p.bilgi||"Açıklama yok"); }
  else box.style.display="none";
}
function tgl(id,key,onT,offT){ $(id).onclick=function(){ H3[key]=!H3[key]; this.classList.toggle("on",H3[key]); this.textContent=H3[key]?onT:offT; }; $(id).classList.toggle("on",!!H3[key]); }
tgl("xrHo","showOut","DIŞ: AÇIK","DIŞ: KAPALI"); tgl("xrHn","showIn","İÇ: AÇIK","İÇ: KAPALI"); tgl("xrHl","lab","ETİKET: AÇIK","ETİKET: KAPALI"); tgl("xrHa","auto","DÖN: AÇIK","DÖN: KAPALI");
$("xrHo").textContent="DIŞ: AÇIK"; $("xrHn").textContent="İÇ: AÇIK"; $("xrHl").textContent="ETİKET: AÇIK"; $("xrHa").textContent="DÖN: AÇIK"; $("xrHg").textContent="EĞİM: KAPALI";
$("xrHg").onclick=function(){ H3.tilt=!H3.tilt; this.classList.toggle("on",H3.tilt); this.textContent=H3.tilt?"EĞİM: AÇIK":"EĞİM: KAPALI"; if(H3.tilt){ H3.auto=false; $("xrHa").classList.remove("on"); $("xrHa").textContent="DÖN: KAPALI"; } };
$("xrHr").onclick=function(){ H3.yaw=0.6; H3.pitch=0.25; H3.z=1; H3.sel=-1; $("xrHi").style.display="none"; };
$("xrHx").onclick=closeH3;
var g0=null;
window.addEventListener("deviceorientation",function(e){ if(!H3.on||!H3.tilt||e.gamma==null) return; if(!g0) g0={g:e.gamma,b:e.beta}; H3.yaw=0.6+(e.gamma-g0.g)*0.035; H3.pitch=Math.max(-1.3,Math.min(1.3,0.25+(e.beta-g0.b)*0.03)); });
$("xrHg").addEventListener("click",function(){ g0=null; });
window.JV_xrayH3={H3:H3,build:buildModel,show:function(arr){ var p=buildModel(arr); if(!p) return false; H3.parts=p; ov.style.display="block"; H3.on=true; startH3(); return true; }};

/* ---- X-ray efekti: nesne bölgesinde ters parlaklık + kenar vurgusu + mavi ton ---- */
function buildFx(bx){
  var x=Math.max(0,Math.floor(bx.x1)), y=Math.max(0,Math.floor(bx.y1)), w=Math.min(X.iw-x,Math.ceil(bx.x2-bx.x1)), h=Math.min(X.ih-y,Math.ceil(bx.y2-bx.y1));
  if(w<4||h<4){ X.fx=null; return; }
  var c=document.createElement("canvas"); c.width=w; c.height=h; var ctx=c.getContext("2d");
  ctx.drawImage(X.img,x,y,w,h,0,0,w,h);
  var id=ctx.getImageData(0,0,w,h), s=id.data, L=new Float32Array(w*h), i, j;
  for(i=0,j=0;i<s.length;i+=4,j++) L[j]=0.3*s[i]+0.59*s[i+1]+0.11*s[i+2];
  var out=ctx.createImageData(w,h), o=out.data, mn=255,mx=0;
  for(j=0;j<L.length;j++){ if(L[j]<mn)mn=L[j]; if(L[j]>mx)mx=L[j]; }
  var rg=Math.max(1,mx-mn);
  for(var yy=0;yy<h;yy++) for(var xx=0;xx<w;xx++){
    j=yy*w+xx; var g=0;
    if(xx>0&&yy>0&&xx<w-1&&yy<h-1){ var gx=-L[j-w-1]-2*L[j-1]-L[j+w-1]+L[j-w+1]+2*L[j+1]+L[j+w+1], gy=-L[j-w-1]-2*L[j-w]-L[j-w+1]+L[j+w-1]+2*L[j+w]+L[j+w+1]; g=Math.min(255,Math.sqrt(gx*gx+gy*gy)); }
    var v=255-(L[j]-mn)/rg*255, e=Math.min(255,v*0.55+g*1.4), k=j*4;
    o[k]=e*0.25; o[k+1]=e*0.8; o[k+2]=Math.min(255,e*1.15+20); o[k+3]=255;
  }
  ctx.putImageData(out,0,0); X.fx={c:c,x:x,y:y,w:w,h:h};
}
/* ---- çizim ---- */
function reset(){ X.z=1; X.tx=0; X.ty=0; }
function draw(ts){
  X.raf=requestAnimationFrame(draw);
  var cv=$("xrC"); if(!cv.clientWidth||!document.getElementById("pXr").classList.contains("show")) return;
  var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight;
  if(cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var ctx=cv.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.fillStyle="#000"; ctx.fillRect(0,0,W,H);
  if(!X.img) return;
  var base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty;
  ctx.setTransform(dpr*sc,0,0,dpr*sc,dpr*ox,dpr*oy);
  var dim=(X.st==="view"&&X.fxOn&&X.fx);
  ctx.globalAlpha=dim?0.28:1; ctx.drawImage(X.img,0,0); ctx.globalAlpha=1;
  if(dim){
    ctx.filter="brightness("+X.bright+")"; ctx.drawImage(X.fx.c,X.fx.x,X.fx.y); ctx.filter="none";
    var sy=((ts/18)%(X.fx.h+40))-20; ctx.fillStyle="rgba(120,220,255,.35)"; ctx.fillRect(X.fx.x,X.fx.y+sy,X.fx.w,2/sc*1.5);
  }
  var lw=1.6/sc, fs=12/sc;
  ctx.lineWidth=lw; ctx.font=fs+"px sans-serif";
  if(X.sel&&(X.st==="confirm"||X.st==="scan"||X.st==="view")){ var b=X.sel.box; ctx.strokeStyle="#2bb5ff"; ctx.setLineDash([6/sc,4/sc]); ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1); ctx.setLineDash([]); if(X.st!=="view"){ ctx.fillStyle="#2bb5ff"; ctx.fillText(X.sel.ad,b.x1+3/sc,b.y1-4/sc); } }
  if(X.st==="view"&&X.lab) X.parts.forEach(function(p,i){
    var b=p.box; ctx.strokeStyle="#ff8a1f"; ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1);
    var t=(i+1)+" "+p.ad, tw=ctx.measureText(t).width; ctx.fillStyle="rgba(0,0,0,.7)"; ctx.fillRect(b.x1,b.y1-fs-3/sc,tw+6/sc,fs+3/sc); ctx.fillStyle="#ffd9b0"; ctx.fillText(t,b.x1+3/sc,b.y1-3/sc);
  });
}
X.raf=requestAnimationFrame(draw);

/* ---- dokunma / zoom ---- */
var ptr={}, lastD=0;
var wrap=$("xrWrap");
wrap.addEventListener("pointerdown",function(e){ ptr[e.pointerId]={x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:Date.now()}; try{ wrap.setPointerCapture(e.pointerId); }catch(er){} lastD=0; });
wrap.addEventListener("pointermove",function(e){
  var p=ptr[e.pointerId]; if(!p) return; var ids=Object.keys(ptr);
  if(ids.length===1){ X.tx+=e.clientX-p.x; X.ty+=e.clientY-p.y; }
  else if(ids.length>=2){
    var a=ptr[ids[0]], b=ptr[ids[1]]; if(e.pointerId==ids[0]){ a={x:e.clientX,y:e.clientY}; } else { b={x:e.clientX,y:e.clientY}; }
    var dd=Math.hypot(a.x-b.x,a.y-b.y); if(lastD) zoomBy(dd/lastD); lastD=dd;
  }
  p.x=e.clientX; p.y=e.clientY;
});
function endP(e){
  var p=ptr[e.pointerId]; delete ptr[e.pointerId]; lastD=0;
  if(p&&Math.hypot(e.clientX-p.x0,e.clientY-p.y0)<8&&Date.now()-p.t<400) tap(e.clientX,e.clientY);
}
wrap.addEventListener("pointerup",endP); wrap.addEventListener("pointercancel",function(e){ delete ptr[e.pointerId]; });
wrap.addEventListener("wheel",function(e){ e.preventDefault(); zoomBy(e.deltaY<0?1.15:0.87); },{passive:false});
function zoomBy(k){ X.z=Math.max(1,Math.min(8,X.z*k)); if(X.z===1){ X.tx=0; X.ty=0; } }
function toImg(cx,cy){ var cv=$("xrC"), r=cv.getBoundingClientRect(), W=cv.clientWidth, H=cv.clientHeight, base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty; return {x:(cx-r.left-ox)/sc,y:(cy-r.top-oy)/sc}; }
function tap(cx,cy){
  if(!X.img||X.st!=="confirm") return;
  var q=toImg(cx,cy), hit=X.objs.filter(function(o){ return q.x>=o.box.x1&&q.x<=o.box.x2&&q.y>=o.box.y1&&q.y<=o.box.y2; }).sort(function(a,b){ return (a.box.x2-a.box.x1)*(a.box.y2-a.box.y1)-(b.box.x2-b.box.x1)*(b.box.y2-b.box.y1); })[0];
  if(hit&&hit!==X.sel){ X.sel=hit; offerConfirm(); }
}
$("xr3d").onclick=function(){ if(H3.parts.length){ ov.style.display="block"; H3.on=true; startH3(); } else toast("Önce bir nesne seçip onayla"); };
$("xrZi").onclick=function(){ zoomBy(1.4); }; $("xrZo").onclick=function(){ zoomBy(1/1.4); }; $("xrRs").onclick=reset;
$("xrFx").onclick=function(){ X.fxOn=!X.fxOn; this.textContent="X-RAY: "+(X.fxOn?"AÇIK":"KAPALI"); this.classList.toggle("on",X.fxOn); };
$("xrLb").onclick=function(){ X.lab=!X.lab; this.textContent="ETİKET: "+(X.lab?"AÇIK":"KAPALI"); this.classList.toggle("on",X.lab); };
$("xrBr").oninput=function(){ X.bright=this.value/100; };

/* ---- sesli/yazılı onay + açma komutu ---- */
var prevS=window.JV_onSpeech;
window.JV_onSpeech=function(t,final){
  if(X.st==="confirm"&&document.getElementById("pXr").classList.contains("show")&&final){
    var x=tl(t).replace(/[.!?,]+$/g,"");
    if(/^(evet|doğru|tamam|onaylıyorum|aynen)/.test(x)){ confirmObj(); return true; }
    if(/^(hayır|yanlış|değil)/.test(x)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return true; }
  }
  return prevS?prevS(t,final):false;
};
function open(){ d.classList.add("show"); if(!X.img) msg("Fotoğraf seçin efendim."); }
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/^x[- ]?ray/.test(t)&&t.split(/\s+/).length<=5){
    if(/(kapat|bitir|çık)/.test(t)){ d.classList.remove("show"); return "X-ray modu kapatıldı."; }
    open(); return "X-ray modu açık. Bir fotoğraf seçin.";
  }
  if(X.st==="confirm"&&d.classList.contains("show")){
    if(/^(evet|doğru|tamam|onaylıyorum)/.test(t)){ confirmObj(); return "X-ray taraması başlıyor."; }
    if(/^(hayır|yanlış|değil)/.test(t)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return "Başka nesneyi öneriyorum."; }
  }
  return prevOff?prevOff(text):null;
};
(function(){ var chips=$("chips"); if(!chips||!chips.appendChild||chips===DUMMY) return; var b=document.createElement("button"); b.textContent="🩻 X-RAY"; b.onclick=open; chips.appendChild(b); })();
window.JV_xray={open:open,_X:X};
})();
