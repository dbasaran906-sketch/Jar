package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.app.SearchManager
import android.app.usage.UsageStatsManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/** Jarvis'in telefonda çalıştırabildiği araçlar. */
object Tools {

    fun httpGet(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Jarvis-Android")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    private fun need(a: JarvisActivity, vararg perms: String) {
        if (!a.ensurePerms(arrayOf(*perms))) {
            throw RuntimeException("Gerekli izin verilmedi. Telefon ayarlarından Jarvis'e izin ver.")
        }
    }

    fun run(a: JarvisActivity, name: String, args: JSONObject): String {
        return try {
            when (name) {
                "get_weather" -> weather(args.optString("city", ""))
                "open_app" -> openApp(a, args.optString("name"))
                "call_phone" -> callPhone(a, args.optString("target"))
                "send_whatsapp" -> whatsapp(a, args.optString("target"), args.optString("message"))
                "set_alarm" -> setAlarm(a, args.optInt("hour"), args.optInt("minute"), args.optString("label", "Jarvis"))
                "set_timer" -> setTimer(a, args.optInt("seconds"), args.optString("label", "Jarvis"))
                "check_update" -> Updater.checkText()
                "install_update" -> Updater.installLatest(a)
                "get_device_status" -> deviceStatus(a)
                "phone_action" -> phoneAction(a, args.optString("action"), args.optString("value"))
                "get_calendar" -> calendar(a, args.optInt("days", 3))
                "add_event" -> addEvent(a, args.optString("title"), args.optString("start"), args.optInt("duration_min", 60))
                "get_call_log" -> callLog(a, args.optInt("limit", 10))
                "get_sms" -> smsInbox(a, args.optInt("limit", 10))
                "send_sms" -> sendSms(a, args.optString("target"), args.optString("message"))
                "get_app_usage" -> appUsage(a, args.optInt("days", 1))
                "scan_nearby" -> Radar.summary(Radar.scan(a))
                "get_notifications" -> notifications(a, args.optInt("limit", 15), args.optString("app"))
                "screen_read" -> screenRead(a)
                "screen_click" -> screenClick(a, args.optString("text"))
                "screen_type" -> screenType(a, args.optString("text"))
                "screen_action" -> screenAction(a, args.optString("action"))
                "delete_event" -> deleteEvent(a, args.optString("title"))
                "move_event" -> moveEvent(a, args.optString("title"), args.optString("new_start"))
                else -> "Bilinmeyen araç: $name"
            }
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
    }

    // ---------- Hava durumu (Open-Meteo, anahtar gerekmez) ----------

    private fun codeText(c: Int): String = when (c) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        51, 53, 55, 56, 57 -> "Çisenti"
        61, 63, 65, 66, 67 -> "Yağmurlu"
        71, 73, 75, 77 -> "Karlı"
        80, 81, 82 -> "Sağanak yağışlı"
        85, 86 -> "Kar sağanağı"
        95, 96, 99 -> "Gök gürültülü fırtına"
        else -> "Bilinmiyor"
    }

    private fun weather(cityIn: String): String {
        val city = if (cityIn.isBlank()) "İstanbul" else cityIn
        val g = JSONObject(
            httpGet(
                "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(city, "UTF-8") + "&count=1&language=tr"
            )
        )
        val res = g.optJSONArray("results") ?: return "Şehir bulunamadı: $city"
        val p = res.getJSONObject(0)
        val lat = p.getDouble("latitude")
        val lon = p.getDouble("longitude")
        val place = p.optString("name", city)
        val w = JSONObject(
            httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
                    "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=auto&forecast_days=3"
            )
        )
        val cur = w.getJSONObject("current")
        val d = w.getJSONObject("daily")
        val days = JSONArray()
        val times = d.getJSONArray("time")
        val mx = d.getJSONArray("temperature_2m_max")
        val mn = d.getJSONArray("temperature_2m_min")
        val rain = d.getJSONArray("precipitation_probability_max")
        for (i in 0 until times.length()) {
            val o = JSONObject()
            o.put("tarih", times.getString(i))
            o.put("en_yuksek", mx.getDouble(i))
            o.put("en_dusuk", mn.getDouble(i))
            o.put("yagis_ihtimali_yuzde", rain.optInt(i))
            days.put(o)
        }
        val out = JSONObject()
        out.put("place", place)
        out.put("temp", cur.getDouble("temperature_2m"))
        out.put("feels", cur.getDouble("apparent_temperature"))
        out.put("humidity", cur.getInt("relative_humidity_2m"))
        out.put("wind_kmh", cur.getDouble("wind_speed_10m"))
        out.put("desc", codeText(cur.getInt("weather_code")))
        out.put("days", days)
        return out.toString()
    }

    // ---------- Uygulama aç ----------

    private fun openApp(a: Activity, name: String): String {
        if (name.isBlank()) return "Uygulama adı boş."
        val pm = a.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val loc = Locale("tr", "TR")
        val want = name.lowercase(loc)
        var bestPkg: String? = null
        var bestLabel = ""
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase(loc)
            if (l == want) {
                bestPkg = ri.activityInfo.packageName
                bestLabel = label
                break
            }
            if (bestPkg == null && (l.contains(want) || want.contains(l))) {
                bestPkg = ri.activityInfo.packageName
                bestLabel = label
            }
        }
        if (bestPkg == null) return "'$name' adında bir uygulama bulamadım."
        val li = pm.getLaunchIntentForPackage(bestPkg) ?: return "$bestLabel açılamıyor."
        a.runOnUiThread { a.startActivity(li) }
        return "$bestLabel açıldı."
    }

    // ---------- Rehber / arama / WhatsApp / SMS ----------

    private fun findNumber(a: JarvisActivity, q: String): String? {
        val digits = q.filter { it.isDigit() || it == '+' }
        if (q.count { it.isDigit() } >= 5) return digits
        need(a, Manifest.permission.READ_CONTACTS)
        val c = a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"),
            null
        )
        c?.use {
            if (it.moveToFirst()) return it.getString(1)
        }
        return null
    }

    private fun callPhone(a: JarvisActivity, target: String): String {
        val num = findNumber(a, target) ?: return "'$target' için rehberde numara bulamadım."
        val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
        a.runOnUiThread { a.startActivity(i) }
        return "Arama ekranı $target için açıldı, arama tuşuna basmak yeterli."
    }

    /** Rehberde q ile eşleşen farklı kişiler (ad, numara). Tam eşleşme varsa yalnız o. */
    private fun findContacts(a: JarvisActivity, q: String): List<Pair<String, String>> {
        if (q.count { it.isDigit() } >= 5) return listOf(Pair(q, q.filter { it.isDigit() || it == '+' }))
        need(a, Manifest.permission.READ_CONTACTS)
        val out = ArrayList<Pair<String, String>>()
        val c = a.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"),
            null
        )
        c?.use {
            while (it.moveToNext() && out.size < 40) {
                val n = it.getString(0) ?: continue
                val d = (it.getString(1) ?: "").filter { ch -> ch.isDigit() }
                if (d.length < 7) continue
                if (out.none { p -> p.second.filter { ch -> ch.isDigit() }.takeLast(10) == d.takeLast(10) }) out.add(Pair(n, it.getString(1) ?: d))
            }
        }
        val exact = out.filter { it.first.equals(q, true) }
        return if (exact.isNotEmpty()) exact.take(1) else out
    }

    private fun whatsapp(a: JarvisActivity, target: String, message: String): String {
        if (message.isBlank()) return "Mesaj metni boş, ne yazacağımı söyle."
        val found = findContacts(a, target)
        if (found.isEmpty()) return "'$target' için rehberde numara bulamadım."
        if (found.size > 1) {
            return "Birden fazla kişi eşleşti: " + found.take(8).joinToString(", ") { it.first } +
                ". Kullanıcıya hangisi olduğunu sor. Cevap gelince AYNI mesajı ('" + message.take(80) + "') o kişinin tam adıyla send_whatsapp ile gönder."
        }
        var d = found[0].second.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = "90" + d.substring(1)
        else if (d.length == 10) d = "90$d"
        val enc = Uri.encode(message)
        var opened = false
        for (pkg in arrayOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$d&text=$enc"))
                i.setPackage(pkg)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                a.startActivity(i)
                opened = true
                break
            } catch (e: Exception) {
            }
        }
        if (!opened) return "WhatsApp telefonda yüklü görünmüyor."
        val acc = JarvisAccess.inst
            ?: return "${found[0].first} sohbeti mesaj yazılı şekilde açıldı ama erişilebilirlik izni kapalı olduğu için gönderemedim. Gönder tuşuna basman gerekiyor (İzin merkezinden erişilebilirliği açarsan bundan sonra kendim göndereceğim)."
        var sent = false
        var tries = 0
        while (tries < 26 && !sent) {
            Thread.sleep(400)
            sent = try {
                acc.sendWhatsapp()
            } catch (e: Exception) {
                false
            }
            tries++
        }
        if (!sent) return "${found[0].first} sohbetini açtım ama Gönder tuşunu bulamadım, mesaj gönderilmedi. Elle basman gerekiyor."
        try {
            Thread.sleep(1200)
            val back = Intent(a, a.javaClass)
            back.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK)
            a.startActivity(back)
        } catch (e: Exception) {
        }
        return "Mesaj gönderildi: ${found[0].first}."
    }

    private fun sendSms(a: JarvisActivity, target: String, message: String): String {
        if (message.isBlank()) return "Mesaj boş."
        val num = findNumber(a, target) ?: return "'$target' için rehberde numara bulamadım."
        need(a, Manifest.permission.SEND_SMS)
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            a.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
        val parts = sm.divideMessage(message)
        sm.sendMultipartTextMessage(num, null, parts, null, null)
        return "SMS gönderildi: $target."
    }

    // ---------- Alarm / zamanlayıcı ----------

    private fun setAlarm(a: Activity, hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.runOnUiThread { a.startActivity(i) }
        return "Alarm %02d:%02d için kuruldu.".format(hour, minute)
    }

    private fun setTimer(a: Activity, seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.runOnUiThread { a.startActivity(i) }
        return "Zamanlayıcı $seconds saniye için kuruldu."
    }

    // ---------- Cihaz durumu ve sensörler ----------

    fun deviceStatus(a: Activity): String {
        val o = JSONObject()
        val bi = a.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (lvl >= 0 && sc > 0) o.put("pil_yuzde", lvl * 100 / sc)
            o.put("pil_sicakligi_c", bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0)
            val st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            o.put(
                "sarj_oluyor",
                st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            )
        }
        try {
            val sm = a.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            val light = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
            val mags = ArrayList<Double>()
            var gyroMax = 0.0
            var lux = -1.0
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    when (e.sensor.type) {
                        Sensor.TYPE_ACCELEROMETER -> {
                            val m = sqrt(
                                (e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()
                            )
                            synchronized(mags) { mags.add(m) }
                        }
                        Sensor.TYPE_GYROSCOPE -> {
                            val g = sqrt(
                                (e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble()
                            )
                            if (g > gyroMax) gyroMax = g
                        }
                        Sensor.TYPE_LIGHT -> lux = e.values[0].toDouble()
                    }
                }

                override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
            }
            if (acc != null) sm.registerListener(l, acc, SensorManager.SENSOR_DELAY_UI)
            if (gyro != null) sm.registerListener(l, gyro, SensorManager.SENSOR_DELAY_UI)
            if (light != null) sm.registerListener(l, light, SensorManager.SENSOR_DELAY_UI)
            Thread.sleep(1200)
            sm.unregisterListener(l)
            val list = synchronized(mags) { ArrayList(mags) }
            if (list.size > 3) {
                val mean = list.average()
                var v = 0.0
                for (x in list) v += (x - mean) * (x - mean)
                v /= list.size
                o.put(
                    "hareket",
                    if (v < 0.05 && gyroMax < 0.15) "hareketsiz" else if (v < 1.0) "hafif hareket" else "hareketli"
                )
            }
            if (lux >= 0) o.put("isik_lux", Math.round(lux))
            if (gyro != null) o.put("donme_hizi_rad_s", Math.round(gyroMax * 100) / 100.0)
        } catch (e: Exception) {
            // sensör okunamazsa geç
        }
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            o.put("bos_depolama_gb", Math.round(st.availableBytes / 1.0e8) / 10.0)
        } catch (e: Exception) {
            // geç
        }
        return o.toString()
    }

    // ---------- Telefon eylemleri ----------

    private fun phoneAction(a: JarvisActivity, action: String, value: String): String {
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (action) {
            "flashlight_on", "flashlight_off" -> {
                val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                var id: String? = null
                for (x in cm.cameraIdList) {
                    if (cm.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                        id = x
                        break
                    }
                }
                if (id == null) return "Bu telefonda flaş yok."
                cm.setTorchMode(id, action == "flashlight_on")
                return if (action == "flashlight_on") "Fener açıldı." else "Fener kapatıldı."
            }
            "volume_up" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                return "Ses yükseltildi."
            }
            "volume_down" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                return "Ses azaltıldı."
            }
            "volume_mute" -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                return "Ses kapatıldı."
            }
            "volume_set" -> {
                val pct = (value.filter { it.isDigit() }.toIntOrNull() ?: 50).coerceIn(0, 100)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * pct / 100, AudioManager.FLAG_SHOW_UI)
                return "Ses yüzde $pct yapıldı."
            }
            "media_play_pause", "media_next", "media_previous" -> {
                val code = when (action) {
                    "media_next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "media_previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                return "Medya komutu gönderildi."
            }
            "open_settings" -> {
                val act = when (value.lowercase(Locale.ROOT)) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display", "ekran", "parlaklik" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound", "ses" -> Settings.ACTION_SOUND_SETTINGS
                    "location", "konum" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "airplane", "ucak" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                    "apps", "uygulamalar" -> Settings.ACTION_APPLICATION_SETTINGS
                    "battery", "pil" -> Intent.ACTION_POWER_USAGE_SUMMARY
                    "nfc" -> Settings.ACTION_NFC_SETTINGS
                    "security", "kilit", "guvenlik" -> Settings.ACTION_SECURITY_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                a.runOnUiThread { a.startActivity(Intent(act)) }
                return "Ayarlar ekranı açıldı ($value). Android bu ayarı uygulamaların doğrudan açıp kapatmasına izin vermiyor, düğmeye sen basmalısın."
            }
            "open_url" -> {
                var u = value.trim()
                if (!u.startsWith("http")) u = "https://$u"
                a.runOnUiThread { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                return "Bağlantı açıldı."
            }
            "navigate" -> {
                val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(value) + "&mode=d"))
                    .setPackage("com.google.android.apps.maps")
                val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(value)))
                val useNav = nav.resolveActivity(a.packageManager) != null
                a.runOnUiThread {
                    try { a.startActivity(if (useNav) nav else geo) } catch (e: Exception) {}
                }
                return if (useNav) "Navigasyon '$value' için başlatıldı (güncel trafik haritada görünür)." else "Harita '$value' için açıldı."
            }
            "web_search" -> {
                val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, value)
                a.runOnUiThread { a.startActivity(i) }
                return "Arama açıldı."
            }
            "open_camera" -> {
                a.runOnUiThread { a.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
                return "Kamera açıldı."
            }
            else -> return "Bilinmeyen eylem: $action"
        }
    }

    // ---------- Takvim ----------

    private fun calendar(a: JarvisActivity, days: Int): String {
        need(a, Manifest.permission.READ_CALENDAR)
        val now = System.currentTimeMillis()
        val end = now + days.coerceIn(1, 60) * 86400000L
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now)
        ContentUris.appendId(b, end)
        val c = a.contentResolver.query(
            b.build(),
            arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION
            ),
            null,
            null,
            CalendarContract.Instances.BEGIN + " ASC"
        )
        val arr = JSONArray()
        val f = SimpleDateFormat("d MMM EEE HH:mm", Locale("tr", "TR"))
        c?.use {
            while (it.moveToNext() && arr.length() < 30) {
                val o = JSONObject()
                o.put("baslik", it.getString(0) ?: "")
                o.put("baslangic", f.format(Date(it.getLong(1))))
                o.put("bitis", f.format(Date(it.getLong(2))))
                val loc = it.getString(3)
                if (!loc.isNullOrBlank()) o.put("yer", loc)
                arr.put(o)
            }
        }
        if (arr.length() == 0) return "Önümüzdeki $days gün için takvimde etkinlik yok."
        return arr.toString()
    }

    private fun addEvent(a: JarvisActivity, title: String, start: String, durMin: Int): String {
        val st = LocalDateTime.parse(start.trim()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val i = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, st)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, st + durMin * 60000L)
        a.runOnUiThread { a.startActivity(i) }
        return "Takvim etkinliği hazır şekilde açıldı, kullanıcının kaydet tuşuna basması gerekiyor."
    }

    // ---------- Arama kaydı / SMS ----------

    private fun callLog(a: JarvisActivity, limit: Int): String {
        need(a, Manifest.permission.READ_CALL_LOG)
        val c = a.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
            ),
            null,
            null,
            CallLog.Calls.DATE + " DESC"
        )
        val arr = JSONArray()
        val f = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))
        c?.use {
            while (it.moveToNext() && arr.length() < limit.coerceIn(1, 40)) {
                val o = JSONObject()
                o.put("kisi", it.getString(1) ?: it.getString(0) ?: "")
                o.put(
                    "tur",
                    when (it.getInt(2)) {
                        CallLog.Calls.INCOMING_TYPE -> "gelen"
                        CallLog.Calls.OUTGOING_TYPE -> "giden"
                        CallLog.Calls.MISSED_TYPE -> "cevapsız"
                        else -> "diğer"
                    }
                )
                o.put("zaman", f.format(Date(it.getLong(3))))
                o.put("sure_sn", it.getInt(4))
                arr.put(o)
            }
        }
        return if (arr.length() == 0) "Arama kaydı yok." else arr.toString()
    }

    private fun smsInbox(a: JarvisActivity, limit: Int): String {
        need(a, Manifest.permission.READ_SMS)
        val c = a.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body", "date"),
            null,
            null,
            "date DESC"
        )
        val arr = JSONArray()
        val f = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))
        c?.use {
            while (it.moveToNext() && arr.length() < limit.coerceIn(1, 30)) {
                val o = JSONObject()
                o.put("gonderen", it.getString(0) ?: "")
                o.put("mesaj", (it.getString(1) ?: "").take(220))
                o.put("zaman", f.format(Date(it.getLong(2))))
                arr.put(o)
            }
        }
        return if (arr.length() == 0) "Gelen SMS yok." else arr.toString()
    }

    // ---------- Ekran kontrolü (erişilebilirlik) ----------

    private const val NO_ACCESS =
        "Erişilebilirlik izni kapalı. Açılan ekranda 'Yüklü uygulamalar' veya 'İndirilen uygulamalar' bölümünden Jarvis'i bulup aç. " +
            "Android 13 ve üstünde izin gri ise: Ayarlar > Uygulamalar > Jarvis > sağ üst üç nokta > 'Kısıtlanmış ayarlara izin ver' de, sonra tekrar aç."

    private fun access(a: JarvisActivity): JarvisAccess? {
        val s = JarvisAccess.inst
        if (s == null) {
            a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        return s
    }

    private fun screenRead(a: JarvisActivity): String {
        val s = access(a) ?: return NO_ACCESS
        return s.readScreen()
    }

    private fun screenClick(a: JarvisActivity, text: String): String {
        val s = access(a) ?: return NO_ACCESS
        if (text.isBlank()) return "Tıklanacak yazı boş."
        val ok = s.clickText(text)
        Thread.sleep(700)
        return if (ok) "Tıklandı: $text" else "'$text' ekranda bulunamadı. screen_read ile ekranı oku."
    }

    private fun screenType(a: JarvisActivity, text: String): String {
        val s = access(a) ?: return NO_ACCESS
        val ok = s.typeText(text)
        return if (ok) "Yazıldı." else "Yazı alanı bulunamadı. Önce bir yazı alanına dokunmak gerekebilir."
    }

    private fun screenAction(a: JarvisActivity, action: String): String {
        val s = access(a) ?: return NO_ACCESS
        val ok = when (action) {
            "scroll_down" -> s.scroll(true)
            "scroll_up" -> s.scroll(false)
            "enter" -> s.imeEnter()
            else -> s.globalAct(action)
        }
        Thread.sleep(800)
        return if (ok) "Tamam: $action" else "Bu eylem yapılamadı: $action"
    }

    // ---------- Takvim düzenleme ----------

    private fun findInstance(a: JarvisActivity, title: String): LongArray? {
        need(a, Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now - 86400000L)
        ContentUris.appendId(b, now + 120 * 86400000L)
        val c = a.contentResolver.query(
            b.build(),
            arrayOf(
                CalendarContract.Instances.EVENT_ID,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END
            ),
            CalendarContract.Instances.TITLE + " LIKE ?",
            arrayOf("%$title%"),
            CalendarContract.Instances.BEGIN + " ASC"
        )
        c?.use {
            if (it.moveToFirst()) return longArrayOf(it.getLong(0), it.getLong(1), it.getLong(2))
        }
        return null
    }

    private fun deleteEvent(a: JarvisActivity, title: String): String {
        val r = findInstance(a, title) ?: return "Takvimde '$title' adında yaklaşan etkinlik bulunamadı."
        val n = a.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, r[0]), null, null)
        return if (n > 0) "Etkinlik silindi: $title" else "Etkinlik silinemedi."
    }

    private fun moveEvent(a: JarvisActivity, title: String, newStart: String): String {
        val r = findInstance(a, title) ?: return "Takvimde '$title' adında yaklaşan etkinlik bulunamadı."
        val st = LocalDateTime.parse(newStart.trim()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val dur = r[2] - r[1]
        val v = ContentValues()
        v.put(CalendarContract.Events.DTSTART, st)
        v.put(CalendarContract.Events.DTEND, st + dur)
        val n = a.contentResolver.update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, r[0]), v, null, null)
        return if (n > 0) "Etkinlik yeni zamana taşındı." else "Etkinlik taşınamadı (tekrarlayan etkinlik olabilir)."
    }

    // ---------- Bildirimler (WhatsApp, SMS vb.) ----------

    private fun notifications(a: JarvisActivity, limit: Int, app: String): String {
        if (!NotificationManagerCompat.getEnabledListenerPackages(a).contains(a.packageName)) {
            a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            return "Bildirim erişimi kapalı. Açılan ekranda Jarvis'i bulup izni aç. İzinden sonra gelen bildirimleri (WhatsApp, SMS vb.) kaydedip okuyabilirim, eskileri okuyamam."
        }
        val arr = NotifStore.list(a, limit.coerceIn(1, 60), app)
        return if (arr.length() == 0) "Kayıtlı bildirim yok (izin yeni açıldıysa yeni bildirimleri bekle)." else arr.toString()
    }

    // ---------- Uygulama kullanımı (alışkanlık analizi) ----------

    private fun appUsage(a: JarvisActivity, days: Int): String {
        val ops = a.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), a.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), a.packageName)
        }
        if (mode != AppOpsManager.MODE_ALLOWED) {
            a.runOnUiThread { a.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            return "Kullanım erişimi izni gerekiyor. Açılan ekranda Jarvis'i bulup izni aç, sonra tekrar iste."
        }
        val usm = a.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - days.coerceIn(1, 30) * 86400000L
        val map = usm.queryAndAggregateUsageStats(begin, end)
        val pm = a.packageManager
        val rows = map.values.filter { it.totalTimeInForeground > 60000 }
            .sortedByDescending { it.totalTimeInForeground }.take(12)
        val arr = JSONArray()
        for (u in rows) {
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(u.packageName, 0)).toString()
            } catch (e: Exception) {
                u.packageName
            }
            val o = JSONObject()
            o.put("uygulama", label)
            o.put("dakika", u.totalTimeInForeground / 60000)
            arr.put(o)
        }
        return if (arr.length() == 0) "Kullanım verisi bulunamadı." else arr.toString()
    }
}
