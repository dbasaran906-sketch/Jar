package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.content.BroadcastReceiver
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/**
 * Arka plan nöbeti: pil, ısı, depolama, internet, zamanlı hatırlatmalar.
 * Ön plan servisi olarak çalışır; uyarıları hem bildirim hem SESLİ (Türkçe TTS) verir.
 */
class WatchService : Service() {
    companion object {
        @Volatile
        var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var lastBat = 101
    private var storWarned = false
    private var chargeAnnounced = false
    private var netDown = 0
    private var netAnnounced = false
    private val firedToday = HashSet<String>()
    private var lastDay = -1
    private val lastSaid = HashMap<String, Long>()
    private val lawLast = HashMap<String, Long>()
    private var lastSsid: String? = null
    private val powerRecv = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val on = i?.action == Intent.ACTION_POWER_CONNECTED
            fireLaws { t -> t.optString("type") == "charge" && t.optBoolean("on", true) == on }
        }
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingSpeech = ArrayList<String>()
    private var focusReq: AudioFocusRequest? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                check()
            } catch (e: Exception) {
            }
            h.postDelayed(this, 60_000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("jarvis_watch", "Jarvis izleme", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel("jarvis_alert", "Jarvis uyarıları", NotificationManager.IMPORTANCE_HIGH))
        }
        try {
            val f = IntentFilter()
            f.addAction(Intent.ACTION_POWER_CONNECTED)
            f.addAction(Intent.ACTION_POWER_DISCONNECTED)
            registerReceiver(powerRecv, f)
        } catch (e: Exception) {
        }
        try {
            tts = TextToSpeech(applicationContext) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("tr", "TR"))
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    tts?.setAudioAttributes(attrs())
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) {
                            release()
                        }

                        @Deprecated("eski imza")
                        override fun onError(id: String?) {
                            release()
                        }
                    })
                    if (ttsReady) {
                        val l = ArrayList(pendingSpeech)
                        pendingSpeech.clear()
                        for (t in l) speakNow(t)
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun attrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANT)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private fun release() {
        try {
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focusReq?.let { a.abandonAudioFocusRequest(it) }
        } catch (e: Exception) {
        }
    }

    private fun speakNow(text: String) {
        try {
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val fr = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs()).build()
            focusReq = fr
            a.requestAudioFocus(fr)
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "w" + System.currentTimeMillis())
        } catch (e: Exception) {
        }
    }

    private fun inQuiet(c: JSONObject): Boolean {
        val qs = c.optInt("qs", 23)
        val qe = c.optInt("qe", 7)
        if (qs == qe) return false
        val hh = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (qs > qe) (hh >= qs || hh < qe) else (hh in qs until qe)
    }

    /** Sesli uyarı. force=true: ayarlara bakmadan konuşur (test). */
    private fun say(key: String, text: String, force: Boolean = false) {
        if (!force) {
            val c = cfg()
            if (!c.optBoolean("voice", true)) return
            if (inQuiet(c)) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!c.optBoolean("off", true) && !pm.isInteractive) return
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (a.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            val now = System.currentTimeMillis()
            if (now - (lastSaid[key] ?: 0L) < 10 * 60_000L) return
            lastSaid[key] = now
        }
        if (!ttsReady) {
            if (pendingSpeech.size < 5) pendingSpeech.add(text)
            return
        }
        speakNow(text)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "jarvis_watch") else Notification.Builder(this)
        n.setContentTitle("Jarvis nöbette")
            .setContentText("Pil, sistem ve hatırlatmalar izleniyor")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(7001, n.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else startForeground(7001, n.build())
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        h.removeCallbacks(tick)
        h.post(tick)
        intent?.getStringExtra("speak")?.let { say("test", it, true) }
        intent?.getStringExtra("msg")?.let { say("m" + System.nanoTime(), it) }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        try {
            lm?.removeUpdates(geoListener)
        } catch (e: Exception) {
        }
        h.removeCallbacks(tick)
        try {
            unregisterReceiver(powerRecv)
        } catch (e: Exception) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        release()
        super.onDestroy()
    }

    private fun cfg(): JSONObject = try {
        JSONObject(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("watch_cfg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun alert(id: Int, title: String, text: String, ask: String? = null, speak: Boolean = true, spoken: String? = null) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (!ask.isNullOrEmpty()) i.putExtra("ask", ask)
        val pi = PendingIntent.getActivity(this, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jarvis_alert") else Notification.Builder(this)
        b.setContentTitle(title).setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pi).setAutoCancel(true)
        if (!ask.isNullOrEmpty()) {
            b.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Evet, uygula", pi
                ).build()
            )
        }
        nm.notify(id, b.build())
        if (speak) say("n$id", spoken ?: text)
    }

    private fun lawsArr(): JSONArray = try {
        JSONArray(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("laws", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    private fun fireLaws(match: (JSONObject) -> Boolean) {
        val arr = lawsArr()
        for (i in 0 until arr.length()) {
            val l = arr.optJSONObject(i) ?: continue
            val t = l.optJSONObject("trigger") ?: continue
            if (match(t)) fireLaw(l)
        }
    }

    private val lawQ = java.util.ArrayDeque<JSONObject>()
    private var lawBusy = false
    private var notifSeq = 0

    /** Yasaları sırayla (3,5 sn arayla) çalıştırır; aynı anda tetiklenenler birbirini ezmez. */
    private fun fireLaw(l: JSONObject) {
        val name = l.optString("name")
        val now = System.currentTimeMillis()
        if (now - (lawLast[name] ?: 0L) < 120_000L) return
        lawLast[name] = now
        if (lawQ.size < 12) lawQ.add(l)
        pumpLaws()
    }

    private fun pumpLaws() {
        if (lawBusy) return
        val l = lawQ.poll() ?: return
        lawBusy = true
        try {
            runLawNow(l)
        } catch (e: Exception) {
        }
        h.postDelayed({
            lawBusy = false
            pumpLaws()
        }, 3500)
    }

    private fun runLawNow(l: JSONObject) {
        val name = l.optString("name")
        val steps = l.optJSONArray("steps") ?: return
        val done = ArrayList<String>()
        val left = ArrayList<String>()
        for (i in 0 until steps.length()) {
            val s = steps.optString(i)
            val r = LawSteps.run(this, s)
            if (r != null) done.add(r) else left.add(s)
        }
        notifSeq = (notifSeq + 1) % 90
        if (left.isNotEmpty() && launchLaw(name, left)) {
            // Kalan adımları Jarvis ekranı uyandırıp kendisi yapıyor; kullanıcıya sorulmaz
            alert(7300 + notifSeq, "Yasa: $name", "'" + name + "' yasası uygulanıyor" + (if (done.isNotEmpty()) " (" + done.joinToString(", ") + ")" else "") + ".", null, false, null)
            return
        }
        var msg = "'" + name + "' yasası çalıştı."
        if (done.isNotEmpty()) msg += " Yapılanlar: " + done.joinToString(", ") + "."
        if (left.isNotEmpty()) msg += " Şunlar için dokun (arka planda yapılamaz; 'Diğer uygulamaların üzerinde göster' iznini verirsen kendim yaparım): " + left.joinToString(", ") + "."
        val spoken = if (left.isEmpty()) "Efendim, $name yasası uygulandı." else "Efendim, $name yasası uygulandı, bazı adımlar için bildirime dokunun."
        alert(7300 + notifSeq, "Yasa: $name", msg, if (left.isNotEmpty()) "$name yasasını aktif et" else null, false, null)
        say("law" + System.nanoTime(), spoken)
    }

    /** Ekranı uyandırıp Jarvis'i öne getirir; kalan adımları orada kendisi çalıştırır. Başarısızsa false. */
    private fun launchLaw(name: String, steps: List<String>): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(this)) return false
            getSharedPreferences("jarvis_kv", MODE_PRIVATE).edit().putString(
                "pending_law",
                JSONObject().put("name", name).put("steps", JSONArray(steps)).put("ts", System.currentTimeMillis()).toString()
            ).apply()
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                @Suppress("DEPRECATION")
                val wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                    "jarvis:law"
                )
                wl.acquire(20_000L)
            } catch (e: Exception) {
            }
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("law", name)
            startActivity(i)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    // ---- Konum tetikleyici (coğrafi çit benzeri; Play Hizmetleri gerekmez) ----
    private var lm: LocationManager? = null
    private var geoOn = false
    private val geoIn = HashMap<String, Boolean>()
    private val geoListener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            try {
                geoCheck(l)
            } catch (e: Exception) {
            }
        }

        @Deprecated("eski imza")
        override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {
        }

        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    private fun hasGeoLaw(): Boolean {
        val arr = lawsArr()
        for (i in 0 until arr.length()) {
            if (arr.optJSONObject(i)?.optJSONObject("trigger")?.optString("type") == "geo") return true
        }
        return false
    }

    private fun ensureGeo() {
        val need = hasGeoLaw()
        if (need && !geoOn) {
            try {
                val m = getSystemService(Context.LOCATION_SERVICE) as LocationManager
                lm = m
                if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 45_000L, 40f, geoListener, Looper.getMainLooper())
                    geoOn = true
                }
                if (m.isProviderEnabled(LocationManager.PASSIVE_PROVIDER)) {
                    m.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 45_000L, 40f, geoListener, Looper.getMainLooper())
                    geoOn = true
                }
            } catch (e: SecurityException) {
            } catch (e: Exception) {
            }
        } else if (!need && geoOn) {
            try {
                lm?.removeUpdates(geoListener)
            } catch (e: Exception) {
            }
            geoOn = false
            geoIn.clear()
        }
    }

    private fun geoCheck(loc: Location) {
        if (loc.hasAccuracy() && loc.accuracy > 400f) return
        val places = try {
            JSONObject(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("places", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val arr = lawsArr()
        for (i in 0 until arr.length()) {
            val l = arr.optJSONObject(i) ?: continue
            val t = l.optJSONObject("trigger") ?: continue
            if (t.optString("type") != "geo") continue
            val p = places.optJSONObject(t.optString("place").lowercase(Locale("tr", "TR"))) ?: continue
            val r = p.optDouble("r", 200.0).toFloat()
            val res = FloatArray(1)
            Location.distanceBetween(loc.latitude, loc.longitude, p.optDouble("lat"), p.optDouble("lon"), res)
            val inside = res[0] <= r
            val key = l.optString("name")
            val prev = geoIn[key]
            geoIn[key] = inside
            if (prev != null && prev != inside && t.optBoolean("on", true) == inside) fireLaw(l)
        }
    }

    private fun curSsid(): String {
        return try {
            @Suppress("DEPRECATION")
            val s = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo?.ssid ?: ""
            val c = s.replace("\"", "")
            if (c.contains("unknown ssid")) "" else c
        } catch (e: Exception) {
            ""
        }
    }

    private fun online(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val nc = cm.getNetworkCapabilities(cm.activeNetwork)
            nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    private fun check() {
        val c = cfg()
        val low = c.optInt("low", 20)
        val prevBat = lastBat
        ensureGeo()
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val temp = (st?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (pct in 0..100) {
            if (!charging && pct <= low && lastBat > low) {
                alert(7101, "Pil %$pct", "Efendim pil yüzde $pct. Şarja takmanızı öneririm.", "pil durumunu analiz et ve tasarruf öner")
            }
            if (!charging && pct <= 10 && lastBat > 10) {
                alert(7102, "Pil kritik %$pct", "Efendim pil kritik seviyede, yüzde $pct. Hemen şarj edin.")
            }
            if (temp >= 42.0 && !charging) {
                alert(7103, "Telefon ısındı", "Telefon ısındı efendim, sıcaklık %.0f derece. Ağır uygulamaları kapatmanızı öneririm.".format(temp))
            }
            if (charging && pct >= 100 && !chargeAnnounced) {
                chargeAnnounced = true
                alert(7105, "Pil doldu", "Efendim pil yüzde yüz doldu, şarjı çıkarabilirsiniz.")
            }
            if (!charging) chargeAnnounced = false
            lastBat = pct
            if (!charging) fireLaws { t -> t.optString("type") == "battery" && pct <= t.optInt("below", 15) && prevBat > t.optInt("below", 15) }
        }
        val fs = StatFs(Environment.getDataDirectory().path)
        val freePct = (fs.availableBytes * 100 / fs.totalBytes).toInt()
        if (freePct < 8 && !storWarned) {
            storWarned = true
            alert(7104, "Depolama dolu", "Efendim depolama alanı dolmak üzere, yüzde $freePct boş kaldı.", "depolamayı analiz et")
        }
        if (freePct > 12) storWarned = false

        if (!online()) {
            netDown++
            if (netDown >= 2 && !netAnnounced) {
                netAnnounced = true
                alert(7106, "İnternet yok", "Efendim internet bağlantısı koptu. Çevrimdışı komutlar çalışmaya devam eder.")
            }
        } else {
            if (netAnnounced) say("netback", "İnternet bağlantısı geri geldi efendim.")
            netDown = 0
            netAnnounced = false
        }

        val now = Calendar.getInstance()
        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != lastDay) {
            lastDay = day
            firedToday.clear()
        }
        val today = "%04d-%02d-%02d".format(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val hh = now.get(Calendar.HOUR_OF_DAY)
        val mm = now.get(Calendar.MINUTE)
        // Yasa tetikleyicileri: saat ve Wi-Fi
        val dow = now.get(Calendar.DAY_OF_WEEK) - 1
        val nowM2 = hh * 60 + mm
        val ssid = curSsid()
        val prevSsid = lastSsid
        lastSsid = ssid
        val laws = lawsArr()
        for (i in 0 until laws.length()) {
            val l = laws.optJSONObject(i) ?: continue
            val t = l.optJSONObject("trigger") ?: continue
            when (t.optString("type")) {
                "time" -> {
                    val days = t.optJSONArray("days")
                    var okDay = days == null || days.length() == 0
                    if (!okDay) for (k in 0 until days!!.length()) if (days.optInt(k) == dow) okDay = true
                    val tm = t.optInt("h", -1) * 60 + t.optInt("m", 0)
                    val key = "law:" + l.optString("name") + ":" + day
                    if (okDay && t.optInt("h", -1) >= 0 && nowM2 >= tm && nowM2 - tm <= 2 && key !in firedToday) {
                        firedToday.add(key)
                        fireLaw(l)
                    }
                }
                "wifi" -> {
                    if (prevSsid != null && prevSsid != ssid) {
                        val want = t.optString("ssid")
                        val on = t.optBoolean("on", true)
                        if (on && ssid.equals(want, true)) fireLaw(l)
                        if (!on && prevSsid.equals(want, true)) fireLaw(l)
                    }
                }
            }
        }
        val rules: JSONArray = c.optJSONArray("rules") ?: return
        for (i in 0 until rules.length()) {
            val r = rules.optJSONObject(i) ?: continue
            val d = r.optString("date", "")
            if (d.isNotEmpty() && d != today) continue
            val key = r.optString("id") + ":" + day
            val rm = r.optInt("h", -1) * 60 + r.optInt("m", 0)
            val nowM = hh * 60 + mm
            if (r.optInt("h", -1) >= 0 && nowM >= rm && nowM - rm <= 2 && key !in firedToday) {
                firedToday.add(key)
                alert(7200 + (i % 90), "Jarvis", r.optString("text"), r.optString("ask", ""))
            }
        }
    }
}
