package com.jarvis.app

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gelen bildirimleri (WhatsApp, SMS vb.) cihazda kaydeder. İzin kullanıcı tarafından açılır. */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
            val e = n.extras
            val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return
            NotifStore.add(this, sbn.packageName, title, text, sbn.postTime)
            speakIfWanted(sbn.packageName, title, text, sbn.postTime)
        } catch (e: Exception) {
            // yok say
        }
    }

    private var lastKey = ""
    private var lastAt = 0L

    /** Otonom mod açıkken, seçili kişilerden gelen mesajı sesli okutur. */
    private fun speakIfWanted(pkg: String, title: String, text: String, ts: Long) {
        if (!WatchService.running) return
        if (title.isEmpty() || text.isEmpty()) return
        val isMsg = pkg.startsWith("com.whatsapp") || pkg == "org.telegram.messenger" ||
            pkg.contains("messaging") || pkg.contains("mms") || pkg.contains("sms")
        if (!isMsg) return
        val tr = java.util.Locale("tr", "TR")
        val c = try {
            JSONObject(getSharedPreferences("jarvis_kv", MODE_PRIVATE).getString("msg_cfg", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        if (!c.optBoolean("on", false)) return
        if (title.equals("WhatsApp", true) || Regex("^\\d+ (yeni )?(mesaj|message).*", RegexOption.IGNORE_CASE).matches(text)) return
        var ok = c.optBoolean("all", false)
        val names = c.optJSONArray("names")
        if (!ok && names != null) {
            val tl = title.lowercase(tr)
            for (i in 0 until names.length()) {
                val n = names.optString(i).lowercase(tr).trim()
                if (n.isNotEmpty() && tl.contains(n)) ok = true
            }
        }
        if (!ok) return
        val key = pkg + "|" + title + "|" + text
        if (key == lastKey && ts - lastAt < 15_000L) return
        lastKey = key
        lastAt = ts
        val i = Intent(this, WatchService::class.java).putExtra("msg", title + " yazdı: " + text.take(180))
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}

object NotifStore {
    private const val FILE = "notifs.json"

    @Synchronized
    fun add(ctx: Context, pkg: String, title: String, text: String, time: Long) {
        val f = File(ctx.filesDir, FILE)
        val arr = try {
            if (f.exists()) JSONArray(f.readText()) else JSONArray()
        } catch (e: Exception) {
            JSONArray()
        }
        val o = JSONObject()
        o.put("p", pkg)
        o.put("t", title.take(80))
        o.put("x", text.take(300))
        o.put("ts", time)
        arr.put(o)
        val keep = JSONArray()
        val start = maxOf(0, arr.length() - 300)
        for (i in start until arr.length()) keep.put(arr.get(i))
        f.writeText(keep.toString())
    }

    @Synchronized
    fun list(ctx: Context, limit: Int, app: String): JSONArray {
        val f = File(ctx.filesDir, FILE)
        val src = try {
            if (f.exists()) JSONArray(f.readText()) else JSONArray()
        } catch (e: Exception) {
            JSONArray()
        }
        val pm = ctx.packageManager
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))
        val q = app.lowercase(Locale("tr", "TR"))
        val out = JSONArray()
        var i = src.length() - 1
        while (i >= 0 && out.length() < limit) {
            val o = src.getJSONObject(i)
            val pkg = o.getString("p")
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            if (q.isEmpty() || label.lowercase(Locale("tr", "TR")).contains(q) || pkg.lowercase(Locale.ROOT).contains(q)) {
                val r = JSONObject()
                r.put("uygulama", label)
                r.put("baslik", o.getString("t"))
                r.put("metin", o.getString("x"))
                r.put("zaman", fmt.format(Date(o.getLong("ts"))))
                out.put(r)
            }
            i--
        }
        return out
    }
}
