package com.jarvis.app

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.WindowManager

/**
 * "Hey Google" benzeri ekran kenarı ışıması. Sistem katmanı (overlay) olarak çizilir:
 * altındaki uygulama olduğu gibi görünür, dokunmayı engellemez, ekran değişmez.
 * Yalnızca bir View'ın saydamlığı animasyonlanır (GPU'da, çok hafif).
 */
object EdgeGlow {

    private var view: GlowView? = null
    private var wm: WindowManager? = null

    private class GlowView(ctx: Context) : View(ctx) {
        private val p = Paint()
        var colorMain: Int = Color.parseColor("#2BB5FF")
        private var anim: ObjectAnimator? = null

        init { setLayerType(LAYER_TYPE_HARDWARE, null) }

        fun setMode(mode: String) {
            colorMain = when (mode) {
                "thinking" -> Color.parseColor("#FF8A1F")
                "speaking" -> Color.parseColor("#7CE0FF")
                else -> Color.parseColor("#2BB5FF")
            }
            val dur = when (mode) {
                "speaking" -> 800L
                "thinking" -> 1300L
                else -> 2200L
            }
            anim?.cancel()
            alpha = 0.5f
            anim = ObjectAnimator.ofFloat(this, "alpha", 0.45f, 1f).apply {
                duration = dur
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
                start()
            }
            invalidate()
        }

        fun stop() { anim?.cancel(); anim = null }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val t = resources.displayMetrics.density * 34f
            val a = Color.argb(230, Color.red(colorMain), Color.green(colorMain), Color.blue(colorMain))
            val z = Color.argb(0, Color.red(colorMain), Color.green(colorMain), Color.blue(colorMain))
            p.shader = LinearGradient(0f, 0f, 0f, t, a, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, t, p)
            p.shader = LinearGradient(0f, h, 0f, h - t, a, z, Shader.TileMode.CLAMP); c.drawRect(0f, h - t, w, h, p)
            p.shader = LinearGradient(0f, 0f, t, 0f, a, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, t, h, p)
            p.shader = LinearGradient(w, 0f, w - t, 0f, a, z, Shader.TileMode.CLAMP); c.drawRect(w - t, 0f, w, h, p)
        }
    }

    /** Ana iş parçacığında çağrılmalı. İzin yoksa false döner. */
    fun show(ctx: Context, mode: String): Boolean {
        val app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(app)) return false
        try {
            if (view == null) {
                val m = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                val v = GlowView(app)
                m.addView(v, lp)
                wm = m
                view = v
            }
            view?.setMode(mode)
            return true
        } catch (e: Exception) {
            view = null
            return false
        }
    }

    fun hide() {
        try {
            view?.stop()
            if (view != null) wm?.removeViewImmediate(view)
        } catch (e: Exception) {
        }
        view = null
    }
}
