package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/**
 * Jarvis'i "Dijital asistan uygulaması" listesine sokan servisler.
 * Güç/ana ekran tuşuna uzun basınca sistem oturumu açar, oturum da mevcut ses balonunu (VoiceActivity) başlatır.
 * Arka planda mikrofon dinlemez; sadece tuş basışında çalışır.
 */
class JarvisVoiceService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, VoiceActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            try { startAssistantActivity(i) } catch (e2: Exception) { /* sessiz geç */ }
        }
        hide()
    }
}

/** Asistan listesinde görünmek için gerekli boş tanıyıcı; gerçek ses tanıma Google'ın servisiyle yapılır. */
class JarvisRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { }
    }
    override fun onCancel(listener: RecognitionService.Callback?) {}
    override fun onStopListening(listener: RecognitionService.Callback?) {}
}
