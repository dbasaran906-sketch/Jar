package com.jarvis.app

import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout

/** Asistan/bildirim/widget ile açılan ses modu: balon yok, ekran kenarında ışıma. 5 sn sessizlikte kapanır. */
class VoiceActivity : JarvisActivity() {

    override val voiceMode: Boolean = true

    // Dokunma engellenmediği için takılı kalırsa 90 sn sonra kendini kapatır
    private val bye = android.os.Handler(android.os.Looper.getMainLooper())
    private val byeRun = Runnable { finish() }
    private fun armBye() { bye.removeCallbacks(byeRun); bye.postDelayed(byeRun, 90000L) }

    override fun onDestroy() {
        bye.removeCallbacks(byeRun)
        EdgeGlow.hide()
        super.onDestroy()
    }

    override fun layoutWeb() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // Küçük, saydam, dokunmayı engellemeyen alt pencere (sadece durum yazısı); ekran kenarı ışığı EdgeGlow ile çizilir
        val d = resources.displayMetrics
        window.setLayout((d.widthPixels * 0.94f).toInt(), (d.density * 110f).toInt())
        window.setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        val lp = window.attributes
        lp.y = (d.density * 40f).toInt()
        lp.dimAmount = 0f
        window.attributes = lp
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        armBye()
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (event?.action == MotionEvent.ACTION_OUTSIDE) {
            finish()
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        armBye()
        web.evaluateJavascript("window.beginVoice&&window.beginVoice()", null)
    }
}
