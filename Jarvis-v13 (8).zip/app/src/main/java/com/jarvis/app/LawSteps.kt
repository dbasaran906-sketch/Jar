package com.jarvis.app

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import java.util.Locale

/**
 * Arka planda (uygulama kapalıyken de) güvenle çalışabilen yasa adımları.
 * Çalıştıramadığı adım için null döner; o adımlar bildirimle kullanıcıya bırakılır
 * (uygulama açma, Wi-Fi/uçak modu gibi ekran gerektirenler arka planda yapılamaz).
 */
object LawSteps {
    private val TR = Locale("tr", "TR")

    private fun pct(t: String): Int? {
        if (Regex("(sıfır)").containsMatchIn(t)) return 0
        if (t.contains("yarım")) return 50
        if (Regex("(full|\\bson\\b|max|maksimum|\\btam\\b|sonuna)").containsMatchIn(t)) return 100
        return Regex("(\\d{1,3})").find(t)?.value?.toIntOrNull()?.coerceIn(0, 100)
    }

    fun run(ctx: Context, step: String): String? {
        val t = step.lowercase(TR).trim()
        if (t.isEmpty()) return null
        if (t.contains("televizyon") || Regex("\\btv\\b").containsMatchIn(t)) return null
        try {
            if (t.contains("fener")) {
                val on = !(t.contains("kapat") || t.contains("söndür"))
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return null
                cm.setTorchMode(id, on)
                return if (on) "fener açıldı" else "fener kapatıldı"
            }
            if (t.contains("parlak")) {
                val v = pct(t) ?: return null
                if (!Settings.System.canWrite(ctx)) return null
                Settings.System.putInt(
                    ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (maxOf(v, 1) * 255 / 100))
                return "parlaklık %" + maxOf(v, 1)
            }
            val isVol = Regex("\\bses(i|in)?\\b").containsMatchIn(t)
            if (t.contains("sessiz") || (isVol && (t.contains("kapat") || t.contains("kıs") && pct(t) == null))) {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
                try {
                    am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                } catch (e: Exception) {
                }
                return "ses kapatıldı"
            }
            if (isVol) {
                val v = pct(t) ?: return null
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v * max / 100, 0)
                return "ses %$v"
            }
        } catch (e: Exception) {
            return null
        }
        return null
    }
}
