/* JARVİS DÜNYA TAKİBİ + SABAH BRİFİNGİ + ÖNGÖRÜ
   - Seçtiğin konuları internetten araştırıp tek Türkçe özet yapar (sesli de okur).
   - Sabah saatinde "yasa" (zamanlı tetikleyici) ile otomatik çalışır.
   - Öngörü: saat, pil, görevler, alışkanlıklar, takvim ve konuma bakıp öneriler üretir. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div"); var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
var W=lsGet("jv_world",{topics:["dünya gündemi","teknoloji","yapay zeka","ekonomi"],time:"08:00",auto:false,last:null});
function save(){ lsSet("jv_world",W); }
var LAWNAME="sabah brifingi";

var d=document.createElement("div"); d.className="page"; d.id="pWd";
d.innerHTML='<div class="ph"><button class="ib" data-close>←</button><h2>DÜNYA TAKİBİ</h2></div><div class="pb">'+
 '<div class="sec"><h3>Takip konuları</h3><div id="wdTopics"></div><div style="display:flex;gap:8px;margin-top:8px"><input class="inp" id="wdNew" placeholder="Konu ekle (örn. Galatasaray, bitcoin)" style="flex:1;margin:0"><button class="btn" id="wdAdd" style="flex:0 0 70px">EKLE</button></div></div>'+
 '<div class="sec"><h3>Sabah brifingi</h3><label style="display:flex;gap:8px;align-items:center;font-size:14px"><input type="checkbox" id="wdAuto"> Her sabah otomatik sesli brifing ver</label><div style="margin-top:8px;font-size:13px">Saat: <input type="time" id="wdTime" style="background:#000;color:var(--c1);border:1px solid var(--line);border-radius:8px;padding:6px"></div>'+
 '<div style="font-size:11px;color:var(--dim);margin-top:6px">Zamanlı yasa olarak çalışır. Telefon uykudayken ekranı açabilmesi için İzinler sayfasındaki "Diğer uygulamaların üzerinde göster" ve pil optimizasyonu izinleri gerekir. Brifing, seçtiğin konuların internetteki güncel haberlerinden hazırlanır; "dünyadaki her şeyi" değil, konularını izler.</div></div>'+
 '<div class="pbtn"><button class="btn" id="wdNow">☀ ŞİMDİ BRİFİNG AL</button><button class="btn" id="wdFore">🔮 ÖNGÖRÜ</button></div>'+
 '<div id="wdStat" style="font-size:12px;color:var(--c1);min-height:16px"></div><div class="sec" id="wdOut" style="display:none;white-space:pre-wrap;font-size:14px;line-height:1.5"></div></div>';
document.body.appendChild(d);

function render(){
  $("wdTopics").innerHTML=W.topics.map(function(t,i){ return '<span style="display:inline-flex;align-items:center;gap:6px;margin:3px;padding:5px 10px;border:1px solid var(--line);border-radius:14px;font-size:13px">'+esc(t)+' <b data-wx="'+i+'" style="color:var(--c2);cursor:pointer">✕</b></span>'; }).join("")||'<div class="pl">Konu yok.</div>';
  $("wdTopics").querySelectorAll("[data-wx]").forEach(function(b){ b.onclick=function(){ W.topics.splice(+b.getAttribute("data-wx"),1); save(); render(); }; });
  $("wdAuto").checked=!!W.auto; $("wdTime").value=W.time||"08:00";
  var l=W.last; if(l){ $("wdOut").style.display="block"; $("wdOut").textContent=l.text+"\n\n— "+new Date(l.ts).toLocaleString("tr-TR"); }
}
$("wdAdd").onclick=function(){ var v=$("wdNew").value.trim(); if(v&&W.topics.indexOf(v)<0&&W.topics.length<8){ W.topics.push(v); save(); render(); } $("wdNew").value=""; };
$("wdTime").onchange=function(){ if(/^\d{2}:\d{2}$/.test(this.value)){ W.time=this.value; save(); syncLaw(); } };
$("wdAuto").onchange=function(){ W.auto=this.checked; save(); syncLaw(); };

/* sabah yasası ile zamanlama */
function syncLaw(){
  var jp=window.JV_plus; if(!jp||!jp.laws) return;
  var L=jp.laws, i=L.map(function(x){ return x.name; }).indexOf(LAWNAME);
  if(W.auto){
    JV.runTool("law_save",{name:LAWNAME,steps:"brifing ver",trigger:"her gün "+W.time}).then(function(r){ $("wdStat").textContent=String(r).slice(0,160); });
  }else if(i>=0){ L.splice(i,1); if(jp.saveLaws) jp.saveLaws(); $("wdStat").textContent="Otomatik brifing kapatıldı."; }
}

function stat(t){ $("wdStat").textContent=t||""; }
function show(t){ $("wdOut").style.display="block"; $("wdOut").textContent=t; }
async function safeTool(n,a,ms){ try{ return String(await JV.withTimeout(JV.runTool(n,a||{}),ms||20000,n+" zaman aşımı")); }catch(e){ return ""; } }

/* ---- Öngörü ---- */
async function foresight(){
  var now=new Date(), hab=lsGet("jv_hab",[]), by={};
  hab.forEach(function(x){ if(Math.abs(x.h-now.getHours())<=1){ by[x.c]=(by[x.c]||0)+1; } });
  var habTxt=Object.keys(by).sort(function(a,b){ return by[b]-by[a]; }).slice(0,4).map(function(k){ return k+" ("+by[k]+" kez)"; }).join(", ")||"veri yok";
  var tasks=lsGet("jv_tasks",[]).filter(function(t){ return !t.done; }).slice(0,6).map(function(t){ return t.title+(t.when?" ["+t.when+"]":""); }).join("; ")||"yok";
  var res=await Promise.all([safeTool("get_device_status"),safeTool("get_calendar",{days:2}),safeTool("location_info",{},25000)]);
  var ctx="Şu an: "+now.toLocaleString("tr-TR",{weekday:"long",day:"numeric",month:"long",hour:"2-digit",minute:"2-digit"})+"\nCihaz: "+res[0].slice(0,300)+"\nTakvim (yakın): "+res[1].slice(0,600)+"\nKonum/hava: "+res[2].slice(0,500)+"\nBu saatlerde sık yapılanlar: "+habTxt+"\nAçık görevler: "+tasks;
  var raw=await JV.withTimeout(JV.aiText("Sen kullanıcının kişisel ÖNGÖRÜ motorusun. Aşağıdaki gerçek verilere bakarak kullanıcının büyük olasılıkla yakında ihtiyaç duyacağı en fazla 5 şeyi öngör ve proaktif öner (örn. pil düşük ve toplantı yakın: şarj et; sabah alışkanlığı; yağmur: şemsiye). Verilerde olmayan şeyi uydurma; veri azsa az öner. Sadece JSON: [{\"oneri\":\"kısa Türkçe öneri\",\"neden\":\"hangi veriye dayanıyor\",\"olasilik\":\"yüksek|orta|düşük\"}].\n\n"+ctx,true),30000,"öngörü zaman aşımı");
  var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
  return arr.slice(0,5);
}
function fmtFore(arr){ return arr.length?arr.map(function(a,i){ return (i+1)+". "+a.oneri+" ("+a.olasilik+") — "+a.neden; }).join("\n"):"Şu an öne çıkan bir öngörüm yok; biraz daha veri biriktirmem gerekiyor."; }
$("wdFore").onclick=async function(){
  stat("Veriler toplanıyor…"); show("…");
  try{ var a=await foresight(); show("ÖNGÖRÜLER\n\n"+fmtFore(a)); stat(""); }catch(e){ show("Hata: "+JV.errMsg(e)); stat(""); }
};

/* ---- Brifing ---- */
async function brief(speak){
  var topics=W.topics.length?W.topics.slice(0,5):["dünya gündemi"], blocks=[], src=[];
  for(var i=0;i<topics.length;i++){
    stat("Araştırıyorum: "+topics[i]+" ("+(i+1)+"/"+topics.length+")");
    try{
      var r=await JV.withTimeout(window.JSTOOLS.web_search({query:topics[i]+" son gelişmeler bugün",queries:[topics[i]+" son dakika",topics[i]+" haber"]}),30000,"arama zaman aşımı");
      r=String(r); var k=r.indexOf("[KAYNAK LİSTESİ"); if(k>=0){ src.push(r.slice(k,k+900)); }
      blocks.push("### "+topics[i]+"\n"+r.slice(0,2600));
    }catch(e){ blocks.push("### "+topics[i]+"\n(araştırılamadı: "+JV.errMsg(e).slice(0,100)+")"); }
  }
  var fore=""; try{ stat("Öngörüler hazırlanıyor…"); fore=fmtFore(await foresight()); }catch(e){}
  stat("Özet yazılıyor…");
  var today=new Date().toLocaleDateString("tr-TR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
  var text=await JV.withTimeout(JV.aiText("Bugün "+today+". Aşağıda kullanıcının takip ettiği konular için az önce internetten çekilen veriler var. Bunlardan kısa bir SABAH BRİFİNGİ yaz: 'Günaydın efendim' ile başla, her konu için 1-2 cümlelik güncel gelişme (yalnızca verilerde geçenler; eski tarihli ise 'eski' diye belirt; veri yoksa 'net bilgi bulamadım' de, uydurma), sonra 'Bugün için öngörülerim' başlığıyla aşağıdaki öngörülerden en önemli 2 tanesini ekle. Toplam en fazla 170 kelime, düz metin, madde işareti ve yıldız kullanma (sesli okunacak). En sonda 'Kaynaklar:' diye en fazla 3 site adı.\n\nÖNGÖRÜLER:\n"+fore+"\n\nVERİLER:\n"+blocks.join("\n\n").slice(0,9000),false),45000,"özet zaman aşımı");
  text=String(text||"").trim(); if(!text) throw new Error("özet boş geldi");
  W.last={ts:Date.now(),text:text}; save(); render(); stat("");
  if(speak){ try{ JV.say(text.replace(/Kaynaklar:[\s\S]*$/,"").slice(0,1400)); }catch(e){} }
  return text;
}
$("wdNow").onclick=async function(){ try{ show("Brifing hazırlanıyor, bu 30-60 sn sürebilir…"); var t=await brief(true); show(t); }catch(e){ stat(""); show("Brifing hazırlanamadı: "+JV.errMsg(e)); } };

/* ---- araç + komutlar ---- */
window.JSTOOLS=window.JSTOOLS||{};
window.JSTOOLS.daily_brief=function(){ return brief(false); };
window.JSTOOLS.foresight=async function(){ return fmtFore(await foresight()); };
window.EXTRA_TOOLS=(window.EXTRA_TOOLS||[]).concat([
 {name:"daily_brief",description:"Kullanıcının takip ettiği konular için internetten güncel brifing hazırlar (günaydın özeti, dünya gelişmeleri, öngörüler).",input_schema:{type:"object",properties:{}}},
 {name:"foresight",description:"Öngörü motoru: saat, pil, takvim, görevler, alışkanlık ve konuma bakarak kullanıcının yakında ihtiyaç duyacağı şeyleri öngörür ve önerir.",input_schema:{type:"object",properties:{}}}
]);
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/^telefonda şunu araçla yap:\s*/,"").replace(/[.!?,]+$/g,"");
  if(t.split(/\s+/).length<=6){
    if(/^((sabah )?brifing(i)?( ver| al| hazırla)?|günaydın brifing|bana brifing ver|günün özeti)$/.test(t)){
      try{ var r=await brief(true); return r; }catch(e){ return "Brifing hazırlanamadı: "+JV.errMsg(e); }
    }
    if(/^(dünya takibi|dünya takip)( modunu)?( aç)?$/.test(t)){ open(); return "Dünya takibi açık."; }
    if(/^(öngörü|öngörülerin|öngörü motoru|neler öngörüyorsun)( ver| aç)?$/.test(t)){ try{ var a=await foresight(); var f=fmtFore(a); JV.say(a.slice(0,2).map(function(x){ return x.oneri; }).join(". ")); return "Öngörülerim:\n"+f; }catch(e){ return "Öngörü hazırlanamadı: "+JV.errMsg(e); } }
  }
  var m=/^(.+?)\s+(?:konusunu|konusunu da|haberlerini)\s+(?:takip et|izle)$/.exec(t);
  if(m){ var tp=m[1].trim(); if(W.topics.indexOf(tp)<0&&W.topics.length<8){ W.topics.push(tp); save(); render(); } return "'"+tp+"' takip listene eklendi. Sabah brifinginde yer alacak."; }
  return prevOff?prevOff(text):null;
};
function open(){ render(); d.classList.add("show"); }
(function(){
  var chips=$("chips"); if(!chips||!chips.appendChild||chips===DUMMY) return;
  [["🔮 ÖNGÖRÜ",function(){ open(); $("wdFore").click(); }],["🌍 DÜNYA",open],["🎖 KOMUTAN",function(){ if(window.JV_commander) window.JV_commander.start(); }]].forEach(function(c){ var b=document.createElement("button"); b.textContent=c[0]; b.onclick=c[1]; chips.appendChild(b); });
})();
window.JV_world={open:open,brief:brief,foresight:foresight,_W:W};
})();
