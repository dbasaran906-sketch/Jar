/* JARVİS kişiliği: karakter seçimi + sabah brifingi */
(function(){
"use strict";
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, $=function(id){ return document.getElementById(id); };
var PERS={
 classic:{n:"Klasik Jarvis",d:"Varsayılan: sakin, zeki, ince esprili.",t:"",v:"Charon"},
 butler:{n:"Ciddi Butler",d:"Resmi, kibar, kısa. Her cevapta 'efendim'.",t:"Resmi ve kusursuz kibar bir İngiliz uşak gibi konuş: kısa, ölçülü, her zaman 'efendim' de, espriden kaçın.",v:"Charon"},
 sarcastic:{n:"Alaycı",d:"Kuru, ince alaycı mizah; asla kırıcı değil.",t:"Kuru, ince ve zekice alaycı bir mizahla konuş (Tony Stark'ın Jarvis'i gibi). Kısa, nükteli göndermeler yap ama asla kırıcı olma, yardımı ihmal etme.",v:"Orus"},
 calm:{n:"Sakin",d:"Yumuşak, rahatlatıcı, sade.",t:"Çok sakin, yumuşak ve rahatlatıcı konuş. Sade, kısa cümleler kur, acele ettirme.",v:"Umbriel"},
 commander:{n:"Komutan",d:"Komuta merkezi dili: net, kısa raporlar.",t:"Komuta merkezi gibi konuş: kısa, net, komut dili. 'Anlaşıldı', 'Onaylandı', 'Durum raporu:' gibi kalıplar kullan, gereksiz süs yapma.",v:"Alnilam"},
 friend:{n:"Dost",d:"Samimi, sıcak, 'sen' diye konuşur.",t:"Samimi bir dost gibi 'sen' diye hitap et, günlük sıcak bir dille konuş, motive et. 'Efendim' deme.",v:"Puck"},
 hacker:{n:"Hacker",d:"Siber film dili (sadece eğlence).",t:"Siber film karakteri gibi teknik jargonla ve kısa cümlelerle konuş ('erişim sağlandı', 'paket çözüldü' gibi). Bu sadece üsluptur; gerçek zarar verici bilgi verme.",v:"Fenrir"}
};
function cur(){ return PERS[cfg.persona]||PERS.classic; }
function text(){ return cur().t; }
window.JV_persona={text:text,list:PERS};

var prev=window.EXTRA_SYS;
window.EXTRA_SYS=function(){ var t=text(); return (prev?prev():"")+(t?"KARAKTER (üslup, bu kuralı koru): "+t+" ":""); };

/* ---- Ayarlar bölümü ---- */
function build(){
  var pb=document.querySelector("#pSet .pb"); if(!pb) return;
  var old=$("personaSet"); if(old) old.remove();
  var w=document.createElement("div"); w.className="sec"; w.id="personaSet";
  w.innerHTML='<h3>Kişilik</h3>'+
   '<div class="row" style="display:block">Jarvis\'in karakteri<select id="peSel">'+Object.keys(PERS).map(function(k){ return '<option value="'+k+'">'+PERS[k].n+'</option>'; }).join("")+'</select><small id="peD"></small></div>'+
   '<button class="btn" id="peV">Karakterin önerilen sesini uygula</button>'+
   '<div class="row"><div>Sabah brifingi<small>Sabah ilk açılışta tarih, hava ve takvimi sesli özetler</small></div><label class="sw"><input type="checkbox" id="peB"><i></i></label></div>'+
   '<button class="btn" id="peN">Brifingi şimdi dinle</button>';
  var anchor=null; pb.querySelectorAll(".sec").forEach(function(s){ var h=s.querySelector(":scope>h3"); if(!anchor&&h&&/^jarvis sesi/i.test(h.textContent)) anchor=s; });
  if(anchor&&anchor.parentNode===pb) pb.insertBefore(w,anchor); else if(anchor&&anchor.parentNode) anchor.parentNode.insertBefore(w,anchor); else pb.appendChild(w);
  $("peSel").value=cfg.persona||"classic"; $("peD").textContent=cur().d; $("peB").checked=!!cfg.brief;
  $("peSel").onchange=function(){ cfg.persona=this.value; JV.saveCfg(); $("peD").textContent=cur().d; JV.toast("Karakter: "+cur().n); };
  $("peV").onclick=function(){ cfg.gvoice=cur().v; cfg.voiceEngine="gemini"; JV.saveCfg(); JV.toast("Ses: "+cur().v+" uygulandı (Ses kütüphanesinde değiştirebilirsin)"); };
  $("peB").onchange=function(){ cfg.brief=this.checked; JV.saveCfg(); };
  $("peN").onclick=function(){ var p=document.getElementById("pSet"); if(p) p.classList.remove("show"); brief(); };
}
var bs=$("bSet"); if(bs) bs.addEventListener("click",function(){ setTimeout(build,80); });

/* ---- Sabah brifingi ---- */
function brief(){
  JV.send("Günaydın brifingi ver: kısaca selamla, bugünün tarihini ve saatini söyle, konumuma göre hava durumunu (get_weather), bugünkü takvimimi (get_calendar) ve hafızandaki önemli hatırlatmaları özetle. En fazla 5 kısa cümle.");
}
function today(){ var d=new Date(); return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); }
if(!JV.voice&&cfg.brief){
  setTimeout(function(){
    var h=new Date().getHours(), last=""; try{ last=localStorage.getItem("jv_brief_day")||""; }catch(e){}
    if(h>=5&&h<12&&last!==today()){ try{ localStorage.setItem("jv_brief_day",today()); }catch(e){} brief(); }
  },7000);
}
})();
