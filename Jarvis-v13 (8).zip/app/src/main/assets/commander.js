/* JARVİS GÖREV KOMUTANI: hedefi sorar -> plan söyler -> onay ister -> uygulama ajanıyla yürütür.
   + derin düşünme (katmanlar) komutları. */
(function(){
var JV=window.JV; if(!JV) return;
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
var C={st:"off",goal:"",plan:null,busy:false};
var DUMMY=document.createElement("div"); var $=function(id){ return document.getElementById(id)||DUMMY; };

/* küçük durum şeridi */
var bar=document.createElement("div"); bar.id="cmdBar";
bar.style.cssText="position:fixed;left:12px;right:12px;top:64px;z-index:15;display:none;padding:9px 12px;border:1px solid var(--c2);border-radius:12px;background:rgba(20,10,2,.88);color:#ffd9b0;font-size:13px;box-shadow:0 0 12px rgba(255,138,31,.35)";
bar.innerHTML='<b style="letter-spacing:2px;color:var(--c2)">GÖREV KOMUTANI</b> <span id="cmdTx"></span> <button id="cmdX" class="ib" style="width:28px;height:28px;float:right;font-size:13px">✕</button>';
document.body.appendChild(bar);
$("cmdX").onclick=function(){ off("Görev komutanı kapatıldı."); };
function show(t){ bar.style.display="block"; $("cmdTx").textContent=t||""; }
function hide(){ bar.style.display="none"; }
function off(msg){ try{ if(C.st==="run"&&window.JV_appAgent) window.JV_appAgent.stop(); }catch(e){} C.st="off"; C.goal=""; C.plan=null; hide(); try{ JV.stopListen(); }catch(e){} if(msg){ JV.toast(msg); } }
function speak(t){ show(t); try{ JV.say(t); }catch(e){} }
function listenSoon(){ setTimeout(function(){ if(C.st==="goal"||C.st==="confirm"){ var w=0; (function t(){ if(JV.isSpeaking()||JV.isBusy()){ if(w++<60) return setTimeout(t,400); } try{ JV.startListen(); }catch(e){} })(); } },700); }

var YES=/^(evet|onaylıyorum|onayla|onaylarım|tamam|olur|yap|başla|devam|aynen|uygun|kabul)/;
var NO=/^(hayır|hayir|iptal|vazgeç|yapma|dur|olmaz|istemiyorum)/;

async function makePlan(goal){
  var raw=await JV.withTimeout(JV.aiText("Kullanıcı bir Android telefonda şu hedefi verdi: \""+goal+"\"\nBunu telefonda ekranı okuyup dokunarak yapacak bir ajan yürütecek. Kısa bir plan yaz. Sadece JSON: {\"ozet\":\"tek cümle Türkçe: ne yapacağım\",\"adimlar\":[\"en fazla 5 kısa adım\"],\"riskli\":true veya false,\"uygulama\":\"kullanılacak uygulama\"}. riskli: para harcama, mesaj gönderme, silme gibi geri alınamaz bir şey varsa true.",true),25000,"plan zaman aşımı");
  var j=JV.parseJSON(raw); if(!j||!j.ozet) return null; return j;
}
async function onGoal(goal){
  C.goal=goal; C.st="plan"; show("Plan hazırlanıyor…");
  var p=null; try{ p=await makePlan(goal); }catch(e){}
  if(!p){ C.st="goal"; speak("Bunu planlayamadım efendim. Hedefi başka şekilde söyler misiniz?"); listenSoon(); return; }
  C.plan=p; C.st="confirm";
  var say="Şunu yapacağım: "+p.ozet+(p.adimlar&&p.adimlar.length?" Adımlar: "+p.adimlar.join(", ")+".":"")+(p.riskli?" Dikkat, riskli adım içeriyor, ilgili adımda ayrıca soracağım.":"")+" Onaylıyor musunuz?";
  speak(say); listenSoon();
}
async function onConfirm(t){
  if(YES.test(t)){
    C.st="run"; show("Çalışıyorum: "+C.goal); try{ JV.say("Başlıyorum efendim."); }catch(e){}
    var goal=C.goal; C.goal=""; 
    var r; try{ r=await window.JSTOOLS.app_agent({goal:goal}); }catch(e){ r="Hata: "+((e&&e.message)||e); }
    C.st="off"; hide(); JV.toast("Görev bitti",3000); try{ JV.say(String(r).split("\n\nAdımlar")[0].slice(0,300)); }catch(e){}
    return String(r);
  }
  if(NO.test(t)){ C.st="goal"; speak("Anlaşıldı efendim. Yeni hedefiniz nedir?"); listenSoon(); return "Plan iptal edildi. Yeni hedefini söyle."; }
  // başka bir cümle = hedefi güncelle
  onGoal(t); return "Planı güncelliyorum…";
}
function start(){ C.st="goal"; speak("Görev komutanı aktif. Hedefiniz nedir efendim?"); listenSoon(); return "Görev komutanı aktif. Hedefini söyle ya da yaz; sana planı okuyup onay isteyeceğim."; }

/* ses yakalama */
var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd;
window.JV_onSpeech=function(t,final){
  if(C.st==="goal"||C.st==="confirm"){
    if(!final){ show("… "+t); return true; }
    var x=tl(t).replace(/[.!?,]+$/g,"");
    if(/(görev komutanı).*(kapat|bitir|çık)/.test(x)||x==="iptal"&&C.st==="goal"){ off("Görev komutanı kapandı."); try{ JV.say("Görev komutanı kapandı."); }catch(e){} return true; }
    if(C.st==="goal") onGoal(t); else onConfirm(x).then(function(){});
    return true;
  }
  return prevS?prevS(t,final):false;
};
window.JV_onListenEnd=function(err){
  if(C.st==="goal"||C.st==="confirm"){ if(err===6||err===7){ listenSoon(); } return true; }
  return prevE?prevE(err):false;
};

/* yazılı komutlar */
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(C.st==="goal"){ if(/(kapat|iptal|bitir|çık)/.test(t)&&t.split(/\s+/).length<4){ off(); return "Görev komutanı kapatıldı."; } onGoal(text); return "Plan hazırlanıyor…"; }
  if(C.st==="confirm") return await onConfirm(t);
  if(C.st==="run") return "Görev çalışıyor; durdurmak için üstteki ✕ ya da 'dur' de.";
  if(/görev komutan/.test(t)&&t.split(/\s+/).length<=6){
    if(/(kapat|bitir|çık)/.test(t)) { off(); return "Görev komutanı kapatıldı."; }
    return start();
  }
  var m=/^(derin düşünme|düşünme katmanları|katmanlı düşünme)\s*(aç|açık|kapat|kapalı|otomatik|oto)?$/.exec(t);
  if(m){
    var v=m[2]||""; var cfg=JV.cfg;
    if(/^(aç|açık)$/.test(v)) cfg.layers="on"; else if(/^(kapat|kapalı)$/.test(v)) cfg.layers="off"; else if(/^(otomatik|oto)$/.test(v)) cfg.layers="auto";
    else return "Düşünme katmanları şu an: "+({on:"her zaman açık",off:"kapalı",auto:"otomatik (zor sorularda)"}[cfg.layers||"auto"])+". 'derin düşünme aç / kapat / otomatik' diyebilirsin.";
    JV.saveCfg(); return "Düşünme katmanları: "+({on:"her soruda açık (yavaş ama daha titiz)",off:"kapalı",auto:"otomatik, zor sorularda devreye girer"}[cfg.layers])+".";
  }
  return prevOff?prevOff(text):null;
};
window.JV_commander={start:start,_C:C};
})();
