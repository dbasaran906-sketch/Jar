/* JARVİS ayarlar düzeni: kartlı ana ekran, gruplar, arama, ses kütüphanesi.
   Mevcut ayar bölümlerine DOKUNMAZ; sadece gruplayıp gösterir/gizler. */
(function(){
"use strict";
var JV = window.JV; if(!JV) return;
var cfg = JV.cfg;
var $ = function(id){ return document.getElementById(id); };
var pSet = $("pSet"); if(!pSet) return;
var pb = pSet.querySelector(".pb"), h2 = pSet.querySelector("h2");
if(!pb||!h2) return;
var esc = JV.esc;

/* ---------- Gruplar ---------- */
var GROUPS = [
  {k:"brain", ic:"🧠", n:"Beyin", d:"Yapay zeka, anahtar, internet"},
  {k:"voice", ic:"🔊", n:"Ses ve Kişilik", d:"Ses, dil, hız, rapor"},
  {k:"look",  ic:"🎨", n:"Görünüm", d:"Tema paketleri"},
  {k:"notif", ic:"🔔", n:"Bildirim ve Işık", d:"Bildirim, dinleme balonu"},
  {k:"feat",  ic:"⚡", n:"Özellikler", d:"Modlar, kamera HUD, otonom"},
  {k:"sys",   ic:"🛠", n:"Sistem", d:"İzinler, güncelleme"},
  {k:"data",  ic:"🗂", n:"Veri", d:"Hafıza, sohbetler"}
];
function grpOf(t){
  t=(t||"").toLowerCase();
  if(t.indexOf("beyin")===0||t.indexOf("api anahtar")===0) return "brain";
  if(t==="ses"||t.indexOf("kişilik")===0||t.indexOf("jarvis sesi")===0||t.indexOf("sesli sistem")===0) return "voice";
  if(t.indexOf("görünüm")===0) return "look";
  if(t.indexOf("bildirim")===0) return "notif";
  if(t.indexOf("jarvis v7")===0||t.indexOf("kamera")===0) return "feat";
  if(t.indexOf("hafıza")===0||t==="veri") return "data";
  return "sys";
}
function gName(k){ for(var i=0;i<GROUPS.length;i++) if(GROUPS[i].k===k) return GROUPS[i]; return GROUPS[5]; }

/* ---------- Stil ---------- */
var st=document.createElement("style");
st.textContent=
"#pSet .pb{padding:12px 14px 40px}"+
".sx-hide{display:none!important}"+
"#sxSearch{width:100%;box-sizing:border-box;height:46px;padding:0 14px 0 40px;border-radius:14px;border:1px solid var(--line);background:#010912 url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' fill='none' stroke='%237a93a8' stroke-width='2' stroke-linecap='round'%3E%3Ccircle cx='8' cy='8' r='6'/%3E%3Cpath d='M13 13l4 4'/%3E%3C/svg%3E\") 13px 14px no-repeat;color:var(--txt);font-size:15px;outline:none;margin-bottom:14px}"+
"#sxSearch:focus{border-color:var(--c1);box-shadow:0 0 0 3px color-mix(in srgb,var(--c1) 22%,transparent)}"+
"#sxHub{display:grid;grid-template-columns:1fr 1fr;gap:10px}"+
".sxc{display:flex;flex-direction:column;gap:6px;min-width:0;padding:14px 12px;border-radius:16px;border:1px solid var(--line);background:linear-gradient(160deg,color-mix(in srgb,var(--c1) 9%,var(--panel)),var(--panel));text-align:left;color:var(--txt);font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .12s,border-color .2s,box-shadow .2s}"+
".sxc:active{transform:scale(.97);border-color:var(--c1);box-shadow:0 0 14px color-mix(in srgb,var(--c1) 40%,transparent)}"+
".sxc .sxi{font-size:26px;line-height:1;background:none!important;border:0!important;padding:0!important;box-shadow:none!important;width:auto;height:auto;align-self:flex-start}"+
"#pSet,#pVoices{background:#020810!important}"+
".sxc b{font-size:14px;letter-spacing:.5px;color:var(--c1)}"+
".sxc small{font-size:11px;color:var(--dim);line-height:1.35;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}"+
".sxc:last-child:nth-child(odd){grid-column:1/-1}"+
"#sxEmpty{text-align:center;color:var(--dim);padding:30px 0;font-size:14px}"+
/* bölüm ve satır düzeni */
"#pSet .sec{margin:0 0 14px;padding:14px;border-radius:16px;position:relative}"+
"#pSet .sec>h3{display:flex;align-items:center;gap:8px;margin:0 0 6px;font-size:12px;letter-spacing:2.5px}"+
"#pSet .sec>h3:before{content:'';width:3px;height:13px;border-radius:2px;background:var(--c2);box-shadow:0 0 8px var(--c2)}"+
"#pSet .row{margin:0;padding:12px 0;border-top:1px solid color-mix(in srgb,var(--line) 55%,transparent);gap:12px}"+
"#pSet .sec>h3+.row,#pSet .sec>.row:first-child{border-top:0}"+
"#pSet .row[style*='display:block']{display:grid!important;gap:8px;align-items:stretch;justify-content:stretch}"+
"#pSet .row>div:first-child{min-width:0}"+
"#pSet .row small{display:block;margin-top:3px;line-height:1.35}"+
"#pSet select,#pSet input[type=text],#pSet input[type=password],#pSet input[type=number],#pSet .inp{box-sizing:border-box;height:44px;margin-top:0!important}"+
"#pSet input[type=range]{height:30px;margin-top:0}"+
"#pSet .sec>.btn,#pSet .sec>button.btn{display:block;width:100%;height:44px;margin:12px 0 0!important;box-sizing:border-box}"+
"#pSet .row>.btn{height:40px;flex:none}"+
"#pSet .btn{border-radius:12px;display:inline-flex;align-items:center;justify-content:center}"+
"#pSet .btn:active{background:color-mix(in srgb,var(--c1) 28%,transparent)}"+
"#pSet .btn.red{background:rgba(255,77,77,.1)}"+
".sw input:checked+i{background:color-mix(in srgb,var(--c1) 32%,transparent)!important}"+
/* tema kutuları */
".themes{display:grid!important;grid-template-columns:1fr 1fr;gap:10px;padding-top:6px}"+
".th{width:auto!important;height:auto!important;border-radius:14px!important;border:1px solid var(--line)!important;background:var(--panel);display:flex;align-items:center;gap:10px;padding:10px;color:var(--txt)!important;font-size:13px}"+
".th i{flex:none;width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--ta),var(--tb));box-shadow:0 0 10px color-mix(in srgb,var(--ta) 55%,transparent)}"+
".th span{min-width:0;line-height:1.2}"+
".th.sel{border-color:var(--ta)!important;box-shadow:0 0 14px color-mix(in srgb,var(--ta) 45%,transparent)!important;background:color-mix(in srgb,var(--ta) 10%,var(--panel))}"+
".th.sel span:after{content:' ✓';color:var(--ta)}"+
/* ses kütüphanesi */
"#sxVg{display:grid;grid-template-columns:1fr 1fr;gap:10px}"+
".sxv{display:flex;flex-direction:column;gap:6px;padding:12px;border-radius:14px;border:1px solid var(--line);background:var(--panel);min-width:0}"+
".sxv.sel{border-color:var(--c1);box-shadow:0 0 14px color-mix(in srgb,var(--c1) 40%,transparent);background:color-mix(in srgb,var(--c1) 8%,var(--panel))}"+
".sxv b{font-size:15px;color:var(--c1)}"+
".sxv small{color:var(--dim);font-size:11px;line-height:1.3}"+
".sxv .bb{display:flex;gap:6px;margin-top:4px}"+
".sxv .bb .btn{flex:1;padding:8px 0;height:38px;font-size:12px;letter-spacing:.5px;display:inline-flex;align-items:center;justify-content:center}"+
".sxv.pl{animation:sxp 1s ease-in-out infinite}"+
"@keyframes sxp{50%{box-shadow:0 0 18px var(--c2)}}";
document.head.appendChild(st);

/* ---------- Ana ekran + arama ---------- */
var view="hub", q="";
var search=document.createElement("input");
search.id="sxSearch"; search.type="search"; search.placeholder="Ayarlarda ara… (ses, tema, anahtar)"; search.autocomplete="off";
var hub=document.createElement("div"); hub.id="sxHub";
var empty=document.createElement("div"); empty.id="sxEmpty"; empty.textContent="Bu aramayla eşleşen ayar yok."; empty.className="sx-hide";
hub.innerHTML=GROUPS.map(function(g){ return '<button class="sxc" data-g="'+g.k+'"><span class="sxi">'+g.ic+'</span><b>'+g.n+'</b><small id="sxs-'+g.k+'">'+g.d+'</small></button>'; }).join("");
pb.insertBefore(hub,pb.firstChild); pb.insertBefore(search,pb.firstChild); pb.appendChild(empty);

function summaries(){
  function put(k,t){ var e=$("sxs-"+k); if(e) e.textContent=t; }
  var v=cfg.voiceEngine==="system"?"Telefon sesi":("Gemini · "+voiceLabel(cfg.gvoice||"Charon"));
  put("brain",(cfg.provider==="claude"?"Claude":"Gemini")+" · internet "+(cfg.web?"açık":"kapalı"));
  put("voice",v+" · sesli yanıt "+(cfg.speak?"açık":"kapalı"));
  put("look",(JV.themeNames&&JV.themeNames[cfg.theme])||cfg.theme);
  put("notif","Bildirim "+(cfg.notif?"açık":"kapalı"));
  var n=0; try{ n=JV.convs().length; }catch(e){}
  put("data",n+" sohbet · "+((cfg.memory||[]).length)+" hafıza");
  try{ var N=window.JarvisNative; if(N) put("sys","Sürüm "+N.getVersion()); }catch(e){}
}

function tag(){
  var secs=pb.querySelectorAll(".sec");
  var ql=q.trim().toLowerCase(), shown=0;
  secs.forEach(function(s){
    var h=s.querySelector(":scope>h3"), g=grpOf(h?h.textContent:"");
    s.setAttribute("data-grp",g);
    var show;
    if(ql){
      var hit=(s.textContent+" "+Array.prototype.map.call(s.querySelectorAll("option"),function(o){return o.textContent;}).join(" ")).toLowerCase().indexOf(ql)>=0;
      show=hit; if(hit) shown++;
      var hh=h&&h.textContent.toLowerCase().indexOf(ql)>=0;
      s.querySelectorAll(".row").forEach(function(r){ r.classList.toggle("sx-hide",!hh&&r.textContent.toLowerCase().indexOf(ql)<0&&!r.querySelector("select")); });
    } else {
      show=(view===g);
      s.querySelectorAll(".row.sx-hide").forEach(function(r){ r.classList.remove("sx-hide"); });
    }
    s.classList.toggle("sx-hide",!show);
  });
  var inHub=(view==="hub"&&!ql);
  hub.classList.toggle("sx-hide",!inHub);
  search.classList.toggle("sx-hide",!(view==="hub"));
  empty.classList.toggle("sx-hide",!(ql&&!shown));
  h2.textContent = ql?"ARAMA":(view==="hub"?"AYARLAR":gName(view).n.toUpperCase());
}
function setView(v){ view=v; q=""; search.value=""; tag(); pb.scrollTop=0; if(v==="hub") summaries(); }

hub.addEventListener("click",function(e){ var b=e.target.closest(".sxc"); if(b) setView(b.getAttribute("data-g")); });
search.addEventListener("input",function(){ q=search.value; tag(); pb.scrollTop=0; });
/* Geri: grup içindeyken önce ana ayar ekranına dön */
pSet.addEventListener("click",function(e){
  var c=e.target.closest&&e.target.closest("[data-close]");
  if(c&&c.closest("#pSet")===pSet&&(view!=="hub"||q)){ e.stopPropagation(); e.preventDefault(); setView("hub"); }
},true);
/* Diğer dosyalar bölümleri sonradan ekleyip yeniler: gruplamayı tazele */
var tt=0;
new MutationObserver(function(){ clearTimeout(tt); tt=setTimeout(tag,40); }).observe(pb,{childList:true,subtree:true});
/* Ayarlar her açıldığında ana ekrandan başla */
var bs=$("bSet");
if(bs) bs.addEventListener("click",function(){ setView("hub"); setTimeout(function(){ tag(); summaries(); },250); });
tag(); summaries();

/* ---------- Ses kütüphanesi (30 Gemini sesi) ---------- */
var VOICES=[
 ["Charon","Bilgilendirici, tok"],["Orus","Kararlı, sert"],["Algenib","Kalın, boğuk"],["Alnilam","Kararlı"],["Rasalgethi","Bilgilendirici"],
 ["Iapetus","Net, düz"],["Umbriel","Rahat, sakin"],["Schedar","Dengeli"],["Gacrux","Olgun"],["Fenrir","Heyecanlı"],
 ["Enceladus","Soluklu, yumuşak"],["Sadaltager","Bilgili"],["Achird","Samimi"],["Zubenelgenubi","Günlük"],["Puck","Neşeli"],
 ["Sadachbia","Canlı"],["Algieba","Pürüzsüz"],["Despina","Pürüzsüz"],["Erinome","Net"],["Kore","Kararlı"],
 ["Sulafat","Sıcak"],["Vindemiatrix","Nazik"],["Achernar","Yumuşak"],["Callirrhoe","Rahat"],["Autonoe","Parlak"],
 ["Zephyr","Parlak"],["Laomedeia","Neşeli"],["Pulcherrima","Dik, net"],["Leda","Genç"],["Aoede","Havadar"]
];
function voiceLabel(id){ for(var i=0;i<VOICES.length;i++) if(VOICES[i][0]===id) return "Ses "+(i+1)+" ("+id+")"; return id; }
var pv=document.createElement("div"); pv.className="page"; pv.id="pVoices";
pv.innerHTML='<div class="ph"><button class="ib" data-close>←</button><h2>SES KÜTÜPHANESİ</h2></div><div class="pb">'+
 '<div style="font-size:13px;color:var(--dim);line-height:1.5;margin-bottom:12px">30 Gemini sesi. <b>Dinle</b> ile dene, <b>Seç</b> ile Jarvis\'in sesi yap. Dinlemek için internet ve API anahtarı gerekir. Sesler tahmini olarak kalından inceye dizili; tını telefonda duyduğuna göre değerlendirilmeli.</div>'+
 '<div id="sxVg"></div></div>';
document.body.appendChild(pv);
var playing="";
function drawVoices(){
  $("sxVg").innerHTML=VOICES.map(function(v,i){
    var sel=(cfg.gvoice||"Charon")===v[0]&&cfg.voiceEngine!=="system";
    return '<div class="sxv'+(sel?' sel':'')+(playing===v[0]?' pl':'')+'" data-v="'+v[0]+'"><b>Ses '+(i+1)+'</b><small>'+v[0]+' · '+v[1]+'</small><div class="bb"><button class="btn" data-a="p">▶ Dinle</button><button class="btn" data-a="s">'+(sel?'✓ Seçili':'Seç')+'</button></div></div>';
  }).join("");
}
$("sxVg").addEventListener("click",function(e){
  var b=e.target.closest("button"); if(!b) return;
  var id=b.closest(".sxv").getAttribute("data-v");
  if(b.getAttribute("data-a")==="s"){
    cfg.gvoice=id; cfg.voiceEngine="gemini"; JV.saveCfg(); drawVoices(); summaries();
    var xe=$("xEng"); if(xe) xe.value="gemini";
    JV.toast(voiceLabel(id)+" seçildi");
  } else {
    playing=id; drawVoices();
    var done=function(){ playing=""; drawVoices(); };
    var p; try{ p=JV.say("Günaydın efendim. Tüm sistemler çevrimiçi. Size nasıl yardımcı olabilirim?",id,true); }catch(x){ p=Promise.reject(x); }
    Promise.resolve(p).then(done,function(er){ done(); JV.toast("Ses çalınamadı: "+(er&&er.message||"internet/anahtar?")); });
  }
});
function openVoices(){ drawVoices(); pv.classList.add("show"); pv.querySelector(".pb").scrollTop=0; }
window.JV_settings={openVoices:openVoices,setView:setView};

/* Ses grubunun içinde de kütüphaneye kısayol */
})();
