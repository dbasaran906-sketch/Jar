/* JARVİS SES KİLİDİ: sesini kaydet, test et, istersen sadece senin sesine cevap versin.
   Basit bir ses parmak izi (spektrum şekli + ses perdesi). Güvenlik amaçlı DEĞİL, rahatsız edici başka seslere karşı filtredir.
   Ses kaydedilmez; sadece sayısal özellikler telefonda saklanır. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var toast=JV.toast;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").trim(); }
var NB=24;
var VP=lsGet("jv_vp",{on:false,tpl:null,pitch:0,th:0,sens:1});
var cap={ac:null,an:null,stream:null,src:null,timer:0,sum:null,n:0,pitches:[],levelMax:0,on:false,t0:0,live:false};
var phrases=["Jarvis, bugün hava nasıl olacak","Telefonun pilini ve şarj durumunu söyle","Yarın sabah yedide beni uyandır","Bana yakın bir market bul ve yol tarif et","Mesajlarımı oku ve gerekirse cevap yaz"];

function pitchOf(buf,sr){
  var n=buf.length, min=Math.floor(sr/400), max=Math.floor(sr/70), best=0, bl=0, e0=0, i, l;
  for(i=0;i<n;i++) e0+=buf[i]*buf[i];
  if(e0<1e-4) return 0;
  for(l=min;l<=max&&l<n;l++){ var c=0; for(i=0;i+l<n;i+=2) c+=buf[i]*buf[i+l]; if(c>best){ best=c; bl=l; } }
  return (best>e0*0.22*0.5&&bl)?sr/bl:0;
}
async function openCap(){
  if(cap.on) return true;
  try{
    var stream=await Promise.race([navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}}),new Promise(function(_,r){ setTimeout(function(){ r(new Error("zaman aşımı")); },4000); })]);
    var AC=window.AudioContext||window.webkitAudioContext, ac=new AC();
    var an=ac.createAnalyser(); an.fftSize=2048; an.smoothingTimeConstant=0;
    var src=ac.createMediaStreamSource(stream); src.connect(an);
    cap.ac=ac; cap.an=an; cap.stream=stream; cap.src=src; cap.on=true;
    cap.fb=new Float32Array(an.frequencyBinCount); cap.tb=new Float32Array(an.fftSize);
    // bant sınırları: 100 Hz - 4 kHz, logaritmik
    var bin=ac.sampleRate/an.fftSize, edges=[];
    for(var i=0;i<=NB;i++) edges.push(Math.round(100*Math.pow(40,i/NB)/bin));
    cap.edges=edges; return true;
  }catch(e){ cap.err=(e&&(e.name||e.message))?((e.name||"")+" "+(e.message||"")).trim():String(e); return false; }
}
function closeCap(){
  clearInterval(cap.timer); cap.timer=0;
  try{ if(cap.stream) cap.stream.getTracks().forEach(function(t){ t.stop(); }); }catch(e){}
  try{ if(cap.ac) cap.ac.close(); }catch(e){}
  cap.ac=cap.an=cap.stream=cap.src=null; cap.on=false;
}
function resetAcc(){ cap.sum=new Float32Array(NB); cap.n=0; cap.pitches=[]; cap.levelMax=0; cap.t0=Date.now(); }
function tick(){
  if(!cap.on) return;
  try{
    var an=cap.an; an.getFloatTimeDomainData(cap.tb);
    var rms=0, tb=cap.tb, i; for(i=0;i<tb.length;i++) rms+=tb[i]*tb[i]; rms=Math.sqrt(rms/tb.length);
    if(rms>cap.levelMax) cap.levelMax=rms;
    cap.lastRms=rms;
    if(rms<0.012) return;                       // sessizlik
    an.getFloatFrequencyData(cap.fb);
    var vec=new Float32Array(NB), m=0, e=cap.edges;
    for(var b=0;b<NB;b++){ var s=0,c=0; for(var k=e[b];k<Math.max(e[b]+1,e[b+1]);k++){ s+=Math.pow(10,cap.fb[k]/20); c++; } vec[b]=Math.log10(s/c+1e-9)*20; m+=vec[b]; }
    m/=NB; for(b=0;b<NB;b++) vec[b]-=m;       // ses şiddetinden bağımsız şekil
    for(b=0;b<NB;b++) cap.sum[b]+=vec[b];
    cap.n++;
    var p=pitchOf(tb.subarray(0,1024),cap.ac.sampleRate); if(p>0) cap.pitches.push(p);
  }catch(e){}
}
function startCap(){ resetAcc(); clearInterval(cap.timer); cap.timer=setInterval(tick,45); }
function result(){
  if(cap.n<8) return null;
  var v=new Array(NB); for(var i=0;i<NB;i++) v[i]=cap.sum[i]/cap.n;
  var p=0; if(cap.pitches.length>=4){ var a=cap.pitches.slice().sort(function(x,y){ return x-y; }); p=a[Math.floor(a.length/2)]; }
  return {v:v,p:p,n:cap.n};
}
function dist(a,b){ var s=0; for(var i=0;i<NB;i++){ var d=a.v[i]-b.v[i]; s+=d*d; } var d1=Math.sqrt(s/NB); var dp=(a.p&&b.p)?Math.abs(12*Math.log2(a.p/b.p)):0; return d1+0.35*dp; }
function score(r){ if(!VP.tpl) return null; var d=dist(r,{v:VP.tpl,p:VP.pitch}); var th=VP.th*VP.sens; return {d:d,th:th,pct:Math.max(0,Math.min(100,Math.round(100*(1-d/(2*th))))),ok:d<=th}; }

/* ---------- Arayüz ---------- */
function mkPage(id,html){ var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d); return d; }
mkPage("pVp",
 '<div class="ph"><button class="ib" data-close>←</button><h2>SES KİLİDİ</h2></div>'+
 '<div class="pb"><div class="sec"><div style="font-size:13px;line-height:1.6;color:var(--dim)">Sesini 5 cümleyle kaydet. Sonra "Sadece benim sesim" açıkken mikrofon sadece senin sesine cevap verir. Ses kaydedilmez, sadece sayısal bir iz saklanır. <b>Bu bir güvenlik özelliği değil</b>, başka seslere karşı basit bir filtre.</div><div id="vpSt" style="margin-top:10px;font-size:14px"></div></div>'+
 '<div class="sec"><button class="btn" id="vpRec" style="width:100%;margin-bottom:8px">SESİMİ KAYDET (5 CÜMLE)</button><button class="btn" id="vpTest" style="width:100%;margin-bottom:8px">SES TESTİ</button>'+
 '<div id="vpBox" style="margin-top:6px"></div></div>'+
 '<div class="sec"><div class="row" style="display:block">Kilit<select id="vpOn" class="inp"><option value="0">Kapalı (herkesin sesine cevap ver)</option><option value="1">Sadece benim sesim</option></select></div>'+
 '<div class="row" style="display:block">Sıkılık<select id="vpSens" class="inp"><option value="1.35">Rahat (az reddeder)</option><option value="1">Orta</option><option value="0.8">Sıkı (çok reddeder)</option></select></div>'+
 '<button class="btn" id="vpDel" style="width:100%;margin-top:8px">KAYDIMI SİL</button></div></div>');
function box(h){ $("vpBox").innerHTML=h; }
function bar(l){ return '<div style="height:8px;border-radius:4px;background:rgba(79,209,255,.15);overflow:hidden"><div style="height:100%;width:'+Math.min(100,Math.round(l*900))+'%;background:linear-gradient(90deg,#4fd1ff,#ff8a1f)"></div></div>'; }
function stText(){
  var s=!VP.tpl?"Henüz ses kaydı yok.":"✅ Ses kaydın var · kilit: "+(VP.on?"AÇIK":"kapalı");
  if(VP.broken) s+="<br>⚠️ Son denemede mikrofon aynı anda paylaşılamadı; kilit bu telefonda güvenilir çalışmıyor olabilir.";
  $("vpSt").innerHTML=s; $("vpOn").value=VP.on?"1":"0"; $("vpSens").value=String(VP.sens);
}
function openVp(){ stText(); box(""); document.getElementById("pVp").classList.add("show"); }
function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
var busyVp=false;
async function record(){
  if(busyVp) return; busyVp=true;
  try{
    if(JV.isListening()) JV.stopListen();
    var ok=await openCap(); if(!ok){ box("Mikrofon açılamadı: "+(cap.err||"bilinmeyen hata")+". Telefon ayarlarından Jarvis > İzinler > Mikrofon açık mı bak."); busyVp=false; return; }
    var samples=[];
    for(var i=0;i<phrases.length;i++){
      box('<div style="font-size:12px;color:var(--dim)">Cümle '+(i+1)+'/'+phrases.length+' — sesli oku:</div><div style="font-size:16px;margin:8px 0;color:#bfe9ff">"'+phrases[i]+'"</div><div id="vpLv"></div>');
      await sleep(900); startCap();
      var lv=setInterval(function(){ var e=$("vpLv"); if(e!==DUMMY) e.innerHTML=bar(cap.lastRms||0); },90);
      await sleep(4200); clearInterval(lv); clearInterval(cap.timer); cap.timer=0;
      var r=result(); if(!r){ box("Seni duyamadım, bu cümleyi tekrar oku."); await sleep(1200); i--; if(++record.fail>4){ break; } continue; }
      samples.push(r);
    }
    closeCap();
    if(samples.length<4){ box("Kayıt tamamlanamadı. Sessiz bir yerde, telefona yakın konuşup tekrar dene."); busyVp=false; record.fail=0; return; }
    var tpl=new Array(NB).fill(0), pp=[]; samples.forEach(function(s){ for(var i=0;i<NB;i++) tpl[i]+=s.v[i]/samples.length; if(s.p) pp.push(s.p); });
    var pitch=pp.length?pp.reduce(function(a,b){ return a+b; },0)/pp.length:0;
    var mx=0; samples.forEach(function(s){ var d=dist(s,{v:tpl,p:pitch}); if(d>mx) mx=d; });
    VP.tpl=tpl; VP.pitch=pitch; VP.th=Math.max(2.2,Math.min(9,mx*1.9+1.2)); lsSet("jv_vp",VP);
    stText(); box('<div style="color:#7dffb0">Kayıt tamam. Şimdi "SES TESTİ" ile dene.</div>');
  }catch(e){ box("Hata: "+((e&&e.message)||e)); closeCap(); }
  record.fail=0; busyVp=false;
}
record.fail=0;
async function test(){
  if(busyVp) return; if(!VP.tpl){ box("Önce sesini kaydet."); return; }
  busyVp=true;
  try{
    if(JV.isListening()) JV.stopListen();
    if(!(await openCap())){ box("Mikrofon açılamadı: "+(cap.err||"bilinmeyen hata")); busyVp=false; return; }
    for(var round=0;round<3;round++){
      box('<div style="font-size:14px">Test '+(round+1)+'/3 — bir şey söyle (veya başkası konuşsun)</div><div id="vpLv" style="margin-top:8px"></div>');
      await sleep(500); startCap();
      var lv=setInterval(function(){ var e=$("vpLv"); if(e!==DUMMY) e.innerHTML=bar(cap.lastRms||0); },90);
      await sleep(3500); clearInterval(lv); clearInterval(cap.timer); cap.timer=0;
      var r=result();
      if(!r){ box("Ses duyamadım."); await sleep(1100); continue; }
      var sc=score(r);
      box('<div style="font-size:22px;margin:6px 0;color:'+(sc.ok?'#7dffb0':'#ff8a8a')+'">'+(sc.ok?'✓ BU SENSİN':'✗ BAŞKASI')+'</div><div style="font-size:13px;color:var(--dim)">Benzerlik %'+sc.pct+' (eşik '+sc.th.toFixed(1)+', fark '+sc.d.toFixed(1)+')</div>');
      await sleep(2000);
    }
    closeCap(); box('<div style="font-size:13px;color:var(--dim)">Test bitti. Hep "BAŞKASI" çıkıyorsa Sıkılığı "Rahat" yap ya da sesini sessiz yerde tekrar kaydet.</div>');
  }catch(e){ box("Hata: "+((e&&e.message)||e)); closeCap(); }
  busyVp=false;
}
$("vpRec").onclick=record; $("vpTest").onclick=test;
$("vpOn").onchange=function(){ if(this.value==="1"&&!VP.tpl){ toast("Önce sesini kaydet"); this.value="0"; return; } VP.on=this.value==="1"; VP.broken=false; lsSet("jv_vp",VP); stText(); toast(VP.on?"Ses kilidi açık":"Ses kilidi kapalı"); };
$("vpSens").onchange=function(){ VP.sens=parseFloat(this.value)||1; lsSet("jv_vp",VP); };
$("vpDel").onclick=function(){ VP={on:false,tpl:null,pitch:0,th:0,sens:1}; lsSet("jv_vp",VP); stText(); box(""); toast("Ses kaydı silindi"); };

/* ---------- Dinleme sırasında doğrulama ---------- */
var guard={active:false,at:0};
var prevReady=window.onListenReady;
window.onListenReady=function(){
  if(prevReady) prevReady.apply(this,arguments);
  if(VP.on&&VP.tpl&&!busyVp){
    guard.active=true; guard.at=Date.now();
    openCap().then(function(ok){ if(ok&&guard.active) startCap(); else if(!ok){ guard.active=false; } });
  }
};
function endGuard(){ clearInterval(cap.timer); cap.timer=0; guard.active=false; setTimeout(function(){ if(!guard.active&&!busyVp) closeCap(); },300); }
var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd;
window.JV_onSpeech=function(t,final){
  if(final&&guard.active&&VP.on&&VP.tpl){
    var r=result(), silent=cap.levelMax<0.004;
    endGuard();
    if(!r||silent){
      // ses alınamadı: engelleme, sadece uyarı bırak (mikrofon paylaşılamıyor olabilir)
      VP.broken=true; lsSet("jv_vp",VP);
    }else{
      VP.broken=false;
      var sc=score(r);
      if(sc&&!sc.ok){
        try{ JV.stopListen(); }catch(e){}
        try{ if(window.JarvisNative&&window.JarvisNative.closeVoice&&JV.voice) window.JarvisNative.closeVoice(); }catch(e){}
        toast("Bu ses senin sesine benzemiyor (%"+sc.pct+"), yok sayıldı",2500);
        return true;
      }
    }
  }
  return prevS?prevS(t,final):false;
};
window.JV_onListenEnd=function(err){
  if(guard.active){
    // ses tanıma, mikrofon çakışmasıyla hata verirse kilidi güvenli şekilde kapat
    if((err===3||err===5||err===8)&&Date.now()-guard.at<2500){ VP.on=false; VP.broken=true; lsSet("jv_vp",VP); toast("Mikrofon çakıştı, ses kilidi kapatıldı"); }
    endGuard();
  }
  return prevE?prevE(err):false;
};

/* ---------- Komutlar ---------- */
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(t.split(/\s+/).length<=7&&/(ses kilid|ses testi|sesimi (kaydet|tanı|dene|test)|ses kaydı|ses tanıma testi|sesimle test|sesli test)/.test(t)){
    if(/(kilid)/.test(t)&&/(aç|aktif|etkin)/.test(t)){ if(!VP.tpl){ openVp(); return "Önce sesini kaydetmen lazım. Ses kilidi sayfasını açtım."; } VP.on=true; lsSet("jv_vp",VP); return "Ses kilidi açık: artık sadece senin sesine cevap vereceğim."; }
    if(/(kilid)/.test(t)&&/(kapat|devre|iptal)/.test(t)){ VP.on=false; lsSet("jv_vp",VP); return "Ses kilidi kapatıldı."; }
    openVp(); if(/(test)/.test(t)&&VP.tpl){ setTimeout(test,400); return "Ses testini başlatıyorum, konuş."; }
    return "Ses kilidi sayfasını açtım.";
  }
  return prevOff?prevOff(text):null;
};
window.JV_voice={open:openVp,score:score,_vp:function(){ return VP; },_cap:cap};
})();
