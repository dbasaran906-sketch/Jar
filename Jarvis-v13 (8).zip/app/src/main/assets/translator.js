/* JARVİS TERCÜMAN MODU v2
   Karşı taraf konuşur -> Türkçesi balon olarak yazılır (isteğe bağlı sesli). Sen Türkçe yazar/konuşursun -> İngilizcesi okunur.
   Kamera çevirisi, hazır cümleler, karşıya göster (dev yazı), geçmiş, hız ayarı, 28 dil. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var toast=JV.toast, esc=JV.esc;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").trim(); }
function N(){ return window.JarvisNative||null; }

var LANGS=[["en-US","EN","İngilizce"],["de-DE","DE","Almanca"],["fr-FR","FR","Fransızca"],["es-ES","ES","İspanyolca"],["it-IT","IT","İtalyanca"],["ru-RU","RU","Rusça"],["ar-SA","AR","Arapça"],["zh-CN","ZH","Çince"],["ja-JP","JA","Japonca"],["ko-KR","KO","Korece"],["hi-IN","HI","Hintçe"],["pt-PT","PT","Portekizce"],["nl-NL","NL","Hollandaca"],["pl-PL","PL","Lehçe"],["uk-UA","UK","Ukraynaca"],["fa-IR","FA","Farsça"],["el-GR","EL","Yunanca"],["ro-RO","RO","Romence"],["bg-BG","BG","Bulgarca"],["sv-SE","SV","İsveççe"],["cs-CZ","CS","Çekçe"],["hu-HU","HU","Macarca"],["az-AZ","AZ","Azerice"],["he-IL","HE","İbranice"],["th-TH","TH","Tayca"],["id-ID","ID","Endonezce"],["vi-VN","VI","Vietnamca"]];
var ISO2LOC={}; LANGS.forEach(function(l){ ISO2LOC[l[0].slice(0,2)]=l[0]; }); ISO2LOC.tr="tr-TR";
function lname(code){ var l=LANGS.filter(function(x){ return x[0]===code; })[0]; return l?l[2]:(code==="auto"?"Otomatik":code); }
var QUICK=["en-US","de-DE","fr-FR","es-ES","ar-SA","ru-RU"];
var PHRASES=[["Tuvalet nerede?","Where is the restroom?"],["Hesap lütfen.","The check, please."],["Yardım eder misiniz?","Can you help me, please?"],["Bunun fiyatı ne kadar?","How much does this cost?"],["Anlamıyorum, daha yavaş konuşur musunuz?","I don't understand. Could you speak more slowly?"],["İngilizce biliyor musunuz?","Do you speak English?"],["Acil durum, ambulans çağırın!","It's an emergency, please call an ambulance!"],["Bu yere nasıl gidebilirim?","How can I get to this place?"],["Teşekkür ederim.","Thank you very much."],["Alerjim var.","I have an allergy."],["Kredi kartı kabul ediyor musunuz?","Do you accept credit cards?"],["Wi-Fi şifresi nedir?","What is the Wi-Fi password?"]];
var S=lsGet("jv_tr3",{lang:"auto",last:"en-US",voice:true,cont:false,rate:0.95});
var H=lsGet("jv_tr3h",[]);
var T={active:false,listening:false,mode:"other",busy:false,relistenT:0,retried:false,t0:0,more:false};

function mkPage(id,html){ var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d); return d; }
var pg=mkPage("pTr2",
 '<div class="ph"><button class="ib" data-close>←</button><h2>TERCÜMAN</h2></div>'+
 '<div class="pb" id="trBody">'+
 '<div class="sec"><div style="font-size:12px;color:var(--dim);margin-bottom:6px">Karşıdakinin dili</div><div id="trLangs" style="display:flex;flex-wrap:wrap;gap:6px"></div>'+
 '<div id="trMoreBox" style="display:none;margin-top:8px"><input class="inp" id="trSearch" placeholder="Dil ara…" style="margin:0 0 6px"><div id="trAll" style="display:flex;flex-wrap:wrap;gap:6px;max-height:140px;overflow:auto"></div></div>'+
 '<div id="trDet" style="font-size:13px;color:var(--c1);margin-top:8px;min-height:18px"></div></div>'+
 '<div class="sec"><div style="display:flex;gap:8px"><button class="btn" id="trListen" style="flex:1">🎙 KARŞIYI DİNLE</button><button class="btn" id="trVoice" style="flex:0 0 112px">🔊 SESLİ</button></div>'+
 '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-top:8px;font-size:13px"><label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="trCont"> Sürekli dinle</label><label style="display:flex;align-items:center;gap:6px;flex:1;min-width:150px">Hız <input type="range" id="trRate" min="60" max="130" value="95" style="flex:1"></label></div>'+
 '<div id="trSt" style="font-size:12px;color:var(--dim);margin-top:6px;min-height:16px"></div><div id="trLvl" style="height:4px;border-radius:2px;background:rgba(43,181,255,.15);margin-top:4px"><div id="trLvlB" style="height:100%;width:0;border-radius:2px;background:var(--c1);transition:width .08s"></div></div></div>'+
 '<div class="sec"><div id="trLog"></div><div style="display:flex;gap:8px;margin-top:6px"><button class="btn" id="trClr" style="flex:1;font-size:12px">GEÇMİŞİ TEMİZLE</button><button class="btn" id="trCam" style="flex:1;font-size:12px">📷 KAMERA ÇEVİRİSİ</button></div><div id="trCamOut"></div></div>'+
 '<div class="sec"><div style="font-size:12px;color:var(--dim);margin-bottom:6px">Türkçeni yaz ya da söyle → İngilizcesini okurum (sadece İngilizce)</div>'+
 '<div style="display:flex;gap:8px"><input class="inp" id="trIn" placeholder="Türkçe yaz…" style="flex:1;margin:0"><button class="btn" id="trMic" style="flex:0 0 52px">🎙</button></div>'+
 '<button class="btn" id="trGo" style="width:100%;margin-top:8px">İNGİLİZCEYE ÇEVİR VE OKU</button></div>'+
 '<div class="sec"><div style="font-size:12px;color:var(--dim);margin-bottom:6px">Hazır cümleler (tek dokunuşla okunur)</div><div id="trPh"></div></div>'+
 '<input type="file" id="trFile" accept="image/*" style="display:none"></div>');
var big=document.createElement("div"); big.id="trBig";
big.style.cssText="position:fixed;inset:0;z-index:60;background:#02070d;color:#fff;display:none;flex-direction:column;align-items:center;justify-content:center;padding:24px;text-align:center";
big.innerHTML='<div id="trBigT" style="font-size:9vw;line-height:1.25;font-weight:600;word-break:break-word"></div><div id="trBigS" style="margin-top:22px;font-size:14px;color:#7fb7d6"></div><button class="btn" id="trBigX" style="margin-top:28px;padding:12px 30px">KAPAT</button>';
document.body.appendChild(big);
var stl=document.createElement("style");
stl.textContent=
"#trLangs button,#trAll button{padding:7px 12px;border-radius:14px;border:1px solid var(--line,#1c4666);background:transparent;color:var(--c1);letter-spacing:1px;font-size:12px}"+
"#trLangs button.on,#trAll button.on{background:rgba(43,181,255,.22);box-shadow:0 0 10px var(--c1);color:#fff}"+
".trB{max-width:88%;border-radius:14px;padding:9px 12px;margin:6px 0;position:relative;border:1px solid var(--line,#1c4666)}"+
".trB.o{background:rgba(5,24,44,.7);margin-right:auto;border-top-left-radius:4px}.trB.m{background:rgba(70,36,6,.55);border-color:#7a4a1a;margin-left:auto;border-top-right-radius:4px}"+
".trB .s{font-size:11px;color:var(--dim)}.trB .t{font-size:17px;margin-top:3px;color:#e8f6ff}.trB.m .t{color:#ffd9b0}"+
".trB .a{display:flex;gap:10px;margin-top:6px}.trB .a span{font-size:11px;color:var(--c1);cursor:pointer;padding:2px 0}"+
"#trListen.live{background:rgba(255,138,31,.25);box-shadow:0 0 12px #ff8a1f}"+
"#trPh button{margin:3px;padding:7px 11px;border-radius:12px;border:1px solid var(--line,#1c4666);background:rgba(5,16,30,.5);color:#cfeaff;font-size:13px;text-align:left}";
document.head.appendChild(stl);

function setSt(t){ $("trSt").textContent=t||""; }
function setDet(t){ $("trDet").textContent=t||""; }
function save(){ lsSet("jv_tr3",S); }
function saveH(){ lsSet("jv_tr3h",H.slice(0,30)); }
function curLang(){ return S.lang==="auto"?(S.last||"en-US"):S.lang; }
function pick(code){ S.lang=code; if(code!=="auto") S.last=code; save(); renderLangs(); setDet(code==="auto"?"Otomatik: son dil "+lname(S.last)+" — algılanınca kendim değiştiririm":"Dil: "+lname(code)); }
function renderLangs(){
  var q=QUICK.slice(); if(S.lang!=="auto"&&q.indexOf(S.lang)<0) q.unshift(S.lang);
  $("trLangs").innerHTML='<button data-l="auto" class="'+(S.lang==="auto"?"on":"")+'">OTO</button>'+q.map(function(c){ var l=LANGS.filter(function(x){ return x[0]===c; })[0]; return '<button data-l="'+c+'" class="'+(S.lang===c?"on":"")+'">'+l[1]+'</button>'; }).join("")+'<button id="trMoreB">'+(T.more?"▲":"▼ DAHA FAZLA ("+LANGS.length+")")+'</button>';
  $("trLangs").querySelectorAll("button[data-l]").forEach(function(b){ b.onclick=function(){ pick(b.getAttribute("data-l")); }; });
  $("trMoreB").onclick=function(){ T.more=!T.more; $("trMoreBox").style.display=T.more?"block":"none"; renderLangs(); renderAll(); };
}
function renderAll(){
  var f=tl($("trSearch").value||"");
  $("trAll").innerHTML=LANGS.filter(function(l){ return !f||tl(l[2]).indexOf(f)>=0||tl(l[1]).indexOf(f)>=0; }).map(function(l){ return '<button data-l="'+l[0]+'" class="'+(S.lang===l[0]?"on":"")+'">'+l[1]+' · '+l[2]+'</button>'; }).join("");
  $("trAll").querySelectorAll("button").forEach(function(b){ b.onclick=function(){ pick(b.getAttribute("data-l")); renderAll(); }; });
}
$("trSearch").oninput=renderAll;
function renderVoice(){ $("trVoice").textContent=S.voice?"🔊 SESLİ":"🔇 SESSİZ"; $("trCont").checked=!!S.cont; $("trRate").value=Math.round((S.rate||0.95)*100); }
function renderPh(){
  $("trPh").innerHTML=PHRASES.map(function(p,i){ return '<button data-p="'+i+'">'+esc(p[0])+'</button>'; }).join("");
  $("trPh").querySelectorAll("button").forEach(function(b){ b.onclick=function(){ var p=PHRASES[+b.getAttribute("data-p")]; addBubble("m",p[0],p[1]); speakEn(p[1]); }; });
}
/* ---- balonlar ---- */
function addBubble(kind,src,txt,lang){
  H.unshift({k:kind,s:src,t:txt,l:lang||"",ts:Date.now()}); H=H.slice(0,30); saveH(); renderLog();
}
function renderLog(){
  if(!H.length){ $("trLog").innerHTML='<div style="font-size:13px;color:var(--dim)">Henüz konuşma yok. "KARŞIYI DİNLE"ye bas ya da aşağıya yaz.</div>'; return; }
  $("trLog").innerHTML=H.slice().reverse().map(function(h,ri){ var i=H.length-1-ri;
    return '<div class="trB '+h.k+'"><div class="s">'+(h.k==="o"?esc((h.l||"?")+" · "+h.s):"Sen: "+esc(h.s))+'</div><div class="t">'+esc(h.t)+'</div><div class="a">'+
      (h.k==="m"?'<span data-a="show" data-i="'+i+'">KARŞIYA GÖSTER</span><span data-a="again" data-i="'+i+'">TEKRAR OKU</span>':'<span data-a="again" data-i="'+i+'">OKU</span>')+'<span data-a="copy" data-i="'+i+'">KOPYALA</span></div></div>'; }).join("");
  $("trLog").querySelectorAll("[data-a]").forEach(function(b){ b.onclick=function(){ var h=H[+b.getAttribute("data-i")], a=b.getAttribute("data-a"); if(!h) return;
    if(a==="show") showBig(h.t,h.s); else if(a==="again"){ if(h.k==="m") speakEn(h.t); else { try{ N().speak(h.t); }catch(e){} } }
    else if(a==="copy"){ try{ N().copy(h.t); }catch(e){} toast("Kopyalandı"); } }; });
  var b=$("trBody"); if(b&&b.scrollTop!==undefined){ /* son balon görünür kalsın */ }
}
function showBig(t,sub){ $("trBigT").textContent=t; $("trBigS").textContent=sub||""; big.style.display="flex"; }
$("trBigX").onclick=function(){ big.style.display="none"; };
function speakEn(t){ try{ var n=N(); if(n.speakInRate) n.speakInRate(t,"en-US",S.rate||0.95); else n.speakIn(t,"en-US"); }catch(e){} }

/* ---- Karşı tarafı dinle ---- */
function listen(mode){
  var n=N(); if(!n||!n.listenIn){ toast("Bu sürümde tercüman dinleme yok"); return; }
  if(JV.isBusy()) return;
  T.mode=mode||"other"; T.listening=true; T.t0=Date.now();
  try{ n.stopSpeak(); }catch(e){}
  var lang=T.mode==="me"?"tr-TR":curLang();
  setSt(T.mode==="me"?"Seni dinliyorum (Türkçe)… konuş":"Dinliyorum ("+lname(curLang())+")… konuş");
  $("trListen").classList.toggle("live",T.mode==="other");
  try{ n.listenIn(lang,false); }catch(e){ T.listening=false; setSt("Dinleme açılamadı: "+e); }
}
function stopListen(){ clearTimeout(T.relistenT); T.listening=false; $("trListen").classList.remove("live"); $("trLvlB").style.width="0"; try{ var n=N(); if(n) n.stopListen(); }catch(e){} }
async function translateToTr(text){
  var prompt="Aşağıdaki metin bir ses tanıma çıktısı (tanıma dili: "+curLang()+"); yanlış dilde tanınmış ve bozuk olabilir. Önce metnin gerçekten hangi dilde söylendiğini tahmin et, sonra doğal ve anlaşılır Türkçeye çevir. Sadece JSON: {\"lang\":\"iki harfli ISO dil kodu\",\"tr\":\"Türkçe çeviri\",\"sure\":true veya false}.\nMetin: "+text;
  var raw=await JV.withTimeout(JV.aiText(prompt,true),20000,"çeviri zaman aşımı");
  var j=JV.parseJSON(raw)||{};
  return {lang:String(j.lang||"").toLowerCase().slice(0,2),tr:String(j.tr||"").trim(),sure:j.sure!==false};
}
async function handleOther(text){
  text=String(text||"").trim(); if(!text){ setSt("Duyamadım."); afterTurn(); return; }
  setSt("Çeviriyorum…"); T.busy=true;
  try{
    var r=await translateToTr(text);
    if(!r.tr){ setSt("Çevrilemedi."); T.busy=false; afterTurn(); return; }
    var loc=ISO2LOC[r.lang]||"", name=loc?lname(loc):(r.lang?r.lang.toUpperCase():"?");
    addBubble("o",text,r.tr,name); setSt("");
    if(S.lang==="auto"&&loc&&loc!==S.last&&r.sure&&r.lang!=="tr"){ S.last=loc; save(); setDet("Algılanan dil: "+name+" — bir sonraki dinlemede bu dil kullanılacak"); }
    if(S.voice){ try{ N().speak(r.tr); }catch(e){} }
  }catch(e){ setSt("Hata: "+((e&&e.message)||e)); }
  T.busy=false; afterTurn();
}
function afterTurn(){
  $("trListen").classList.remove("live"); $("trLvlB").style.width="0";
  if(T.active&&S.cont&&T.mode==="other"){
    clearTimeout(T.relistenT);
    (function waitRe(){ T.relistenT=setTimeout(function(){ if(!T.active||!S.cont) return; if(JV.isSpeaking()||T.busy){ waitRe(); return; } listen("other"); },700); })();
  }
}
/* ---- Sen konuşunca ---- */
async function toEnglish(text){
  text=String(text||"").trim(); if(!text) return;
  setSt("Çeviriliyor…");
  try{
    var raw=await JV.withTimeout(JV.aiText("Translate the following Turkish text into natural, clear, polite English. Output ONLY the English translation, nothing else.\n\n"+text,false),20000,"çeviri zaman aşımı");
    var en=String(raw||"").replace(/^["'\s]+|["'\s]+$/g,"");
    addBubble("m",text,en); setSt(""); $("trIn").value=""; speakEn(en);
  }catch(e){ setSt("Hata: "+((e&&e.message)||e)); }
}
/* ---- Kamera çevirisi ---- */
$("trCam").onclick=function(){ $("trFile").click(); };
$("trFile").onchange=function(){
  var f=this.files&&this.files[0]; if(!f) return; var inp=this;
  var r=new FileReader();
  r.onload=function(){ var im=new Image(); im.onload=async function(){
    var k=Math.min(1,1280/Math.max(im.width,im.height)), c=document.createElement("canvas"); c.width=Math.round(im.width*k); c.height=Math.round(im.height*k); c.getContext("2d").drawImage(im,0,0,c.width,c.height);
    var b64=c.toDataURL("image/jpeg",0.82).split(",")[1]; setSt("Yazı okunuyor ve çevriliyor…");
    try{
      var raw=await JV.withTimeout(JV.visionAI("Bu fotoğraftaki tüm yazıları oku ve doğal Türkçeye çevir. Önce yazının dilini söyle. Biçim: 'Dil: X' satırı, sonra çeviri. Yazı yoksa 'Yazı bulunamadı' de. Uydurma.",[{data:b64}],false),45000,"görüntü zaman aşımı");
      var t=String(raw||"").trim(); $("trCamOut").innerHTML='<div class="trB o"><div class="s">📷 Kamera çevirisi</div><div class="t" style="white-space:pre-wrap">'+esc(t)+'</div><div class="a"><span id="trCamR">OKU</span><span id="trCamC">KOPYALA</span></div></div>';
      $("trCamR").onclick=function(){ try{ N().speak(t.replace(/^Dil:.*\n/,"")); }catch(e){} }; $("trCamC").onclick=function(){ try{ N().copy(t); }catch(e){} toast("Kopyalandı"); };
      setSt("");
    }catch(e){ setSt("Hata: "+JV.errMsg(e)); }
  }; im.src=r.result; };
  r.readAsDataURL(f); inp.value="";
};
/* ---- Bağlantılar ---- */
$("trListen").onclick=function(){ if(T.listening){ stopListen(); setSt("Durdu."); } else { T.retried=false; listen("other"); } };
$("trVoice").onclick=function(){ S.voice=!S.voice; save(); renderVoice(); if(!S.voice){ try{ N().stopSpeak(); }catch(e){} } };
$("trCont").onchange=function(){ S.cont=this.checked; save(); };
$("trRate").oninput=function(){ S.rate=this.value/100; save(); };
$("trClr").onclick=function(){ H=[]; saveH(); renderLog(); $("trCamOut").innerHTML=""; };
$("trGo").onclick=function(){ toEnglish($("trIn").value); };
$("trIn").onkeydown=function(e){ if(e.key==="Enter"){ e.preventDefault(); toEnglish($("trIn").value); } };
$("trMic").onclick=function(){ stopListen(); T.retried=false; listen("me"); };
pg.addEventListener("click",function(e){ if(e.target.closest&&e.target.closest("[data-close]")) closeMode(); });

var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd, prevR=window.onRms;
window.onRms=function(v){ if(T.active&&T.listening){ try{ $("trLvlB").style.width=Math.max(2,Math.min(100,(v+2)*9))+"%"; }catch(e){} } if(prevR) prevR(v); };
window.JV_onSpeech=function(t,final){
  if(T.active&&T.listening){
    if(!final){ if(T.mode==="me") $("trIn").value=t; else setSt("… "+t); return true; }
    T.listening=false;
    if(T.mode==="me"){ $("trIn").value=t; toEnglish(t); $("trListen").classList.remove("live"); return true; }
    handleOther(t); return true;
  }
  return prevS?prevS(t,final):false;
};
window.JV_onListenEnd=function(err){
  if(T.active&&T.listening){
    T.listening=false; $("trListen").classList.remove("live"); $("trLvlB").style.width="0";
    var ms=Date.now()-T.t0;
    if(err===9){ setSt("Mikrofon izni gerekli (Ayarlar > İzinler)."); return true; }
    if(err===100){ setSt("Bu telefonda ses tanıma servisi yok."); return true; }
    if((err===7||err===6||err===5)&&!T.retried){ T.retried=true; setSt("Tekrar deniyorum…"); setTimeout(function(){ if(T.active&&!T.listening) listen(T.mode); },350); return true; }
    var why={1:"ağ zaman aşımı",2:"ağ hatası",3:"ses kaydı hatası",4:"sunucu hatası",5:"istemci hatası",6:"konuşma başlamadı",7:"anlaşılamadı",8:"tanıyıcı meşgul (başka bir şey mikrofonu kullanıyor olabilir)",10:"çok fazla istek",11:"sunucu bağlantısı koptu",12:"dil desteklenmiyor",13:"dil paketi yok"}[err]||"bilinmeyen";
    setSt("Duyulamadı — kod "+err+": "+why+" ("+Math.round(ms/100)/10+" sn)."+(err===12||err===13?" Telefon ayarlarından "+lname(curLang())+" ses tanıma dilini indir.":""));
    afterTurn(); return true;
  }
  return prevE?prevE(err):false;
};
function openMode(){
  T.active=true; renderLangs(); renderVoice(); renderLog(); renderPh(); setSt("");
  setDet(S.lang==="auto"?"Otomatik: son dil "+lname(S.last)+" — algılanınca kendim değiştiririm":"Dil: "+lname(S.lang));
  pg.classList.add("show");
}
function closeMode(){ T.active=false; stopListen(); big.style.display="none"; try{ N().stopSpeak(); }catch(e){} }
(function(){ var chips=$("chips"); if(!chips||!chips.appendChild||chips===DUMMY) return; var b=document.createElement("button"); b.id="cTr2"; b.textContent="🌐 TERCÜMAN"; b.onclick=openMode; chips.appendChild(b); })();
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/tercüman/.test(t)&&t.split(/\s+/).length<=5){
    if(/(kapat|durdur|bitir|çık)/.test(t)){ closeMode(); pg.classList.remove("show"); return "Tercüman modu kapatıldı."; }
    openMode(); return "Tercüman modu açık. Karşıdakini dinlemek için 'KARŞIYI DİNLE'ye bas, kendi cümleni yazarsan ya da söylersen İngilizcesini okurum.";
  }
  return prevOff?prevOff(text):null;
};
window.JV_translator={open:openMode,_S:S,_T:T,_handle:handleOther,_toEn:toEnglish};
})();
