/* Durdur tuşu: Jarvis konuşurken/düşünürken beliren ince neon halka. */
(function(){
var JV=window.JV; if(!JV) return;
var st=document.createElement("style");
st.textContent="#jvStop{position:absolute;right:16px;bottom:6px;width:34px;height:34px;border-radius:50%;border:1.5px solid var(--c2);background:rgba(255,138,31,.08);display:flex;align-items:center;justify-content:center;padding:0;opacity:0;pointer-events:none;transform:scale(.7);transition:opacity .25s,transform .25s,box-shadow .2s;z-index:6;-webkit-tap-highlight-color:transparent}"+
"#jvStop.on{opacity:.85;pointer-events:auto;transform:scale(1);box-shadow:0 0 10px rgba(255,138,31,.45)}"+
"#jvStop:active{transform:scale(.88);box-shadow:0 0 16px var(--c2)}"+
"#jvStop svg{width:12px;height:12px;fill:var(--c2);filter:drop-shadow(0 0 3px var(--c2))}";
document.head.appendChild(st);
var b=document.createElement("button"); b.id="jvStop"; b.setAttribute("aria-label","Durdur");
b.innerHTML='<svg viewBox="0 0 12 12"><rect x="1" y="1" width="10" height="10" rx="2"/></svg>';
var host=document.getElementById("orbwrap")||document.body; host.appendChild(b);
b.onclick=function(){ JV.stop(); b.classList.remove("on"); };
setInterval(function(){ var on=JV.isBusy()||JV.isSpeaking(); if(on!==b.classList.contains("on")) b.classList.toggle("on",on); },250);
})();
