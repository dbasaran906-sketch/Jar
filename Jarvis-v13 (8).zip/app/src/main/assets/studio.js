/* JARVİS Hologram Stüdyosu: X-ray / holo sohbet modellerini kaydeder, galeride saklar */
(function(){
"use strict";
var JV=window.JV; if(!JV) return;
var $=function(id){ return document.getElementById(id); };
var esc=JV.esc, KEY="jv_studio", MAX=30;
function load(){ try{ var a=JSON.parse(localStorage.getItem(KEY)||"[]"); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
function store(a){ try{ localStorage.setItem(KEY,JSON.stringify(a)); return true; }catch(e){ return false; } }

var st=document.createElement("style");
st.textContent=
"#pStudio{background:#020810!important}"+
"#stG{display:grid;grid-template-columns:1fr 1fr;gap:10px}"+
".stc{display:flex;flex-direction:column;gap:6px;padding:10px;border-radius:14px;border:1px solid var(--line);background:var(--panel);min-width:0}"+
".stc img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:10px;background:#041a2e;display:block}"+
".stc b{font-size:14px;color:var(--c1);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}"+
".stc small{color:var(--dim);font-size:11px}"+
".stc .bb{display:flex;gap:6px}.stc .bb .btn{flex:1;height:38px;padding:0;font-size:12px;display:inline-flex;align-items:center;justify-content:center}";
document.head.appendChild(st);

var pg=document.createElement("div"); pg.className="page"; pg.id="pStudio";
pg.innerHTML='<div class="ph"><button class="ib" data-close>←</button><h2>HOLOGRAM STÜDYOSU</h2></div><div class="pb"><div id="stN" style="font-size:13px;color:var(--dim);margin-bottom:12px"></div><div id="stG"></div></div>';
document.body.appendChild(pg);

function draw(){
  var a=load();
  $("stN").textContent=a.length?(a.length+" / "+MAX+" model kayıtlı. AÇ ile tekrar döndürebilir, parçalarını ayırabilirsin."):"Henüz model yok. X-ray hologramında ya da Holo Sohbet'te 💾 düğmesiyle kaydet.";
  $("stG").innerHTML=a.map(function(m,i){
    return '<div class="stc" data-i="'+i+'">'+(m.th?'<img alt="" src="'+m.th+'">':'<div style="aspect-ratio:4/3;border-radius:10px;background:#041a2e"></div>')+
      '<b>'+esc(m.name)+'</b><small>'+new Date(m.ts).toLocaleDateString("tr-TR")+' · '+m.spec.length+' parça</small>'+
      '<div class="bb"><button class="btn" data-a="o">AÇ</button><button class="btn red" data-a="d">SİL</button></div></div>';
  }).join("");
}
$("stG").addEventListener("click",function(e){
  var b=e.target.closest("button"); if(!b) return;
  var i=+b.closest(".stc").getAttribute("data-i"), a=load(), m=a[i]; if(!m) return;
  if(b.getAttribute("data-a")==="o"){
    if(window.JV_xrayH3&&window.JV_xrayH3.show(m.spec,m.name)){} else JV.toast("Model açılamadı");
  } else {
    if(b.getAttribute("data-s")!=="1"){ b.setAttribute("data-s","1"); b.textContent="EMİN MİSİN?"; setTimeout(function(){ b.removeAttribute("data-s"); b.textContent="SİL"; },3000); return; }
    a.splice(i,1); store(a); draw(); JV.toast("Silindi");
  }
});

function save(name,spec,th){
  var a=load();
  if(!spec||!spec.length){ JV.toast("Kaydedilecek model yok"); return false; }
  if(a.length>=MAX){ JV.toast("Stüdyo dolu ("+MAX+"). Önce birini sil."); return false; }
  name=String(name||"Model").slice(0,40);
  a.unshift({id:Date.now(),name:name,ts:Date.now(),spec:spec,th:th||""});
  if(!store(a)){ a.shift(); JV.toast("Kaydedilemedi: depolama dolu"); return false; }
  JV.toast("Stüdyoya kaydedildi: "+name); return true;
}
function open(){ draw(); pg.classList.add("show"); }
window.JV_studio={save:save,open:open,list:load};

var chips=$("chips");
if(chips){ var b=document.createElement("button"); b.id="cStudio"; b.textContent="🗂 STÜDYO"; b.onclick=open; chips.appendChild(b); }
})();
