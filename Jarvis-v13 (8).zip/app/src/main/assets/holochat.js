/* JARVİS Holo Sohbet: cevabı konuşur, konuyu 3D hologram olarak çizer. Temalar: Hacker, Iron, Alarm, Buz */
(function(){
"use strict";
var JV=window.JV; if(!JV) return;
var cfg=JV.cfg, $=function(id){ return document.getElementById(id); }, esc=JV.esc;
var TH={
 hacker:{n:"HACKER",c:[57,255,20],bg:"#000a02",rain:true},
 iron:{n:"IRON",c:[43,181,255],bg:"#02101c"},
 alarm:{n:"ALARM",c:[255,77,94],bg:"#14040a"},
 ice:{n:"BUZ",c:[159,246,255],bg:"#04101a"}
};
var hc={theme:cfg.hcTheme||"hacker",parts:[],spec:[],name:"",cx:0,cy:0,cz:0,R:1,yaw:0.6,pitch:0.35,fade:1,on:false,raf:0,busy:false,listening:false,lastT:0,drag:null,rain:[],rt:0,title:""};
if(!TH[hc.theme]) hc.theme="hacker";

var st=document.createElement("style");
st.textContent=
"#pHc{background:#000;overflow:hidden}"+
"#pHc canvas{position:absolute;inset:0;width:100%;height:100%}"+
"#pHc .hcT{position:relative;z-index:3;display:flex;align-items:center;gap:8px;padding:calc(env(safe-area-inset-top) + 10px) 12px 6px}"+
"#pHc .hcT h2{flex:1;margin:0;font-size:15px;letter-spacing:4px}"+
"#hcTh{position:relative;z-index:3;display:flex;gap:6px;padding:0 12px;overflow-x:auto;scrollbar-width:none}"+
"#hcTh button{flex:none;padding:7px 12px;border-radius:16px;border:1px solid var(--line);background:rgba(0,0,0,.5);font-size:11px;letter-spacing:2px;color:var(--dim)}"+
"#hcOut{position:absolute;z-index:3;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom) + 70px);max-height:34vh;overflow-y:auto;font-size:14px;line-height:1.5;padding:10px 12px;border-radius:14px;background:rgba(0,0,0,.55);border:1px solid var(--line);display:none}"+
"#hcOut .q{opacity:.65;margin-bottom:4px}"+
"#hcBar{position:absolute;z-index:3;left:10px;right:10px;bottom:calc(env(safe-area-inset-bottom) + 10px);display:flex;gap:8px;align-items:center}"+
"#hcIn{flex:1;min-width:0;height:46px;box-sizing:border-box;border-radius:23px;padding:0 16px;font-size:15px;background:rgba(0,0,0,.6);color:#fff;border:1px solid var(--line);outline:none}"+
"#hcBar .rb{flex:none}"+
"#hcSt{position:absolute;z-index:3;left:0;right:0;top:calc(env(safe-area-inset-top) + 96px);text-align:center;font-size:12px;letter-spacing:2px;color:var(--dim)}";
document.head.appendChild(st);

var pg=document.createElement("div"); pg.className="page"; pg.id="pHc";
pg.innerHTML='<canvas id="hcBg"></canvas><canvas id="hcM"></canvas>'+
 '<div class="hcT"><button class="ib" data-close>←</button><h2 id="hcH">HOLO SOHBET</h2><button class="btn" id="hcSv" style="padding:8px 12px">💾</button></div>'+
 '<div id="hcTh"></div><div id="hcSt">Bir şey sor, konuyu hologramda çizeyim.</div>'+
 '<div id="hcOut"></div>'+
 '<div id="hcBar"><input id="hcIn" placeholder="Bir şey sor…" autocomplete="off"><button class="rb" id="hcMic">🎤</button><button class="rb" id="hcGo">➤</button></div>';
document.body.appendChild(pg);

function col(a){ var c=TH[hc.theme].c; return "rgba("+c[0]+","+c[1]+","+c[2]+","+a+")"; }
function themeBtns(){
  $("hcTh").innerHTML=Object.keys(TH).map(function(k){ var c=TH[k].c, on=k===hc.theme; return '<button data-t="'+k+'" style="'+(on?'color:rgb('+c+');border-color:rgb('+c+');box-shadow:0 0 10px rgba('+c+',.5)':'')+'">'+TH[k].n+'</button>'; }).join("");
  $("hcH").style.color="rgb("+TH[hc.theme].c+")"; $("hcOut").style.color="rgb("+TH[hc.theme].c+")";
  pg.style.background=TH[hc.theme].bg; $("hcOut").style.fontFamily=hc.theme==="hacker"?"monospace":"inherit";
}
$("hcTh").addEventListener("click",function(e){ var b=e.target.closest("button"); if(!b) return; hc.theme=b.getAttribute("data-t"); cfg.hcTheme=hc.theme; JV.saveCfg(); themeBtns(); hc.rain=[]; });

/* ---- vektör yardımcıları ---- */
function sub(a,b){ return [a[0]-b[0],a[1]-b[1],a[2]-b[2]]; }
function cross(a,b){ return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]; }
function norm(a){ var l=Math.hypot(a[0],a[1],a[2])||1; return [a[0]/l,a[1]/l,a[2]/l]; }
function setModel(arr){
  var parts=window.JV_xrayH3.build(arr); if(!parts) return false;
  var mn=[1e9,1e9,1e9], mx=[-1e9,-1e9,-1e9], n=0;
  parts.forEach(function(p){ p.faces.forEach(function(f){ f.forEach(function(q){ for(var k=0;k<3;k++){ if(q[k]<mn[k])mn[k]=q[k]; if(q[k]>mx[k])mx[k]=q[k]; } }); n++; }); });
  hc.cx=(mn[0]+mx[0])/2; hc.cy=(mn[1]+mx[1])/2; hc.cz=(mn[2]+mx[2])/2; hc.R=Math.max(0.01,Math.hypot(mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2])/2);
  hc.parts=parts; hc.spec=arr; hc.fade=0; return true;
}

/* ---- çizim ---- */
function loop(ts){
  if(!hc.on) return; hc.raf=requestAnimationFrame(loop);
  if(ts-hc.lastT<33) return; var dt=ts-hc.lastT; hc.lastT=ts;
  drawBg(ts); drawModel(ts,dt);
}
function size(cv){ var dpr=Math.min(window.devicePixelRatio||1,1.5), W=cv.clientWidth, H=cv.clientHeight; if(W&&(cv.width!==Math.round(W*dpr)||cv.height!==Math.round(H*dpr))){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); } return [W,H,dpr]; }
function drawBg(ts){
  var cv=$("hcBg"), s=size(cv), W=s[0], H=s[1]; if(!W) return; var c=cv.getContext("2d"); c.setTransform(s[2],0,0,s[2],0,0);
  if(hc.theme==="hacker"){
    if(ts-hc.rt<70) return; hc.rt=ts; var cw=16, n=Math.floor(W/cw);
    if(hc.rain.length!==n){ hc.rain=[]; for(var i=0;i<n;i++) hc.rain.push(Math.random()*H/cw); c.fillStyle="#000a02"; c.fillRect(0,0,W,H); }
    c.fillStyle="rgba(0,10,2,.14)"; c.fillRect(0,0,W,H); c.font="14px monospace";
    for(var i2=0;i2<n;i2++){ var ch=String.fromCharCode(0x30A0+Math.random()*60|0); c.fillStyle=Math.random()<0.06?"#d6ffd0":"rgba(57,255,20,.75)"; c.fillText(ch,i2*cw,hc.rain[i2]*cw); if(hc.rain[i2]*cw>H&&Math.random()>0.97) hc.rain[i2]=0; else hc.rain[i2]+=1; }
  } else {
    c.fillStyle=TH[hc.theme].bg; c.fillRect(0,0,W,H); var g=c.createRadialGradient(W/2,H*0.4,10,W/2,H*0.4,Math.max(W,H)*0.75); g.addColorStop(0,col(0.16)); g.addColorStop(1,TH[hc.theme].bg); c.fillStyle=g; c.fillRect(0,0,W,H);
    c.strokeStyle=col(0.12); c.lineWidth=1; for(var y=((ts/40)%24); y<H; y+=24){ c.beginPath(); c.moveTo(0,y); c.lineTo(W,y); c.stroke(); }
  }
}
function drawModel(ts,dt){
  var cv=$("hcM"), s=size(cv), W=s[0], H=s[1]; if(!W) return; var c=cv.getContext("2d"); c.setTransform(s[2],0,0,s[2],0,0); c.clearRect(0,0,W,H);
  var cx=W/2, cy=H*0.36, base=Math.min(W,H*0.7)*0.36;
  /* taban halkaları */
  c.strokeStyle=col(0.5); c.lineWidth=1.5; for(var r=0;r<3;r++){ c.beginPath(); c.ellipse(cx,cy+base*1.05,base*(0.7+r*0.28),base*(0.7+r*0.28)*0.22,0,0,6.3); c.globalAlpha=0.7-r*0.2; c.stroke(); } c.globalAlpha=1;
  if(!hc.parts.length){ c.strokeStyle=col(0.6); c.beginPath(); c.arc(cx,cy,base*0.45+Math.sin(ts/300)*5,0,6.3); c.stroke(); return; }
  if(!hc.drag) hc.yaw+=dt*0.0004;
  if(hc.fade<1) hc.fade=Math.min(1,hc.fade+dt/700);
  var S=base/hc.R, F=3.2*hc.R, cyw=Math.cos(hc.yaw), syw=Math.sin(hc.yaw), cp=Math.cos(hc.pitch), sp=Math.sin(hc.pitch);
  var L=norm([-0.4,0.6,-0.7]), fl=[], tc=TH[hc.theme].c;
  hc.parts.forEach(function(p){
    p.faces.forEach(function(f){
      var pts=[], rs=[], zs=0, k;
      for(k=0;k<f.length;k++){
        var x=f[k][0]-hc.cx, y=f[k][1]-hc.cy, z=f[k][2]-hc.cz, x1=x*cyw+z*syw, z1=-x*syw+z*cyw, y1=y*cp-z1*sp, z2=y*sp+z1*cp, fc=F/(F+z2);
        rs.push([x1,y1,z2]); pts.push([cx+x1*S*fc,cy-y1*S*fc]); zs+=z2;
      }
      var nv=norm(cross(sub(rs[1],rs[0]),sub(rs[2],rs[0]))); if(nv[2]>0) nv=[-nv[0],-nv[1],-nv[2]];
      var df=Math.max(0,nv[0]*L[0]+nv[1]*L[1]+nv[2]*L[2]), lt=0.3+0.7*df;
      fl.push({p:pts,z:zs/f.length,lt:lt,pc:p.col});
    });
  });
  fl.sort(function(a,b){ return b.z-a.z; });
  var a=hc.fade;
  fl.forEach(function(q){
    var mix=hc.theme==="hacker"?0:0.35, r=(tc[0]*(1-mix)+q.pc[0]*mix)*q.lt, g=(tc[1]*(1-mix)+q.pc[1]*mix)*q.lt, b=(tc[2]*(1-mix)+q.pc[2]*mix)*q.lt;
    c.globalAlpha=0.62*a; c.fillStyle="rgb("+(r|0)+","+(g|0)+","+(b|0)+")"; c.beginPath(); c.moveTo(q.p[0][0],q.p[0][1]); for(var k=1;k<q.p.length;k++) c.lineTo(q.p[k][0],q.p[k][1]); c.closePath(); c.fill();
    c.globalAlpha=0.55*a; c.strokeStyle="rgb("+tc[0]+","+tc[1]+","+tc[2]+")"; c.lineWidth=0.7; c.stroke();
  });
  c.globalAlpha=1;
  /* tarama çizgisi */
  var sy=cy-base+((ts/12)%(base*2.2)); c.fillStyle=col(0.18); c.fillRect(cx-base*1.1,sy,base*2.2,3);
}
pg.addEventListener("pointerdown",function(e){ if(e.target.closest("button,input,#hcOut")) return; hc.drag={x:e.clientX,y:e.clientY}; try{ pg.setPointerCapture(e.pointerId); }catch(er){} });
pg.addEventListener("pointermove",function(e){ if(!hc.drag) return; hc.yaw+=(e.clientX-hc.drag.x)*0.012; hc.pitch=Math.max(-1.2,Math.min(1.2,hc.pitch+(e.clientY-hc.drag.y)*0.008)); hc.drag={x:e.clientX,y:e.clientY}; });
pg.addEventListener("pointerup",function(){ hc.drag=null; }); pg.addEventListener("pointercancel",function(){ hc.drag=null; });

/* ---- sohbet ---- */
function status(t){ $("hcSt").textContent=t||""; }
function line(who,t,type){
  var o=$("hcOut"); o.style.display="block";
  if(who==="q"){ o.innerHTML='<div class="q">&gt; '+esc(t)+'</div><div id="hcA"></div>'; return; }
  var a=$("hcA"); if(!a) return;
  if(hc.theme==="hacker"&&type){ var i=0, tx=String(t).slice(0,500); clearInterval(hc.ty); hc.ty=setInterval(function(){ i+=2; a.textContent=tx.slice(0,i)+(i<tx.length?"▌":""); o.scrollTop=o.scrollHeight; if(i>=tx.length) clearInterval(hc.ty); },22); }
  else a.textContent=t;
}
function clean(t){ return String(t).replace(/[*_`#>]/g,"").replace(/\s+/g," ").trim(); }
function modelPrompt(q,ans){
  return 'Konu: "'+q+'". Kısa cevap: "'+String(ans).slice(0,200)+'". Bu konuyu en iyi temsil eden TEK somut nesnenin (somut bir şey yoksa konuyu simgeleyen bir sembolün; örneğin bilgi için kitap, zaman için saat) 3 boyutlu, renkli, basit KATI modelini çiz: en çok 14 parça, hepsi grup="dis". '+window.JV_xrayH3.spec;
}
async function ask(q){
  q=String(q||"").trim(); if(!q||hc.busy) return; hc.busy=true; $("hcIn").value=""; try{ JV.stop(); }catch(e){}
  hc.title=q; line("q",q); status("DÜŞÜNÜYORUM…");
  try{
    var pt=window.JV_persona?window.JV_persona.text():"";
    var ans=await JV.withTimeout(JV.aiText("Sen JARVİS'sin."+(pt?" Karakterin: "+pt:"")+" Kullanıcıya Türkçe, en fazla 3 kısa cümleyle cevap ver. Markdown ve liste kullanma. Kullanıcı: "+q),45000,"cevap zaman aşımı");
    ans=clean(ans)||"Bunu çözemedim efendim.";
    line("a",ans,true); status("HOLOGRAM ÇİZİLİYOR…"); try{ JV.say(ans); }catch(e){}
    try{
      var raw=await JV.withTimeout(JV.aiText(modelPrompt(q,ans),true),50000,"model zaman aşımı");
      var arr=window.JV_xrayH3.salvage(raw);
      if(arr.length>=3&&setModel(arr)){ status("HOLOGRAM HAZIR · parmakla çevir"); }
      else status("Model çıkmadı; önceki hologram duruyor.");
    }catch(e2){ status("Model çıkmadı: "+JV.errMsg(e2)); }
  }catch(e){ line("a","Hata: "+JV.errMsg(e)); status(""); }
  hc.busy=false;
}
$("hcGo").onclick=function(){ ask($("hcIn").value); };
$("hcIn").addEventListener("keydown",function(e){ if(e.key==="Enter"){ e.preventDefault(); ask(this.value); } });
$("hcMic").onclick=function(){
  if(hc.listening){ hc.listening=false; try{ JV.stopListen(); }catch(e){} this.textContent="🎤"; this.classList.remove("on"); return; }
  try{ JV.stop(); }catch(e){} hc.listening=true; this.textContent="●"; this.classList.add("on"); status("DİNLİYORUM…"); JV.listen();
};
var prevSp=window.JV_onSpeech;
window.JV_onSpeech=function(t,final){
  if(hc.listening&&hc.on){
    $("hcIn").value=t;
    if(final){ hc.listening=false; $("hcMic").textContent="🎤"; $("hcMic").classList.remove("on"); ask(t); }
    return true;
  }
  return prevSp?prevSp(t,final):false;
};
$("hcSv").onclick=function(){
  if(!hc.spec.length){ JV.toast("Önce bir hologram çizdir"); return; }
  var th=""; try{ var cv=$("hcM"), t=document.createElement("canvas"); t.width=200; t.height=Math.max(60,Math.round(200*cv.height/Math.max(1,cv.width))); var x=t.getContext("2d"); x.fillStyle=TH[hc.theme].bg; x.fillRect(0,0,t.width,t.height); x.drawImage(cv,0,0,t.width,t.height); th=t.toDataURL("image/jpeg",0.6); }catch(e){}
  if(window.JV_studio) window.JV_studio.save(hc.title||"Holo model",hc.spec,th);
};

function open(){
  if(!window.JV_xrayH3){ JV.toast("X-ray modülü yüklenmedi"); return; }
  themeBtns(); pg.classList.add("show"); hc.on=true; hc.lastT=0; cancelAnimationFrame(hc.raf); hc.raf=requestAnimationFrame(loop);
}
function stop(){ hc.on=false; cancelAnimationFrame(hc.raf); clearInterval(hc.ty); if(hc.listening){ hc.listening=false; try{ JV.stopListen(); }catch(e){} $("hcMic").textContent="🎤"; $("hcMic").classList.remove("on"); } }
new MutationObserver(function(){ if(!pg.classList.contains("show")) stop(); }).observe(pg,{attributes:true,attributeFilter:["class"]});
window.JV_holochat={open:open};
var chips=$("chips");
if(chips){ var b=document.createElement("button"); b.id="cHc"; b.textContent="🌐 HOLO SOHBET"; b.onclick=open; chips.appendChild(b); }
})();
