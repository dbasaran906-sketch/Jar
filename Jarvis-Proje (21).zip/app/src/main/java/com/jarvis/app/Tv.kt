package com.jarvis.app

import android.annotation.SuppressLint
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.security.auth.x500.X500Principal

/**
 * Android TV / Google TV uzaktan kumanda protokolü (v2) için küçük istemci.
 * Eşleşme 6467, kumanda 6466 portundan TLS ile yapılır. Protobuf mesajları elle kodlanır.
 */
object Tv {
    private const val ALIAS = "jarvis_tv2"
    private const val OLD_ALIAS = "jarvis_tv"
    private const val PREFS = "jarvis_kv"

    // ---------- Protobuf yardımcıları ----------

    private fun varintBytes(v0: Long): ByteArray {
        var v = v0
        val o = ByteArrayOutputStream()
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) {
                o.write(v.toInt())
                break
            } else {
                o.write(((v and 0x7F) or 0x80).toInt())
                v = v ushr 7
            }
        }
        return o.toByteArray()
    }

    private class Msg {
        private val o = ByteArrayOutputStream()

        fun vi(f: Int, v: Long): Msg {
            o.write(varintBytes(((f shl 3) or 0).toLong()))
            o.write(varintBytes(v))
            return this
        }

        fun by(f: Int, b: ByteArray): Msg {
            o.write(varintBytes(((f shl 3) or 2).toLong()))
            o.write(varintBytes(b.size.toLong()))
            o.write(b)
            return this
        }

        fun str(f: Int, s: String): Msg = by(f, s.toByteArray(Charsets.UTF_8))
        fun msg(f: Int, m: Msg): Msg = by(f, m.bytes())
        fun bytes(): ByteArray = o.toByteArray()
    }

    private fun readVarint(inp: InputStream): Long {
        var shift = 0
        var result = 0L
        while (shift < 64) {
            val b = inp.read()
            if (b < 0) return -1
            result = result or ((b and 0x7F).toLong() shl shift)
            if ((b and 0x80) == 0) return result
            shift += 7
        }
        return -1
    }

    /** Alan numarası -> değerler (Long ya da ByteArray). */
    private fun parse(b: ByteArray): Map<Int, List<Any>> {
        val out = HashMap<Int, MutableList<Any>>()
        var i = 0
        fun rv(): Long {
            var shift = 0
            var r = 0L
            while (i < b.size && shift < 64) {
                val x = b[i++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl shift)
                if ((x and 0x80) == 0) return r
                shift += 7
            }
            return r
        }
        while (i < b.size) {
            val tag = rv().toInt()
            val field = tag ushr 3
            when (tag and 7) {
                0 -> out.getOrPut(field) { mutableListOf() }.add(rv())
                2 -> {
                    val len = rv().toInt()
                    if (len < 0 || i + len > b.size) return out
                    out.getOrPut(field) { mutableListOf() }.add(b.copyOfRange(i, i + len))
                    i += len
                }
                1 -> i += 8
                5 -> i += 4
                else -> return out
            }
        }
        return out
    }

    private fun Map<Int, List<Any>>.long(f: Int): Long? = (this[f]?.firstOrNull() as? Long)
    private fun Map<Int, List<Any>>.sub(f: Int): Map<Int, List<Any>>? =
        (this[f]?.firstOrNull() as? ByteArray)?.let { parse(it) }

    private fun writeFrame(out: java.io.OutputStream, m: Msg) {
        val p = m.bytes()
        out.write(varintBytes(p.size.toLong()))
        out.write(p)
        out.flush()
    }

    private fun readFrame(inp: InputStream): Map<Int, List<Any>>? {
        val len = readVarint(inp)
        if (len < 0 || len > 1_000_000) return null
        val buf = ByteArray(len.toInt())
        var off = 0
        while (off < buf.size) {
            val n = inp.read(buf, off, buf.size - off)
            if (n < 0) return null
            off += n
        }
        return parse(buf)
    }

    // ---------- TLS ----------

    private fun ensureKey(ks: KeyStore) {
        try {
            if (ks.containsAlias(OLD_ALIAS)) ks.deleteEntry(OLD_ALIAS)
        } catch (e: Exception) {
        }
        if (ks.containsAlias(ALIAS)) return
        val now = System.currentTimeMillis()
        val spec = KeyGenParameterSpec.Builder(
            ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setDigests(
                KeyProperties.DIGEST_NONE,
                KeyProperties.DIGEST_SHA1,
                KeyProperties.DIGEST_SHA256,
                KeyProperties.DIGEST_SHA384,
                KeyProperties.DIGEST_SHA512
            )
            .setSignaturePaddings(
                KeyProperties.SIGNATURE_PADDING_RSA_PKCS1,
                KeyProperties.SIGNATURE_PADDING_RSA_PSS
            )
            .setKeySize(2048)
            .setCertificateSubject(X500Principal("CN=jarvis-remote"))
            .setCertificateSerialNumber(BigInteger.valueOf(now))
            .setCertificateNotBefore(Date(now - 86400000L))
            .setCertificateNotAfter(Date(now + 20L * 365 * 86400000L))
            .build()
        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
        kpg.initialize(spec)
        kpg.generateKeyPair()
    }

    private fun clientCert(): X509Certificate {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        ensureKey(ks)
        return ks.getCertificate(ALIAS) as X509Certificate
    }

    @SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
    private fun open(host: String, port: Int): SSLSocket {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        ensureKey(ks)
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, null)
        val tm = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })
        val c = SSLContext.getInstance("TLS")
        c.init(kmf.keyManagers, tm, SecureRandom())
        // Önce TLS 1.2 (AndroidKeyStore RSA anahtarıyla en uyumlu), olmazsa varsayılan.
        var last: Exception? = null
        for (proto in arrayOf("TLSv1.2", "")) {
            val s = c.socketFactory.createSocket() as SSLSocket
            try {
                if (proto.isNotEmpty()) s.enabledProtocols = arrayOf(proto)
                s.connect(InetSocketAddress(host, port), 4000)
                s.soTimeout = 8000
                s.startHandshake()
                return s
            } catch (e: Exception) {
                last = e
                try {
                    s.close()
                } catch (x: Exception) {
                }
                if (e is java.net.ConnectException || e is SocketTimeoutException) throw e
            }
        }
        throw last ?: RuntimeException("TLS bağlantısı kurulamadı")
    }

    private fun hexBytes(n: BigInteger): ByteArray {
        var h = n.toString(16)
        if (h.length % 2 == 1) h = "0$h"
        return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    // ---------- Kayıt ----------

    fun host(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("tv_host", "") ?: ""
    fun paired(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("tv_paired", false)
    fun setHost(ctx: Context, h: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("tv_host", h).apply()
    }

    // ---------- Eşleşme ----------

    private var pairSock: SSLSocket? = null

    private fun pairMsg(inner: Int, body: Msg?): Msg {
        val m = Msg().vi(1, 2).vi(2, 200)
        if (body != null) m.msg(inner, body)
        return m
    }

    fun pairStart(host: String): String {
        try {
            pairSock?.close()
        } catch (e: Exception) {
        }
        val s = open(host, 6467)
        pairSock = s
        val out = s.outputStream
        val inp = s.inputStream
        writeFrame(out, pairMsg(10, Msg().str(1, "atvremote").str(2, "Jarvis")))
        val r1 = readFrame(inp) ?: return "TV cevap vermedi."
        if (r1.long(2) != 200L) return "TV eşleşmeyi reddetti."
        val enc = Msg().vi(1, 3).vi(2, 6)
        writeFrame(out, pairMsg(20, Msg().msg(1, enc).vi(3, 1)))
        readFrame(inp) ?: return "TV seçenek cevabı vermedi."
        writeFrame(out, pairMsg(30, Msg().msg(1, enc).vi(2, 1)))
        val r3 = readFrame(inp) ?: return "TV ayar cevabı vermedi."
        if (r3.long(2) != 200L) return "TV ayarı kabul etmedi."
        setHost(Plus.ctxHolder!!, host)
        return "ok"
    }

    fun pairFinish(code0: String): String {
        val s = pairSock ?: return "Önce eşleşmeyi başlat."
        val code = code0.trim().uppercase().filter { it.isDigit() || it in 'A'..'F' }
        if (code.length != 6) return "Kod 6 karakter olmalı (örn. 1A2B3C)."
        val cb = ByteArray(3) { code.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val serverKey = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
        val clientKey = clientCert().publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(hexBytes(clientKey.modulus))
        md.update(hexBytes(clientKey.publicExponent))
        md.update(hexBytes(serverKey.modulus))
        md.update(hexBytes(serverKey.publicExponent))
        md.update(cb.copyOfRange(1, 3))
        val secret = md.digest()
        if (secret[0] != cb[0]) return "Kod yanlış görünüyor, TV'deki kodu tekrar kontrol et."
        writeFrame(s.outputStream, pairMsg(40, Msg().by(1, secret)))
        val r = readFrame(s.inputStream) ?: return "TV onay vermedi."
        try {
            s.close()
        } catch (e: Exception) {
        }
        pairSock = null
        if (r.long(2) != 200L) return "Eşleşme reddedildi, kodu yeniden iste."
        Plus.ctxHolder?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.putBoolean("tv_paired", true)?.apply()
        return "ok"
    }

    // ---------- Kumanda oturumu ----------

    private class Remote(val sock: SSLSocket) {
        val inp: InputStream = sock.inputStream
        val out = sock.outputStream
        var started = false
        var isOn = false
        var vol = -1
        var volMax = 100
        var err = ""

        private fun device(): Msg =
            Msg().str(1, "Jarvis").str(2, "Google").vi(3, 1).str(4, "1").str(5, "com.jarvis.app").str(6, "1.0")

        fun handle(m: Map<Int, List<Any>>) {
            if (m.containsKey(1)) writeFrame(out, Msg().msg(1, Msg().vi(1, 622).msg(2, device())))
            if (m.containsKey(2)) writeFrame(out, Msg().msg(2, Msg().vi(1, 622)))
            m.sub(8)?.let { p ->
                writeFrame(out, Msg().msg(9, Msg().vi(1, p.long(1) ?: 0)))
            }
            m.sub(40)?.let { st ->
                started = true
                isOn = (st.long(1) ?: 0L) == 1L
            }
            m.sub(50)?.let { v ->
                v.long(7)?.let { vol = it.toInt() }
                v.long(6)?.let { volMax = it.toInt() }
            }
            if (m.containsKey(3)) err = "TV hata bildirdi."
        }

        /** Mesajları ms süre boyunca ya da koşul gerçekleşene kadar işler. */
        fun pump(ms: Long, until: () -> Boolean) {
            val end = System.currentTimeMillis() + ms
            sock.soTimeout = 600
            while (System.currentTimeMillis() < end && !until()) {
                try {
                    val m = readFrame(inp) ?: break
                    handle(m)
                } catch (e: SocketTimeoutException) {
                    // devam
                }
            }
        }

        fun key(code: Int) {
            writeFrame(out, Msg().msg(10, Msg().vi(1, code.toLong()).vi(2, 3)))
        }

        fun launch(link: String) {
            writeFrame(out, Msg().msg(90, Msg().str(1, link)))
        }

        fun close() {
            try {
                sock.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun connect(ctx: Context): Remote {
        val h = host(ctx)
        if (h.isEmpty()) throw RuntimeException("Televizyon kayıtlı değil. Önce TV sayfasından eşleştir.")
        val r = Remote(open(h, 6466))
        r.pump(4000) { r.started }
        return r
    }

    private fun friendlyFail(e: Exception): String = when (e) {
        is java.net.ConnectException, is SocketTimeoutException, is java.net.NoRouteToHostException ->
            "Televizyona ulaşamadım. Kapalı ya da başka bir Wi-Fi'da olabilir. TV ayarlarında ağdan uyandırma açık değilse kapalıyken açılamaz."
        else -> "TV hatası: " + (e.message ?: e.javaClass.simpleName)
    }

    fun power(ctx: Context, on: Boolean?): String {
        return try {
            val r = connect(ctx)
            try {
                if (on == true && r.isOn) return "Televizyon zaten açık."
                if (on == false && r.started && !r.isOn) return "Televizyon zaten kapalı."
                r.key(26)
                r.pump(600) { false }
                if (on == false) "Televizyon kapatıldı." else "Televizyon açıldı."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun key(ctx: Context, code: Int, times: Int = 1): String {
        return try {
            val r = connect(ctx)
            try {
                repeat(times.coerceIn(1, 60)) {
                    r.key(code)
                    Thread.sleep(110)
                }
                "Tamam."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun launch(ctx: Context, link: String): String {
        return try {
            val r = connect(ctx)
            try {
                r.launch(link)
                r.pump(500) { false }
                "Açıldı."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun volume(ctx: Context, level: Int): String {
        return try {
            val r = connect(ctx)
            try {
                val target = level.coerceIn(0, 100)
                if (r.vol < 0) r.pump(2500) { r.vol >= 0 }
                if (r.vol >= 0) {
                    val tgt = if (r.volMax != 100 && r.volMax > 0) (target * r.volMax / 100) else target
                    val diff = tgt - r.vol
                    val code = if (diff > 0) 24 else 25
                    repeat(kotlin.math.abs(diff).coerceAtMost(100)) {
                        r.key(code)
                        Thread.sleep(90)
                    }
                    "Ses $target yapıldı."
                } else {
                    repeat(100) {
                        r.key(25)
                        Thread.sleep(40)
                    }
                    repeat(target) {
                        r.key(24)
                        Thread.sleep(90)
                    }
                    "Ses yaklaşık $target yapıldı (TV mevcut seviyeyi bildirmedi)."
                }
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }
}
