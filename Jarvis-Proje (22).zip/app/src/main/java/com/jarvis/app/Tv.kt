package com.jarvis.app

import android.annotation.SuppressLint
import android.content.Context
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Android TV / Google TV uzaktan kumanda protokolü (v2) için küçük istemci.
 * Eşleşme 6467, kumanda 6466 portundan TLS ile yapılır. Protobuf mesajları elle kodlanır.
 */
object Tv {
    private const val PREFS = "jarvis_kv"

    // ---------- Protobuf yardımcıları ----------

    private fun varintBytes(v0: Long): ByteArray {
        var v = v0
        val o = ByteArrayOutputStream()
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) {
                o.write(v.toInt())
                break
            } else {
                o.write(((v and 0x7F) or 0x80).toInt())
                v = v ushr 7
            }
        }
        return o.toByteArray()
    }

    private class Msg {
        private val o = ByteArrayOutputStream()

        fun vi(f: Int, v: Long): Msg {
            o.write(varintBytes(((f shl 3) or 0).toLong()))
            o.write(varintBytes(v))
            return this
        }

        fun by(f: Int, b: ByteArray): Msg {
            o.write(varintBytes(((f shl 3) or 2).toLong()))
            o.write(varintBytes(b.size.toLong()))
            o.write(b)
            return this
        }

        fun str(f: Int, s: String): Msg = by(f, s.toByteArray(Charsets.UTF_8))
        fun msg(f: Int, m: Msg): Msg = by(f, m.bytes())
        fun bytes(): ByteArray = o.toByteArray()
    }

    private fun readVarint(inp: InputStream): Long {
        var shift = 0
        var result = 0L
        while (shift < 64) {
            val b = inp.read()
            if (b < 0) return -1
            result = result or ((b and 0x7F).toLong() shl shift)
            if ((b and 0x80) == 0) return result
            shift += 7
        }
        return -1
    }

    /** Alan numarası -> değerler (Long ya da ByteArray). */
    private fun parse(b: ByteArray): Map<Int, List<Any>> {
        val out = HashMap<Int, MutableList<Any>>()
        var i = 0
        fun rv(): Long {
            var shift = 0
            var r = 0L
            while (i < b.size && shift < 64) {
                val x = b[i++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl shift)
                if ((x and 0x80) == 0) return r
                shift += 7
            }
            return r
        }
        while (i < b.size) {
            val tag = rv().toInt()
            val field = tag ushr 3
            when (tag and 7) {
                0 -> out.getOrPut(field) { mutableListOf() }.add(rv())
                2 -> {
                    val len = rv().toInt()
                    if (len < 0 || i + len > b.size) return out
                    out.getOrPut(field) { mutableListOf() }.add(b.copyOfRange(i, i + len))
                    i += len
                }
                1 -> i += 8
                5 -> i += 4
                else -> return out
            }
        }
        return out
    }

    private fun Map<Int, List<Any>>.long(f: Int): Long? = (this[f]?.firstOrNull() as? Long)
    private fun Map<Int, List<Any>>.sub(f: Int): Map<Int, List<Any>>? =
        (this[f]?.firstOrNull() as? ByteArray)?.let { parse(it) }

    private fun writeFrame(out: java.io.OutputStream, m: Msg) {
        val p = m.bytes()
        out.write(varintBytes(p.size.toLong()))
        out.write(p)
        out.flush()
    }

    private fun readFrame(inp: InputStream): Map<Int, List<Any>>? {
        val len = readVarint(inp)
        if (len < 0 || len > 1_000_000) return null
        val buf = ByteArray(len.toInt())
        var off = 0
        while (off < buf.size) {
            val n = inp.read(buf, off, buf.size - off)
            if (n < 0) return null
            off += n
        }
        return parse(buf)
    }

    // ---------- TLS (yazılım anahtarı + elle üretilen sertifika) ----------

    private val PW = "jarvis".toCharArray()
    private var idKey: PrivateKey? = null
    private var idCert: X509Certificate? = null

    private fun dlen(n: Int): ByteArray = when {
        n < 128 -> byteArrayOf(n.toByte())
        n < 256 -> byteArrayOf(0x81.toByte(), n.toByte())
        else -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
    }

    private fun der(tag: Int, vararg parts: ByteArray): ByteArray {
        val b = ByteArrayOutputStream()
        for (p in parts) b.write(p, 0, p.size)
        val c = b.toByteArray()
        val o = ByteArrayOutputStream()
        o.write(tag)
        val l = dlen(c.size)
        o.write(l, 0, l.size)
        o.write(c, 0, c.size)
        return o.toByteArray()
    }

    private fun hx(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun utc(d: Date): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return der(0x17, f.format(d).toByteArray())
    }

    private fun makeCert(kp: KeyPair): ByteArray {
        val sigAlg = der(0x30, der(0x06, hx("2A864886F70D01010B")), der(0x05))
        val name = der(0x30, der(0x31, der(0x30, der(0x06, hx("550403")), der(0x0C, "jarvis-remote".toByteArray(Charsets.UTF_8)))))
        val now = System.currentTimeMillis()
        val tbs = der(
            0x30,
            der(0xA0, der(0x02, byteArrayOf(2))),
            der(0x02, BigInteger.valueOf(now).toByteArray()),
            sigAlg,
            name,
            der(0x30, utc(Date(now - 86400000L)), utc(Date(now + 20L * 365 * 86400000L))),
            name,
            kp.public.encoded
        )
        val sg = Signature.getInstance("SHA256withRSA")
        sg.initSign(kp.private)
        sg.update(tbs)
        val sig = sg.sign()
        val bits = ByteArray(sig.size + 1)
        System.arraycopy(sig, 0, bits, 1, sig.size)
        return der(0x30, tbs, sigAlg, der(0x03, bits))
    }

    @Synchronized
    private fun identity(): Pair<PrivateKey, X509Certificate> {
        val k0 = idKey
        val c0 = idCert
        if (k0 != null && c0 != null) return Pair(k0, c0)
        val sp = Plus.ctxHolder!!.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        try {
            val kb = sp.getString("tv_key2", null)
            val cb = sp.getString("tv_cert2", null)
            if (kb != null && cb != null) {
                val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(Base64.decode(kb, Base64.NO_WRAP)))
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(Base64.decode(cb, Base64.NO_WRAP))) as X509Certificate
                idKey = key
                idCert = cert
                return Pair(key, cert)
            }
        } catch (e: Exception) {
        }
        val g = KeyPairGenerator.getInstance("RSA")
        g.initialize(2048)
        val kp = g.generateKeyPair()
        val cd = makeCert(kp)
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(cd)) as X509Certificate
        sp.edit()
            .putString("tv_key2", Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP))
            .putString("tv_cert2", Base64.encodeToString(cd, Base64.NO_WRAP))
            .apply()
        idKey = kp.private
        idCert = cert
        return Pair(kp.private, cert)
    }

    private fun clientCert(): X509Certificate = identity().second

    fun err(e: Throwable): String {
        val sb = StringBuilder()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 3) {
            if (n > 0) sb.append(" <- ")
            sb.append(t.javaClass.simpleName).append(": ").append(t.message ?: "")
            t = t.cause
            n++
        }
        return sb.toString().take(400)
    }

    @SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
    private fun open(host: String, port: Int): SSLSocket {
        val id = identity()
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("c", id.first, PW, arrayOf<Certificate>(id.second))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PW)
        val tm = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })
        val c = SSLContext.getInstance("TLS")
        c.init(kmf.keyManagers, tm, SecureRandom())
        // Önce TLS 1.2, olmazsa varsayılan (TLS 1.3). Hata ayrıntıları birleştirilir.
        val errs = ArrayList<String>()
        for (proto in arrayOf("TLSv1.2", "")) {
            val s = c.socketFactory.createSocket() as SSLSocket
            try {
                if (proto.isNotEmpty()) s.enabledProtocols = arrayOf(proto)
                s.connect(InetSocketAddress(host, port), 4000)
                s.soTimeout = 8000
                s.startHandshake()
                return s
            } catch (e: Exception) {
                try {
                    s.close()
                } catch (x: Exception) {
                }
                if (e is java.net.ConnectException || e is SocketTimeoutException) throw e
                errs.add((if (proto.isEmpty()) "varsayılan" else proto) + ": " + err(e))
            }
        }
        throw RuntimeException("TLS el sıkışma başarısız (port $port) -> " + errs.joinToString(" | "))
    }

    private fun hexBytes(n: BigInteger): ByteArray {
        var h = n.toString(16)
        if (h.length % 2 == 1) h = "0$h"
        return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    // ---------- Kayıt ----------

    fun host(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("tv_host", "") ?: ""
    fun paired(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("tv_paired", false)
    fun setHost(ctx: Context, h: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("tv_host", h).apply()
    }

    // ---------- Eşleşme ----------

    private var pairSock: SSLSocket? = null

    private fun pairMsg(inner: Int, body: Msg?): Msg {
        val m = Msg().vi(1, 2).vi(2, 200)
        if (body != null) m.msg(inner, body)
        return m
    }

    fun pairStart(host: String): String {
        try {
            pairSock?.close()
        } catch (e: Exception) {
        }
        var stage = "bağlanma"
        try {
            val s = open(host, 6467)
            pairSock = s
            val out = s.outputStream
            val inp = s.inputStream
            stage = "eşleşme isteği"
            writeFrame(out, pairMsg(10, Msg().str(1, "atvremote").str(2, "Jarvis")))
            val r1 = readFrame(inp) ?: return "TV cevap vermedi (aşama: $stage)."
            if (r1.long(2) != 200L) return "TV eşleşmeyi reddetti (durum ${r1.long(2)})."
            val enc = Msg().vi(1, 3).vi(2, 6)
            stage = "seçenekler"
            writeFrame(out, pairMsg(20, Msg().msg(1, enc).vi(3, 1)))
            readFrame(inp) ?: return "TV seçenek cevabı vermedi."
            stage = "ayar"
            writeFrame(out, pairMsg(30, Msg().msg(1, enc).vi(2, 1)))
            val r3 = readFrame(inp) ?: return "TV ayar cevabı vermedi."
            if (r3.long(2) != 200L) return "TV ayarı kabul etmedi (durum ${r3.long(2)})."
            setHost(Plus.ctxHolder!!, host)
            return "ok"
        } catch (e: java.net.ConnectException) {
            return "TV'ye ulaşılamadı ($host:6467). TV açık ve aynı Wi-Fi'da mı?"
        } catch (e: Exception) {
            return "Eşleşme hatası (aşama: $stage): " + err(e)
        }
    }

    fun pairFinish(code0: String): String {
        val s = pairSock ?: return "Önce eşleşmeyi başlat."
        val code = code0.trim().uppercase().filter { it.isDigit() || it in 'A'..'F' }
        if (code.length != 6) return "Kod 6 karakter olmalı (örn. 1A2B3C)."
        val cb = ByteArray(3) { code.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val serverKey = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
        val clientKey = clientCert().publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(hexBytes(clientKey.modulus))
        md.update(hexBytes(clientKey.publicExponent))
        md.update(hexBytes(serverKey.modulus))
        md.update(hexBytes(serverKey.publicExponent))
        md.update(cb.copyOfRange(1, 3))
        val secret = md.digest()
        if (secret[0] != cb[0]) return "Kod yanlış görünüyor, TV'deki kodu tekrar kontrol et."
        writeFrame(s.outputStream, pairMsg(40, Msg().by(1, secret)))
        val r = readFrame(s.inputStream) ?: return "TV onay vermedi."
        try {
            s.close()
        } catch (e: Exception) {
        }
        pairSock = null
        if (r.long(2) != 200L) return "Eşleşme reddedildi, kodu yeniden iste."
        Plus.ctxHolder?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.putBoolean("tv_paired", true)?.apply()
        return "ok"
    }

    // ---------- Kumanda oturumu ----------

    private class Remote(val sock: SSLSocket) {
        val inp: InputStream = sock.inputStream
        val out = sock.outputStream
        var started = false
        var isOn = false
        var vol = -1
        var volMax = 100
        var err = ""

        private fun device(): Msg =
            Msg().str(1, "Jarvis").str(2, "Google").vi(3, 1).str(4, "1").str(5, "com.jarvis.app").str(6, "1.0")

        fun handle(m: Map<Int, List<Any>>) {
            if (m.containsKey(1)) writeFrame(out, Msg().msg(1, Msg().vi(1, 622).msg(2, device())))
            if (m.containsKey(2)) writeFrame(out, Msg().msg(2, Msg().vi(1, 622)))
            m.sub(8)?.let { p ->
                writeFrame(out, Msg().msg(9, Msg().vi(1, p.long(1) ?: 0)))
            }
            m.sub(40)?.let { st ->
                started = true
                isOn = (st.long(1) ?: 0L) == 1L
            }
            m.sub(50)?.let { v ->
                v.long(7)?.let { vol = it.toInt() }
                v.long(6)?.let { volMax = it.toInt() }
            }
            if (m.containsKey(3)) err = "TV hata bildirdi."
        }

        /** Mesajları ms süre boyunca ya da koşul gerçekleşene kadar işler. */
        fun pump(ms: Long, until: () -> Boolean) {
            val end = System.currentTimeMillis() + ms
            sock.soTimeout = 600
            while (System.currentTimeMillis() < end && !until()) {
                try {
                    val m = readFrame(inp) ?: break
                    handle(m)
                } catch (e: SocketTimeoutException) {
                    // devam
                }
            }
        }

        fun key(code: Int) {
            writeFrame(out, Msg().msg(10, Msg().vi(1, code.toLong()).vi(2, 3)))
        }

        fun launch(link: String) {
            writeFrame(out, Msg().msg(90, Msg().str(1, link)))
        }

        fun close() {
            try {
                sock.close()
            } catch (e: Exception) {
            }
        }
    }

    private fun connect(ctx: Context): Remote {
        val h = host(ctx)
        if (h.isEmpty()) throw RuntimeException("Televizyon kayıtlı değil. Önce TV sayfasından eşleştir.")
        val r = Remote(open(h, 6466))
        r.pump(4000) { r.started }
        return r
    }

    private fun friendlyFail(e: Exception): String = when (e) {
        is java.net.ConnectException, is SocketTimeoutException, is java.net.NoRouteToHostException ->
            "Televizyona ulaşamadım. Kapalı ya da başka bir Wi-Fi'da olabilir. TV ayarlarında ağdan uyandırma açık değilse kapalıyken açılamaz."
        else -> "TV hatası: " + (e.message ?: e.javaClass.simpleName)
    }

    fun power(ctx: Context, on: Boolean?): String {
        return try {
            val r = connect(ctx)
            try {
                if (on == true && r.isOn) return "Televizyon zaten açık."
                if (on == false && r.started && !r.isOn) return "Televizyon zaten kapalı."
                r.key(26)
                r.pump(600) { false }
                if (on == false) "Televizyon kapatıldı." else "Televizyon açıldı."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun key(ctx: Context, code: Int, times: Int = 1): String {
        return try {
            val r = connect(ctx)
            try {
                repeat(times.coerceIn(1, 60)) {
                    r.key(code)
                    Thread.sleep(110)
                }
                "Tamam."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun launch(ctx: Context, link: String): String {
        return try {
            val r = connect(ctx)
            try {
                r.launch(link)
                r.pump(500) { false }
                "Açıldı."
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }

    fun volume(ctx: Context, level: Int): String {
        return try {
            val r = connect(ctx)
            try {
                val target = level.coerceIn(0, 100)
                if (r.vol < 0) r.pump(2500) { r.vol >= 0 }
                if (r.vol >= 0) {
                    val tgt = if (r.volMax != 100 && r.volMax > 0) (target * r.volMax / 100) else target
                    val diff = tgt - r.vol
                    val code = if (diff > 0) 24 else 25
                    repeat(kotlin.math.abs(diff).coerceAtMost(100)) {
                        r.key(code)
                        Thread.sleep(90)
                    }
                    "Ses $target yapıldı."
                } else {
                    repeat(100) {
                        r.key(25)
                        Thread.sleep(40)
                    }
                    repeat(target) {
                        r.key(24)
                        Thread.sleep(90)
                    }
                    "Ses yaklaşık $target yapıldı (TV mevcut seviyeyi bildirmedi)."
                }
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            friendlyFail(e)
        }
    }
}
