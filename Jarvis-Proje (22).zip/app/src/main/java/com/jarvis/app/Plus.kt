package com.jarvis.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** v7 ek köprüsü (JS tarafında JarvisP): internet, konum, ağ, TV, parlaklık, kalıcı depo, izleme servisi. */
class Plus(private val act: JarvisActivity) {

    companion object {
        @JvmStatic
        var ctxHolder: Context? = null
        val HOSTS = setOf(
            "news.google.com", "api.open-meteo.com", "nominatim.openstreetmap.org",
            "overpass-api.de", "tr.wikipedia.org", "en.wikipedia.org", "router.project-osrm.org"
        )
    }

    init {
        ctxHolder = act.applicationContext
    }

    private fun js(code: String) {
        act.runOnUiThread { act.web.evaluateJavascript(code, null) }
    }

    private fun result(id: String, ok: Boolean, data: String) {
        js("window.onNativeResult(${JSONObject.quote(id)}, $ok, ${JSONObject.quote(data)})")
    }

    private fun kv() = act.getSharedPreferences("jarvis_kv", Context.MODE_PRIVATE)

    // ---------- İnternet (CORS'suz) ----------

    @JavascriptInterface
    fun httpGet(id: String, url: String) {
        thread {
            try {
                val u = URL(url)
                if (u.protocol != "https" || u.host !in HOSTS) {
                    result(id, false, "izin verilmeyen adres"); return@thread
                }
                val c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                c.setRequestProperty("User-Agent", "JarvisApp/7 (Android)")
                c.setRequestProperty("Accept-Language", "tr,en;q=0.7")
                val code = c.responseCode
                val s = (if (code in 200..299) c.inputStream else c.errorStream)
                val txt = s?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                result(id, code in 200..299, txt.take(250_000))
            } catch (e: Exception) {
                result(id, false, e.message ?: "hata")
            }
        }
    }

    // ---------- Konum ----------

    private fun locJson(l: Location): JSONObject = JSONObject()
        .put("lat", l.latitude).put("lon", l.longitude)
        .put("acc", l.accuracy.toDouble())
        .put("speed", if (l.hasSpeed()) (l.speed * 3.6) else 0.0)
        .put("bearing", if (l.hasBearing()) l.bearing.toDouble() else -1.0)
        .put("alt", if (l.hasAltitude()) l.altitude else 0.0)
        .put("age", (System.currentTimeMillis() - l.time) / 1000)

    @SuppressLint("MissingPermission")
    @JavascriptInterface
    fun loc(id: String) {
        thread {
            try {
                if (!act.ensurePerms(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION))) {
                    result(id, false, "konum izni verilmedi"); return@thread
                }
                val lm = act.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var best: Location? = null
                for (p in lm.getProviders(true)) {
                    val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } ?: continue
                    if (best == null || l.time > best!!.time) best = l
                }
                val fresh = best != null && System.currentTimeMillis() - best!!.time < 60_000
                if (!fresh) {
                    val latch = CountDownLatch(1)
                    var got: Location? = null
                    val ls = object : LocationListener {
                        override fun onLocationChanged(l: Location) { got = l; latch.countDown() }
                        @Deprecated("x") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {}
                    }
                    val prov = when {
                        lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                        lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                        else -> null
                    }
                    if (prov != null) {
                        act.runOnUiThread {
                            try { lm.requestLocationUpdates(prov, 0L, 0f, ls, Looper.getMainLooper()) } catch (e: Exception) { latch.countDown() }
                        }
                        latch.await(12, TimeUnit.SECONDS)
                        act.runOnUiThread { try { lm.removeUpdates(ls) } catch (e: Exception) {} }
                        if (got != null) best = got
                    }
                }
                val b = best
                if (b == null) result(id, false, "Konum alınamadı. Konum (GPS) kapalı olabilir.")
                else result(id, true, locJson(b).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "hata")
            }
        }
    }

    // ---------- Ağ radarı ----------

    private fun localIp(): String? {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                if (!(ni.name.startsWith("wlan") || ni.name.startsWith("eth"))) continue
                for (a in ni.inetAddresses) {
                    val h = a.hostAddress ?: continue
                    if (a is java.net.Inet4Address && a.isSiteLocalAddress) return h
                }
            }
        } catch (e: Exception) {}
        return null
    }

    private val PORTS = intArrayOf(80, 443, 8008, 8009, 6466, 5555, 22, 53, 554, 8080, 445, 62078, 1900)

    private fun probe(ip: String): JSONObject? {
        var alive = false
        val open = JSONArray()
        for (p in PORTS) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(ip, p), 220)
                alive = true
                open.put(p)
            } catch (e: ConnectException) {
                alive = true
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) {}
            }
            if (alive && open.length() == 0 && p == 80) { /* devam */ }
        }
        if (!alive) return null
        var name = ""
        try {
            val n = java.net.InetAddress.getByName(ip).canonicalHostName
            if (n != ip) name = n
        } catch (e: Exception) {}
        return JSONObject().put("ip", ip).put("name", name).put("ports", open)
    }

    @JavascriptInterface
    fun lanScan(id: String) {
        thread {
            try {
                val me = localIp()
                if (me == null) { result(id, false, "Wi-Fi ağına bağlı değilsin."); return@thread }
                val base = me.substringBeforeLast(".")
                val pool = Executors.newFixedThreadPool(48)
                val futs = (1..254).map { i ->
                    val ip = "$base.$i"
                    pool.submit<JSONObject?> { probe(ip) }
                }
                val arr = JSONArray()
                for (f in futs) {
                    try { f.get(40, TimeUnit.SECONDS)?.let { arr.put(it) } } catch (e: Exception) {}
                }
                pool.shutdownNow()
                var ssid = ""
                try {
                    @Suppress("DEPRECATION")
                    ssid = (act.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                        .connectionInfo.ssid.replace("\"", "")
                } catch (e: Exception) {}
                result(id, true, JSONObject().put("me", me).put("ssid", ssid).put("devices", arr).toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "hata")
            }
        }
    }

    /** Ağdaki Android TV'leri (6466 açık) bulur. */
    @JavascriptInterface
    fun tvFind(id: String) {
        thread {
            try {
                val me = localIp()
                if (me == null) { result(id, false, "Wi-Fi ağına bağlı değilsin."); return@thread }
                val base = me.substringBeforeLast(".")
                val pool = Executors.newFixedThreadPool(64)
                val futs = (1..254).map { i ->
                    val ip = "$base.$i"
                    pool.submit<String?> {
                        val s = Socket()
                        try { s.connect(InetSocketAddress(ip, 6466), 400); ip } catch (e: Exception) { null } finally { try { s.close() } catch (e: Exception) {} }
                    }
                }
                val arr = JSONArray()
                for (f in futs) try { f.get(20, TimeUnit.SECONDS)?.let { arr.put(it) } } catch (e: Exception) {}
                pool.shutdownNow()
                result(id, true, arr.toString())
            } catch (e: Exception) {
                result(id, false, e.message ?: "hata")
            }
        }
    }

    // ---------- Televizyon ----------

    @JavascriptInterface
    fun tvStatus(): String =
        JSONObject().put("host", Tv.host(act)).put("paired", Tv.paired(act)).toString()

    @JavascriptInterface
    fun tvPairStart(id: String, host: String) {
        thread {
            try {
                val r = Tv.pairStart(host.trim())
                result(id, r == "ok", r)
            } catch (e: Exception) { result(id, false, "Bağlanamadı: " + Tv.err(e)) }
        }
    }

    @JavascriptInterface
    fun tvPairFinish(id: String, code: String) {
        thread {
            try {
                val r = Tv.pairFinish(code)
                result(id, r == "ok", r)
            } catch (e: Exception) { result(id, false, e.message ?: "hata") }
        }
    }

    @JavascriptInterface
    fun tvSetHost(host: String) { Tv.setHost(act, host.trim()) }

    @JavascriptInterface
    fun tvForget() {
        kv().edit().remove("tv_host").putBoolean("tv_paired", false).apply()
    }

    /** kind: power_on, power_off, key, launch, volume, mute, home, back */
    @JavascriptInterface
    fun tv(id: String, kind: String, arg: String) {
        thread {
            val ctx = act.applicationContext
            val r = when (kind) {
                "power_on" -> Tv.power(ctx, true)
                "power_off" -> Tv.power(ctx, false)
                "mute" -> Tv.key(ctx, 164)
                "home" -> Tv.key(ctx, 3)
                "back" -> Tv.key(ctx, 4)
                "up" -> Tv.key(ctx, 19)
                "down" -> Tv.key(ctx, 20)
                "left" -> Tv.key(ctx, 21)
                "right" -> Tv.key(ctx, 22)
                "ok" -> Tv.key(ctx, 23)
                "play" -> Tv.key(ctx, 85)
                "vol_up" -> Tv.key(ctx, 24, arg.toIntOrNull() ?: 1)
                "vol_down" -> Tv.key(ctx, 25, arg.toIntOrNull() ?: 1)
                "key" -> Tv.key(ctx, arg.toIntOrNull() ?: 0)
                "launch" -> Tv.launch(ctx, arg)
                "volume" -> Tv.volume(ctx, arg.toIntOrNull() ?: 20)
                else -> "bilinmeyen TV komutu"
            }
            val ok = !(r.startsWith("Televizyona ulaş") || r.startsWith("TV hata") || r.startsWith("Televizyon kayıtlı"))
            result(id, ok, r)
        }
    }

    // ---------- Parlaklık ----------

    @JavascriptInterface
    fun setBrightness(id: String, pct: Int) {
        thread {
            try {
                if (!Settings.System.canWrite(act)) {
                    act.runOnUiThread {
                        try {
                            act.startActivity(
                                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                                    .setData(android.net.Uri.parse("package:" + act.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {}
                    }
                    result(id, false, "Parlaklık için 'Sistem ayarlarını değiştir' iznini aç, sonra tekrar söyle.")
                    return@thread
                }
                val v = (pct.coerceIn(1, 100) * 255 / 100)
                Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                result(id, true, "Parlaklık %${pct.coerceIn(1, 100)} yapıldı.")
            } catch (e: Exception) {
                result(id, false, e.message ?: "hata")
            }
        }
    }

    @JavascriptInterface
    fun writeSettingsGranted(): Boolean = try { Settings.System.canWrite(act) } catch (e: Exception) { false }

    @JavascriptInterface
    fun openWriteSettings() {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                        .setData(android.net.Uri.parse("package:" + act.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {}
        }
    }

    // ---------- Depo + izleme servisi ----------

    @JavascriptInterface
    fun kvSet(k: String, v: String) { kv().edit().putString(k, v).apply() }

    @JavascriptInterface
    fun kvGet(k: String): String = kv().getString(k, "") ?: ""

    /** İzleme servisini aç/kapat. Kurallar JSON: {"rules":[{"id","h","m","text"}], "low":20} */
    @JavascriptInterface
    fun watch(on: Boolean, cfg: String) {
        if (cfg.isNotEmpty()) kv().edit().putString("watch_cfg", cfg).apply()
        kv().edit().putBoolean("watch_on", on).apply()
        val i = Intent(act, WatchService::class.java)
        try {
            if (on) {
                if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
            } else act.stopService(i)
        } catch (e: Exception) {}
    }

    @JavascriptInterface
    fun watchOn(): Boolean = kv().getBoolean("watch_on", false)

    @JavascriptInterface
    fun pendingTake(): String {
        val s = kv().getString("pending_q", "") ?: ""
        kv().edit().remove("pending_q").apply()
        return s
    }
}
