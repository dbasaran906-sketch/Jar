/* JARVİS X-RAY ANALİZ: fotoğraf seç -> nesneyi bul -> onay -> X-ray görünümü + tahmini iç yapı etiketleri; zoom/kaydır.
   NOT: gerçek röntgen değildir; görüntü filtresi + yapay zekânın bildiği iç yapıdan çıkardığı TAHMİNİ şemadır. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div"); var $=function(id){ return document.getElementById(id)||DUMMY; };
var esc=JV.esc, toast=JV.toast;
function tl(t){ return String(t).toLocaleLowerCase("tr").replace(/[’`´]/g,"'").trim(); }
var X={img:null,iw:0,ih:0,b64:"",objs:[],sel:null,parts:[],fx:null,st:"idle",z:1,tx:0,ty:0,fxOn:true,lab:true,bright:1.0,raf:0,busy:false};

var d=document.createElement("div"); d.className="page"; d.id="pXr";
d.innerHTML=
 '<div class="ph"><button class="ib" data-close>←</button><h2>X-RAY ANALİZ</h2></div>'+
 '<div class="pb" style="padding:8px;display:flex;flex-direction:column;gap:8px">'+
 '<div id="xrWrap" style="position:relative;height:44vh;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#000;touch-action:none"><canvas id="xrC" style="width:100%;height:100%;display:block"></canvas><div id="xrHint" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:13px;text-align:center;padding:20px">Bir fotoğraf seç. Jarvis nesneyi bulacak, sana soracak, sonra X-ray görünümünü çıkaracak.</div></div>'+
 '<div id="xrMsg" style="font-size:14px;min-height:20px;color:var(--c1)"></div>'+
 '<div id="xrAsk" style="display:none;gap:8px;flex-wrap:wrap"></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="xrPick" style="flex:1">📷 FOTOĞRAF SEÇ</button><button class="btn" id="xrZi" style="flex:0 0 52px">＋</button><button class="btn" id="xrZo" style="flex:0 0 52px">－</button><button class="btn" id="xrRs" style="flex:0 0 52px">⟲</button></div>'+
 '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn on" id="xrFx" style="flex:1">X-RAY: AÇIK</button><button class="btn on" id="xrLb" style="flex:1">ETİKET: AÇIK</button></div>'+
 '<label style="font-size:12px;color:var(--dim)">Parlaklık <input type="range" id="xrBr" min="50" max="200" value="100" style="width:100%"></label>'+
 '<div id="xrList" style="font-size:13px"></div>'+
 '<input type="file" id="xrFile" accept="image/*" style="display:none"></div>';
document.body.appendChild(d);
function msg(t){ $("xrMsg").textContent=t||""; }
function ask(opts){
  var a=$("xrAsk"); a.innerHTML=""; if(!opts||!opts.length){ a.style.display="none"; return; }
  a.style.display="flex";
  opts.forEach(function(o){ var b=document.createElement("button"); b.className="btn"; b.textContent=o[0]; b.onclick=o[1]; a.appendChild(b); });
}
function jsay(t){ msg(t); try{ JV.say(t); }catch(e){} }

/* ---- görüntü yükle ---- */
$("xrPick").onclick=function(){ $("xrFile").click(); };
$("xrFile").onchange=function(){
  var f=this.files&&this.files[0]; if(!f) return;
  var r=new FileReader();
  r.onload=function(){
    var im=new Image();
    im.onload=function(){
      var k=Math.min(1,1024/Math.max(im.width,im.height)), c=document.createElement("canvas"); c.width=Math.round(im.width*k); c.height=Math.round(im.height*k);
      c.getContext("2d").drawImage(im,0,0,c.width,c.height);
      X.img=c; X.iw=c.width; X.ih=c.height; X.b64=c.toDataURL("image/jpeg",0.82).split(",")[1];
      X.objs=[]; X.sel=null; X.parts=[]; X.fx=null; reset(); $("xrHint").style.display="none"; $("xrList").innerHTML="";
      analyze();
    };
    im.src=r.result;
  };
  r.readAsDataURL(f); this.value="";
};

function nb(b){ if(!b||b.length<4) return null; var a=b.map(Number); if(a.some(isNaN)) return null; var mx=Math.max.apply(null,a); if(mx<=1.5) a=a.map(function(x){ return x*1000; }); return {y1:a[0]/1000*X.ih,x1:a[1]/1000*X.iw,y2:a[2]/1000*X.ih,x2:a[3]/1000*X.iw}; }

async function analyze(){
  X.st="find"; X.busy=true; msg("Nesneler aranıyor…"); ask(null);
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki belirgin tek tek nesneleri bul (en fazla 5; ana nesne en önce). Sadece JSON: [{"ad":"kısa Türkçe ad","box_2d":[ymin,xmin,ymax,xmax],"guven":0-1}] box_2d 0-1000 normalize. Nesne yoksa [].',[{data:X.b64}],true),40000,"analiz zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.objs=arr.map(function(o){ return {ad:String(o.ad||"nesne"),box:nb(o.box_2d),g:o.guven||0}; }).filter(function(o){ return o.box; });
    if(!X.objs.length){ X.busy=false; X.st="idle"; msg("Nesne bulamadım. Başka bir fotoğraf dene."); return; }
    X.sel=X.objs[0]; X.st="confirm"; X.busy=false;
    offerConfirm();
  }catch(e){ X.busy=false; X.st="idle"; msg("Hata: "+JV.errMsg(e)); }
}
function offerConfirm(){
  var o=X.sel; jsay("Fotoğrafta "+o.ad+" var. "+o.ad+" mı seçmiştiniz?");
  var opts=[["EVET, "+o.ad.toUpperCase(),function(){ confirmObj(); }]];
  X.objs.filter(function(x){ return x!==o; }).forEach(function(x){ opts.push([x.ad.toUpperCase()+" AYNI DEĞİL, BUNU SEÇ",function(){ X.sel=x; offerConfirm(); }]); });
  ask(opts);
  msg(o.ad+" mı seçmiştiniz? (Görüntüde başka bir nesneye de dokunabilirsin.)");
}
async function confirmObj(){
  if(X.busy) return; X.busy=true; X.st="scan"; ask(null); msg("X-ray taraması yapılıyor…");
  var o=X.sel, bx=o.box;
  buildFx(bx);
  try{
    var raw=await JV.withTimeout(JV.visionAI('Fotoğraftaki "'+o.ad+'" nesnesinin (kutu: ymin='+Math.round(bx.y1/X.ih*1000)+', xmin='+Math.round(bx.x1/X.iw*1000)+', ymax='+Math.round(bx.y2/X.ih*1000)+', xmax='+Math.round(bx.x2/X.iw*1000)+') ürün türüne göre TİPİK iç yapısını düşün. Gizli iç parçaların bu fotoğraftaki yaklaşık konumlarını tahmin et. Sadece JSON: [{"ad":"parça adı","box_2d":[ymin,xmin,ymax,xmax],"bilgi":"tek satır açıklama, en fazla 60 karakter"}] en fazla 8 parça, box_2d 0-1000 normalize (nesne kutusunun içinde).',[{data:X.b64}],true),45000,"tarama zaman aşımı");
    var arr=JV.parseJSON(raw); arr=Array.isArray(arr)?arr:[];
    X.parts=arr.map(function(p){ return {ad:String(p.ad||"parça"),box:nb(p.box_2d),bilgi:String(p.bilgi||"")}; }).filter(function(p){ return p.box; });
    X.st="view"; X.busy=false;
    $("xrList").innerHTML='<div class="sec"><b>TAHMİNİ İÇ YAPI</b> <span style="color:var(--dim);font-size:11px">(gerçek röntgen değil; yapay zekâ tahmini)</span>'+X.parts.map(function(p,i){ return '<div class="pl">'+(i+1)+'. '+esc(p.ad)+'<small>'+esc(p.bilgi)+'</small></div>'; }).join("")+'</div>';
    msg("X-ray hazır: "+o.ad+" — "+X.parts.length+" iç parça (tahmini). Yakınlaştırmak için iki parmakla aç ya da ＋ tuşunu kullan.");
    try{ JV.say("X-ray görüntüsü hazır efendim. Bu tahmini bir iç yapı şemasıdır."); }catch(e){}
  }catch(e){ X.st="view"; X.busy=false; msg("İç yapı çıkarılamadı ("+JV.errMsg(e)+"). Sadece X-ray filtresi gösteriliyor."); }
}
/* ---- X-ray efekti: nesne bölgesinde ters parlaklık + kenar vurgusu + mavi ton ---- */
function buildFx(bx){
  var x=Math.max(0,Math.floor(bx.x1)), y=Math.max(0,Math.floor(bx.y1)), w=Math.min(X.iw-x,Math.ceil(bx.x2-bx.x1)), h=Math.min(X.ih-y,Math.ceil(bx.y2-bx.y1));
  if(w<4||h<4){ X.fx=null; return; }
  var c=document.createElement("canvas"); c.width=w; c.height=h; var ctx=c.getContext("2d");
  ctx.drawImage(X.img,x,y,w,h,0,0,w,h);
  var id=ctx.getImageData(0,0,w,h), s=id.data, L=new Float32Array(w*h), i, j;
  for(i=0,j=0;i<s.length;i+=4,j++) L[j]=0.3*s[i]+0.59*s[i+1]+0.11*s[i+2];
  var out=ctx.createImageData(w,h), o=out.data, mn=255,mx=0;
  for(j=0;j<L.length;j++){ if(L[j]<mn)mn=L[j]; if(L[j]>mx)mx=L[j]; }
  var rg=Math.max(1,mx-mn);
  for(var yy=0;yy<h;yy++) for(var xx=0;xx<w;xx++){
    j=yy*w+xx; var g=0;
    if(xx>0&&yy>0&&xx<w-1&&yy<h-1){ var gx=-L[j-w-1]-2*L[j-1]-L[j+w-1]+L[j-w+1]+2*L[j+1]+L[j+w+1], gy=-L[j-w-1]-2*L[j-w]-L[j-w+1]+L[j+w-1]+2*L[j+w]+L[j+w+1]; g=Math.min(255,Math.sqrt(gx*gx+gy*gy)); }
    var v=255-(L[j]-mn)/rg*255, e=Math.min(255,v*0.55+g*1.4), k=j*4;
    o[k]=e*0.25; o[k+1]=e*0.8; o[k+2]=Math.min(255,e*1.15+20); o[k+3]=255;
  }
  ctx.putImageData(out,0,0); X.fx={c:c,x:x,y:y,w:w,h:h};
}
/* ---- çizim ---- */
function reset(){ X.z=1; X.tx=0; X.ty=0; }
function draw(ts){
  X.raf=requestAnimationFrame(draw);
  var cv=$("xrC"); if(!cv.clientWidth||!document.getElementById("pXr").classList.contains("show")) return;
  var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=cv.clientHeight;
  if(cv.width!==Math.round(W*dpr)){ cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); }
  var ctx=cv.getContext("2d"); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.fillStyle="#000"; ctx.fillRect(0,0,W,H);
  if(!X.img) return;
  var base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty;
  ctx.setTransform(dpr*sc,0,0,dpr*sc,dpr*ox,dpr*oy);
  var dim=(X.st==="view"&&X.fxOn&&X.fx);
  ctx.globalAlpha=dim?0.28:1; ctx.drawImage(X.img,0,0); ctx.globalAlpha=1;
  if(dim){
    ctx.filter="brightness("+X.bright+")"; ctx.drawImage(X.fx.c,X.fx.x,X.fx.y); ctx.filter="none";
    var sy=((ts/18)%(X.fx.h+40))-20; ctx.fillStyle="rgba(120,220,255,.35)"; ctx.fillRect(X.fx.x,X.fx.y+sy,X.fx.w,2/sc*1.5);
  }
  var lw=1.6/sc, fs=12/sc;
  ctx.lineWidth=lw; ctx.font=fs+"px sans-serif";
  if(X.sel&&(X.st==="confirm"||X.st==="scan"||X.st==="view")){ var b=X.sel.box; ctx.strokeStyle="#2bb5ff"; ctx.setLineDash([6/sc,4/sc]); ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1); ctx.setLineDash([]); if(X.st!=="view"){ ctx.fillStyle="#2bb5ff"; ctx.fillText(X.sel.ad,b.x1+3/sc,b.y1-4/sc); } }
  if(X.st==="view"&&X.lab) X.parts.forEach(function(p,i){
    var b=p.box; ctx.strokeStyle="#ff8a1f"; ctx.strokeRect(b.x1,b.y1,b.x2-b.x1,b.y2-b.y1);
    var t=(i+1)+" "+p.ad, tw=ctx.measureText(t).width; ctx.fillStyle="rgba(0,0,0,.7)"; ctx.fillRect(b.x1,b.y1-fs-3/sc,tw+6/sc,fs+3/sc); ctx.fillStyle="#ffd9b0"; ctx.fillText(t,b.x1+3/sc,b.y1-3/sc);
  });
}
X.raf=requestAnimationFrame(draw);

/* ---- dokunma / zoom ---- */
var ptr={}, lastD=0;
var wrap=$("xrWrap");
wrap.addEventListener("pointerdown",function(e){ ptr[e.pointerId]={x:e.clientX,y:e.clientY,x0:e.clientX,y0:e.clientY,t:Date.now()}; try{ wrap.setPointerCapture(e.pointerId); }catch(er){} lastD=0; });
wrap.addEventListener("pointermove",function(e){
  var p=ptr[e.pointerId]; if(!p) return; var ids=Object.keys(ptr);
  if(ids.length===1){ X.tx+=e.clientX-p.x; X.ty+=e.clientY-p.y; }
  else if(ids.length>=2){
    var a=ptr[ids[0]], b=ptr[ids[1]]; if(e.pointerId==ids[0]){ a={x:e.clientX,y:e.clientY}; } else { b={x:e.clientX,y:e.clientY}; }
    var dd=Math.hypot(a.x-b.x,a.y-b.y); if(lastD) zoomBy(dd/lastD); lastD=dd;
  }
  p.x=e.clientX; p.y=e.clientY;
});
function endP(e){
  var p=ptr[e.pointerId]; delete ptr[e.pointerId]; lastD=0;
  if(p&&Math.hypot(e.clientX-p.x0,e.clientY-p.y0)<8&&Date.now()-p.t<400) tap(e.clientX,e.clientY);
}
wrap.addEventListener("pointerup",endP); wrap.addEventListener("pointercancel",function(e){ delete ptr[e.pointerId]; });
wrap.addEventListener("wheel",function(e){ e.preventDefault(); zoomBy(e.deltaY<0?1.15:0.87); },{passive:false});
function zoomBy(k){ X.z=Math.max(1,Math.min(8,X.z*k)); if(X.z===1){ X.tx=0; X.ty=0; } }
function toImg(cx,cy){ var cv=$("xrC"), r=cv.getBoundingClientRect(), W=cv.clientWidth, H=cv.clientHeight, base=Math.min(W/X.iw,H/X.ih), sc=base*X.z, ox=(W-X.iw*sc)/2+X.tx, oy=(H-X.ih*sc)/2+X.ty; return {x:(cx-r.left-ox)/sc,y:(cy-r.top-oy)/sc}; }
function tap(cx,cy){
  if(!X.img||X.st!=="confirm") return;
  var q=toImg(cx,cy), hit=X.objs.filter(function(o){ return q.x>=o.box.x1&&q.x<=o.box.x2&&q.y>=o.box.y1&&q.y<=o.box.y2; }).sort(function(a,b){ return (a.box.x2-a.box.x1)*(a.box.y2-a.box.y1)-(b.box.x2-b.box.x1)*(b.box.y2-b.box.y1); })[0];
  if(hit&&hit!==X.sel){ X.sel=hit; offerConfirm(); }
}
$("xrZi").onclick=function(){ zoomBy(1.4); }; $("xrZo").onclick=function(){ zoomBy(1/1.4); }; $("xrRs").onclick=reset;
$("xrFx").onclick=function(){ X.fxOn=!X.fxOn; this.textContent="X-RAY: "+(X.fxOn?"AÇIK":"KAPALI"); this.classList.toggle("on",X.fxOn); };
$("xrLb").onclick=function(){ X.lab=!X.lab; this.textContent="ETİKET: "+(X.lab?"AÇIK":"KAPALI"); this.classList.toggle("on",X.lab); };
$("xrBr").oninput=function(){ X.bright=this.value/100; };

/* ---- sesli/yazılı onay + açma komutu ---- */
var prevS=window.JV_onSpeech;
window.JV_onSpeech=function(t,final){
  if(X.st==="confirm"&&document.getElementById("pXr").classList.contains("show")&&final){
    var x=tl(t).replace(/[.!?,]+$/g,"");
    if(/^(evet|doğru|tamam|onaylıyorum|aynen)/.test(x)){ confirmObj(); return true; }
    if(/^(hayır|yanlış|değil)/.test(x)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return true; }
  }
  return prevS?prevS(t,final):false;
};
function open(){ d.classList.add("show"); if(!X.img) msg("Fotoğraf seçin efendim."); }
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/^x[- ]?ray/.test(t)&&t.split(/\s+/).length<=5){
    if(/(kapat|bitir|çık)/.test(t)){ d.classList.remove("show"); return "X-ray modu kapatıldı."; }
    open(); return "X-ray modu açık. Bir fotoğraf seçin.";
  }
  if(X.st==="confirm"&&d.classList.contains("show")){
    if(/^(evet|doğru|tamam|onaylıyorum)/.test(t)){ confirmObj(); return "X-ray taraması başlıyor."; }
    if(/^(hayır|yanlış|değil)/.test(t)){ var nx=X.objs[(X.objs.indexOf(X.sel)+1)%X.objs.length]; X.sel=nx; offerConfirm(); return "Başka nesneyi öneriyorum."; }
  }
  return prevOff?prevOff(text):null;
};
(function(){ var chips=$("chips"); if(!chips||!chips.appendChild||chips===DUMMY) return; var b=document.createElement("button"); b.textContent="🩻 X-RAY"; b.onclick=open; chips.appendChild(b); })();
window.JV_xray={open:open,_X:X};
})();
