/* JARVİS TERCÜMAN MODU
   Karşı taraf konuşur -> dil algılanır -> Türkçesi ekrana yazılır (isteğe bağlı sesli okunur).
   Sen Türkçeni yazarsın -> İngilizcesi ekrana yazılır ve sesli okunur (sadece İngilizce). */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var toast=JV.toast, esc=JV.esc;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").trim(); }
function N(){ return window.JarvisNative||null; }

var LANGS=[["auto","OTO","Otomatik"],["en-US","EN","İngilizce"],["de-DE","DE","Almanca"],["fr-FR","FR","Fransızca"],["es-ES","ES","İspanyolca"],["ar-SA","AR","Arapça"],["ru-RU","RU","Rusça"],["it-IT","IT","İtalyanca"],["zh-CN","ZH","Çince"],["ja-JP","JA","Japonca"]];
var ISO2LOC={en:"en-US",de:"de-DE",fr:"fr-FR",es:"es-ES",ar:"ar-SA",ru:"ru-RU",it:"it-IT",zh:"zh-CN",ja:"ja-JP",tr:"tr-TR",nl:"nl-NL",pt:"pt-PT",pl:"pl-PL",ko:"ko-KR",fa:"fa-IR",uk:"uk-UA",ro:"ro-RO",el:"el-GR",bg:"bg-BG",hi:"hi-IN"};
function langName(code){ var l=LANGS.filter(function(x){ return x[0]===code; })[0]; return l?l[2]:code; }
var S=lsGet("jv_tr2",{lang:"auto",last:"en-US",voice:true,cont:false});
var T={active:false,listening:false,mode:"other",hist:[],busy:false,nativeLang:"",relistenT:0};

/* ---------- Sayfa ---------- */
function mkPage(id,html){ var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d); return d; }
var pg=mkPage("pTr2",
 '<div class="ph"><button class="ib" data-close>←</button><h2>TERCÜMAN</h2></div>'+
 '<div class="pb">'+
 '<div class="sec"><div style="font-size:12px;color:var(--dim);margin-bottom:6px">Karşıdakinin dili</div><div id="trLangs" style="display:flex;flex-wrap:wrap;gap:6px"></div><div id="trDet" style="font-size:13px;color:var(--c1);margin-top:8px;min-height:18px"></div></div>'+
 '<div class="sec"><div style="display:flex;gap:8px"><button class="btn" id="trListen" style="flex:1">🎙 KARŞIYI DİNLE</button><button class="btn" id="trVoice" style="flex:0 0 112px">🔊 SESLİ</button></div>'+
 '<label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:13px"><input type="checkbox" id="trCont"> Sürekli dinle (her cümleden sonra tekrar aç)</label>'+
 '<div id="trSt" style="font-size:12px;color:var(--dim);margin-top:6px;min-height:16px"></div></div>'+
 '<div class="sec"><div id="trLog"></div></div>'+
 '<div class="sec"><div style="font-size:12px;color:var(--dim);margin-bottom:6px">Türkçeni yaz → İngilizcesini sesli okurum</div>'+
 '<div style="display:flex;gap:8px"><input class="inp" id="trIn" placeholder="Türkçe yaz…" style="flex:1;margin:0"><button class="btn" id="trMic" style="flex:0 0 52px">🎙</button></div>'+
 '<button class="btn" id="trGo" style="width:100%;margin-top:8px">İNGİLİZCEYE ÇEVİR VE OKU</button>'+
 '<div id="trEn" style="margin-top:10px"></div></div></div>');
var stl=document.createElement("style");
stl.textContent=
"#trLangs button{padding:7px 12px;border-radius:14px;border:1px solid var(--line,#1c4666);background:transparent;color:var(--c1);letter-spacing:1px;font-size:12px}"+
"#trLangs button.on{background:rgba(43,181,255,.22);box-shadow:0 0 10px var(--c1);color:#fff}"+
".trC{border:1px solid var(--line,#1c4666);border-radius:12px;padding:10px 12px;margin-bottom:8px;background:rgba(5,16,30,.5)}"+
".trC .o{font-size:12px;color:var(--dim)}.trC .t{font-size:17px;margin-top:4px;color:#e8f6ff}"+
".trC .e{font-size:17px;color:#ffd9b0}"+
"#trListen.live{background:rgba(255,138,31,.25);box-shadow:0 0 12px #ff8a1f}";
document.head.appendChild(stl);

function setSt(t){ $("trSt").textContent=t||""; }
function setDet(t){ $("trDet").textContent=t||""; }
function save(){ lsSet("jv_tr2",S); }
function renderLangs(){
  $("trLangs").innerHTML=LANGS.map(function(l){ return '<button data-l="'+l[0]+'" class="'+(S.lang===l[0]?"on":"")+'">'+l[1]+'</button>'; }).join("");
  $("trLangs").querySelectorAll("button").forEach(function(b){ b.onclick=function(){ S.lang=b.getAttribute("data-l"); if(S.lang!=="auto") S.last=S.lang; save(); renderLangs(); setDet(S.lang==="auto"?"Otomatik: dil algılanır (son: "+langName(S.last)+")":"Dil: "+langName(S.lang)); }; });
}
function renderVoice(){ $("trVoice").textContent=S.voice?"🔊 SESLİ":"🔇 SESSİZ"; $("trCont").checked=!!S.cont; }
function logAdd(o,t,lang){
  T.hist.unshift({o:o,t:t,l:lang}); T.hist=T.hist.slice(0,8);
  $("trLog").innerHTML=T.hist.map(function(h){ return '<div class="trC"><div class="o">'+esc(h.l||"")+' · '+esc(h.o)+'</div><div class="t">'+esc(h.t)+'</div></div>'; }).join("");
}

/* ---------- Karşı tarafı dinle ---------- */
function curLang(){ return S.lang==="auto"?(S.last||"en-US"):S.lang; }
function listen(mode){
  var n=N(); if(!n||!n.listenIn){ toast("Bu sürümde tercüman dinleme yok"); return; }
  if(JV.isBusy()) return;
  T.mode=mode||"other"; T.listening=true; T.nativeLang="";
  try{ n.stopSpeak(); }catch(e){}
  var lang=T.mode==="me"?"tr-TR":curLang();
  setSt(T.mode==="me"?"Seni dinliyorum (Türkçe)…":"Dinliyorum ("+langName(curLang())+(S.lang==="auto"?", otomatik":"")+")…");
  $("trListen").classList.toggle("live",T.mode==="other");
  try{ n.listenIn(lang,T.mode==="other"&&S.lang==="auto"); }catch(e){ T.listening=false; setSt("Dinleme açılamadı: "+e); }
}
function stopListen(){
  clearTimeout(T.relistenT); T.listening=false; $("trListen").classList.remove("live");
  try{ var n=N(); if(n) n.stopListen(); }catch(e){}
}
async function translateToTr(text){
  var prompt="Aşağıdaki metin bir ses tanıma çıktısı (tanıma dili: "+curLang()+"); yanlış dilde tanınmış ve bozuk olabilir. Önce metnin gerçekten hangi dilde söylendiğini tahmin et, sonra doğal ve anlaşılır Türkçeye çevir. Sadece JSON döndür: {\"lang\":\"iki harfli ISO dil kodu\",\"tr\":\"Türkçe çeviri\",\"sure\":true veya false}.\nMetin: "+text;
  var raw=await JV.withTimeout(JV.aiText(prompt,true),20000,"çeviri zaman aşımı");
  var j=JV.parseJSON(raw)||{};
  return {lang:String(j.lang||"").toLowerCase().slice(0,2),tr:String(j.tr||"").trim(),sure:j.sure!==false};
}
async function handleOther(text){
  text=String(text||"").trim(); if(!text){ setSt("Duyamadım."); afterTurn(); return; }
  setSt("Çeviriyorum…"); T.busy=true;
  try{
    var r=await translateToTr(text);
    if(!r.tr){ setSt("Çevrilemedi."); T.busy=false; afterTurn(); return; }
    var code=r.lang||"", loc=ISO2LOC[code]||"";
    var name=code?(langName(loc)!==loc?langName(loc):code.toUpperCase()):"?";
    logAdd(text,r.tr,name);
    setSt("");
    if(S.lang==="auto"&&loc&&loc!==S.last&&r.sure&&code!=="tr"){
      S.last=loc; save();
      setDet("Algılanan dil: "+name+(JV.isSpeaking()?"":" · yanlışsa üstten dili seç"));
    }else if(S.lang==="auto"){ setDet("Otomatik: son dil "+langName(S.last)); }
    if(S.voice){ try{ N().speak(r.tr); }catch(e){} }
  }catch(e){ setSt("Hata: "+((e&&e.message)||e)); }
  T.busy=false; afterTurn();
}
function afterTurn(){
  $("trListen").classList.remove("live");
  if(T.active&&S.cont&&T.mode==="other"){
    clearTimeout(T.relistenT);
    (function waitRe(){ T.relistenT=setTimeout(function(){ if(!T.active||!S.cont) return; if(JV.isSpeaking()||T.busy){ waitRe(); return; } listen("other"); },700); })();
  }
}

/* ---------- Sen konuşunca (Türkçe -> İngilizce) ---------- */
async function toEnglish(text){
  text=String(text||"").trim(); if(!text) return;
  $("trEn").innerHTML='<div class="trC"><div class="o">Çeviriliyor…</div></div>';
  try{
    var raw=await JV.withTimeout(JV.aiText("Translate the following Turkish text into natural, clear, polite English. Output ONLY the English translation, nothing else.\\n\\n"+text,false),20000,"çeviri zaman aşımı");
    var en=String(raw||"").replace(/^["'\s]+|["'\s]+$/g,"");
    $("trEn").innerHTML='<div class="trC"><div class="o">'+esc(text)+'</div><div class="e">'+esc(en)+'</div></div><button class="btn" id="trAgain" style="width:100%">🔁 TEKRAR OKU</button>';
    $("trAgain").onclick=function(){ try{ N().speakIn(en,"en-US"); }catch(e){} };
    try{ N().speakIn(en,"en-US"); }catch(e){}
  }catch(e){ $("trEn").innerHTML='<div class="trC"><div class="o">Hata: '+esc((e&&e.message)||e)+'</div></div>'; }
}

/* ---------- Olay bağlantıları ---------- */
$("trListen").onclick=function(){ if(T.listening){ stopListen(); setSt("Durdu."); } else listen("other"); };
$("trVoice").onclick=function(){ S.voice=!S.voice; save(); renderVoice(); if(!S.voice){ try{ N().stopSpeak(); }catch(e){} } };
$("trCont").onchange=function(){ S.cont=this.checked; save(); };
$("trGo").onclick=function(){ toEnglish($("trIn").value); };
$("trIn").onkeydown=function(e){ if(e.key==="Enter"){ e.preventDefault(); toEnglish($("trIn").value); } };
$("trMic").onclick=function(){ stopListen(); listen("me"); };
pg.addEventListener("click",function(e){ if(e.target.closest&&e.target.closest("[data-close]")) closeMode(); });

var prevS=window.JV_onSpeech, prevE=window.JV_onListenEnd, prevL=window.onSpeechLang;
window.onSpeechLang=function(l){ T.nativeLang=String(l||""); if(prevL) prevL(l); };
window.JV_onSpeech=function(t,final){
  if(T.active&&T.listening){
    if(!final){ if(T.mode==="me") $("trIn").value=t; else setSt("… "+t); return true; }
    T.listening=false;
    if(T.mode==="me"){ $("trIn").value=t; toEnglish(t); afterTurnMe(); return true; }
    handleOther(t); return true;
  }
  return prevS?prevS(t,final):false;
};
function afterTurnMe(){ $("trListen").classList.remove("live"); }
window.JV_onListenEnd=function(err){
  if(T.active&&T.listening){
    T.listening=false; $("trListen").classList.remove("live");
    if(err===9){ setSt("Mikrofon izni gerekli."); return true; }
    if(err===100){ setSt("Bu telefonda ses tanıma yok."); return true; }
    setSt(err===7||err===6?"Bir şey duyamadım.":"Dinleme bitti ("+err+").");
    afterTurn(); return true;
  }
  return prevE?prevE(err):false;
};

/* ---------- Aç / kapat ---------- */
function openMode(){
  T.active=true; renderLangs(); renderVoice(); setSt("");
  setDet(S.lang==="auto"?"Otomatik: dil algılanır (son: "+langName(S.last)+")":"Dil: "+langName(S.lang));
  document.getElementById("pTr2").classList.add("show");
}
function closeMode(){ T.active=false; stopListen(); try{ N().stopSpeak(); }catch(e){} }
(function(){
  var chips=$("chips"); if(!chips||!chips.appendChild) return;
  var b=document.createElement("button"); b.id="cTr2"; b.textContent="🌐 TERCÜMAN"; b.onclick=openMode; chips.appendChild(b);
})();
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/tercüman/.test(t)&&t.split(/\s+/).length<=5){
    if(/(kapat|durdur|bitir|çık)/.test(t)){ closeMode(); document.getElementById("pTr2").classList.remove("show"); return "Tercüman modu kapatıldı."; }
    openMode(); return "Tercüman modu açık. Karşıdakini dinlemek için 'KARŞIYI DİNLE'ye bas, kendi cümleni yazarsan İngilizcesini okurum.";
  }
  return prevOff?prevOff(text):null;
};
window.JV_translator={open:openMode,_S:S,_T:T,_handle:handleOther,_toEn:toEnglish};
})();
