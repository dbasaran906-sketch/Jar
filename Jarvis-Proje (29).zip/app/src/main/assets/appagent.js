/* JARVİS UYGULAMA AJANI — çok adımlı: ekranı oku -> yapay zeka sıradaki adımı seçer -> uygula -> tekrar.
   Riskli adımlarda (ödeme, satın alma, silme, gönderme...) Jarvis öne gelir ve sorar. */
(function(){
var JV=window.JV; if(!JV) return;
function sleep(ms){ return new Promise(function(r){ setTimeout(r,ms); }); }
function tool(n,a){ return JV.nat("tool",n,JSON.stringify(a||{})).then(String,function(e){ return "Hata: "+((e&&e.message)||e); }); }
var RISK=/(öde|ödeme|satın|sipariş|onayla|siparişi ver|satın al|sil\b|kaldır|gönder|paylaş|transfer|havale|şifre|iptal et|abone|kaydı sil|çıkış yap|hesabı|format|sıfırla|buy|pay|purchase|delete|remove|send|confirm|order|checkout)/i;
var A={running:false,stop:false,log:[],app:""};
var MAX=15;

function parseAct(raw){
  var j=JV.parseJSON(raw); if(j&&j.action) return j;
  return null;
}
async function decide(goal,screen,hist){
  var p="Sen bir Android telefonu kullanan ajansın. Hedef: "+goal+"\n\nŞu ana kadar yapılanlar:\n"+(hist.length?hist.map(function(h,i){ return (i+1)+". "+h; }).join("\n"):"(henüz yok)")+
   "\n\nŞU ANKİ EKRAN (köşeli parantez = düğme/alan):\n"+String(screen).slice(0,3500)+
   "\n\nSıradaki TEK adımı seç. Sadece JSON döndür:\n{\"thought\":\"kısa gerekçe\",\"action\":\"open_app|click|type|scroll_down|scroll_up|back|home|wait|done|fail\",\"arg\":\"uygulama adı / tıklanacak yazı / yazılacak metin\",\"risky\":true veya false,\"say\":\"done veya fail ise kullanıcıya Türkçe kısa sonuç\"}\n"+
   "Kurallar: Ekranda görmediğin bir yazıya tıklama. Aynı adımı üst üste tekrarlama; takıldıysan scroll veya back dene. Para harcatan, mesaj/e-posta gönderen, bir şeyi silen, hesap/şifre değiştiren, sipariş/ödeme onaylayan adımlarda risky=true yap. Hedef tamamlandıysa action=done. Yapılamıyorsa action=fail.";
  var raw=await JV.withTimeout(JV.aiText(p,true),30000,"ajan yanıt vermedi");
  return parseAct(raw);
}
async function toFront(){ try{ await tool("open_app",{name:"JARVİS"}); }catch(e){} await sleep(1200); }
async function askUser(q){
  await toFront();
  try{ JV.say(q); }catch(e){}
  var ok=false; try{ ok=confirm(q); }catch(e){}
  if(A.app){ try{ await tool("open_app",{name:A.app}); }catch(e){} await sleep(1500); }
  return ok;
}
async function run(goal){
  if(A.running) return "Ajan zaten çalışıyor.";
  goal=String(goal||"").trim(); if(!goal) return "Hedef boş.";
  A.running=true; A.stop=false; A.log=[]; A.app="";
  var hist=[], last="", same=0, result="";
  try{
    var test=await tool("screen_read");
    if(/erişilebilirlik|izin|accessib/i.test(String(test).slice(0,200))&&/ver|aç|etkin|kapalı|gerek/i.test(String(test).slice(0,200))&&String(test).length<300) return String(test);
    for(var i=0;i<MAX&&!A.stop;i++){
      var screen=await tool("screen_read");
      var d=await decide(goal,screen,hist);
      if(!d){ hist.push("(yanıt anlaşılamadı)"); await sleep(500); continue; }
      var act=String(d.action||"").trim(), arg=String(d.arg||"").trim();
      A.log.push(act+(arg?": "+arg:""));
      if(act==="done"){ result=d.say||"Tamamlandı."; break; }
      if(act==="fail"){ result="Yapamadım: "+(d.say||d.thought||"takıldım"); break; }
      var key=act+"|"+arg; if(key===last){ same++; } else { same=0; last=key; }
      if(same>=2){ hist.push("DİKKAT: aynı adım tekrarlandı, farklı bir şey dene"); if(same>=4){ result="Aynı adımda takıldım ("+act+" "+arg+")."; break; } }
      var risky=d.risky===true||((act==="click"||act==="type")&&RISK.test(arg));
      if(risky){
        var okk=await askUser("Efendim, "+(d.thought||"bir adım")+" — '"+(arg||act)+"' adımını yapayım mı?");
        if(!okk){ result="Riskli adımda onay vermedin, durdum."; break; }
      }
      var r="";
      if(act==="open_app"){ r=await tool("open_app",{name:arg}); A.app=arg; await sleep(2200); }
      else if(act==="click"){ r=await tool("screen_click",{text:arg}); await sleep(1300); }
      else if(act==="type"){ r=await tool("screen_type",{text:arg}); await sleep(900); }
      else if(act==="scroll_down"||act==="scroll_up"||act==="back"||act==="home"){ r=await tool("screen_action",{action:act}); await sleep(900); }
      else if(act==="wait"){ await sleep(2000); r="bekledim"; }
      else { r="bilinmeyen eylem"; }
      hist.push(act+(arg?" '"+arg+"'":"")+" → "+String(r).slice(0,80));
      if(hist.length>8) hist.shift();
    }
    if(!result) result=A.stop?"Ajan durduruldu.":"Adım sınırına ("+MAX+") ulaştım, hedef tamamlanmamış olabilir.";
  }catch(e){ result="Ajan hatası: "+String((e&&e.message)||e); }
  A.running=false;
  await toFront();
  return result;
}
window.JSTOOLS=window.JSTOOLS||{};
window.JSTOOLS.app_agent=function(a){ return run(a&&a.goal); };
window.EXTRA_TOOLS=(window.EXTRA_TOOLS||[]).concat([
 {name:"app_agent",description:"Çok adımlı telefon ajanı: bir uygulamada birden fazla adımlı işi (örn. 'Spotify'da X çal', 'Ayarlar'dan Y'yi aç', 'Trendyol'da Z ara') ekranı okuyarak kendi başına yapar. Tek adımlık işlerde open_app/screen_* yeterli; çok adım gerektiğinde bunu kullan. Riskli adımlarda kullanıcıya sorar.",input_schema:{type:"object",properties:{goal:{type:"string",description:"Yapılacak işin tam tarifi"}},required:["goal"]}}
]);
window.JV_appAgent={run:run,stop:function(){ A.stop=true; },_A:A};
})();
