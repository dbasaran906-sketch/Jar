/* JARVİS HOLOGRAM MODU: ön kamera gizli çalışır, ekranda sadece mavi neon imleç görünür.
   İşaret parmağı = imleç, parmağı sabit tut = tıklama, düz el = komut jestleri.
   Donmaması için: 80x60 küçük görüntü, saniyede ~15 kare, kare başına ölçüm, yavaşlarsa otomatik kısma/kapanma. */
(function(){
var JV=window.JV; if(!JV) return;
var DUMMY=document.createElement("div");
var $=function(id){ return document.getElementById(id)||DUMMY; };
var toast=JV.toast, esc=JV.esc;
function lsGet(k,d){ try{ var v=localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return d; } }
function lsSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
function tl(t){ return String(t).toLocaleLowerCase("tr").trim(); }

var W=80, HH=60;
var S=lsGet("jv_holo",{sens:1,dwell:900,click:true,cal:null});
var DEF={crMin:134,crMax:174,cbMin:78,cbMax:126};
var H={on:false,stream:null,v:null,cv:null,cx:null,timer:0,period:66,avg:5,slow:0,err:0,
  prevG:null,labels:null,stack:null,cur:null,curX:0,curY:0,hasCur:false,lost:0,
  hist:[],paused:false,palmSince:0,gestAt:0,pauseAt:0,dwellStart:0,dwellX:0,dwellY:0,dwellDone:false,
  lastClickAt:0,lastSeen:0,calib:false,calS:null};

var st=document.createElement("style");
st.textContent=
"#holoCur{position:fixed;left:0;top:0;width:44px;height:44px;margin:-22px 0 0 -22px;z-index:2147483000;pointer-events:none;display:none;will-change:transform}"+
"#holoCur .c1{position:absolute;inset:6px;border-radius:50%;border:2px solid #4fd1ff;box-shadow:0 0 14px #4fd1ff,inset 0 0 8px rgba(79,209,255,.6);background:radial-gradient(circle,rgba(127,220,255,.55) 0,rgba(79,209,255,.08) 70%)}"+
"#holoCur .c2{position:absolute;inset:0;border-radius:50%;border:1px dashed rgba(79,209,255,.6);animation:hoSpin 4s linear infinite}"+
"#holoCur svg{position:absolute;inset:0;width:44px;height:44px;transform:rotate(-90deg)}"+
"#holoCur svg circle{fill:none;stroke:#ff8a1f;stroke-width:3;stroke-linecap:round;stroke-dasharray:119.4;stroke-dashoffset:119.4;filter:drop-shadow(0 0 4px #ff8a1f)}"+
"#holoCur.pause .c1{border-color:#ff8a1f;box-shadow:0 0 14px #ff8a1f}"+
"@keyframes hoSpin{to{transform:rotate(360deg)}}"+
".hoRip{position:fixed;z-index:2147483000;pointer-events:none;width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;border:2px solid #4fd1ff;animation:hoRip .5s ease-out forwards}"+
"@keyframes hoRip{to{transform:scale(3.2);opacity:0}}"+
"#holoUI{position:fixed;left:50%;top:calc(env(safe-area-inset-top) + 6px);transform:translateX(-50%);z-index:2147483001;display:none;align-items:center;gap:8px;padding:5px 12px;border-radius:16px;border:1px solid #4fd1ff;background:rgba(2,12,22,.8);color:#4fd1ff;font-size:11px;letter-spacing:2px;box-shadow:0 0 12px rgba(79,209,255,.4)}"+
"#holoUI b{color:#ff8a1f;font-weight:600}"+
"#holoCal{position:fixed;inset:0;z-index:2147483002;display:none;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 50%,#06223a 0,#02070d 75%);color:#cfefff;text-align:center;padding:24px}"+
"#holoCal .ring{width:150px;height:150px;border-radius:50%;border:3px solid #4fd1ff;box-shadow:0 0 24px #4fd1ff,inset 0 0 24px rgba(79,209,255,.4);animation:hoPulse 1.4s ease-in-out infinite;margin-bottom:26px}"+
"#holoCal .t{letter-spacing:3px;color:#4fd1ff;font-size:14px;text-shadow:0 0 10px #4fd1ff;margin-bottom:8px}"+
"#holoCal .s{font-size:13px;color:#8fb6cc;max-width:280px}"+
"@keyframes hoPulse{0%,100%{transform:scale(.95);opacity:.7}50%{transform:scale(1.05);opacity:1}}";
document.head.appendChild(st);

/* ---------- Arayüz öğeleri ---------- */
var cur=document.createElement("div"); cur.id="holoCur"; cur.innerHTML='<div class="c2"></div><div class="c1"></div><svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="19" id="holoPr"/></svg>'; document.body.appendChild(cur);
var ui=document.createElement("div"); ui.id="holoUI"; ui.innerHTML='<span>HOLOGRAM</span><b id="holoSt">HAZIR</b><span id="holoX" style="padding:0 4px;border-left:1px solid rgba(79,209,255,.4);cursor:pointer">✕</span>'; document.body.appendChild(ui);
var cal=document.createElement("div"); cal.id="holoCal"; cal.innerHTML='<div class="ring"></div><div class="t">KALİBRASYON</div><div class="s" id="holoCalS">Düz elini çemberin hizasında kameraya tut. Kamera görüntüsü ekranda gösterilmez.</div>'; document.body.appendChild(cal);
$("holoX").onclick=function(){ stop("Hologram modu kapatıldı"); };
function setSt(t){ var e=$("holoSt"); if(e&&e.textContent!==t) e.textContent=t; }

/* ---------- Yardımcılar ---------- */
function ripple(x,y){ var r=document.createElement("div"); r.className="hoRip"; r.style.left=x+"px"; r.style.top=y+"px"; document.body.appendChild(r); setTimeout(function(){ if(r.parentNode) r.parentNode.removeChild(r); },520); }
function clickAt(x,y){
  var el=document.elementFromPoint(x,y); if(!el||el.closest("#holoUI")||el.id==="holoCur") return;
  var tg=el.closest("button,a,input,select,textarea,label,[onclick],[data-go],.pl,.chip,.m")||el;
  ripple(x,y);
  try{ if(tg.focus&&/^(input|textarea|select)$/i.test(tg.tagName)) tg.focus(); }catch(e){}
  try{ tg.dispatchEvent(new MouseEvent("pointerdown",{bubbles:true,clientX:x,clientY:y})); tg.dispatchEvent(new MouseEvent("pointerup",{bubbles:true,clientX:x,clientY:y})); }catch(e){}
  try{ if(tg.click) tg.click(); else tg.dispatchEvent(new MouseEvent("click",{bubbles:true,clientX:x,clientY:y})); }catch(e){}
}
function scrollAt(x,y,dy){
  var el=document.elementFromPoint(x,y);
  while(el&&el!==document.body){ var cs=getComputedStyle(el); if(/(auto|scroll)/.test(cs.overflowY)&&el.scrollHeight>el.clientHeight+4){ el.scrollBy({top:dy,behavior:"smooth"}); return; } el=el.parentElement; }
  var p=document.querySelector(".page.show .pb")||$("chat")||document.scrollingElement; if(p) p.scrollBy({top:dy,behavior:"smooth"});
}

/* ---------- Kamera ve işleme ---------- */
function thr(){ var c=S.cal||DEF; return c; }
function process(){
  var v=H.v; if(!v||v.readyState<2||!v.videoWidth) return;
  var cx=H.cx; cx.drawImage(v,0,0,W,HH);
  var d=cx.getImageData(0,0,W,HH).data, n=W*HH;
  var mask=H.mask, g=H.g, prev=H.prevG, mot=H.mot;
  var c=thr();
  for(var i=0,p=0;i<n;i++,p+=4){
    var r=d[p],gg=d[p+1],b=d[p+2];
    var y=0.299*r+0.587*gg+0.114*b;
    var cr=128+0.5*r-0.4187*gg-0.0813*b, cb=128-0.1687*r-0.3313*gg+0.5*b;
    mask[i]=(y>45&&y<245&&cr>=c.crMin&&cr<=c.crMax&&cb>=c.cbMin&&cb<=c.cbMax)?1:0;
    g[i]=y; mot[i]=prev?(Math.abs(y-prev[i])>16?1:0):0;
  }
  H.prevG=H.prevG||new Float32Array(n); H.prevG.set(g);
  if(H.calib){ calSample(d); return; }
  /* bağlı bileşenler */
  var lab=H.labels, stack=H.stack; lab.fill(0);
  var blobs=[], id=0;
  for(var s=0;s<n;s++){
    if(!mask[s]||lab[s]) continue;
    if(id>=7) break;
    id++; var sp=0; stack[sp++]=s; lab[s]=id;
    var B={area:0,minx:W,maxx:0,miny:HH,maxy:0,sx:0,sy:0,m:0,tx:0,tn:0,ty:HH};
    var pts=[];
    while(sp>0){
      var q=stack[--sp], qx=q%W, qy=(q-qx)/W;
      B.area++; B.sx+=qx; B.sy+=qy; if(mot[q]) B.m++;
      if(qx<B.minx)B.minx=qx; if(qx>B.maxx)B.maxx=qx; if(qy<B.miny)B.miny=qy; if(qy>B.maxy)B.maxy=qy;
      if(qx>0){ var l=q-1; if(mask[l]&&!lab[l]){ lab[l]=id; stack[sp++]=l; } }
      if(qx<W-1){ var rr=q+1; if(mask[rr]&&!lab[rr]){ lab[rr]=id; stack[sp++]=rr; } }
      if(qy>0){ var u=q-W; if(mask[u]&&!lab[u]){ lab[u]=id; stack[sp++]=u; } }
      if(qy<HH-1){ var dn=q+W; if(mask[dn]&&!lab[dn]){ lab[dn]=id; stack[sp++]=dn; } }
    }
    if(B.area>=40) blobs.push(B);
  }
  var now=performance.now(), pick=null;
  if(blobs.length){
    if(H.cur){
      var bd=1e9; blobs.forEach(function(B){ var dx=B.sx/B.area-H.cur.cx, dy=B.sy/B.area-H.cur.cy, dd=dx*dx+dy*dy; if(dd<bd&&dd<(W*0.4)*(W*0.4)){ bd=dd; pick=B; } });
    }
    if(!pick){
      var bm=0; blobs.forEach(function(B){ if(B.m>bm&&B.m>=Math.max(5,B.area*0.06)){ bm=B.m; pick=B; } });
    }
  }
  if(!pick){
    H.lost++; if(H.lost>12){ H.cur=null; cur.style.display="none"; H.hasCur=false; H.hist.length=0; H.dwellStart=0; setSt(H.paused?"DURAKLATILDI":"EL ARANIYOR"); }
    if(now-H.lastSeen>300000){ stop("Hologram modu 5 dk el görmediği için kapandı"); }
    return;
  }
  H.lost=0; H.lastSeen=now;
  var bw=pick.maxx-pick.minx+1, bh=pick.maxy-pick.miny+1;
  var fill=pick.area/(bw*bh), palm=(fill>0.6&&bw>W*0.26&&bh>HH*0.3);
  var ccx=pick.sx/pick.area, ccy=pick.sy/pick.area;
  H.cur={cx:ccx,cy:ccy};
  /* parmak ucu: en üstteki satırların ortalaması */
  var tx=0,tn=0; for(var yy=pick.miny;yy<=Math.min(pick.maxy,pick.miny+2);yy++){ for(var xx=pick.minx;xx<=pick.maxx;xx++){ var k=yy*W+xx; if(lab[k]&&mask[k]){ tx+=xx; tn++; } } }
  var tipx=tn?tx/tn:ccx, tipy=pick.miny+1;
  /* geçmiş (jest için) */
  H.hist.push({t:now,x:ccx,y:ccy}); while(H.hist.length&&now-H.hist[0].t>600) H.hist.shift();
  if(palm){
    if(!H.palmSince) H.palmSince=now;
    var h0=H.hist[0], dx=ccx-h0.x, dy=ccy-h0.y, dt=now-h0.t;
    if(now-H.gestAt>1000&&dt>150){
      if(Math.abs(dx)>W*0.28&&Math.abs(dx)>Math.abs(dy)*1.4){ H.gestAt=now; gesture(dx>0?"right":"left"); }
      else if(Math.abs(dy)>HH*0.32&&Math.abs(dy)>Math.abs(dx)*1.4){ H.gestAt=now; gesture(dy>0?"down":"up"); }
    }
    var still=Math.abs(dx)<W*0.05&&Math.abs(dy)<HH*0.07;
    if(still&&now-H.palmSince>1100&&now-H.pauseAt>1800){ H.pauseAt=now; H.palmSince=now; H.paused=!H.paused; cur.classList.toggle("pause",H.paused); setSt(H.paused?"DURAKLATILDI":"İMLEÇ"); toast(H.paused?"Hologram duraklatıldı":"Hologram devam ediyor",1200); }
    if(!still) H.palmSince=now;
    H.dwellStart=0; $("holoPr").style.strokeDashoffset="119.4";
    return;
  }
  H.palmSince=0;
  if(H.paused) return;
  /* imleç */
  var m=0.5/S.sens; // kullanılan kamera alanı (sens büyükse daha küçük hareket yeter)
  var nx=((tipx/W)-(0.5-m))/(2*m), ny=((tipy/HH)-(0.5-m*0.8))/(2*m*0.9);
  nx=Math.max(0,Math.min(1,nx)); ny=Math.max(0,Math.min(1,ny));
  var X=nx*innerWidth, Y=ny*innerHeight;
  if(!H.hasCur){ H.curX=X; H.curY=Y; H.hasCur=true; cur.style.display="block"; }
  else{ var a=0.38, ddx=X-H.curX, ddy=Y-H.curY; if(Math.abs(ddx)+Math.abs(ddy)>3){ H.curX+=ddx*a; H.curY+=ddy*a; } }
  cur.style.transform="translate3d("+H.curX.toFixed(1)+"px,"+H.curY.toFixed(1)+"px,0)";
  setSt("İMLEÇ");
  /* bekleyerek tıkla */
  if(S.click){
    var mv=Math.hypot(H.curX-H.dwellX,H.curY-H.dwellY);
    if(!H.dwellStart||mv>26){ H.dwellStart=now; H.dwellX=H.curX; H.dwellY=H.curY; H.dwellDone=H.dwellDone&&mv<=60; $("holoPr").style.strokeDashoffset="119.4"; }
    else if(!H.dwellDone){
      var pr=Math.min(1,(now-H.dwellStart)/S.dwell);
      $("holoPr").style.strokeDashoffset=(119.4*(1-pr)).toFixed(1);
      if(pr>=1&&now-H.lastClickAt>600){ H.dwellDone=true; H.lastClickAt=now; clickAt(H.curX,H.curY); $("holoPr").style.strokeDashoffset="119.4"; }
    }
  }
}
function gesture(k){
  if(k==="left"){ var r=false; try{ r=window.onBack&&window.onBack(); }catch(e){} toast(r?"Geri":"Sola salla: kapatılacak bir şey yok",1000); }
  else if(k==="right"){ try{ if(!JV.isBusy()&&!JV.isListening()){ toast("Dinliyorum",1000); JV.startListen(); } }catch(e){} }
  else if(k==="up"){ scrollAt(H.curX||innerWidth/2,H.curY||innerHeight/2,-320); }
  else if(k==="down"){ scrollAt(H.curX||innerWidth/2,H.curY||innerHeight/2,320); }
}

/* ---------- Kalibrasyon: ortadaki bölgeden cilt rengini öğren ---------- */
function calSample(d){
  var a=H.calS; if(!a) return;
  var x0=Math.floor(W*0.4),x1=Math.floor(W*0.6),y0=Math.floor(HH*0.38),y1=Math.floor(HH*0.62);
  for(var y=y0;y<y1;y++) for(var x=x0;x<x1;x++){
    var p=(y*W+x)*4, r=d[p],g=d[p+1],b=d[p+2];
    a.cr.push(128+0.5*r-0.4187*g-0.0813*b); a.cb.push(128-0.1687*r-0.3313*g+0.5*b);
  }
  a.n++;
}
function stats(arr){ var m=0,i; for(i=0;i<arr.length;i++) m+=arr[i]; m/=arr.length; var v=0; for(i=0;i<arr.length;i++) v+=(arr[i]-m)*(arr[i]-m); return {m:m,sd:Math.sqrt(v/arr.length)}; }
function calibrate(){
  return new Promise(function(res){
    H.calib=true; H.calS={cr:[],cb:[],n:0}; cal.style.display="flex"; $("holoCalS").textContent="Düz elini çemberin hizasında kameraya tut. Kamera görüntüsü ekranda gösterilmez.";
    var t0=Date.now(), iv=setInterval(function(){
      var left=Math.ceil((2800-(Date.now()-t0))/1000); if(left>0) $("holoCalS").textContent="Elini sabit tut… "+left;
      if(Date.now()-t0>2800||!H.on){
        clearInterval(iv); var a=H.calS; H.calib=false; H.calS=null; cal.style.display="none";
        if(!H.on){ res(false); return; }
        if(!a||a.n<8||a.cr.length<50){ toast("Kalibrasyon yapılamadı, varsayılan renk kullanılıyor"); res(false); return; }
        var cs=stats(a.cr), bs=stats(a.cb);
        var mc=Math.max(11,Math.min(22,cs.sd*2.6)), mb=Math.max(11,Math.min(22,bs.sd*2.6));
        S.cal={crMin:cs.m-mc,crMax:cs.m+mc,cbMin:bs.m-mb,cbMax:bs.m+mb}; lsSet("jv_holo",S);
        // ortadaki bölge cilt değilse (örn. boş duvar) uyar
        if(cs.sd>14||bs.sd>14){ toast("El net görünmedi, tekrar kalibre etmeyi dene",3000); }
        res(true);
      }
    },200);
  });
}

/* ---------- Aç / kapat ---------- */
async function start(){
  if(H.on) return "Hologram modu zaten açık.";
  if(document.getElementById("pHud")&&document.getElementById("pHud").classList.contains("show")) return "Önce HUD kamerayı kapat, kamera meşgul.";
  try{ await JV.natX("requestPerms","android.permission.CAMERA"); }catch(e){ return "Kamera izni gerekli, Ayarlar > İzin merkezinden ver."; }
  var stream=null;
  try{
    stream=await Promise.race([
      navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:160},height:{ideal:120},frameRate:{ideal:15,max:20}},audio:false}),
      new Promise(function(_,rej){ setTimeout(function(){ rej(new Error("kamera yanıt vermedi")); },7000); })
    ]);
  }catch(e){ return "Ön kamera açılamadı: "+((e&&e.message)||e); }
  var v=document.createElement("video"); v.setAttribute("playsinline",""); v.muted=true; v.autoplay=true;
  v.style.cssText="position:fixed;right:0;bottom:0;width:2px;height:2px;opacity:.01;pointer-events:none;z-index:-1";
  document.body.appendChild(v); v.srcObject=stream; try{ await v.play(); }catch(e){}
  var cv=document.createElement("canvas"); cv.width=W; cv.height=HH;
  var cx=cv.getContext("2d",{willReadFrequently:true}); cx.setTransform(-1,0,0,1,W,0);
  H.stream=stream; H.v=v; H.cv=cv; H.cx=cx; H.mask=new Uint8Array(W*HH); H.g=new Float32Array(W*HH); H.mot=new Uint8Array(W*HH);
  H.labels=new Int16Array(W*HH); H.stack=new Int32Array(W*HH); H.prevG=null;
  H.on=true; H.period=66; H.avg=5; H.slow=0; H.err=0; H.cur=null; H.hasCur=false; H.lost=0; H.hist=[]; H.paused=false; H.lastSeen=performance.now();
  ui.style.display="flex"; setSt("HAZIRLANIYOR"); cur.classList.remove("pause");
  setChip(true);
  // video karesi gelene kadar bekle (en fazla 3 sn)
  for(var k=0;k<20&&!(v.videoWidth>0);k++) await new Promise(function(r){ setTimeout(r,150); });
  if(!(v.videoWidth>0)){ stop(); return "Kamera görüntüsü gelmedi (başka uygulama kullanıyor olabilir)."; }
  H.timer=setTimeout(frame,60);
  if(!S.cal){ await calibrate(); }
  setSt("EL ARANIYOR");
  return "Hologram modu açıldı. Tek parmağını kameraya göster: imleç parmağını izler. Parmağını 1 sn sabit tutarsan tıklar. Düz elini sağa salla: dinler, sola: geri, yukarı/aşağı: kaydırır, 1 sn sabit tut: duraklatır. Ekranda sadece imleci göreceksin.";
}
function stop(msg){
  clearTimeout(H.timer); H.timer=0;
  if(H.stream){ try{ H.stream.getTracks().forEach(function(t){ t.stop(); }); }catch(e){} H.stream=null; }
  if(H.v){ try{ H.v.srcObject=null; if(H.v.parentNode) H.v.parentNode.removeChild(H.v); }catch(e){} H.v=null; }
  var was=H.on; H.on=false; H.calib=false; H.cur=null; H.hasCur=false; H.hist=[];
  cur.style.display="none"; ui.style.display="none"; cal.style.display="none";
  setChip(false);
  if(was&&msg) toast(msg,2500);
}
function frame(){
  if(!H.on) return;
  var t0=performance.now();
  try{ process(); H.err=0; }catch(e){ H.err++; if(H.err>=3){ stop("Hologram modu hata verdi, kapatıldı"); return; } }
  var dt=performance.now()-t0;
  H.avg=H.avg*0.9+dt*0.1;
  if(H.avg>12){ H.slow++; if(H.slow>=15){ H.slow=0; if(H.period<140){ H.period+=25; H.avg=8; } else { stop("Telefon bu modu kaldıramadı, donmaması için kapattım"); return; } } }
  else H.slow=Math.max(0,H.slow-1);
  H.timer=setTimeout(frame,Math.max(12,H.period-dt));
}
document.addEventListener("visibilitychange",function(){ if(document.hidden&&H.on) stop("Hologram modu arka planda kapandı"); });
window.addEventListener("pagehide",function(){ if(H.on) stop(); });

/* ---------- Sayfa, çip, komut ---------- */
function mkPage(id,html){ var d=document.createElement("div"); d.className="page"; d.id=id; d.innerHTML=html; document.body.appendChild(d); return d; }
mkPage("pHolo",
 '<div class="ph"><button class="ib" data-close>←</button><h2>HOLOGRAM MODU</h2></div>'+
 '<div class="pb"><div class="sec"><div style="font-size:13px;line-height:1.6;color:var(--dim)">Ön kamera arkada gizli çalışır, ekranda elin görünmez; sadece mavi neon imleç görünür.<br>'+
 '☝️ <b>Tek parmak</b>: imleç parmağını izler<br>⏱ Parmağı <b>sabit tut</b>: tıklar (turuncu halka dolar)<br>🖐 <b>Düz el sağa</b>: Jarvis dinler · <b>sola</b>: geri/kapat · <b>yukarı/aşağı</b>: kaydırır<br>🖐 Düz eli <b>1 sn sabit</b> tut: duraklat / devam<br>'+
 'İpucu: önünde ışık olsun, arkada ten rengine yakın duvar/nesne olmasın, elini yüzünün altında tut.</div></div>'+
 '<div class="sec"><button class="btn" id="hoGo" style="width:100%;margin-bottom:8px">BAŞLAT</button><button class="btn" id="hoCal" style="width:100%">CİLT RENGİNİ KALİBRE ET</button></div>'+
 '<div class="sec"><div class="row" style="display:block">Hassasiyet<select id="hoSens" class="inp"><option value="0.8">Düşük (büyük hareket)</option><option value="1">Orta</option><option value="1.3">Yüksek (küçük hareket yeter)</option></select></div>'+
 '<div class="row" style="display:block">Tıklama<select id="hoClick" class="inp"><option value="1">Parmağı bekleterek tıkla</option><option value="0">Sadece imleç (tıklama yok)</option></select></div>'+
 '<div class="row" style="display:block">Bekleme süresi<select id="hoDw" class="inp"><option value="700">0,7 sn</option><option value="900">0,9 sn</option><option value="1200">1,2 sn</option></select></div></div></div>');
function syncUi(){ $("hoSens").value=String(S.sens); $("hoClick").value=S.click?"1":"0"; $("hoDw").value=String(S.dwell); $("hoGo").textContent=H.on?"DURDUR":"BAŞLAT"; }
function setChip(on){ var b=$("cHolo"); if(b) b.classList.toggle("holoOn",!!on); syncUi(); }
$("hoGo").onclick=async function(){ if(H.on){ stop("Hologram modu kapatıldı"); } else { document.getElementById("pHolo").classList.remove("show"); var r=await start(); toast(r.length>120?"Hologram modu açıldı":r,r.length>120?1500:3500); } syncUi(); };
$("hoCal").onclick=async function(){ document.getElementById("pHolo").classList.remove("show"); if(!H.on){ var r=await start(); if(!H.on){ toast(r,3500); return; } } await calibrate(); setSt("EL ARANIYOR"); toast("Kalibrasyon kaydedildi"); };
["hoSens","hoClick","hoDw"].forEach(function(id){ $(id).onchange=function(){ S.sens=parseFloat($("hoSens").value)||1; S.click=$("hoClick").value==="1"; S.dwell=parseInt($("hoDw").value,10)||900; lsSet("jv_holo",S); }; });
function openHolo(){ syncUi(); document.getElementById("pHolo").classList.add("show"); }
(function(){
  var chips=$("chips"); if(!chips||!chips.appendChild) return;
  var b=document.createElement("button"); b.id="cHolo"; b.textContent="◈ HOLOGRAM";
  b.onclick=async function(){ if(H.on){ stop("Hologram modu kapatıldı"); return; } openHolo(); };
  chips.appendChild(b);
  var s2=document.createElement("style"); s2.textContent="#chips button.holoOn{border-color:#ff8a1f;box-shadow:0 0 12px #ff8a1f}"; document.head.appendChild(s2);
})();
/* Sohbet komutları */
var prevOff=window.OFFLINE;
window.OFFLINE=async function(text){
  var t=tl(text).replace(/[.!?,]+$/g,"");
  if(/hologram/.test(t)){
    if(/(kapat|durdur|bitir|iptal|kapa)/.test(t)){ if(!H.on) return "Hologram modu zaten kapalı."; stop(); return "Hologram modu kapatıldı."; }
    if(/(kalibre)/.test(t)){ if(!H.on){ var rr=await start(); if(!H.on) return rr; } await calibrate(); return "Kalibrasyon tamam."; }
    if(/(aç|başlat|aktif|çalıştır|devreye|etkinleştir)/.test(t)||t.split(/\s+/).length<=3) return await start();
  }
  return prevOff?prevOff(text):null;
};
window.JV_holo={open:openHolo,start:start,stop:stop,isOn:function(){ return H.on; },_state:H,_process:process};
})();
