# JARVİS

Kişisel yapay zeka asistanı (Android). Beyin: Claude API.

## Kurulum (3 adım)
1. GitHub'da **herkese açık (public)** yeni bir depo aç.
2. Bu klasörün İÇİNDEKİ her şeyi (`app`, `.github`, `build.gradle.kts` ...) depoya yükle. Web'de "Add file > Upload files" ile sürükle-bırak yeterli. `.github` klasörünün de yüklendiğinden emin ol.
3. Üstteki **Actions** sekmesinde derleme kendiliğinden başlar (5-8 dk). Bitince **Releases** bölümünde `Jarvis.apk` çıkar. Telefona indirip kur.

İlk açılışta ⚙ Ayarlar'dan Claude API anahtarını gir.

## Güncelleme
Yeni sürümde dosyaları depoya yükle, Actions yeni APK'yı Release'e koyar. Uygulamada Ayarlar > Güncelleme > Kontrol et (ya da Jarvis'e "güncelleme var mı" de).

Not: Güncelleme kontrolü için depo herkese açık olmalı.

## v2 (Ağır güncelleme)
Gemini/Claude seçimi, kamera HUD (nesne, mimik/el, çeviri, yüz), radar, medya arama, şifre kasası, canlı çeviri, cihaz durumu, takvim/arama/SMS araçları.

## v3
Gemini model otomatik seçimi ve yeniden deneme, anahtar sihirbazı, video/ses analizi, ESP32 BLE inceleme/yazma, bildirim okuma, alışkanlık analizi.

## v4
Yoğunluk hatasında otomatik yedek model, doğal Gemini sesi, ekran kontrolü (erişilebilirlik), takvim silme/taşıma.

## v5
Bilgi sorularında önce internet araması, HUD'da sesle soru sorma, HUD kota tasarrufu (görüntü değişince analiz), kota dolunca otomatik başka modele geçiş ve anlaşılır Türkçe hata.

v5.1: Gemini araması çalışmazsa Vikipedi yedeği, arama hatası cevabın altında görünür.

## v6
Küçük ses balonu (dışına dokununca kapanır), İzin merkezi, ekrana bak (screen_look), geçmiş sohbet arama ve genişletilmiş hafıza, çevrimdışı komutlar (fener, ses, saat, pil, alarm, sayaç, uygulama aç, ara, müzik).

## v7
- Güncel bilgi: her soruda Google Haberler (RSS) + Vikipedi birlikte, ~2 dk önbellek; sonuç yoksa "yok" demez.
- "WhatsApp'ı aç" gibi eylemlerde araç çağrısı zorunlu; "açtım" deyip açmazsa otomatik yeniden dener.
- Daha akıllı model: analiz/ön görü sorularında daha fazla düşünme.
- GPS radarı (konum, hız, adres, hava, yakındaki eczane/benzin…, navigasyon), Ağ radarı/cihaz tarayıcı/konum terminali (Hacker modu).
- Televizyon (Arçelik Google TV): bul, bir kez eşleştir, aç/kapat, Netflix/YouTube, "ses 28 yap".
- Yasalar: adlandırılmış komut dizileri (saman yasası), Ayarlar'dan yönetilir, "X yasasını aktif et".
- Otonom mod (arka plan nöbeti: pil/ısı/depolama uyarısı), alışkanlık önerileri, ajan modu (sürekli dinleme), görev & tercih hafızası, ön görü aracı, mod açılınca özellik anlatımı.
- Parlaklık ayarı için "sistem ayarlarını değiştir" izni gerekir (İzin merkezinde düğmesi var).
